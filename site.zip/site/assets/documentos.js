/* BMK · Boletim Mensal Klingele · página do colaborador: documentos da Klingele para a medição do fornecedor.
   Pelo link (sem login) o colaborador anexa os documentos e envia (o fornecedor recebe o link do boletim,
   baixa os documentos e depois envia o boletim pelo mesmo link) ou informa que não houve medição ou não há
   contrato no mês (o envio do mês é desligado e o analista é avisado). */
(function () {
  'use strict';
  const esc = U.esc;
  const EXTS = ['pdf', 'xlsx', 'xls', 'csv', 'jpg', 'jpeg', 'png'];

  function montar(el, token, opts) {
    const api = opts.api;
    const st = { fase: 'carregando', d: null, arquivos: [], nome: '', obs: '', acao: 'enviar', avisar: true, enviando: false, resultado: null, previa: false };
    let seq = 0;

    const topo = () => `<header class="portal-top"><div class="in">${U.marca('Boletim Mensal Klingele · documentos para a medição')}</div></header>`;
    const contatos = () => ((st.d && st.d.contatos_klingele) || []);
    const cartoes = () => `<div class="kl-contatos">${contatos().map((c) => `<div class="kl-contato">
        ${c.nome ? `<b>${esc(c.nome)}</b>` : ''}${c.cargo ? `<span class="small muted">${esc(c.cargo)}</span>` : ''}
        ${c.email ? `<a href="mailto:${esc(c.email)}">${U.ic.mail}<span>${esc(c.email)}</span></a>` : ''}
        ${c.telefone ? `<a href="tel:${esc(String(c.telefone).replace(/[^0-9+]/g, ''))}">${U.ic.tel}<span>${esc(c.telefone)}</span></a>` : ''}
      </div>`).join('')}</div>`;
    const ajuda = () => (contatos().length ? `<div class="stack" style="gap:8px"><p>Dúvidas? Fale com a equipe de contratos:</p>${cartoes()}</div>` : '');
    const limite = () => ((st.d && st.d.limites && st.d.limites.arquivos) || 15);
    const jaAnexados = () => ((st.d && st.d.documentos) || []).length;
    const validos = () => st.arquivos.filter((a) => !a.erro && !a.verificando);
    const mesTxt = () => (st.d && st.d.mes ? `${U.cap(st.d.mes)}/${st.d.ano}` : 'este mês');

    function render() {
      let corpo = '';
      if (st.fase === 'carregando') corpo = '<div class="portal-done"><p class="muted">Abrindo…</p></div>';
      else if (st.fase === 'erro') corpo = telaErro();
      else if (st.fase === 'concluido') corpo = telaConcluido();
      else corpo = telaFormulario();
      const faixa = st.previa ? '<div class="demo-banner"><strong>Prévia da equipe</strong><span>É o que o colaborador vê ao abrir o link. Nada aqui é gravado.</span></div>' : '';
      el.innerHTML = `<div class="portal">${topo()}<main class="portal-main">${faixa}${corpo}</main></div>`;
      if (st.fase === 'form') { renderArquivos(); renderAcao(); }
    }

    function telaErro() {
      const d = st.d || {};
      const forn = d.fornecedor && d.fornecedor.nome ? d.fornecedor.nome : 'este fornecedor';
      const t = {
        invalido: ['Link não encontrado', 'Confira se o endereço foi copiado inteiro do e-mail. Se o problema continuar, peça um novo link à equipe de contratos.'],
        dispensado: ['Envio deste mês já dispensado', `${d.dispensa === 'sem_contrato' ? 'Não há contrato' : 'Não houve medição'} de ${forn} em ${mesTxt()}${d.dispensa_por ? `, informado por ${d.dispensa_por}` : ''}${d.dispensa_em ? ` em ${U.dataHoraBR(d.dispensa_em)}` : ''}. Para desfazer, fale com a equipe de contratos.`],
        respondido: ['O fornecedor já enviou o boletim', `${forn} enviou o boletim de ${mesTxt()}${d.recebido_em ? ` em ${U.dataHoraBR(d.recebido_em)}` : ''}. Este link foi encerrado.`],
        cancelado: ['Solicitação cancelada', 'A equipe de contratos cancelou a solicitação deste mês. Se ainda precisar enviar documentos, peça um novo link.'],
        expirado: ['O link do fornecedor venceu', 'O prazo do link do boletim terminou. Fale com a equipe de contratos para gerar um novo link.'],
        bloqueado: ['Acesso bloqueado temporariamente', 'Houve muitas tentativas com links inválidos a partir desta rede. Aguarde uma hora e abra o link do e-mail novamente.'],
        limite: ['Muitas tentativas em pouco tempo', 'Aguarde alguns minutos e recarregue a página.'],
        falha: ['Não foi possível abrir a página', d.mensagem || 'Verifique sua conexão e recarregue a página.']
      }[d.motivo] || ['Link indisponível', ''];
      return `<section class="portal-done"><h1>${esc(t[0])}</h1><p>${esc(t[1])}</p>${ajuda()}</section>`;
    }

    function telaConcluido() {
      const r = st.resultado || {};
      if (r.acao === 'dispensar') {
        return `<section class="portal-done">
          <div class="mark">${U.ic.ok}</div>
          <h1>${esc(U.DISPENSA_TXT[r.dispensa] || 'Registrado')}</h1>
          <p>Registrado para <b>${esc(st.d.fornecedor.nome)}</b> em <b>${esc(mesTxt())}</b>. O envio do boletim deste mês foi desligado para este fornecedor nesta pasta e o analista foi avisado.</p>
          <p class="muted">O contrato continua ativo: no próximo mês o envio segue normalmente.</p>
          ${opts.simulacao ? '<div class="row"><button class="btn primary" data-a="fechar">Voltar ao app da equipe</button></div>' : ''}
        </section>`;
      }
      const n = r.anexados || 0;
      const txt = r.link_enviado
        ? (r.ja_enviado ? 'O fornecedor já tinha o link do boletim: os documentos já aparecem para ele e ele recebeu um aviso por e-mail.' : 'O fornecedor recebeu por e-mail o link do boletim: ele baixa os documentos e depois envia o boletim pelo mesmo link.')
        : r.ja_enviado ? 'O fornecedor já tinha o link do boletim: os documentos já aparecem para ele.'
          : r.sem_email ? 'O fornecedor está sem e-mail cadastrado: a equipe de contratos foi avisada para enviar o link.'
            : 'A equipe de contratos foi avisada: o link do boletim sai para o fornecedor com os documentos.';
      return `<section class="portal-done">
        <div class="mark">${U.ic.ok}</div>
        <h1>Documentos enviados</h1>
        <p>${n === 1 ? '1 documento anexado' : `${n} documentos anexados`} para a medição de <b>${esc(st.d.fornecedor.nome)}</b> em <b>${esc(mesTxt())}</b>.</p>
        <p>${esc(txt)}</p>
        <p class="muted">Enquanto o fornecedor não enviar o boletim, você pode voltar a este link para incluir mais documentos.</p>
        <div class="row">${opts.simulacao ? '<button class="btn" data-a="fechar">Voltar ao app da equipe</button>' : ''}<button class="btn ${opts.simulacao ? '' : 'primary'}" data-a="mais">${U.ic.mais} Incluir mais documentos</button></div>
      </section>`;
    }

    function telaFormulario() {
      const d = st.d;
      const docs = d.documentos || [];
      const jaEnviado = ['enviado', 'aberto'].includes(d.link_status);
      return `
      <section class="portal-hero">
        <span class="label">Documentos para a medição · ${esc(mesTxt())}</span>
        <h1>${esc(d.fornecedor.nome)}</h1>
        <div class="portal-facts">
          ${d.fornecedor.codigo ? `<span>Código Klingele <b class="num">${esc(d.fornecedor.codigo)}</b></span>` : ''}
          <span>Pasta <b>${esc(d.pasta || 'Avulso')}</b></span>
          ${d.colaborador ? `<span>Responsável <b>${esc(d.colaborador)}</b></span>` : ''}
          <span>Link do fornecedor <b>${jaEnviado ? 'já enviado' : 'aguardando os documentos'}</b></span>
        </div>
        ${d.contratos && d.contratos.length ? `<ul class="small" style="margin:0;padding-left:18px;color:var(--ink-2)">${d.contratos.map((c) => `<li>${esc(c.titulo)} <span class="mono muted">${esc(c.pedido)}</span>${c.tipo_servico ? ` <span class="muted">· ${esc(U.tipoServicoTxt(c.tipo_servico))}</span>` : ''}</li>`).join('')}</ul>` : ''}
        <p class="muted small">Este fornecedor faz a medição com documentos da Klingele. Anexe-os aqui: ele baixa no link do boletim e depois envia o boletim pelo mesmo link. Se não houve serviço neste mês, informe abaixo.</p>
        ${contatos().length ? `<details class="kl-box"><summary>Dúvidas? Contatos da Klingele (${contatos().length})</summary>${cartoes()}</details>` : ''}
      </section>

      ${docs.length ? `<section class="pstep" id="d-sec-ja">
        <div class="pstep-head"><span class="pstep-n" aria-hidden="true">${U.ic.docs}</span><div><h2>Já anexados (${docs.length})</h2>
          <p>${d.docs_por ? `Por ${esc(d.docs_por)}` : 'Pela Klingele'}${d.docs_enviado_em ? ` em ${esc(U.dataHoraBR(d.docs_enviado_em))}` : ''}. O fornecedor já vê estes documentos no link.</p></div></div>
        <div class="pstep-body"><div class="stack" style="gap:8px">${docs.map((x, i) => `<div class="file-row">
            <span class="ext ${esc(U.extensao(x.nome || x.nome_arquivo))}">${esc(U.extensao(x.nome || x.nome_arquivo))}</span>
            <div class="stack" style="gap:2px;min-width:0"><b style="overflow-wrap:anywhere">${esc(x.nome || x.nome_arquivo)}</b><span class="small muted">${x.tamanho ? U.tamanho(x.tamanho) : ''}</span></div>
            <button class="btn sm" type="button" data-a="baixar" data-i="${i}">${U.ic.baixar} Baixar</button></div>`).join('')}</div></div>
      </section>` : ''}

      <section class="pstep" id="d-sec-acao">
        <div class="pstep-head"><span class="pstep-n">1</span><div><h2>O que aconteceu neste mês?</h2><p>Escolha uma opção.</p></div></div>
        <div class="pstep-body"><div class="docs-op" role="radiogroup" aria-label="Situação do mês">
          ${[['enviar', docs.length ? 'Incluir mais documentos' : 'Anexar e enviar os documentos', 'O fornecedor recebe o link do boletim com os documentos para fazer a medição.'],
            ['sem_medicao', U.DISPENSA_TXT.sem_medicao, 'O contrato continua, mas não houve serviço a medir neste mês.'],
            ['sem_contrato', U.DISPENSA_TXT.sem_contrato, 'Não há contrato vigente para este mês (ainda não começou ou está entre períodos).']]
            .map(([v, t, sub]) => `<label class="docs-op-item${st.acao === v ? ' marcado' : ''}"><input type="radio" name="d-acao" value="${v}" ${st.acao === v ? 'checked' : ''}><span><b>${esc(t)}</b><small>${esc(sub)}</small></span></label>`).join('')}
        </div></div>
      </section>

      <section class="pstep" id="d-sec-arquivos">
        <div class="pstep-head"><span class="pstep-n">2</span><div><h2 id="d-t2">Documentos</h2><p id="d-s2">PDF, Excel, CSV, JPG ou PNG · até ${esc((d.limites || {}).mb_por_arquivo || 25)} MB cada · até ${limite()} por mês.</p></div></div>
        <div class="pstep-body" id="d-corpo2"></div>
      </section>

      <section class="pstep" id="d-sec-envio">
        <div class="pstep-head"><span class="pstep-n">3</span><div><h2>Confirmar</h2><p>Seu nome fica registrado com a resposta.</p></div></div>
        <div class="pstep-body">
          <div class="form-grid">
            <label class="field"><span>Seu nome</span><input type="text" id="d-nome" maxlength="120" autocomplete="name" value="${esc(st.nome)}"></label>
            <label class="field full"><span>Observação <span class="hint">(opcional; vai para o analista)</span></span><textarea id="d-obs" rows="3" maxlength="1000" style="min-height:84px">${esc(st.obs)}</textarea></label>
          </div>
          <div id="d-erros"></div>
          <div class="row"><button class="btn primary" type="button" data-a="enviar" id="d-enviar" ${st.previa ? 'disabled title="Desativado na prévia"' : ''}></button>
            <span class="small muted" id="d-status"></span></div>
        </div>
      </section>`;
    }

    function renderAcao() {
      const t2 = el.querySelector('#d-t2'), s2 = el.querySelector('#d-s2'), btn = el.querySelector('#d-enviar'), corpo = el.querySelector('#d-corpo2');
      if (!btn) return;
      const enviar = st.acao === 'enviar';
      el.querySelector('#d-sec-arquivos').hidden = !enviar;
      el.querySelectorAll('.docs-op-item').forEach((l) => l.classList.toggle('marcado', l.querySelector('input').value === st.acao));
      el.querySelector('#d-sec-envio .pstep-n').textContent = enviar ? '3' : '2';
      if (enviar) {
        t2.textContent = 'Documentos';
        s2.textContent = `PDF, Excel, CSV, JPG ou PNG · até ${(st.d.limites || {}).mb_por_arquivo || 25} MB cada · até ${limite()} por mês${jaAnexados() ? ` (${jaAnexados()} já anexados)` : ''}.`;
        if (!corpo.dataset.montado) {
          corpo.dataset.montado = '1';
          corpo.innerHTML = `<label class="drop" id="d-drop" for="d-file">${U.ic.upload}<b>Arraste os arquivos aqui ou clique para escolher</b><span class="small muted">Os arquivos só vão para o fornecedor quando você confirmar.</span></label>
            <input type="file" id="d-file" class="sr-only" multiple accept="${U.ACEITOS}">
            <div class="stack" style="gap:8px;margin-top:10px" id="d-arquivos"></div>
            ${['enviado', 'aberto'].includes(st.d.link_status) ? `<label class="check" style="margin-top:10px"><input type="checkbox" id="d-avisar" ${st.avisar ? 'checked' : ''}> Avisar o fornecedor por e-mail que há documentos novos (o prazo do link continua o mesmo)</label>` : ''}`;
          renderArquivos();
        }
      }
      btn.innerHTML = enviar ? `${U.ic.envio} ${['enviado', 'aberto'].includes(st.d.link_status) ? 'Incluir os documentos no link' : 'Enviar os documentos ao fornecedor'}`
        : `${U.ic.ok} Registrar: ${esc(U.DISPENSA_TXT[st.acao].toLowerCase())}`;
      btn.className = 'btn primary';
    }

    function renderArquivos() {
      const box = el.querySelector('#d-arquivos');
      if (!box) return;
      box.innerHTML = st.arquivos.map((a) => {
        const ext = U.extensao(a.file.name);
        return `<div class="file-row">
          <span class="ext ${esc(ext)}">${esc(ext)}</span>
          <div class="stack" style="gap:2px;min-width:0">
            <b style="overflow-wrap:anywhere">${esc(a.file.name)}</b>
            <span class="small muted">${U.tamanho(a.file.size)}${a.verificando ? ' · conferindo o arquivo…' : ''}${a.erro ? ` · <span style="color:var(--crit)">${esc(a.erro)}</span>` : ''}</span>
          </div>
          <button class="icon-btn" type="button" data-a="rm" data-id="${a.id}" aria-label="Remover arquivo">${U.ic.x}</button>
        </div>`;
      }).join('') + (st.arquivos.length ? `<div class="row"><label class="btn sm" for="d-file">${U.ic.mais} Adicionar outro arquivo</label><span class="small muted">${st.arquivos.length} escolhido${st.arquivos.length > 1 ? 's' : ''}</span></div>` : '');
    }

    function adicionar(lista) {
      Array.from(lista || []).forEach((file) => {
        if (st.arquivos.length + jaAnexados() >= limite()) { U.toast(`Máximo de ${limite()} documentos por mês`, 'erro'); return; }
        const ext = U.extensao(file.name);
        const a = { id: ++seq, file, erro: null, hash: null, verificando: true };
        st.arquivos.push(a);
        if (!EXTS.includes(ext)) { a.erro = 'Tipo não aceito (use PDF, Excel, CSV, JPG ou PNG)'; a.verificando = false; return; }
        if (file.size > 25 * 1048576) { a.erro = 'Maior que 25 MB'; a.verificando = false; return; }
        if (file.size === 0) { a.erro = 'Arquivo vazio'; a.verificando = false; return; }
        (async () => {
          const ok = await U.conferirAssinatura(file).catch(() => false);
          if (!ok) a.erro = `O conteúdo não corresponde a um arquivo .${ext}`;
          else {
            a.hash = await U.sha256(file).catch(() => null);
            if (a.hash && st.arquivos.some((x) => x !== a && x.hash === a.hash)) a.erro = 'Arquivo repetido nesta lista';
          }
          a.verificando = false;
          renderArquivos();
        })();
      });
      renderArquivos();
    }

    function validar() {
      const e = [];
      if (st.acao === 'enviar') {
        if (!validos().length) e.push(['d-sec-arquivos', 'Anexe pelo menos um documento.']);
        if (st.arquivos.some((a) => a.verificando)) e.push(['d-sec-arquivos', 'Aguarde a conferência dos arquivos terminar.']);
        st.arquivos.forEach((a) => { if (a.erro) e.push(['d-sec-arquivos', `Remova o arquivo "${a.file.name}" (${a.erro}).`]); });
      }
      if (st.nome.trim().length < 2) e.push(['d-sec-envio', 'Informe seu nome.']);
      if (st.obs.length > 1000) e.push(['d-sec-envio', 'Observação muito longa (máximo 1.000 caracteres).']);
      return e;
    }
    const erroBox = (titulo, itens) => `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">${esc(titulo)}</strong>
      ${Array.isArray(itens) ? `<ul style="margin:6px 0 0;padding-left:18px">${itens.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : `<p style="margin-top:4px">${esc(itens)}</p>`}</div></div>`;

    async function enviar() {
      if (st.enviando) return;
      if (st.previa) { U.toast('Na prévia o envio fica desativado'); return; }
      const box = el.querySelector('#d-erros');
      const erros = validar();
      if (erros.length) {
        box.innerHTML = erroBox('Antes de confirmar', [...new Set(erros.map((x) => x[1]))]);
        const alvo = el.querySelector('#' + erros[0][0]); if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (st.acao !== 'enviar' && !(await U.confirmar(U.DISPENSA_TXT[st.acao] + '?', `O envio do boletim de ${st.d.fornecedor.nome} em ${mesTxt()} será desligado nesta pasta e o analista será avisado.`, 'Confirmar'))) return;
      box.innerHTML = '';
      st.enviando = true;
      const btn = el.querySelector('#d-enviar'), stt = el.querySelector('#d-status');
      btn.disabled = true;
      try {
        let dados;
        if (st.acao === 'enviar') {
          const arquivos = [];
          const lista = validos();
          for (let i = 0; i < lista.length; i++) {
            const a = lista[i];
            stt.textContent = `Enviando arquivo ${i + 1} de ${lista.length}…`;
            if (!a.caminho) a.caminho = await api.docsEnviarArquivo(st.d.pasta_upload, a.file, i);
            arquivos.push({ caminho: a.caminho, nome: a.file.name, mime: U.mimeArquivo(a.file.name) || a.file.type || null, tamanho: a.file.size, hash_sha256: a.hash || null });
          }
          dados = { acao: 'enviar', nome: st.nome.trim(), observacao: st.obs.trim(), avisar: st.avisar, arquivos };
        } else dados = { acao: 'dispensar', motivo: st.acao, nome: st.nome.trim(), observacao: st.obs.trim() };
        stt.textContent = 'Registrando…';
        const r = await api.docsFinalizar(token, dados);
        if (!r || r.ok === false) {
          st.enviando = false; btn.disabled = false; stt.textContent = '';
          box.innerHTML = erroBox('Não foi possível registrar', (r && r.erro) || 'Tente de novo.');
          return;
        }
        st.resultado = r;
        st.fase = 'concluido';
        st.arquivos = [];
        render();
        (el.closest('.portal-overlay') || document.scrollingElement || document.documentElement).scrollTo(0, 0);
        if (opts.aoConcluir && r.acao === 'dispensar') opts.aoConcluir();
      } catch (err) {
        st.enviando = false; btn.disabled = false; stt.textContent = '';
        box.innerHTML = erroBox('Não foi possível registrar', `${err.message} Tente de novo.`);
      }
    }

    async function baixar(i) {
      const x = ((st.d && st.d.documentos) || [])[i];
      if (!x) return;
      try {
        const url = await api.urlDocPortal(x);
        const a = document.createElement('a');
        a.href = url; a.download = x.nome || x.nome_arquivo || 'documento'; a.rel = 'noopener';
        document.body.appendChild(a); a.click(); a.remove();
      } catch (e) { U.toast(e.message || 'Não foi possível baixar o arquivo.', 'erro'); }
    }

    async function carregar() {
      try {
        let d;
        if (opts.previaId) { st.previa = true; d = await api.docsPrevia(opts.previaId); }
        else {
          if (!token || !/^[0-9a-f]{64}$/.test(token)) { st.d = { ok: false, motivo: 'invalido' }; st.fase = 'erro'; return render(); }
          d = await api.docsAbrir(token);
        }
        st.d = d;
        if (!d.ok) { st.fase = 'erro'; return render(); }
        if (!st.nome && d.colaborador) st.nome = d.colaborador;
        st.acao = 'enviar';
        st.fase = 'form';
        render();
      } catch (e) {
        st.d = { ok: false, motivo: 'falha', mensagem: e.message };
        st.fase = 'erro';
        render();
      }
    }

    el.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-a]');
      if (!b) return;
      const a = b.dataset.a;
      if (a === 'enviar') enviar();
      if (a === 'rm') { st.arquivos = st.arquivos.filter((x) => x.id !== Number(b.dataset.id)); renderArquivos(); }
      if (a === 'baixar') baixar(Number(b.dataset.i));
      if (a === 'mais') { st.resultado = null; st.enviando = false; st.fase = 'carregando'; render(); carregar(); }
      if (a === 'fechar' && opts.aoFechar) opts.aoFechar();
    });
    el.addEventListener('change', (ev) => {
      const t = ev.target;
      if (t.name === 'd-acao') { st.acao = t.value; renderAcao(); }
      if (t.id === 'd-file') { adicionar(t.files); t.value = ''; }
      if (t.id === 'd-avisar') st.avisar = t.checked;
    });
    el.addEventListener('input', (ev) => {
      const t = ev.target;
      if (t.id === 'd-nome') st.nome = t.value;
      if (t.id === 'd-obs') st.obs = t.value;
    });
    el.addEventListener('dragover', (ev) => { const d = ev.target.closest('#d-drop'); if (d) { ev.preventDefault(); d.classList.add('over'); } });
    el.addEventListener('dragleave', (ev) => { const d = ev.target.closest('#d-drop'); if (d) d.classList.remove('over'); });
    el.addEventListener('drop', (ev) => { const d = ev.target.closest('#d-drop'); if (d) { ev.preventDefault(); d.classList.remove('over'); adicionar(ev.dataTransfer.files); } });

    render();
    carregar();
  }

  window.Documentos = { montar };
})();

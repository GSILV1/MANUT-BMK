/* Abre o portal do fornecedor. O link chega como portal.html#CODIGO:
   o trecho depois do # não vai para o servidor nem aparece em logs. */
(async function () {
  var el = document.getElementById('portal');
  var token = (location.hash || '').slice(1) || new URLSearchParams(location.search).get('t') || '';
  // Tira o código da barra de endereço (não fica no histórico do navegador); guarda só nesta aba
  // para o fornecedor poder recarregar a página enquanto preenche.
  try {
    if (token) sessionStorage.setItem('klg-portal', token);
    else token = sessionStorage.getItem('klg-portal') || '';
    history.replaceState(null, '', location.pathname);
  } catch (e) { /* sem armazenamento */ }
  try { await API.init({ portal: true }); }
  catch (e) { el.textContent = 'Não foi possível carregar a página. Verifique sua conexão e recarregue.'; return; }
  Portal.montar(el, token.trim(), {
    api: API,
    aoConcluir: function () { try { sessionStorage.removeItem('klg-portal'); } catch (e) { /* sem armazenamento */ } }
  });
})();

/* BMK · Boletim Mensal Klingele · leitura e conferência da nota fiscal no navegador.
   Mesmas regras do banco (nf_finalizar): a página do fornecedor mostra a conferência antes do envio
   e o banco confere tudo de novo. XML com DOCTYPE/ENTITY é recusado. */
(function () {
  'use strict';
  const NF = {};
  const val = (c) => c.charCodeAt(0) - 48;

  NF.MODELOS = {
    nfe: ['NF-e', 'Nota fiscal eletrônica (modelo 55). Envie o PDF (DANFE) e/ou o XML.'],
    nfse: ['NFS-e', 'Nota fiscal de serviço. Envie o PDF e, se tiver, o XML.'],
    fatura: ['Fatura ou recibo de locação', 'Quando o serviço não tem nota fiscal eletrônica (ex.: locação de bens).']
  };
  NF.LIMITES = { arquivos: 10, mb: 25, xmlKb: 500 };
  NF.ACEITOS = '.pdf,.jpg,.jpeg,.png';

  // Chave de acesso da NF-e: 44 posições, dígito verificador módulo 11 (aceita CNPJ alfanumérico)
  NF.chaveValida = (ch) => {
    if (!/^[0-9]{6}[0-9A-Z]{12}[0-9]{26}$/.test(ch || '')) return false;
    let s = 0, w = 2;
    for (let i = 42; i >= 0; i--) { s += val(ch[i]) * w; w = w === 9 ? 2 : w + 1; }
    let dv = 11 - (s % 11);
    if (dv >= 10) dv = 0;
    return dv === Number(ch[43]);
  };
  NF.formatarChave = (ch) => String(ch || '').replace(/(.{4})/g, '$1 ').trim();

  // ---------- Leitura do XML ----------
  const filhos = (el, nome) => (el ? Array.from(el.children).filter((c) => c.localName === nome) : []);
  const caminho = (el, partes) => partes.reduce((atual, p) => atual.flatMap((e) => filhos(e, p)), el ? [el] : []);
  const todos = (doc, nome) => Array.from(doc.getElementsByTagNameNS('*', nome));
  const t1 = (els) => { const e = els && els[0]; const v = e ? e.textContent.trim() : ''; return v || null; };
  const sobAlgum = (e, nomes) => { for (let p = e.parentElement; p; p = p.parentElement) if (nomes.includes(p.localName)) return true; return false; };
  const corta = (v, n) => (v == null ? v : String(v).slice(0, n));

  NF.lerXml = (texto) => {
    let t = String(texto || '');
    if (!t.trim()) return null;
    if (new Blob([t]).size > NF.LIMITES.xmlKb * 1000) return { ok: false, erro: `XML muito grande (máximo ${NF.LIMITES.xmlKb} KB).` };
    t = t.replace(/^[﻿\s]+/, '');
    if (/<!(DOCTYPE|ENTITY|ELEMENT|ATTLIST|NOTATION)/i.test(t) || /[\x01-\x08\x0B\x0C\x0E-\x1F]/.test(t)) {
      return { ok: false, erro: 'XML com conteúdo não permitido (declarações DOCTYPE/ENTITY ou caracteres de controle).' };
    }
    t = t.replace(/^<\?xml[^>]*\?>/, '');
    let doc;
    try { doc = new DOMParser().parseFromString(t, 'application/xml'); } catch (e) { doc = null; }
    if (!doc || doc.getElementsByTagName('parsererror').length || !doc.documentElement) return { ok: false, erro: 'O XML está incompleto ou corrompido.' };

    const inf = todos(doc, 'infNFe')[0];
    if (inf && inf.getAttribute('Id')) {
      const ide = (n) => t1(caminho(inf, ['ide', n]));
      const prot = todos(doc, 'protNFe')[0];
      const det = todos(doc, 'det')[0];
      return {
        ok: true, tipo: 'nfe', chave: inf.getAttribute('Id').replace(/^NFe/i, '').toUpperCase(),
        modelo: ide('mod'), serie: ide('serie'), numero: ide('nNF'), tpamb: ide('tpAmb'), data: corta(ide('dhEmi') || ide('dEmi'), 10),
        emitente: t1(caminho(inf, ['emit', 'CNPJ'])), emitente_nome: t1(caminho(inf, ['emit', 'xNome'])),
        destinatario: t1(caminho(inf, ['dest', 'CNPJ'])), valor: t1(caminho(inf, ['total', 'ICMSTot', 'vNF'])),
        pedidos: Array.from(inf.getElementsByTagNameNS('*', 'xPed')).map((e) => e.textContent.trim().slice(0, 500)).filter(Boolean),
        complemento: corta(t1(todos(doc, 'infAdic').flatMap((e) => filhos(e, 'infCpl'))) || '', 5000),
        descricao: det ? t1(caminho(det, ['prod', 'xProd'])) : null,
        protocolo_cstat: prot ? t1(caminho(prot, ['infProt', 'cStat'])) : null,
        protocolo_chave: prot ? t1(caminho(prot, ['infProt', 'chNFe'])) : null,
        protocolo_numero: prot ? t1(caminho(prot, ['infProt', 'nProt'])) : null,
        assinada: todos(doc, 'Signature').length > 0
      };
    }
    const nfse = todos(doc, 'infNFSe')[0];
    if (nfse && nfse.getAttribute('Id')) {
      const dps = todos(doc, 'infDPS')[0];
      const prest = todos(doc, 'prest')[0], toma = todos(doc, 'toma')[0], vsp = todos(doc, 'vServPrest')[0];
      return {
        ok: true, tipo: 'nfse', chave: nfse.getAttribute('Id').replace(/^NFS/i, '').toUpperCase(),
        numero: t1(filhos(nfse, 'nNFSe')), tpamb: dps ? t1(filhos(dps, 'tpAmb')) : null,
        data: corta((dps && t1(filhos(dps, 'dhEmi'))) || t1(filhos(nfse, 'dhProc')), 10),
        emitente: t1(caminho(nfse, ['emit', 'CNPJ'])) || (prest ? t1(filhos(prest, 'CNPJ')) : null),
        emitente_nome: t1(caminho(nfse, ['emit', 'xNome'])),
        destinatario: toma ? t1(filhos(toma, 'CNPJ')) : null,
        valor: (vsp && t1(filhos(vsp, 'vServ'))) || t1(caminho(nfse, ['valores', 'vLiq'])),
        valor_liquido: t1(caminho(nfse, ['valores', 'vLiq'])),
        pedidos: todos(doc, 'xPed').map((e) => e.textContent.trim().slice(0, 500)).filter(Boolean),
        complemento: corta([t1(todos(doc, 'xInfComp')), t1(todos(doc, 'xOutInf'))].filter(Boolean).join(' '), 5000),
        descricao: corta(t1(todos(doc, 'xDescServ')), 2000),
        assinada: todos(doc, 'Signature').length > 0
      };
    }
    const abrasf = todos(doc, 'InfNfse')[0];
    const numAbrasf = abrasf ? t1(filhos(abrasf, 'Numero')) : null;
    if (numAbrasf) {
      const cnpjSob = (nomes) => { const e = todos(doc, 'Cnpj').find((x) => sobAlgum(x, nomes) && x.textContent.trim()); return e ? e.textContent.trim() : null; };
      return {
        ok: true, tipo: 'nfse_municipal', numero: numAbrasf,
        codigo_verificacao: t1(filhos(abrasf, 'CodigoVerificacao')),
        data: corta(t1(filhos(abrasf, 'DataEmissao')) || t1(todos(doc, 'DataEmissao')), 10),
        emitente: cnpjSob(['PrestadorServico', 'Prestador']), destinatario: cnpjSob(['TomadorServico', 'Tomador']),
        valor: t1(todos(doc, 'ValorServicos')), valor_liquido: t1(todos(doc, 'ValorLiquidoNfse')),
        pedidos: [], complemento: corta(t1(todos(doc, 'OutrasInformacoes')) || '', 5000), descricao: corta(t1(todos(doc, 'Discriminacao')), 2000)
      };
    }
    return { ok: true, tipo: 'desconhecido' };
  };

  // ---------- Conferência ----------
  // ctx = { modelo, xml (resultado de lerXml ou null), temXml, form:{numero, serie, codigo_verificacao, data_emissao, valor},
  //         competencia, valorAprovado, pedido, cnpjFornecedor, cnpjsKlingele:[], hoje, duplicada(chave, numero, serie, modelo) }
  // Devolve { modelo, itens:[{item, nivel, msg}], erros, alertas, nota:{...} } ou { bloqueio: 'mensagem' }
  const dataOk = (s) => { const m = /(\d{4})-(\d{2})-(\d{2})/.exec(String(s || '')); if (!m) return null; const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3])); return d.getUTCMonth() === +m[2] - 1 ? m[0] : null; };
  const numOk = (s) => { if (s === null || s === undefined || String(s).trim() === '') return null; if (typeof s === 'number') return s; return /^\s*-?\d{1,12}(\.\d{1,6})?\s*$/.test(String(s)) ? Number(s) : null; };
  const brData = (iso) => U.dataBR(iso);
  const compMes = (comp) => comp.slice(5, 7) + '/' + comp.slice(0, 4);

  NF.conferir = (ctx) => {
    const itens = [];
    const add = (item, nivel, msg) => itens.push({ item, nivel, msg });
    let modelo = ctx.modelo;
    if (!NF.MODELOS[modelo]) return { bloqueio: 'Escolha o tipo do documento: NF-e, NFS-e ou fatura/recibo de locação.' };
    const x = ctx.xml;
    if (x && !x.ok) return { bloqueio: x.erro };
    const tx = x ? x.tipo : null;
    if (tx === 'nfe') modelo = 'nfe';
    else if (tx === 'nfse' || tx === 'nfse_municipal') modelo = 'nfse';
    else if (x && modelo === 'nfe') return { bloqueio: 'O XML enviado não é de uma NF-e.' };

    const lido = ['nfe', 'nfse', 'nfse_municipal'].includes(tx);
    const f = ctx.form || {};
    let numero, serie, chave = null, cod, data, valor, emit = null, dest = null, textos = '';
    if (lido) {
      numero = x.numero; serie = x.serie || null; chave = x.chave || null;
      cod = (x.codigo_verificacao || f.codigo_verificacao || '').trim() || null;
      data = dataOk(x.data); valor = numOk(x.valor);
      emit = U.cnpjNorm(x.emitente) || null; dest = U.cnpjNorm(x.destinatario) || null;
      textos = [(x.pedidos || []).join(' '), x.complemento, x.descricao].filter(Boolean).join(' ');
    } else {
      numero = String(f.numero || '').replace(/\s/g, ''); serie = String(f.serie || '').trim() || null;
      cod = String(f.codigo_verificacao || '').trim() || null; data = dataOk(f.data_emissao);
      valor = typeof f.valor === 'number' ? f.valor : numOk(f.valor);
      if (modelo === 'nfe') chave = String(f.chave || '').replace(/[^0-9]/g, '') || null;
    }
    numero = modelo === 'fatura' ? (String(numero || '').replace(/\s/g, '').toUpperCase() || null) : (String(numero || '').replace(/^0+/, '') || null);
    if (serie && /^[0-9]+$/.test(serie)) serie = serie.replace(/^0+/, '') || '0';
    cod = cod ? cod.replace(/\s/g, '') || null : null;

    if (!numero || (modelo !== 'fatura' && !/^[0-9]{1,15}$/.test(numero)) || (modelo === 'fatura' && !/^[A-Z0-9./-]{1,20}$/.test(numero))) add('numero', 'erro', 'Número da nota inválido.');
    else add('numero', 'ok', 'Número da nota: ' + numero + (serie ? ' · série ' + serie : ''));
    if (serie && !/^[0-9]{1,3}$/.test(serie)) add('serie', 'erro', 'Série da nota inválida.');
    if (cod && !/^[A-Za-z0-9./-]{1,60}$/.test(cod)) add('codigo', 'erro', 'Código de verificação inválido (use só letras e números).');

    if (!data) add('data', 'erro', 'Data de emissão inválida.');
    else if (data > ctx.hoje) add('data', 'erro', 'A data de emissão está no futuro.');
    else if (data < ctx.competencia) add('data', 'alerta', `Emitida em ${brData(data)}, antes do mês do serviço (${compMes(ctx.competencia)}).`);
    else add('data', 'ok', 'Emitida em ' + brData(data));

    const aprov = ctx.valorAprovado === null || ctx.valorAprovado === undefined ? null : Number(ctx.valorAprovado);
    if (valor === null || !(valor > 0) || valor > 1e9 || Math.abs(valor * 100 - Math.round(valor * 100)) > 1e-6) add('valor', 'erro', 'Valor da nota inválido.');
    else if (aprov !== null && Math.round(valor * 100) !== Math.round(aprov * 100)) add('valor', 'alerta', `Valor da nota (${U.brl(valor)}) diferente do valor aprovado na medição (${U.brl(aprov)}).`);
    else add('valor', 'ok', 'Valor confere com o aprovado: ' + U.brl(valor));

    if (modelo === 'nfe' && !lido) {
      // NF-e sem XML: a chave (se informada) é conferida; a autorização na SEFAZ fica para a equipe
      const forn0 = U.cnpjNorm(ctx.cnpjFornecedor) || null;
      if (!chave) add('chave', 'alerta', 'NF-e sem XML e sem chave de acesso: confira a nota na SEFAZ.');
      else if (!NF.chaveValida(chave)) add('chave', 'erro', 'Chave de acesso inválida (formato ou dígito verificador não confere).');
      else if (chave.slice(20, 22) !== '55' || (serie && /^[0-9]{1,3}$/.test(serie) && Number(chave.slice(22, 25)) !== Number(serie))
        || (/^[0-9]{1,9}$/.test(numero || '') && Number(chave.slice(25, 34)) !== Number(numero)) || (forn0 && chave.slice(6, 14) !== forn0.slice(0, 8))) {
        add('chave', 'erro', 'A chave de acesso não corresponde ao número, à série ou ao CNPJ do fornecedor.');
      } else {
        add('chave', 'ok', 'Chave de acesso válida: ' + chave);
        add('autorizacao', 'alerta', 'NF-e sem XML: a autorização na SEFAZ não foi conferida automaticamente.');
      }
    } else if (modelo === 'nfe') {
      if (x.modelo !== '55') add('modelo', 'erro', 'Só é aceita NF-e modelo 55 (NFC-e e outros modelos não servem).');
      if (!NF.chaveValida(chave)) add('chave', 'erro', 'Chave de acesso inválida (formato ou dígito verificador não confere).');
      else if (chave.slice(20, 22) !== '55' || (serie && /^[0-9]{1,3}$/.test(serie) && Number(chave.slice(22, 25)) !== Number(serie))
        || (/^[0-9]{1,9}$/.test(numero || '') && Number(chave.slice(25, 34)) !== Number(numero)) || (emit && chave.slice(6, 20) !== emit)) {
        add('chave', 'erro', 'A chave de acesso não corresponde ao modelo, série, número ou emitente do XML.');
      } else add('chave', 'ok', 'Chave de acesso válida: ' + chave);
      if (x.tpamb === '2') add('ambiente', 'erro', 'Nota emitida em homologação (teste), sem valor fiscal.');
      if (!x.protocolo_cstat) add('autorizacao', 'alerta', 'XML sem o protocolo de autorização da SEFAZ (envie o XML completo, de distribuição).');
      else if (!['100', '150'].includes(x.protocolo_cstat)) add('autorizacao', 'erro', `Nota não autorizada pela SEFAZ (situação ${x.protocolo_cstat}).`);
      else if (String(x.protocolo_chave || '').toUpperCase() !== chave) add('autorizacao', 'erro', 'O protocolo de autorização é de outra nota.');
      else add('autorizacao', 'ok', 'Autorizada pela SEFAZ' + (x.protocolo_numero ? ` (protocolo ${x.protocolo_numero})` : ''));
      if (!x.assinada) add('assinatura', 'alerta', 'XML sem assinatura digital.');
    } else if (modelo === 'nfse' && tx === 'nfse') {
      if (!chave || !/^[0-9]{9}[0-9A-Z]{12}[0-9]{29}$/.test(chave)) add('chave', 'alerta', 'Chave de acesso da NFS-e fora do padrão nacional (50 posições).');
      else if ((emit && chave.slice(9, 23) !== emit) || (/^[0-9]{1,13}$/.test(numero || '') && Number(chave.slice(23, 36)) !== Number(numero))) add('chave', 'alerta', 'A chave de acesso da NFS-e não corresponde ao emitente ou ao número.');
      else add('chave', 'ok', 'Chave de acesso da NFS-e: ' + chave);
      if (x.tpamb === '2') add('ambiente', 'erro', 'NFS-e emitida em homologação (teste), sem valor fiscal.');
    } else if (modelo === 'nfse' && tx === 'nfse_municipal') {
      add('origem', 'alerta', 'NFS-e municipal: confira a nota no site da prefeitura com o código de verificação.');
    } else if (modelo === 'nfse') {
      add('origem', 'alerta', !ctx.temXml ? 'NFS-e sem XML: confira a nota no site da prefeitura ou no Emissor Nacional.' : 'XML não reconhecido: confira a nota no site da prefeitura ou no Emissor Nacional.');
      if (!cod) add('codigo', 'alerta', 'Sem código de verificação da NFS-e.');
    } else add('origem', 'alerta', 'Documento sem nota fiscal eletrônica (fatura ou recibo de locação).');

    const forn = U.cnpjNorm(ctx.cnpjFornecedor) || null;
    if (emit) {
      if (!forn) add('emitente', 'alerta', `Fornecedor sem CNPJ cadastrado: confira o emitente ${U.cnpj(emit)}.`);
      else if (emit.slice(0, 8) !== forn.slice(0, 8)) add('emitente', 'erro', `A nota foi emitida por outra empresa (CNPJ ${U.cnpj(emit)}), não pelo fornecedor (CNPJ ${U.cnpj(forn)}).`);
      else if (emit !== forn) add('emitente', 'alerta', `Emitida por outra filial do fornecedor (CNPJ ${U.cnpj(emit)}).`);
      else add('emitente', 'ok', 'Emitente: CNPJ do fornecedor');
    }
    const klg = (ctx.cnpjsKlingele || []).map(U.cnpjNorm).filter(Boolean);
    if (dest) {
      if (!klg.length) add('destinatario', 'alerta', `Destinatário (CNPJ ${U.cnpj(dest)}) não conferido: cadastre os CNPJs da Klingele em Configurações.`);
      else if (klg.includes(dest)) add('destinatario', 'ok', `Emitida para a Klingele (CNPJ ${U.cnpj(dest)})`);
      else add('destinatario', 'alerta', `A nota não foi emitida para um CNPJ da Klingele cadastrado (destinatário ${U.cnpj(dest)}).`);
    } else if (lido) add('destinatario', 'alerta', 'O XML não informa o CNPJ do destinatário.');

    if (ctx.pedido) {
      if (lido) {
        if (new RegExp('(^|[^0-9])' + String(ctx.pedido) + '([^0-9]|$)').test(textos)) add('pedido', 'ok', `Pedido ${ctx.pedido} informado na nota`);
        else add('pedido', 'alerta', `O número do pedido ${ctx.pedido} não aparece na nota.`);
      } else add('pedido', 'alerta', `Sem XML: confira se o pedido ${ctx.pedido} consta na nota.`);
    }
    const dup = ctx.duplicada ? ctx.duplicada(chave, numero, serie, modelo) : null;
    if (dup === 'chave') add('duplicada', 'erro', 'Esta nota já foi enviada antes.');
    else if (dup === 'numero') add('duplicada', 'erro', 'Já existe uma nota com este número para o fornecedor.');

    return {
      modelo, itens, erros: itens.filter((i) => i.nivel === 'erro').length, alertas: itens.filter((i) => i.nivel === 'alerta').length,
      nota: { modelo, numero, serie, chave, codigo_verificacao: cod, data_emissao: data, valor, cnpj_emitente: emit, cnpj_destinatario: dest,
        pedidos_xml: lido ? (x.pedidos || []).map((p) => p.slice(0, 60)) : [], info: lido ? (x.descricao || null) : null }
    };
  };

  // XML de NF-e de exemplo (demonstração): chave válida, protocolo de autorização e assinatura simbólica
  NF.xmlExemplo = ({ cnpjEmitente, nomeEmitente, cnpjDestinatario, numero, serie, valor, pedido, data, descricao, complemento }) => {
    const hoje = data || U.hojeISO();
    const base = '35' + hoje.slice(2, 4) + hoje.slice(5, 7) + U.cnpjNorm(cnpjEmitente) + '55' + String(serie || 1).padStart(3, '0')
      + String(numero).padStart(9, '0') + '1' + String(10000000 + (Number(numero) * 7919) % 89999999);
    let s = 0, w = 2;
    for (let i = 42; i >= 0; i--) { s += val(base[i]) * w; w = w === 9 ? 2 : w + 1; }
    const chave = base + (11 - (s % 11) >= 10 ? 0 : 11 - (s % 11));
    const e = U.esc;
    const xml = `<?xml version="1.0" encoding="UTF-8"?><nfeProc xmlns="http://www.portalfiscal.inf.br/nfe" versao="4.00"><NFe><infNFe Id="NFe${chave}" versao="4.00">`
      + `<ide><cUF>35</cUF><natOp>PRESTACAO DE SERVICO</natOp><mod>55</mod><serie>${serie || 1}</serie><nNF>${numero}</nNF><dhEmi>${hoje}T09:00:00-03:00</dhEmi><tpAmb>1</tpAmb></ide>`
      + `<emit><CNPJ>${U.cnpjNorm(cnpjEmitente)}</CNPJ><xNome>${e(nomeEmitente || 'Fornecedor')}</xNome></emit>`
      + `<dest><CNPJ>${U.cnpjNorm(cnpjDestinatario)}</CNPJ><xNome>KLINGELE PAPER &amp; PACKING</xNome></dest>`
      + `<det nItem="1"><prod><xProd>${e(descricao || 'Servico')}</xProd>${pedido ? `<xPed>${e(pedido)}</xPed>` : ''}</prod></det>`
      + `<total><ICMSTot><vNF>${Number(valor || 0).toFixed(2)}</vNF></ICMSTot></total><infAdic><infCpl>${e(complemento || (pedido ? 'Pedido ' + pedido : ''))}</infCpl></infAdic>`
      + `</infNFe><Signature xmlns="http://www.w3.org/2000/09/xmldsig#"><SignedInfo/></Signature></NFe>`
      + `<protNFe versao="4.00"><infProt><tpAmb>1</tpAmb><chNFe>${chave}</chNFe><nProt>1352600000${String(numero).padStart(5, '0')}</nProt><cStat>100</cStat></infProt></protNFe></nfeProc>`;
    return { xml, chave };
  };
  // PDF mínimo (só para a demonstração: o conteúdo começa com %PDF como um PDF de verdade)
  NF.pdfExemplo = (texto) => {
    const t = String(texto || 'Documento de exemplo').replace(/[()\\]/g, ' ');
    return `%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n`
      + `3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n`
      + `4 0 obj<</Length ${t.length + 30}>>stream\nBT /F1 14 Tf 60 780 Td (${t}) Tj ET\nendstream endobj\n`
      + `5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n`;
  };

  // Lista de conferência (mesmo visual na página do fornecedor e no app da equipe)
  NF.checklistHTML = (itens) => `<ul class="nf-check">${(itens || []).map((i) => `<li class="${i.nivel === 'erro' ? 'crit' : i.nivel === 'alerta' ? 'warn' : 'ok'}">
      <span class="ic" aria-hidden="true">${i.nivel === 'ok' ? U.ic.ok : i.nivel === 'erro' ? U.ic.x : U.ic.alerta}</span>
      <span>${U.esc(i.msg)}</span><span class="sr-only">${i.nivel === 'ok' ? 'conferido' : i.nivel === 'erro' ? 'erro' : 'alerta'}</span></li>`).join('')}</ul>`;

  U.NF = NF;
})();

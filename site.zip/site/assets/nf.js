/* BMK · Boletim Mensal Klingele · página do fornecedor para enviar a nota fiscal (link de uso único) */
(function () {
  'use strict';
  const esc = U.esc;
  const NF = U.NF;

  function montar(el, token, opts) {
    const api = opts.api;
    const st = {
      fase: 'carregando', d: null, modelo: null, xml: null, arquivos: [], form: { numero: '', serie: '', chave: '', codigo_verificacao: '', data_emissao: '', valor: '' }, links: [],
      resp: { nome: '', email: '' }, obs: '', conferencia: null, enviando: false, resultado: null, previa: false
    };
    let seq = 0;

    const topo = () => `<header class="portal-top"><div class="in">
      ${U.marca('Boletim Mensal Klingele · envio da nota fiscal')}
    </div></header>`;

    function render() {
      let corpo = '';
      if (st.fase === 'carregando') corpo = '<div class="portal-done"><p class="muted">Abrindo o pedido de nota fiscal…</p></div>';
      else if (st.fase === 'erro') corpo = telaErro();
      else if (st.fase === 'concluido') corpo = telaConcluido();
      else corpo = telaFormulario();
      const faixa = st.previa ? '<div class="demo-banner"><strong>Prévia da equipe</strong><span>É o que o fornecedor vê ao abrir o link. Nada aqui é gravado e o link não é marcado como aberto.</span></div>' : '';
      el.innerHTML = `<div class="portal">${topo()}<main class="portal-main">${faixa}${corpo}</main></div>`;
      if (st.fase === 'form') { renderXml(); renderArquivos(); renderDados(); renderConferencia(); }
    }

    const contatos = () => (st.d && st.d.contatos_klingele) || [];
    const cartoes = () => `<div class="kl-contatos">${contatos().map((c) => `<div class="kl-contato">
        ${c.nome ? `<b>${esc(c.nome)}</b>` : ''}${c.cargo ? `<span class="small muted">${esc(c.cargo)}</span>` : ''}
        ${c.email ? `<a href="mailto:${esc(c.email)}">${U.ic.mail}<span>${esc(c.email)}</span></a>` : ''}
        ${c.telefone ? `<a href="tel:${esc(String(c.telefone).replace(/[^0-9+]/g, ''))}">${U.ic.tel}<span>${esc(c.telefone)}</span></a>` : ''}
      </div>`).join('')}</div>`;
    const contatoKlingele = () => (contatos().length ? `<div class="stack" style="gap:8px"><p>Dúvidas? Fale com a Klingele:</p>${cartoes()}</div>` : '<p class="muted">Fale com seu contato na Klingele.</p>');

    function telaErro() {
      const d = st.d || {};
      const t = {
        invalido: ['Link não encontrado', 'Confira se o endereço foi copiado inteiro do e-mail. Se o problema continuar, peça um novo link.'],
        usado: ['A nota fiscal já foi enviada', `Recebemos a nota em ${U.dataHoraBR(d.recebido_em)}. Cada link aceita um único envio.`],
        recusada: ['A nota enviada foi recusada', 'A equipe Klingele vai enviar um novo link com o motivo. Aguarde o e-mail ou fale com a Klingele.'],
        expirado: ['O prazo deste link terminou', `O link valia até ${U.dataBR(U.dataLocal(d.expira_em))}. Peça um novo link à Klingele.`],
        cancelado: ['Pedido de nota fiscal cancelado', 'Este pedido foi cancelado pela Klingele. Se ainda precisar enviar a nota, peça um novo link.'],
        bloqueado: ['Acesso bloqueado temporariamente', 'Houve muitas tentativas com links inválidos a partir desta rede. Aguarde uma hora e abra o link do e-mail novamente.'],
        limite: ['Muitas tentativas em pouco tempo', 'Aguarde alguns minutos e recarregue a página.'],
        falha: ['Não foi possível abrir o pedido', d.mensagem || 'Verifique sua conexão e recarregue a página.']
      }[d.motivo] || ['Link indisponível', ''];
      return `<section class="portal-done"><h1>${esc(t[0])}</h1><p>${esc(t[1])}</p>${contatoKlingele()}</section>`;
    }

    function telaConcluido() {
      const r = st.resultado || {}, n = r.nota || {};
      return `<section class="portal-done">
        <div class="mark">${U.ic.ok}</div>
        <h1>Nota fiscal recebida</h1>
        <p>Recebemos a ${esc(NF.MODELOS[n.modelo || st.modelo][0])} nº <b>${esc(n.numero || '')}</b> de <b>${esc(st.d.fornecedor.nome)}</b>
          (${esc(U.brl(n.valor))}) referente ao pedido <b class="mono">${esc(st.d.pedido || '')}</b>, parcela ${esc(parcelaTxt())}, em ${esc(U.dataHoraBR(r.recebido_em || new Date().toISOString()))}.</p>
        ${r.alertas ? `<p class="muted">A equipe Klingele vai conferir ${r.alertas === 1 ? 'o alerta indicado' : `os ${r.alertas} alertas indicados`} e avisa se precisar de outra nota.</p>` : '<p class="muted">A conferência automática não encontrou pendências. A equipe Klingele faz a aprovação final.</p>'}
        ${NF.checklistHTML(r.validacoes)}
        <p class="muted">Este link foi encerrado. Guarde esta tela como comprovante do envio.</p>
        ${opts.simulacao ? '<div class="row"><button class="btn primary" data-n="fechar">Voltar ao app da equipe</button></div>' : ''}
      </section>`;
    }

    const parcelaTxt = () => (st.d.parcela ? st.d.parcela + (st.d.parcelas_total ? ' de ' + st.d.parcelas_total : '') : '—');

    function telaFormulario() {
      const d = st.d;
      const prazo = U.dataLocal(d.expira_em);
      const restam = U.diasUteisAte(prazo, { feriados: new Set(d.feriados || []) });
      const cnpjs = d.cnpj_klingele || [];
      return `
      <section class="portal-hero">
        <span class="label">Nota fiscal · ${esc(U.cap(d.mes))}/${esc(d.ano)}</span>
        <h1>${esc(d.fornecedor.nome)}</h1>
        <div class="portal-facts">
          <span>Pedido <b class="mono">${esc(d.pedido || '—')}</b></span>
          <span>Parcela <b>${esc(parcelaTxt())}</b></span>
          <span>Valor da nota <b class="num">${esc(U.brl(d.valor))}</b></span>
          <span>Prazo <b>${esc(U.dataBR(prazo))}</b> ${restam <= 2 ? `<span class="chip warn">${restam <= 0 ? 'último dia' : `faltam ${restam} dias úteis`}</span>` : `<span class="muted">(${restam} dias úteis)</span>`}</span>
        </div>
        <p class="muted small">Link de uso único. A nota é conferida antes do envio.</p>
        ${contatos().length ? `<details class="kl-box"><summary>Dúvidas? Contatos da Klingele (${contatos().length})</summary>${cartoes()}</details>` : ''}
      </section>
      ${d.recusa ? `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">A nota nº ${esc(d.recusa.numero)} enviada antes foi recusada</strong>
        <p style="margin-top:4px">Motivo: ${esc(d.recusa.motivo || '—')}</p><p class="small muted" style="margin-top:4px">Emita uma nova nota com a correção e envie por esta página.</p></div></div>` : ''}

      <section class="pstep">
        <div class="pstep-head"><span class="pstep-n">${U.ic.nf}</span><div><h2>Dados para emitir a nota</h2>
          <p>Use exatamente estes dados. A Klingele confere CNPJ, valor e pedido.</p></div></div>
        <div class="pstep-body">
          <dl class="kv">
            <dt>Emitir para</dt><dd>${cnpjs.length ? cnpjs.map((c) => `<span class="tag mono">${esc(c)}</span>`).join(' ') : '<span class="muted">Confirme o CNPJ com a Klingele</span>'}</dd>
            <dt>Pedido de compra</dt><dd><b class="mono">${esc(d.pedido || '—')}</b> <span class="small muted">· informe nas informações complementares da nota</span></dd>
            <dt>Serviço</dt><dd>${esc(d.servico || '—')}</dd>
            <dt>Parcela</dt><dd>${esc(parcelaTxt())}</dd>
            <dt>Folha de serviço</dt><dd>${d.folha && d.folha.numero ? `${esc(d.folha.numero)}${d.folha.data ? ' · ' + esc(U.dataBR(d.folha.data)) : ''}` : '—'}</dd>
            <dt>Valor da nota</dt><dd><b class="num">${esc(U.brl(d.valor))}</b></dd>
          </dl>
          ${d.descricao ? `<div class="field"><span>Descrição para a nota</span>
            <div class="nf-desc"><pre>${esc(d.descricao)}</pre><button class="btn sm" type="button" data-n="copiar-desc">${U.ic.copiar} Copiar</button></div></div>` : ''}
          ${(d.anexos || []).length ? `<div class="field"><span>Arquivos da folha de serviço</span>
            ${d.anexos.some((a) => a.imagem) ? `<div class="nf-imgs">${d.anexos.filter((a) => a.imagem).map((a) => `<a href="${esc(a.url)}" target="_blank" rel="noopener noreferrer" title="${esc(a.nome)}"><img src="${esc(a.url)}" alt="${esc(a.nome)}" loading="lazy"></a>`).join('')}</div>` : ''}
            <div class="row">${d.anexos.map((a, i) => `<a class="btn sm nf-anexo" href="${esc(a.url)}" target="_blank" rel="noopener noreferrer" data-anexo="${i}">${U.ic.baixar}<span>${esc(a.nome)}</span></a>`).join('')}</div>
            <span class="hint">O link dos arquivos vale até o fim do prazo deste pedido.</span></div>` : ''}
        </div>
      </section>

      <section class="pstep" id="n-sec-modelo">
        <div class="pstep-head"><span class="pstep-n">1</span><div><h2>Tipo do documento</h2><p>Escolha o que você vai enviar.</p></div></div>
        <div class="pstep-body"><div class="nf-modelos" role="radiogroup" aria-label="Tipo do documento">
          ${Object.entries(NF.MODELOS).map(([k, [t, sub]]) => `<label class="nf-modelo ${st.modelo === k ? 'sel' : ''}"><input type="radio" name="n-modelo" value="${k}" ${st.modelo === k ? 'checked' : ''}>
            <b>${esc(t)}</b><span class="small muted">${esc(sub)}</span></label>`).join('')}
        </div></div>
      </section>

      <section class="pstep" id="n-sec-arquivos">
        <div class="pstep-head"><span class="pstep-n">2</span><div><h2>Arquivos da nota</h2>
          <p>Anexe pelo menos um arquivo: a nota (PDF ou imagem), o XML, a fatura ou o recibo. É possível anexar mais de um documento, até ${NF.LIMITES.arquivos} arquivos de ${NF.LIMITES.mb} MB.</p></div></div>
        <div class="pstep-body">
          <label class="drop" id="n-drop" for="n-file">${U.ic.upload}<b>Arraste os arquivos aqui ou clique para escolher</b>
            <span class="small muted">PDF · JPG · PNG · XML · um ou mais arquivos</span></label>
          <input type="file" id="n-file" class="sr-only" multiple accept="${NF.ACEITOS},.xml,text/xml,application/xml">
          <div id="n-arquivos" class="stack"></div>
          <div id="n-xml"></div>
          ${opts.simulacao ? '<div class="row"><button class="btn sm ghost" type="button" data-n="exemplo">Gerar XML e PDF de exemplo (demonstração)</button></div>' : ''}
        </div>
      </section>

      <section class="pstep" id="n-sec-dados">
        <div class="pstep-head"><span class="pstep-n">3</span><div><h2>Dados da nota</h2><p id="n-dados-sub"></p></div></div>
        <div class="pstep-body"><div id="n-dados"></div></div>
      </section>

      <section class="pstep" id="n-sec-envio">
        <div class="pstep-head"><span class="pstep-n">4</span><div><h2>Conferência e envio</h2>
          <p>Erros impedem o envio; alertas vão para a Klingele conferir.</p></div></div>
        <div class="pstep-body">
          <div id="n-conf"></div>
          <div class="form-grid">
            <label class="field"><span>Seu nome</span><input type="text" id="n-resp-nome" maxlength="120" autocomplete="name" value="${esc(st.resp.nome)}"></label>
            <label class="field"><span>Seu e-mail <span class="hint">(opcional)</span></span><input type="email" id="n-resp-email" maxlength="254" autocomplete="email" value="${esc(st.resp.email)}"></label>
            <label class="field full"><span>Observações <span class="hint">(opcional)</span></span><textarea id="n-obs" rows="3" maxlength="1000" style="min-height:76px">${esc(st.obs)}</textarea></label>
          </div>
          <div id="n-erros"></div>
          <div class="progress" id="n-prog" hidden><i></i></div>
          <div class="row"><button class="btn primary" type="button" data-n="enviar" id="n-enviar" ${st.previa ? 'disabled title="Desativado na prévia"' : ''}>${U.ic.envio} Conferir e enviar a nota</button>
            <span class="small muted" id="n-status"></span></div>
        </div>
      </section>`;
    }

    // ---------- XML ----------
    function renderXml() {
      const box = el.querySelector('#n-xml');
      if (!box) return;
      if (st.modelo === 'fatura' && !st.xml) { box.innerHTML = ''; return; }
      const x = st.xml;
      let info = '';
      if (x && x.lido && !x.lido.ok) info = `<span style="color:var(--crit)">${esc(x.lido.erro)}</span>`;
      else if (x && x.lido && x.lido.tipo === 'desconhecido') info = '<span style="color:var(--warn)">XML não reconhecido como NF-e ou NFS-e. Preencha os dados da nota no passo 3.</span>';
      else if (x && x.lido) info = `<span>${esc({ nfe: 'NF-e', nfse: 'NFS-e (padrão nacional)', nfse_municipal: 'NFS-e (padrão municipal)' }[x.lido.tipo])} nº <b>${esc(x.lido.numero || '—')}</b>
        · ${esc(U.brl(x.lido.valor === null || x.lido.valor === undefined ? null : Number(x.lido.valor)))}${x.lido.emitente_nome ? ' · ' + esc(x.lido.emitente_nome) : ''}</span>`;
      box.innerHTML = `<div class="nf-xml ${x ? 'tem' : ''}">
        <div class="stack" style="gap:2px;min-width:0"><b>Arquivo XML <span class="muted small">(opcional)</span></b>
          ${x ? `<span class="small" style="overflow-wrap:anywhere">${esc(x.file.name)} · ${U.tamanho(x.file.size)}</span><span class="small">${info}</span>` : '<span class="small muted">O XML permite conferir a chave de acesso, o emitente e o valor automaticamente.</span>'}</div>
        <div class="row" style="flex-wrap:nowrap"><label class="btn sm" for="n-xml-file">${U.ic.upload} ${x ? 'Trocar XML' : 'Escolher XML'}</label>
          ${x ? `<button class="icon-btn" type="button" data-n="rm-xml" aria-label="Remover XML">${U.ic.x}</button>` : ''}</div>
        <input type="file" id="n-xml-file" class="sr-only" accept=".xml,text/xml,application/xml"></div>`;
    }
    async function lerXml(file) {
      if (!/\.xml$/i.test(file.name)) { U.toast('Escolha um arquivo .xml', 'erro'); return; }
      if (file.size > NF.LIMITES.xmlKb * 1000) { st.xml = { file, texto: null, lido: { ok: false, erro: `XML muito grande (máximo ${NF.LIMITES.xmlKb} KB).` } }; renderTudo(); return; }
      const texto = await file.text();
      st.xml = { file, texto, lido: NF.lerXml(texto) };
      if (st.xml.lido && st.xml.lido.ok) {
        if (st.xml.lido.tipo === 'nfe') st.modelo = 'nfe';
        else if (['nfse', 'nfse_municipal'].includes(st.xml.lido.tipo)) st.modelo = 'nfse';
      }
      st.conferencia = null;
      render();
    }

    // ---------- Arquivos ----------
    function renderArquivos() {
      const box = el.querySelector('#n-arquivos');
      if (!box) return;
      const mais = st.arquivos.length || st.xml
        ? `<div class="row"><label class="btn sm" for="n-file">${U.ic.mais || '+'} Adicionar outro arquivo</label><span class="small muted">${st.arquivos.length + (st.xml ? 1 : 0)} anexado${st.arquivos.length + (st.xml ? 1 : 0) > 1 ? 's' : ''} · até ${NF.LIMITES.arquivos} arquivos, além do XML</span></div>` : '';
      box.innerHTML = st.arquivos.map((a) => {
        const ext = U.extensao(a.file.name);
        return `<div class="file-row">
          <span class="ext ${esc(ext)}">${esc(ext)}</span>
          <div class="stack" style="gap:2px;min-width:0">
            <b style="overflow-wrap:anywhere">${esc(a.file.name)}</b>
            <span class="small muted">${U.tamanho(a.file.size)}${a.verificando ? ' · conferindo o arquivo…' : ''}${a.erro ? ` · <span style="color:var(--crit)">${esc(a.erro)}</span>` : ''}</span>
            <div class="opts"><label class="field"><span>Tipo</span><select data-nt="${a.id}">${[['nota_fiscal', 'Nota fiscal, fatura ou recibo'], ['outro', 'Outro (boleto, relatório…)']].map(([k, v]) => `<option value="${k}" ${a.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label></div>
          </div>
          <button class="icon-btn" type="button" data-n="rm-arquivo" data-a="${a.id}" aria-label="Remover arquivo">${U.ic.x}</button>
        </div>`;
      }).join('') + mais;
    }
    function adicionarArquivos(lista) {
      Array.from(lista || []).forEach((file) => {
        if (/\.xml$/i.test(file.name)) { lerXml(file); return; }
        if (st.arquivos.length >= NF.LIMITES.arquivos) { U.toast(`Máximo de ${NF.LIMITES.arquivos} arquivos`, 'erro'); return; }
        const ext = U.extensao(file.name);
        const a = { id: ++seq, file, tipo: st.arquivos.some((x) => x.tipo === 'nota_fiscal') ? 'outro' : 'nota_fiscal', caminho: null, erro: null, hash: null, verificando: true };
        st.arquivos.push(a);
        if (!['pdf', 'jpg', 'jpeg', 'png'].includes(ext)) { a.erro = 'Tipo não aceito (use PDF, JPG, PNG ou XML)'; a.verificando = false; return; }
        if (file.size > NF.LIMITES.mb * 1048576) { a.erro = `Maior que ${NF.LIMITES.mb} MB`; a.verificando = false; return; }
        if (file.size === 0) { a.erro = 'Arquivo vazio'; a.verificando = false; return; }
        (async () => {
          const okAss = await U.conferirAssinatura(file).catch(() => false);
          if (!okAss) a.erro = `O conteúdo não corresponde a um arquivo .${ext}`;
          else {
            a.hash = await U.sha256(file);
            if (a.hash && st.arquivos.some((x) => x !== a && x.hash === a.hash)) a.erro = 'Arquivo repetido nesta lista';
          }
          a.verificando = false;
          renderArquivos(); renderConferencia();
        })();
      });
      st.conferencia = null;
      renderArquivos(); renderConferencia();
    }

    // ---------- Dados da nota ----------
    const xmlLido = () => (st.xml && st.xml.lido && st.xml.lido.ok && st.xml.lido.tipo !== 'desconhecido' ? st.xml.lido : null);
    function renderDados() {
      const box = el.querySelector('#n-dados'), sub = el.querySelector('#n-dados-sub');
      if (!box) return;
      const x = xmlLido();
      if (!st.modelo) { sub.textContent = 'Escolha o tipo do documento no passo 1.'; box.innerHTML = ''; return; }
      if (x) {
        sub.textContent = 'Lidos do XML. Para corrigir algo, emita a nota de novo e troque o arquivo.';
        box.innerHTML = `<dl class="kv">
          <dt>Número</dt><dd><b>${esc(x.numero || '—')}</b>${x.serie ? ` · série ${esc(x.serie)}` : ''}</dd>
          ${x.chave ? `<dt>Chave de acesso</dt><dd class="mono small">${esc(NF.formatarChave(x.chave))}</dd>` : ''}
          ${x.codigo_verificacao ? `<dt>Código de verificação</dt><dd class="mono">${esc(x.codigo_verificacao)}</dd>` : ''}
          <dt>Emissão</dt><dd>${esc(U.dataBR(x.data))}</dd>
          <dt>Valor</dt><dd class="num">${esc(U.brl(x.valor === null || x.valor === undefined ? null : Number(x.valor)))}</dd>
          <dt>Emitente</dt><dd>${esc(U.cnpj(x.emitente) || '—')}${x.emitente_nome ? ' · ' + esc(x.emitente_nome) : ''}</dd>
          <dt>Destinatário</dt><dd>${esc(U.cnpj(x.destinatario) || '—')}</dd>
        </dl>`;
        return;
      }
      sub.textContent = st.modelo === 'fatura' ? 'Preencha conforme o documento.' : 'Preencha conforme a nota, ou anexe o XML no passo 2 para preencher automaticamente.';
      const f = st.form;
      box.innerHTML = `<div class="form-grid">
        <label class="field"><span>Número ${st.modelo === 'fatura' ? 'do documento' : 'da nota'}</span><input type="text" data-nf="numero" maxlength="20" inputmode="${st.modelo === 'fatura' ? 'text' : 'numeric'}" value="${esc(f.numero)}"></label>
        ${st.modelo === 'nfse' ? `<label class="field"><span>Código de verificação</span><input type="text" data-nf="codigo_verificacao" maxlength="60" value="${esc(f.codigo_verificacao)}"></label>` : `<label class="field"><span>Série <span class="hint">(se houver)</span></span><input type="text" data-nf="serie" maxlength="3" inputmode="numeric" value="${esc(f.serie)}"></label>`}
        <label class="field"><span>Data de emissão</span><input type="date" data-nf="data_emissao" max="${esc(U.hojeISO())}" value="${esc(f.data_emissao)}"></label>
        <label class="field"><span>Valor (R$)</span><input type="text" data-nf="valor" inputmode="decimal" maxlength="18" placeholder="${esc(U.numBR(st.d.valor))}" value="${esc(f.valor)}"></label>
        ${st.modelo === 'nfe' ? `<label class="field full"><span>Chave de acesso <span class="hint">(opcional, 44 números)</span></span><input type="text" data-nf="chave" maxlength="60" inputmode="numeric" value="${esc(f.chave)}"></label>` : ''}
      </div>`;
    }

    // ---------- Conferência ----------
    function conferirLocal() {
      const d = st.d;
      return NF.conferir({
        modelo: st.modelo, xml: st.xml ? st.xml.lido : null, temXml: !!st.xml,
        form: { ...st.form, valor: U.arred(U.parseValor(st.form.valor)) },
        competencia: d.competencia, valorAprovado: d.valor, pedido: d.pedido, cnpjFornecedor: d.fornecedor.cnpj,
        cnpjsKlingele: d.cnpj_klingele || [], hoje: U.hojeISO()
      });
    }
    function renderConferencia() {
      const box = el.querySelector('#n-conf');
      if (!box) return;
      if (!st.modelo) { box.innerHTML = ''; return; }
      if (st.conferencia) {
        const r = st.conferencia;
        box.innerHTML = `<div class="nf-conf"><div class="row between"><b>Conferência do servidor</b>${r.alertas ? `<span class="chip warn">${r.alertas} alerta${r.alertas > 1 ? 's' : ''}</span>` : '<span class="chip ok">Sem pendências</span>'}</div>${NF.checklistHTML(r.validacoes)}</div>`;
        return;
      }
      const r = conferirLocal();
      if (r.bloqueio) { box.innerHTML = `<div class="nf-conf"><p class="small" style="color:var(--warn)">${esc(r.bloqueio)}</p></div>`; return; }
      const semNf = !st.arquivos.some((a) => !a.erro) && !st.xml;
      box.innerHTML = `<div class="nf-conf"><div class="row between"><b>Conferência prévia</b>${r.erros ? `<span class="chip crit">${r.erros} erro${r.erros > 1 ? 's' : ''}</span>` : r.alertas ? `<span class="chip warn">${r.alertas} alerta${r.alertas > 1 ? 's' : ''}</span>` : '<span class="chip ok">Tudo certo até aqui</span>'}</div>
        ${NF.checklistHTML(r.itens.concat(semNf ? [{ item: 'arquivo', nivel: 'erro', msg: 'Anexe pelo menos um arquivo: nota (PDF ou imagem), XML, fatura ou recibo.' }] : []))}</div>`;
    }
    const renderTudo = () => { renderXml(); renderDados(); renderConferencia(); };

    function validar() {
      const e = [];
      if (!st.modelo) e.push(['n-sec-modelo', 'Escolha o tipo do documento.']);
      if (st.xml && st.xml.lido && !st.xml.lido.ok) e.push(['n-sec-arquivos', st.xml.lido.erro]);
      if (!st.arquivos.some((a) => !a.erro) && !st.xml) e.push(['n-sec-arquivos', 'Anexe pelo menos um arquivo: nota (PDF ou imagem), XML, fatura ou recibo.']);
      if (st.arquivos.some((a) => a.verificando)) e.push(['n-sec-arquivos', 'Aguarde a conferência dos arquivos terminar.']);
      st.arquivos.forEach((a) => { if (a.erro) e.push(['n-sec-arquivos', `Remova o arquivo "${a.file.name}" (${a.erro}).`]); });
      if (st.modelo) {
        const r = conferirLocal();
        if (r.bloqueio) e.push(['n-sec-arquivos', r.bloqueio]);
        else r.itens.filter((i) => i.nivel === 'erro').forEach((i) => e.push(['n-sec-dados', i.msg]));
      }
      if (st.resp.nome.trim().length < 2) e.push(['n-sec-envio', 'Informe seu nome.']);
      if (st.resp.email && !U.emailValido(st.resp.email)) e.push(['n-sec-envio', 'Seu e-mail parece incorreto.']);
      if (st.obs.length > 1000) e.push(['n-sec-envio', 'Observação muito longa (máximo 1.000 caracteres).']);
      return e;
    }

    const dadosEnvio = (somenteConferir) => ({
      modelo: st.modelo, xml: st.xml && st.xml.texto ? st.xml.texto : null,
      numero: st.form.numero.trim(), serie: st.form.serie.trim(), chave: st.form.chave.trim(), codigo_verificacao: st.form.codigo_verificacao.trim(),
      data_emissao: st.form.data_emissao, valor: U.arred(U.parseValor(st.form.valor)),
      arquivos: st.arquivos.map((a) => ({ caminho: a.caminho, nome: a.file.name, tipo: a.tipo, hash_sha256: a.hash || null })),
      links: somenteConferir ? [] : st.links,
      responsavel: { nome: st.resp.nome.trim(), email: st.resp.email.trim() }, observacao: st.obs,
      somente_conferir: !!somenteConferir
    });

    function mostrarErro(titulo, msg, validacoes) {
      const box = el.querySelector('#n-erros');
      box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div style="min-width:0"><strong style="color:var(--crit)">${esc(titulo)}</strong>
        <p style="margin-top:4px">${esc(msg)}</p>${validacoes && validacoes.length ? NF.checklistHTML(validacoes) : ''}</div></div>`;
    }

    async function enviar(forcar) {
      if (st.enviando) return;
      if (st.previa) { U.toast('Na prévia o envio fica desativado'); return; }
      const box = el.querySelector('#n-erros');
      const erros = validar();
      if (erros.length) {
        box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Antes de enviar</strong><ul style="margin:6px 0 0;padding-left:18px">${[...new Set(erros.map((x) => x[1]))].map((x) => `<li>${esc(x)}</li>`).join('')}</ul></div></div>`;
        const alvo = el.querySelector('#' + erros[0][0]);
        if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      box.innerHTML = '';
      st.enviando = true;
      const btn = el.querySelector('#n-enviar'), prog = el.querySelector('#n-prog'), stt = el.querySelector('#n-status');
      btn.disabled = true; prog.hidden = false;
      try {
        const total = st.arquivos.length + 2;
        for (let i = 0; i < st.arquivos.length; i++) {
          const a = st.arquivos[i];
          stt.textContent = `Enviando ${i + 1} de ${st.arquivos.length}: ${a.file.name}`;
          if (!a.caminho) {
            const base = U.nomePadrao({ competencia: st.d.competencia, fornecedor: st.d.fornecedor.nome, tipo: a.tipo, ext: U.extensao(a.file.name) }).replace(/\.[^.]+$/, '');
            a.caminho = await api.portalEnviarArquivo(st.d.pasta_upload, a.file, i + 1, base);
          }
          prog.firstElementChild.style.width = Math.round(((i + 1) / total) * 100) + '%';
        }
        if (!forcar) {
          stt.textContent = 'Conferindo a nota…';
          const c = await api.nfFinalizar(token, dadosEnvio(true));
          if (!c || c.ok === false) {
            fimEnvio();
            mostrarErro('A nota não passou na conferência', (c && c.erro) || 'Tente de novo.', c && c.validacoes);
            return;
          }
          st.conferencia = c;
          renderConferencia();
          if (c.alertas > 0) {
            fimEnvio();
            box.innerHTML = `<div class="demo-banner"><div style="min-width:0"><strong>${c.alertas === 1 ? 'Há 1 alerta' : `Há ${c.alertas} alertas`} na conferência</strong>
              <p style="margin-top:4px">Confira os itens em amarelo acima. Se estiver tudo certo, envie mesmo assim: a equipe Klingele confere os alertas. Se algo estiver errado, corrija a nota e troque o arquivo.</p>
              <div class="row" style="margin-top:8px"><button class="btn sm primary" type="button" data-n="enviar-assim">${U.ic.envio} Enviar mesmo assim</button></div></div></div>`;
            return;
          }
        }
        stt.textContent = 'Concluindo…';
        // Links temporários dos arquivos: vão anexos quando a nota for encaminhada a Serviços
        st.links = st.arquivos.length && api.nfLinksArquivos ? await api.nfLinksArquivos(st.arquivos.map((a) => a.caminho)).catch(() => []) : [];
        const r = await api.nfFinalizar(token, dadosEnvio(false));
        if (!r || r.ok === false) {
          fimEnvio();
          mostrarErro('Envio não concluído', (r && r.erro) || 'Tente de novo.', r && r.validacoes);
          return;
        }
        st.resultado = r;
        st.fase = 'concluido';
        render();
        (el.closest('.portal-overlay') || document.scrollingElement || document.documentElement).scrollTo(0, 0);
        if (opts.aoConcluir) opts.aoConcluir();
      } catch (err) {
        fimEnvio();
        mostrarErro('Envio não concluído', err.message + ' Tente de novo; os arquivos já enviados não serão duplicados.');
      }
      function fimEnvio() { st.enviando = false; btn.disabled = false; stt.textContent = ''; prog.hidden = true; }
    }

    // Demonstração: XML e PDF de exemplo com os dados deste pedido
    function gerarExemplo() {
      const d = st.d;
      const forn = U.cnpjNorm(d.fornecedor.cnpj).length === 14 ? d.fornecedor.cnpj : '11.222.333/0001-81';
      const numero = 1000 + Math.floor(Math.random() * 8999);
      const { xml, chave } = NF.xmlExemplo({ cnpjEmitente: forn, nomeEmitente: d.fornecedor.nome, cnpjDestinatario: (d.cnpj_klingele || [])[0] || '61.064.929/0001-79',
        numero, valor: d.valor, pedido: d.pedido, descricao: d.servico, complemento: `Pedido ${d.pedido || ''} - parcela ${parcelaTxt()}` });
      st.arquivos = [];
      adicionarArquivos([new File([NF.pdfExemplo(`DANFE - NF-e ${numero} - exemplo da demonstracao`)], `DANFE-${numero}.pdf`, { type: 'application/pdf' })]);
      lerXml(new File([xml], `NFe${chave}.xml`, { type: 'application/xml' }));
      if (!st.resp.nome) st.resp.nome = 'Responsável do fornecedor';
    }

    // ---------- Eventos ----------
    el.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-n]');
      if (!b) return;
      const acao = b.dataset.n;
      if (acao === 'copiar-desc') U.copiar(st.d.descricao || '', 'Descrição copiada');
      if (acao === 'rm-xml') { st.xml = null; st.conferencia = null; renderTudo(); }
      if (acao === 'rm-arquivo') {
        st.arquivos = st.arquivos.filter((a) => a.id !== Number(b.dataset.a));
        st.arquivos.forEach((a) => { if (a.erro === 'Arquivo repetido nesta lista' && !st.arquivos.some((x) => x !== a && x.hash === a.hash && !x.erro)) a.erro = null; });
        st.conferencia = null; renderArquivos(); renderConferencia();
      }
      if (acao === 'enviar') enviar(false);
      if (acao === 'enviar-assim') enviar(true);
      if (acao === 'exemplo') gerarExemplo();
      if (acao === 'fechar' && opts.aoFechar) opts.aoFechar();
    });
    el.addEventListener('input', (ev) => {
      const t = ev.target;
      if (t.dataset.nf) { st.form[t.dataset.nf] = t.value; st.conferencia = null; renderConferencia(); }
      if (t.id === 'n-resp-nome') st.resp.nome = t.value;
      if (t.id === 'n-resp-email') st.resp.email = t.value;
      if (t.id === 'n-obs') st.obs = t.value;
    });
    el.addEventListener('change', (ev) => {
      const t = ev.target;
      if (t.name === 'n-modelo') { st.modelo = t.value; st.conferencia = null; el.querySelectorAll('.nf-modelo').forEach((l) => l.classList.toggle('sel', l.querySelector('input').checked)); renderTudo(); }
      if (t.id === 'n-file') { adicionarArquivos(t.files); t.value = ''; }
      if (t.id === 'n-xml-file') { const f = t.files[0]; t.value = ''; if (f) lerXml(f); }
      if (t.dataset.nt) { const a = st.arquivos.find((x) => x.id === Number(t.dataset.nt)); a.tipo = t.value; st.conferencia = null; renderConferencia(); }
    });
    el.addEventListener('dragover', (ev) => { const d = ev.target.closest('#n-drop'); if (d) { ev.preventDefault(); d.classList.add('over'); } });
    el.addEventListener('dragleave', (ev) => { const d = ev.target.closest('#n-drop'); if (d) d.classList.remove('over'); });
    el.addEventListener('drop', (ev) => { const d = ev.target.closest('#n-drop'); if (d) { ev.preventDefault(); d.classList.remove('over'); adicionarArquivos(ev.dataTransfer.files); } });

    // ---------- Início ----------
    render();
    (async () => {
      try {
        let d;
        if (opts.previaId) { st.previa = true; d = await api.nfPrevia(opts.previaId); }
        else {
          if (!token || !/^[0-9a-f]{64}$/.test(token)) { st.d = { ok: false, motivo: 'invalido' }; st.fase = 'erro'; return render(); }
          d = await api.nfAbrir(token);
        }
        st.d = d;
        st.fase = d && d.ok ? 'form' : 'erro';
        render();
      } catch (e) {
        st.d = { ok: false, motivo: 'falha', mensagem: e.message };
        st.fase = 'erro';
        render();
      }
    })();
  }

  window.NotaFiscal = { montar };
})();

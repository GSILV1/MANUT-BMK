/* Abre a página de documentos do colaborador. O link chega como documentos.html#CODIGO:
   o trecho depois do # não vai para o servidor nem aparece em logs. */
(async function () {
  var el = document.getElementById('documentos');
  var token = (location.hash || '').slice(1) || '';
  try {
    if (token) sessionStorage.setItem('klg-documentos', token);
    else token = sessionStorage.getItem('klg-documentos') || '';
    history.replaceState(null, '', location.pathname);
  } catch (e) { /* sem armazenamento */ }
  try { await API.init({ portal: true }); }
  catch (e) { el.textContent = 'Não foi possível carregar a página. Verifique sua conexão e recarregue.'; return; }
  Documentos.montar(el, token.trim(), {
    api: API,
    aoConcluir: function () { try { sessionStorage.removeItem('klg-documentos'); } catch (e) { /* sem armazenamento */ } }
  });
})();

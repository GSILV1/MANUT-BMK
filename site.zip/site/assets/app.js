/* BMK · Boletim Mensal Klingele · app da equipe */
(function () {
  'use strict';
  const esc = U.esc, ic = U.ic;
  const cfg = window.APP_CONFIG || {};
  const root = document.getElementById('app');
  const DEMO = API.modo === 'demo';

  const S = {
    view: 'painel', comp: U.compAnterior(), user: null,
    base: null, mapF: {}, mapC: {}, mapCol: {}, fer: new Set(),
    solic: [], med: [], docs: [], periodo: [], envios: [], aval: [], avalPeriodo: [], nfSolic: [], nfNotas: [], parc: {},
    cache: { envios: null, hist: null, rotina: null },
    f: { receb: 'todos', pag: 'todos', forn: '', fornFiltro: 'lista', contr: '', contrFiltro: 'ativos', contrPasta: '', gestor: '', tipoServ: '', hist: 'envios', histForn: '', aval: 'todos', nf: 'todos',
      pForn: '', pSup: '', pTipo: '', pEtapa: '', usu: 'pendentes', usuBusca: '', pasta: '', histBusca: '', histLimpos: false, usuAba: 'usuarios', envioVis: (() => { try { return localStorage.getItem('bmk-envio-vis') === 'lista' ? 'lista' : 'pastas'; } catch (e) { return 'pastas'; } })(), envioFechados: { _avulsos: true } },
    gaveta: null, papel: null, emailCfg: null, usuarios: [], cad: null, ret: {},
    escopo: (() => { try { return localStorage.getItem('bmk-escopo') === 'meus' ? 'meus' : 'todos'; } catch (e) { return 'todos'; } })()
  };
  const podeEnviarPeloApp = () => !!(S.emailCfg && S.emailCfg.chave && S.emailCfg.remetente && S.emailCfg.site);
  // Envio mensal (pasta padrão): dia útil e horário da rotina base do mês. Dia 0 = último dia útil do mês (pede o
  // próprio mês); N = N-ésimo dia útil do mês seguinte (sábado, domingo e feriados não contam)
  const pastaPadrao = () => ((S.base && S.base.pastas) || []).find((p) => p.padrao) || null;
  const diaUtilEnvio = () => { const p = pastaPadrao(); const n = Number(p ? p.dia_util : cfgv('dia_util_envio', 1)); return Number.isInteger(n) && n >= 0 && n <= 10 ? n : 1; };
  const horarioEnvio = () => (pastaPadrao() || {}).horario || cfgv('horario_envio', '08:00') || '08:00';
  const diaEnvioTxt = () => (diaUtilEnvio() === 0 ? 'último dia útil do mês' : `${diaUtilEnvio()}º dia útil`);
  function diaDoEnvio(comp) { return diaUtilEnvio() === 0 ? U.ultimoDiaUtil(comp, S.fer) : U.diaUtilDoMes(comp, diaUtilEnvio(), S.fer); }
  function proximoEnvioAutomatico() {
    const hoje = U.hojeISO();
    let d = diaDoEnvio(U.compDe(hoje));
    if (d < hoje) d = diaDoEnvio(U.addMes(U.compDe(hoje), 1));
    return { data: d, competencia: diaUtilEnvio() === 0 ? U.compDe(d) : U.addMes(U.compDe(d), -1) };
  }
  const compLiberada = (c) => U.compLiberada(c, S.fer);
  const VIEWS = {};
  // [chave, nome, ícone, nome curto (barra inferior do celular), principal no celular]
  const NAV = [
    ['painel', 'Painel', ic.painel, 'Painel', 1], ['envio', 'Envio do mês', ic.envio, 'Envio', 1], ['pastas', 'Pastas', ic.pasta, 'Pastas'], ['receb', 'Recebimentos', ic.receb, 'Recebidos', 1],
    ['nf', 'F.S. e notas fiscais', ic.nf, 'F.S./NF', 1], ['pag', 'Pagamentos', ic.pag, 'Pagamentos'], ['aval', 'Avaliações', ic.estrela, 'Avaliações'],
    ['hist', 'Histórico', ic.hist, 'Histórico'], ['forn', 'Fornecedores', ic.forn, 'Fornecedores'], ['contr', 'Contratos', ic.contr, 'Contratos'],
    ['colab', 'Contatos Klingele', ic.pessoas, 'Contatos'], ['usuarios', 'Usuários', ic.usuarios, 'Usuários'], ['conf', 'Configurações', ic.conf, 'Configurações']
  ];
  // Áreas do menu (computador): rotina do mês, acompanhamento, cadastros e administração
  const AREA_NAV = { painel: 'Rotina do mês', aval: 'Acompanhamento', forn: 'Cadastros', usuarios: 'Administração' };
  const TITULOS = {
    painel: ['Painel do mês', 'Contratado x medido e andamento da competência.'],
    envio: ['Envio do mês', 'Um link por fornecedor e por pasta: envio, e-mails e respostas.'],
    pastas: ['Pastas', 'Rotinas de fechamento dos contratos: quando cada link sai, quem cuida e quem pode mexer.'],
    receb: ['Recebimentos', 'Arquivos recebidos e conferência dos valores.'],
    nf: ['Folha de serviço e nota fiscal', 'F.S. enviada ao fornecedor, nota fiscal, aprovação da F.S. e encaminhamento a Serviços.'],
    usuarios: ['Usuários', 'Cadastros dos colaboradores Klingele, aprovação e perfis.'],
    pag: ['Pagamentos', 'Valor aprovado, NF e data de pagamento.'],
    aval: ['Avaliação de satisfação', 'Notas de 1 a 10 dos supervisores por fornecedor.'],
    forn: ['Fornecedores', 'Cadastro, e-mails e pastas dos contratos.'],
    contr: ['Contratos e pedidos', 'Vigência, valores, parcelas, supervisores e contatos de cada serviço.'],
    colab: ['Contatos Klingele', 'Supervisores e contatos dos contratos. Usuários aprovados do BMK entram aqui automaticamente.'],
    hist: ['Histórico', 'E-mails, alterações e rotina das 08:00 e 16:00, por período.'],
    conf: ['Configurações', 'E-mails, prazos, fluxo do mês, avisos, feriados e acesso.']
  };
  const COMP_VIEWS = ['painel', 'envio', 'receb', 'nf', 'pag', 'aval'];

  // ---------- Dados ----------
  const num = (v) => (v === null || v === undefined || v === '' ? null : Number(v));
  const soma = (arr) => arr.reduce((t, v) => t + (num(v) || 0), 0);
  const F = (id) => S.mapF[id] || { nome: '(fornecedor removido)', contatos: [] };
  const C = (id) => S.mapC[id] || { titulo: '(contrato removido)', pedido: '' };
  const medido = (m) => (num(m.valor_aprovado) ?? num(m.valor_informado) ?? num(m.valor_lido));
  const cfgv = (k, p) => (S.base && S.base.config[k] !== undefined ? S.base.config[k] : p);
  // Validade do link em dias úteis: a da pasta (se tiver) ou a padrão
  const prazoDias = (pid) => Number((pid && S.mapPasta && S.mapPasta[pid] && S.mapPasta[pid].prazo_dias) || cfgv('prazo_dias_uteis', 7)) || 7;
  const COL = (id) => S.mapCol[id] || null;
  // ---------- Responsáveis do contrato: supervisores (avaliação e aviso de vencimento) e contatos (suporte ao fornecedor) ----------
  const supsDe = (c) => (c && c.supervisores) || [];
  const ctsDe = (c) => (c && c.contatos) || [];
  const nomesCol = (ids) => ids.map(COL).filter(Boolean).map((x) => x.nome);
  const contatosProprios = (c) => ctsDe(c).map(COL).filter((x) => x && x.ativo && (x.email || x.telefone)).slice(0, 5);
  const servicosSuporte = (cs) => cs.filter(Boolean).map((c) => ({ titulo: c.titulo, pedido: c.pedido, contatos: contatosProprios(c) }));
  // ---------- Pastas de fechamento: cada contrato fica em uma pasta (ou avulso); Envio mensal = pasta padrão ----------
  const EU = () => ((S.user && S.user.email) || '').toLowerCase();
  const PASTA = (id) => (id && S.mapPasta && S.mapPasta[id]) || null;
  const minhaPasta = (p) => !!p && !!p.responsavel && p.responsavel === EU();
  // ---------- Equipes de trabalho e compartilhamento das pastas ----------
  const minhasEquipes = () => (S.base.membros || []).filter((m) => m.email === EU() && m.status === 'ativo').map((m) => m.equipe_id);
  const meusConvites = () => (S.base.membros || []).filter((m) => m.email === EU() && m.status === 'convidado' && S.mapEq[m.equipe_id]);
  const gereEquipe = (e) => !!e && (S.papel === 'admin' || (podeAprovar() && e.criado_por === EU()));
  const membrosDe = (eid) => (S.base.membros || []).filter((m) => m.equipe_id === eid);
  // Acesso à pasta (igual ao banco): dono, gerir, editar, ver ou null. Administrador gere todas; supervisor que participa
  // da pasta gere; o responsável edita; somente leitura só vê
  const RANK_P = { ver: 1, editar: 2, gerir: 3, dono: 4 };
  const nivelPasta = (p) => {
    if (!p) return null;
    const eu = EU(), eqs = minhasEquipes();
    const cs = (S.base.compart || []).filter((c) => c.pasta_id === p.id && ((c.alvo_tipo === 'usuario' && c.alvo === eu) || (c.alvo_tipo === 'equipe' && eqs.includes(c.alvo))));
    if (S.papel === 'leitura') return p.padrao || p.visibilidade !== 'restrita' || p.responsavel === eu || cs.length ? 'ver' : null;
    if (p.criado_por && p.criado_por === eu) return 'dono';
    if (S.papel === 'admin') return 'gerir';
    let n = cs.some((c) => c.nivel === 'gerir') ? 'gerir' : cs.some((c) => c.nivel === 'editar') ? 'editar' : cs.length ? 'ver' : null;
    if (p.visibilidade === 'todos_editar' && (RANK_P[n] || 0) < 2) n = 'editar';
    if (p.responsavel === eu && (RANK_P[n] || 0) < 2) n = 'editar';
    if (!n && (p.padrao || p.visibilidade === 'todos_ver')) n = 'ver';
    return n && S.papel === 'supervisor' ? 'gerir' : n;
  };
  const podeEditarPasta = (p) => (RANK_P[nivelPasta(p)] || 0) >= 2;
  const podeGerirPasta = (p) => (RANK_P[nivelPasta(p)] || 0) >= 3;
  // Pôr ou tirar contrato de uma pasta: avulso sempre; Envio mensal com o perfil de edição; outras, quem edita a pasta
  const podePorNaPasta = (pid) => S.papel !== 'leitura' && (!pid || (!!PASTA(pid) && (PASTA(pid).padrao || podeEditarPasta(PASTA(pid)))));
  const podeEnviarPasta = (p) => !!p && S.papel !== 'leitura' && (p.padrao || podeEditarPasta(p));
  const ctxRegra = () => ({ forn: (id) => S.mapF[id], naLista: () => true,
    colabNaEquipe: (cid, eqs) => { const co = COL(cid), e = co && (co.email || '').toLowerCase(); return !!e && (S.base.membros || []).some((m) => m.email === e && m.status === 'ativo' && eqs.includes(m.equipe_id)); } });
  // Contratos e fornecedores de cada pasta na competência da tela ('' = avulsos): contratos vigentes no mês
  // (fornecedor de boletim mensal: qualquer contrato ativo da pasta, como no banco)
  function memoPastas() {
    if (S.memoP && S.memoP.comp === S.comp) return S.memoP;
    const m = { comp: S.comp, contratos: {}, forns: {} };
    S.base.contratos.forEach((c) => {
      const f = S.mapF[c.fornecedor_id];
      if (!f || !f.ativo || c.situacao !== 'ativo') return;
      const k = c.pasta_id || '';
      if (!(U.vigenteNoMes(c, S.comp) || (k && f.deseja_enviar))) return;
      (m.contratos[k] = m.contratos[k] || []).push(c);
      (m.forns[k] = m.forns[k] || new Set()).add(f.id);
    });
    Object.keys(m.forns).forEach((k) => { m.forns[k] = [...m.forns[k]]; });
    S.memoP = m;
    return m;
  }
  const fornsDaPasta = (pid) => memoPastas().forns[pid || ''] || [];
  const contratosDaPasta = (pid, fid) => (memoPastas().contratos[pid || ''] || []).filter((c) => !fid || c.fornecedor_id === fid);
  // Pastas com contrato ativo do fornecedor
  const pastasDoForn = (fid) => (S.base.pastas || []).filter((p) => S.base.contratos.some((c) => c.fornecedor_id === fid && c.situacao === 'ativo' && c.pasta_id === p.id));
  // ---------- Visão pessoal: "Meus contratos" = contratos em que sou supervisor ou contato, e fornecedores das pastas que assumi ----------
  const meuSupervisor = () => {
    const cad = S.cad || {}, eu = cad.colaborador_id ? COL(cad.colaborador_id) : null;
    const id = eu && eu.supervisor ? eu.id : cad.supervisor_id || null;
    return id && COL(id) ? id : null;
  };
  const meuColab = () => { const id = (S.cad || {}).colaborador_id; return id && COL(id) ? id : null; };
  const temEscopo = () => !!(S.base && (meuSupervisor() || meuColab() || S.base.pastas.some((p) => !p.padrao && minhaPasta(p))));
  const escopoMeu = () => S.escopo === 'meus' && temEscopo();
  const contratoEhMeu = (c) => !!c && ((!!meuSupervisor() && supsDe(c).includes(meuSupervisor()))
    || (!!meuColab() && (ctsDe(c).includes(meuColab()) || supsDe(c).includes(meuColab()))) || (!!PASTA(c.pasta_id) && !PASTA(c.pasta_id).padrao && minhaPasta(PASTA(c.pasta_id))));
  const contratoMeu = (c) => !escopoMeu() || contratoEhMeu(c);
  const fornecedorMeu = (fid) => !escopoMeu() || S.base.contratos.some((c) => c.fornecedor_id === fid && contratoEhMeu(c));
  const medMeu = (m) => contratoMeu(S.mapC[m.contrato_id]);
  const escopoRotulo = () => (meuSupervisor() ? COL(meuSupervisor()).nome : meuColab() ? COL(meuColab()).nome : 'suas pastas');
  // Aprovação de cadastros: administrador (todos) e supervisor (encaminhados a ele ou a qualquer responsável; só analista e leitura)
  const podeAprovar = () => S.papel === 'admin' || S.papel === 'supervisor';
  const meuUsuarioId = () => (S.usuarios.find((x) => (x.email || '').toLowerCase() === ((S.user || {}).email || '').toLowerCase()) || {}).id || null;
  const paraMim = (u) => u.status === 'pendente' && (!u.aprovador_id || u.aprovador_id === meuUsuarioId());
  const pendentesParaMim = () => S.usuarios.filter((u) => u.status === 'pendente' && (S.papel === 'admin' || paraMim(u)));
  const ESCOPO_VIEWS = ['painel', 'envio', 'pastas', 'receb', 'nf', 'pag', 'aval', 'contr', 'forn'];
  const escopoHTML = () => (temEscopo() && ESCOPO_VIEWS.includes(S.view) ? `<div class="seg escopo" role="group" aria-label="Exibir">
      <button type="button" data-act="escopo" data-v="todos" aria-pressed="${!escopoMeu()}">Todos</button>
      <button type="button" data-act="escopo" data-v="meus" aria-pressed="${escopoMeu()}" title="Contratos em que você é supervisor ou contato e contratos das pastas de que você é responsável">Meus contratos</button></div>` : '');
  const ordemCol = (a, b) => (a.ordem || 0) - (b.ordem || 0) || a.nome.localeCompare(b.nome);
  // Contatos Klingele mostrados ao fornecedor (até 5, na ordem cadastrada)
  const contatosFornecedor = () => (S.base.colaboradores || []).filter((c) => c.ativo && c.contato_fornecedor && (c.email || c.telefone)).sort(ordemCol).slice(0, 5);
  const supervisores = () => (S.base.colaboradores || []).filter((c) => c.ativo && c.supervisor).sort((a, b) => a.nome.localeCompare(b.nome));
  // Histórico dentro das gavetas: recolhido por padrão, abre no clique (a página Histórico mostra tudo)
  const retratil = (chave, titulo, n, corpo) => `<details class="retratil" data-ret="${chave}" ${S.ret[chave] ? 'open' : ''}>
    <summary><span class="ret-seta" aria-hidden="true">${ic.dir}</span><h3>${esc(titulo)}</h3><span class="ret-n">${n === null || n === undefined ? '' : n}</span></summary>
    <div class="ret-corpo">${corpo}</div></details>`;
  const contarRetratil = (chave, n) => { const el = document.querySelector(`[data-ret="${chave}"] .ret-n`); if (el) el.textContent = n; };
  const modalidadeDe = (f, comp) => U.modalidade(f, S.base.contratos, comp || S.comp, S.base.config);
  const chipModalidade = (k) => (k && U.MODALIDADE[k] ? `<span class="chip ${U.MODALIDADE[k][1]}" title="Motivo do envio do link">${esc(U.MODALIDADE[k][0])}</span>` : '');
  const cfgN = (k, p) => Number(cfgv(k, p)) || p;
  // Cobrança de quem não respondeu (mesma regra do banco): reenvio com novo prazo e, depois, lembrete semanal
  function cobrancaEtapa(s) {
    const auto = S.envios.filter((e) => e.solicitacao_id === s.id && e.autor === 'cobrança automática').sort((a, b) => (a.created_at < b.created_at ? -1 : 1));
    const n = auto.length, ult = n ? auto[n - 1].created_at : null, max = cfgN('cobranca_lembretes_max', 4), agora = new Date().toISOString();
    if (!s.enviado_em || s.recebido_em || !['enviado', 'aberto', 'expirado'].includes(s.status)) return { devida: false, etapa: 'fora', feitas: n };
    if (!n) return { devida: s.expira_em < agora, etapa: 'reenvio', dias: cfgN('cobranca_reenvio_dias', 10), feitas: 0, quando: s.expira_em };
    if (n - 1 >= max) return { devida: false, etapa: 'encerrada', feitas: n };
    const prox = new Date(new Date(ult).getTime() + cfgN('cobranca_intervalo_dias', 7) * 86400000).toISOString();
    return { devida: s.expira_em < agora || (n > 1 && prox <= agora), etapa: 'semanal', dias: cfgN('cobranca_semanal_dias', 5), feitas: n, semana: n, de: max,
      quando: n > 1 && prox < s.expira_em ? prox : s.expira_em };
  }
  function cobrancaTxt(s) {
    if (cfgv('cobranca_automatica', 'true') !== 'true') return '';
    const e = cobrancaEtapa(s);
    if (e.etapa === 'fora') return '';
    if (e.etapa === 'encerrada') return `Cobrança encerrada (${e.feitas} envios automáticos)`;
    const dia = U.dataBR(U.dataLocal(e.quando));
    if (e.etapa === 'reenvio') return e.devida ? `Reenvio com ${e.dias} dias úteis: no próximo envio automático` : `Sem resposta até ${dia}: reenvio com ${e.dias} dias úteis`;
    return `${e.feitas === 1 ? 'Reenviado pela cobrança' : `Lembrete semanal ${e.semana - 1} de ${e.de}`} · próximo ${e.devida ? 'no próximo envio automático' : 'em ' + dia}`;
  }
  // Em que ponto do fluxo do mês a medição está
  const ETAPAS = [['sem_envio', 'Sem link enviado', ''], ['aguardando', 'Aguardando boletim', 'info'], ['recebido', 'A conferir', 'warn'],
    ['conferido', 'Lançar F.S.', 'accent'], ['fs', 'Enviar F.S.', 'accent'], ['nf', 'Aguardando NF', 'info'], ['servicos', 'NF recebida', 'warn'], ['finalizado', 'Finalizado', 'ok']];
  const ETAPA = Object.fromEntries(ETAPAS.map(([k, t, c]) => [k, { k, txt: t, cls: c }]));
  function etapaFluxo(m) {
    if (m.status === 'sem_medicao') return { k: 'sem_medicao', txt: 'Sem medição', cls: '' };
    if (m.encaminhado_em || m.finalizado_em) return ETAPA.finalizado;
    if (S.nfNotas.some((x) => x.medicao_id === m.id && ['em_conferencia', 'aprovada'].includes(x.status))) return ETAPA.servicos;
    if (S.nfSolic.some((x) => x.medicao_id === m.id && ['enviada', 'aberta', 'recebida', 'aprovada'].includes(x.status))) return ETAPA.nf;
    if (m.folha_numero) return ETAPA.fs;
    if (['aprovado', 'pago'].includes(m.status)) return ETAPA.conferido;
    const s = S.solic.find((x) => x.id === m.solicitacao_id) || solicDe(m.fornecedor_id);
    if (['recebido', 'em_conferencia'].includes(m.status) || (s && ['recebido', 'conferido'].includes(s.status))) return ETAPA.recebido;
    if (s && s.enviado_em && !['cancelado'].includes(s.status)) return ETAPA.aguardando;
    return ETAPA.sem_envio;
  }
  // Aviso de vencimento do contrato: data do aviso e se já foi dado
  function alertaDe(c) {
    if (c.situacao !== 'ativo' || !c.data_fim) return null;
    const dias = U.alertaDias(c, S.base.config), data = U.addDias(c.data_fim, -dias), hoje = U.hojeISO();
    const av = (S.base.alertas || []).find((a) => a.contrato_id === c.id && a.data_fim === c.data_fim) || null;
    return { dias, data, avisado: av, janela: hoje >= data && c.data_fim >= hoje, vencido: c.data_fim < hoje };
  }

  async function carregarBase() {
    S.base = await API.carregarBase();
    S.base.colaboradores = S.base.colaboradores || [];
    S.mapF = {}; S.mapC = {}; S.mapCol = {};
    S.base.fornecedores.forEach((f) => { S.mapF[f.id] = f; f.contatos = f.contatos || []; });
    S.base.contratos.forEach((c) => { S.mapC[c.id] = c; });
    S.base.colaboradores.forEach((c) => { S.mapCol[c.id] = c; });
    // Responsáveis do contrato (o 1º supervisor é o principal) e pastas de fechamento
    S.base.contratos.forEach((c) => { c.supervisores = c.supervisores && c.supervisores.length ? c.supervisores : c.supervisor_id ? [c.supervisor_id] : []; c.contatos = c.contatos || []; c.pasta_id = c.pasta_id || null; });
    S.base.pastas = S.base.pastas || []; S.base.pastaExec = S.base.pastaExec || [];
    S.mapPasta = {};
    S.base.pastas.forEach((p) => { p.visibilidade = p.visibilidade || 'restrita'; p.calendario = p.calendario || 'mensal'; p.meses = p.meses || []; p.datas = p.datas || []; S.mapPasta[p.id] = p; });
    S.base.equipes = S.base.equipes || []; S.base.membros = S.base.membros || []; S.base.compart = S.base.compart || [];
    S.mapEq = {}; S.base.equipes.forEach((e) => { S.mapEq[e.id] = e; });
    S.memoP = null;
    S.parc = {};
    (S.base.parcelas || []).forEach((p) => { S.parc[p.contrato_id] = p; });
    S.fer = U.calendario(S.base.feriados);
    S.base.alertas = S.base.alertas || [];
    S.emailCfg = await API.emailConfigurado().catch(() => null);
    S.usuarios = podeAprovar() ? await API.usuarios().catch(() => []) : [];
    S.segPend = S.papel === 'admin' && API.eventosSeguranca ? await API.eventosSeguranca({ naoVistos: true, de: U.addDias(U.hojeISO(), -30), limite: 200 }).catch(() => []) : [];
    if (S.papel === 'admin' && API.webhookSituacao) [S.webhookSit, S.emailTeste] = await Promise.all([API.webhookSituacao().catch(() => null), API.emailTesteResultado().catch(() => null)]);
  }
  async function carregarComp() {
    const [solic, med, docs, periodo, envios, aval, avalPeriodo, nfSolic, nfNotas] = await Promise.all([
      API.solicitacoes(S.comp), API.medicoes(S.comp), API.documentos(S.comp), API.medicoesPeriodo(U.addMes(S.comp, -5), S.comp),
      API.enviosCompetencia(S.comp).catch(() => []), API.avaliacoes(S.comp).catch(() => []), API.avaliacoesPeriodo(U.addMes(S.comp, -5), S.comp).catch(() => []),
      API.solicitacoesNF(S.comp).catch(() => []), API.notasFiscais(S.comp).catch(() => [])
    ]);
    Object.assign(S, { solic, med, docs, periodo, envios, aval, avalPeriodo, nfSolic, nfNotas });
    S.memoP = null;
  }
  async function recarregar(tudo) {
    try {
      if (tudo) await carregarBase();
      await carregarComp();
      S.cache = { envios: null, hist: null, rotina: null, seg: null };
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  // ---------- Situações ----------
  const SOL = { gerado: ['Link gerado', ''], enviado: ['E-mail enviado', 'info'], aberto: ['Link aberto', 'info'], recebido: ['Recebido', 'accent'],
    conferido: ['Conferido', 'ok'], expirado: ['Expirado', 'crit'], cancelado: ['Cancelado', ''] };
  const MED = { aguardando: ['Aguardando', ''], recebido: ['Recebido', 'info'], em_conferencia: ['Em conferência', 'warn'], aprovado: ['Aprovado', 'accent'],
    pago: ['Pago', 'ok'], sem_medicao: ['Sem medição', ''] };
  const chip = (cls, txt) => `<span class="chip ${cls}">${esc(txt)}</span>`;
  const chipSol = (s) => (s ? (s.dispensa ? `<span class="chip" title="Envio desligado só neste mês e nesta pasta">${esc(U.DISPENSA_TXT[s.dispensa])}</span>` : chip(SOL[s.status][1], SOL[s.status][0])) : chip('', 'Sem link'));
  // ---------- Documentos da Klingele para a medição (fornecedor marcado) e envio dispensado no mês ----------
  const docsKlg = (sid) => (sid ? S.docs.filter((d) => d.solicitacao_id === sid && d.tipo === 'klingele') : []);
  const pedeDocs = (f) => !!(f && f.docs_klingele);
  const colabDocs = (f) => { const c = f && f.docs_colaborador_id ? COL(f.docs_colaborador_id) : null;
    return c && c.ativo && c.email ? c : ((S.base.colaboradores || []).find((x) => x.ativo && x.email && f && f.docs_analista && x.email.toLowerCase() === f.docs_analista.toLowerCase()) || null); };
  const dispensaTxt = (s) => (s && s.dispensa ? `Envio desligado no mês${s.dispensa_por ? ' · informado por ' + s.dispensa_por : ''}${s.dispensa_em ? ' em ' + U.dataHoraBR(s.dispensa_em) : ''}` : '');
  function chipDocs(f, s) {
    if (s && s.dispensa) return '';
    if (!pedeDocs(f) || (s && ['recebido', 'conferido'].includes(s.status))) return '';
    const n = s ? docsKlg(s.id).length : 0;
    return n ? `<span class="chip ok" title="Documentos que o fornecedor baixa no link">${n} doc${n > 1 ? 's' : ''} da Klingele</span>`
      : '<span class="chip warn" title="O envio automático aguarda os documentos da Klingele">Aguardando docs da Klingele</span>';
  }
  const linkDocs = (s) => (cfg.portalUrl ? cfg.portalUrl.replace(/portal\.html.*$/, 'documentos.html') : new URL('documentos.html', location.href).href.split('#')[0].split('?')[0]) + '#' + s.docs_token;
  const chipMed = (m) => chip(MED[m.status][1], MED[m.status][0]);
  function comparar(m) {
    const med = medido(m), ct = num(m.valor_contratado) || 0;
    if (m.status === 'sem_medicao') return { cls: '', txt: 'Sem medição', diff: null, pct: null };
    if (med === null) return { cls: '', txt: 'Aguardando', diff: null, pct: null };
    const diff = med - ct, pct = ct ? diff / ct : null;
    if (Math.abs(diff) <= Math.max(1, ct * 0.005)) return { cls: 'ok', txt: 'Conforme', diff, pct };
    return diff > 0 ? { cls: 'crit', txt: 'Acima do contrato', diff, pct } : { cls: 'info', txt: 'Abaixo do contrato', diff, pct };
  }
  const divergente = (m) => num(m.valor_informado) !== null && num(m.valor_lido) !== null && Math.abs(num(m.valor_informado) - num(m.valor_lido)) > 1;
  function vigencia(c) {
    if (c.situacao !== 'ativo') return { cls: '', txt: { finalizado: 'Finalizado', nao_iniciado: 'Não iniciado', suspenso: 'Suspenso' }[c.situacao] || c.situacao };
    if (!c.data_fim) return { cls: '', txt: 'Sem data final' };
    const d = U.diffDias(U.hojeISO(), c.data_fim);
    if (d < 0) return { cls: 'crit', txt: `Vencido há ${-d} dias`, dias: d };
    if (d <= 60) return { cls: 'warn', txt: `Vence em ${d} dias`, dias: d };
    if (d <= 120) return { cls: 'info', txt: `Vence em ${d} dias`, dias: d };
    return { cls: 'ok', txt: `${d} dias`, dias: d };
  }
  const diffHTML = (r) => {
    if (r.diff === null) return '<span class="muted">—</span>';
    const cls = r.cls === 'ok' ? 'diff-zero' : r.diff > 0 ? 'diff-pos' : 'diff-neg';
    return `<span class="num ${cls}">${r.diff > 0 ? '+' : ''}${U.brl(r.diff)}</span><div class="cell-sub num">${U.pct(r.pct)}</div>`;
  };
  function prazoTxt(s) {
    if (!s || !['gerado', 'enviado', 'aberto'].includes(s.status)) return '';
    const fim = U.dataLocal(s.expira_em), r = U.diasUteisAte(fim, S.fer);
    return `até ${U.dataBR(fim)} · ${r === 0 ? 'último dia' : r === 1 ? '1 dia útil' : r + ' dias úteis'}`;
  }
  // Link do fornecedor no mês: da pasta indicada (null = avulso; sem informar = qualquer) — o ativo ou o mais recente
  function solicDe(fid, pid) {
    const doF = S.solic.filter((s) => s.fornecedor_id === fid && (pid === undefined || (s.pasta_envio_id || null) === (pid || null)));
    return doF.find((s) => !['cancelado', 'expirado'].includes(s.status)) || doF.sort((a, b) => (a.created_at < b.created_at ? 1 : -1))[0] || null;
  }
  function contratosPrevistos(fid, pid) {
    const ini = S.comp, fim = U.fimMes(S.comp);
    const ativos = S.base.contratos.filter((c) => c.fornecedor_id === fid && c.situacao === 'ativo' && (pid === undefined || (c.pasta_id || null) === (pid || null)));
    const vig = ativos.filter((c) => (!c.data_inicio || c.data_inicio <= fim) && (!c.data_fim || c.data_fim >= ini));
    if (vig.length) return vig;
    const max = ativos.reduce((m, c) => (c.data_fim > m ? c.data_fim : m), '');
    return ativos.filter((c) => c.data_fim === max);
  }
  // Pedidos de um link: as medições ligadas a ele (ou, antes de gerar, os contratos previstos da pasta)
  function servicosDoLink(s) {
    const meds = S.med.filter((m) => m.solicitacao_id === s.id);
    return meds.length ? meds.map((m) => C(m.contrato_id)).filter(Boolean).sort((a, b) => a.pedido - b.pedido) : contratosPrevistos(s.fornecedor_id, s.pasta_envio_id || null);
  }
  function servicosDe(fid, pid) {
    const s = solicDe(fid, pid);
    return s && s.status !== 'cancelado' ? servicosDoLink(s) : contratosPrevistos(fid, pid);
  }
  const destinatarios = (s) => {
    const cs = (F(s.fornecedor_id).contatos || []).filter((c) => c.recebe_boletim).sort((a, b) => b.principal - a.principal).map((c) => c.email);
    return cs.length ? cs : (s.emails_destino || []);
  };
  const linkPortal = (s) => (cfg.portalUrl || new URL('portal.html', location.href).href.split('#')[0].split('?')[0]) + '#' + s.token;
  const aindaValido = (s) => !!s && ['gerado', 'enviado', 'aberto'].includes(s.status) && new Date(s.expira_em) > new Date();
  function emailDe(s, manter) {
    const f = F(s.fornecedor_id);
    const prazoISO = manter ? s.expira_em : aindaValido(s) || s.status === 'gerado' ? U.fimPrazoISO(new Date().toISOString(), prazoDias(s.pasta_envio_id), S.fer) : s.expira_em;
    const m = U.montarEmail({ modeloAssunto: cfgv('modelo_assunto', ''), modeloCorpo: cfgv('modelo_corpo', ''), fornecedor: f.nome, competencia: s.competencia,
      servicos: servicosDoLink(s), link: linkPortal(s), prazoISO, prazoDias: prazoDias(s.pasta_envio_id), suporte: contatosFornecedor(), suporteServicos: servicosSuporte(servicosDoLink(s)),
      documentos: docsKlg(s.id).map((d) => d.nome_padrao || d.nome_arquivo) });
    if (manter) m.assunto = 'LEMBRETE - ' + m.assunto;
    return m;
  }
  // ---------- Registro de envios ----------
  const TIPO_ENVIO = { envio: 'Envio', reenvio: 'Reenvio', lembrete: 'Lembrete', fs_aprovada: 'Aviso de F.S. aprovada', vencimento: 'Aviso de vencimento', nf_servicos: 'NF encaminhada a Serviços' };
  const VIA_ENVIO = { outlook: 'Outlook', app: 'pelo app', automatico: 'automático' };
  const ST_ENVIO = { registrado: ['Registrado (Outlook)', ''], pendente: ['Na fila do serviço', 'info'], aceito: ['Aceito pelo serviço', 'ok'],
    falha: ['Falha no envio', 'crit'], desconhecido: ['Sem confirmação', 'warn'],
    entregue: ['Entregue', 'ok'], atrasado: ['Entrega atrasada', 'warn'], devolvido: ['Devolvido', 'crit'], spam: ['Marcado como spam', 'crit'] };
  const chipEnvio = (e) => {
    const [t, c] = ST_ENVIO[e.status] || [e.status, ''];
    const dica = e.erro || (e.entrega_detalhe ? e.entrega_detalhe + (e.entrega_em ? ' · ' + U.dataHoraBR(e.entrega_em) : '') : '');
    return `<span class="chip ${c}"${dica ? ` title="${esc(dica)}"` : ''}>${esc(t)}</span>`;
  };
  const enviosDa = (sid) => S.envios.filter((e) => e.solicitacao_id === sid).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));

  // ---------- Estrutura ----------
  // Usuário no rodapé do menu: iniciais, nome e perfil de acesso (abre Meu perfil)
  function railUserHTML() {
    const nome = (S.cad && S.cad.nome) || (S.user ? S.user.email : '') || 'Usuário';
    const ini = nome.split(/[\s@._-]+/).filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');
    return `<span class="ru-av" aria-hidden="true">${esc(ini)}</span><span class="ru-t"><b>${esc(nome)}</b><span>${esc(PAPEL[S.papel] || '')}${S.cad && S.cad.nome && S.user ? ' · ' + esc(S.user.email) : ''}</span></span>`;
  }
  function shell() {
    root.innerHTML = `<div class="shell">
      <aside class="rail">
        ${U.marca('Boletim Mensal Klingele')}
        <nav class="nav" aria-label="Seções" id="nav"></nav>
        <div class="rail-foot">
          <button type="button" class="rail-user" data-act="ir-perfil" title="Meu perfil"></button>
          <div class="rail-actions">
            <button type="button" data-act="tema" aria-label="Alternar tema claro e escuro"><span class="ra-ic" id="tema-ic">${U.tema.atual() === 'dark' ? ic.sol : ic.lua}</span><span id="tema-txt">${U.tema.atual() === 'dark' ? 'Tema claro' : 'Tema escuro'}</span></button>
            <button type="button" data-act="sair" aria-label="Sair" title="Sair"><span class="ra-ic">${ic.sair}</span><span>Sair</span></button>
          </div>
        </div>
      </aside>
      <div class="nav-fundo" data-act="nav-mais" aria-hidden="true"></div>
      <main class="main" id="main"></main>
    </div>`;
  }
  // ---------- Envio do mês: um link por fornecedor e por pasta ----------
  // Filtro de pasta ('' = todas, 'avulsos' = contratos sem pasta, ou o id da pasta)
  const pastaFiltro = () => (S.f.pasta && S.f.pasta !== 'avulsos' ? PASTA(S.f.pasta) : null);
  // Linhas do mês: fornecedores com contrato da pasta no mês (ou com link dela) — cada par fornecedor + pasta é um link
  function linhasEnvio() {
    const out = [], visto = new Set();
    const add = (fid, pid) => {
      const k = fid + '|' + (pid || ''); if (visto.has(k)) return; visto.add(k);
      const f = F(fid); if (!f || !f.id) return;
      out.push({ f, pid: pid || null, s: solicDe(fid, pid || null) });
    };
    // pasta de meses escolhidos ou de datas marcadas só entra nos meses que ela pede (ou se já tem link no mês)
    Object.keys(memoPastas().forns).filter((k) => !k || !PASTA(k) || U.pastaPedeComp(PASTA(k), S.comp)).forEach((k) => fornsDaPasta(k || null).forEach((fid) => add(fid, k || null)));
    S.solic.forEach((s) => add(s.fornecedor_id, s.pasta_envio_id || null));
    return out.filter((x) => fornecedorMeu(x.f.id)).sort((a, b) => a.f.nome.localeCompare(b.f.nome));
  }
  // Links do mês ainda a enviar: Envio mensal sem link e links gerados e não enviados (pastas que a pessoa vê)
  const pendEnvioN = () => {
    if (!compLiberada(S.comp)) return 0;
    const pad = pastaPadrao();
    return linhasEnvio().filter((x) => x.pid && (PASTA(x.pid) || {}).id && ((x.s && x.s.status === 'gerado') || (!x.s && pad && x.pid === pad.id))).length;
  };
  // Última execução e próximo disparo de cada pasta
  function ultimaExecPasta(p) {
    return (S.base.pastaExec || []).find((x) => x.detalhes && x.detalhes.ok !== false && (x.detalhes.pasta_id === p.id || (p.padrao && x.origem === 'envio automático' && !x.detalhes.pasta_id))) || null;
  }
  const agoraHHMM = () => { const d = new Date(); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  function proximoEnvioPasta(p) {
    const px = U.proximoDisparo(p, S.fer, agoraHHMM());
    if (!px) return null;
    const ult = ultimaExecPasta(p);
    // já disparou nesta competência (mensal/meses): o próximo é o seguinte
    if (ult && p.calendario !== 'datas' && ult.detalhes.competencia === px.competencia.slice(0, 7) && px.data === U.hojeISO()) {
      const q = U.proximoDisparo({ ...p, datas: [] }, S.fer, '23:59');
      return q;
    }
    return px;
  }
  const proxTxt = (p) => {
    if (p.calendario === 'manual') return 'Só pelo botão "Enviar agora"';
    if (p.ativa === false) return 'Disparo automático desligado';
    const px = proximoEnvioPasta(p);
    return px ? `Próximo: ${U.dataBR(px.data)} (${U.DIAS_SEMANA[U.diaSemana(px.data)]}) às ${p.horario}, pedindo ${U.compLabel(px.competencia)}` : 'Sem data futura marcada';
  };
  const pastaChip = (pid) => {
    if (!pid) return '<span class="chip plain com-ic" title="Contratos sem pasta: o link só sai pelo botão">' + ic.pasta + 'Avulso</span>';
    const p = PASTA(pid);
    if (!p) return `<span class="chip plain com-ic" title="Pasta que você não vê">${ic.pasta}Pasta de outra pessoa</span>`;
    return `<span class="chip ${p.padrao ? 'accent' : 'info'} plain com-ic" title="${esc(U.calendarioTxt(p))}">${ic.pasta}${esc(p.nome)}</span>`;
  };
  const nomeEquipe = (email) => { const m = (S.base.equipe || []).find((x) => (x.email || '').toLowerCase() === email); return m ? m.nome || m.email : email + ' (sem acesso)'; };
  const VIS_PASTA = { restrita: 'Só quem eu compartilhar', todos_ver: 'Todos os usuários veem', todos_editar: 'Todos os usuários veem e editam' };
  const NIVEL_TXT = { dono: 'Sua pasta', gerir: 'Pode gerir', editar: 'Pode editar', ver: 'Só visualização' };
  const NIVEIS_COMP = [['ver', 'Pode ver'], ['editar', 'Pode editar'], ['gerir', 'Pode gerir']];
  // Resumo de quem vê a pasta: "Só você", "Equipe Manutenção (edita) · Beto (gere)", "Todos veem"
  function compartTxt(p) {
    if (p.padrao) return 'Todos veem · administradores e supervisores gerem';
    const cs = (S.base.compart || []).filter((c) => c.pasta_id === p.id);
    const nv = { editar: ' (edita)', gerir: ' (gere)' };
    const nomes = cs.map((c) => (c.alvo_tipo === 'equipe' ? `Equipe ${(S.mapEq[c.alvo] || {}).nome || '—'}` : nomeEquipe(c.alvo)) + (nv[c.nivel] || ''));
    const base = p.visibilidade === 'todos_ver' ? 'Todos veem' : p.visibilidade === 'todos_editar' ? 'Todos veem e editam' : '';
    if (!nomes.length) return base || (p.criado_por === EU() ? 'Só você' : 'Restrita');
    return [base, nomes.join(', ')].filter(Boolean).join(' · ');
  }
  const filtroTxt = (f) => {
    if (!f) return '';
    const p = [];
    if ((f.tipos || []).length) p.push(f.tipos.map((k) => (U.FILTRO_TIPOS.find((x) => x[0] === k) || [k, k])[1]).join(' ou '));
    if ((f.supervisores || []).length) p.push('supervisor: ' + nomesCol(f.supervisores).join(', '));
    if ((f.contatos || []).length) p.push('contato: ' + nomesCol(f.contatos).join(', '));
    if ((f.equipes || []).length) p.push('equipe: ' + f.equipes.map((id) => (S.mapEq[id] || {}).nome || '—').join(', '));
    if (f.texto) p.push(`contém "${f.texto}"`);
    return p.join(' · ');
  };
  // Andamento da pasta na competência da tela: links gerados, enviados e respondidos
  function cicloPasta(pid) {
    const ls = linhasEnvio().filter((x) => (x.pid || null) === (pid || null));
    const ativos = ls.map((x) => x.s).filter((s) => s && s.status !== 'cancelado');
    return { n: ls.length, gerados: ativos.length, enviados: ativos.filter((s) => s.enviado_em).length, respondidos: ativos.filter((s) => ['recebido', 'conferido'].includes(s.status)).length };
  }
  const contratosAtivosPasta = (pid) => S.base.contratos.filter((c) => c.situacao === 'ativo' && (c.pasta_id || null) === (pid || null) && (S.mapF[c.fornecedor_id] || {}).ativo);

  // ---------- Página Pastas ----------
  VIEWS.pastas = () => {
    const ps = S.base.pastas.filter(nivelPasta).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome));
    const pode = S.papel !== 'leitura';
    const avs = contratosAtivosPasta(null).filter(contratoMeu).sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || (a.pedido || 0) - (b.pedido || 0));
    const ocultos = S.base.contratos.filter((c) => c.situacao === 'ativo' && c.pasta_id && !PASTA(c.pasta_id)).length;
    const destinos = S.base.pastas.filter((p) => podePorNaPasta(p.id)).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome));
    const card = (p) => {
      const nv = nivelPasta(p), ult = ultimaExecPasta(p), ci = cicloPasta(p.id);
      const nC = contratosAtivosPasta(p.id).length, nF = new Set(contratosAtivosPasta(p.id).map((c) => c.fornecedor_id)).size;
      const opts = [p.prazo_dias ? `prazo de ${p.prazo_dias} dias úteis` : '', p.cobranca === false ? 'sem cobrança automática' : '', p.avaliacao === false ? 'sem avaliação junto' : ''].filter(Boolean);
      return `<article class="pasta-card${p.padrao ? ' padrao' : ''}${p.ativa === false && p.calendario !== 'manual' ? ' desligada' : ''}" data-pasta="${p.id}">
        <div class="pc-topo"><span class="pasta-ic" aria-hidden="true">${ic.pasta}</span>
          <div class="pc-t"><h3>${esc(p.nome)}</h3>
            <div class="row" style="gap:6px">${p.padrao ? chip('accent', 'Pasta padrão') : ''}${chip('plain', NIVEL_TXT[nv] || '')}${p.ativa === false && p.calendario !== 'manual' ? chip('warn', 'Disparo desligado') : ''}</div></div></div>
        ${p.descricao ? `<p class="small muted clamp2" style="margin:0">${esc(p.descricao)}</p>` : ''}
        <dl class="pc-dados">
          <div><dt>Quando</dt><dd>${esc(U.calendarioTxt(p))}</dd></div>
          <div><dt>Disparo</dt><dd>${esc(proxTxt(p))}</dd></div>
          <div><dt>Contratos</dt><dd>${nC} contrato${nC !== 1 ? 's' : ''} · ${nF} fornecedor${nF !== 1 ? 'es' : ''}${p.filtro ? ` · contratos novos entram se: ${esc(filtroTxt(p.filtro))}` : ''}</dd></div>
          <div><dt>No mês</dt><dd>${esc(U.compLabel(S.comp))}: ${ci.n ? `${ci.enviados} de ${ci.n} link${ci.n !== 1 ? 's' : ''} enviado${ci.enviados !== 1 ? 's' : ''} · ${ci.respondidos} respondido${ci.respondidos !== 1 ? 's' : ''}` : U.pastaPedeComp(p, S.comp) ? 'nenhum contrato vigente' : 'a pasta não pede este mês'}</dd></div>
          <div><dt>Responsável</dt><dd>${p.responsavel ? esc(nomeEquipe(p.responsavel)) : '<span class="muted">ninguém (sem resumo por e-mail)</span>'}</dd></div>
          <div><dt>Acesso</dt><dd>${esc(compartTxt(p))}</dd></div>
          ${opts.length ? `<div><dt>Opções</dt><dd>${esc(opts.join(' · ').replace(/^./, (x) => x.toUpperCase()))}</dd></div>` : ''}
          ${ult ? `<div><dt>Último</dt><dd>${U.dataHoraBR(ult.executado_em)} · ${esc(U.compLabel(ult.detalhes.competencia + '-01'))} · ${ult.detalhes.enviados || 0} enviado${ult.detalhes.enviados === 1 ? '' : 's'}</dd></div>` : ''}
        </dl>
        <div class="pasta-acts">
          <button class="btn sm" data-act="pasta-filtrar" data-id="${p.id}">${ic.envio} Ver links</button>
          <button class="btn sm ${podeEditarPasta(p) ? 'primary' : ''}" data-act="abrir-pasta" data-id="${p.id}">${podeEditarPasta(p) ? `${ic.lapis} Editar` : `${ic.olho} Abrir`}</button></div>
      </article>`;
    };
    return `
      <section class="panel" id="sec-pastas">
        <div class="panel-head"><div><h2>${ps.length} pasta${ps.length !== 1 ? 's' : ''} · ${avs.length} contrato${avs.length !== 1 ? 's' : ''} avulso${avs.length !== 1 ? 's' : ''}</h2>
          <span class="sub">Cada contrato fica em uma pasta só. A pasta diz quando o fornecedor recebe o link (todo mês, em meses escolhidos, em datas marcadas ou só pelo botão), quem é o responsável e quem pode mexer. O Envio mensal é a rotina base do mês.</span></div>
          ${pode ? `<button class="btn sm primary" data-act="nova-pasta">${ic.mais} Nova pasta</button>` : ''}</div>
        <div class="pastas-grid">${ps.map(card).join('')}</div>
        ${ocultos ? `<p class="small muted" style="margin:0;padding:0 18px 16px">${ocultos} contrato${ocultos !== 1 ? 's' : ''} em pastas que não foram compartilhadas com você.</p>` : ''}
      </section>
      <details class="panel retratil-painel" id="sec-avulsos" ${avs.length && lembrado('bmk-pastas-avulsos') ? 'open' : ''} data-lembrar="bmk-pastas-avulsos">
        <summary class="panel-head" style="cursor:pointer"><div><h2>Contratos avulsos (${avs.length})</h2>
          <span class="sub">Contratos ativos fora de qualquer pasta: não recebem link automático. Gere o link avulso no Envio do mês ou ponha numa pasta.</span></div></summary>
        ${avs.length ? `${pode && destinos.length ? `<div class="panel-body row" style="gap:8px;border-bottom:1px solid var(--line)">
            <label class="check sm"><input type="checkbox" id="av-todos" aria-label="Marcar todos"> Todos</label>
            <select id="av-destino" aria-label="Pasta de destino" style="width:auto;max-width:260px"><option value="">Mover os marcados para…</option>${destinos.map((p) => `<option value="${p.id}">${esc(p.nome)}</option>`).join('')}</select>
            <button class="btn sm primary" data-act="avulsos-mover">${ic.ok} Mover</button></div>` : ''}
          <div class="table-wrap"><table class="tbl"><thead><tr>${pode ? '<th class="sel"></th>' : ''}<th>Fornecedor</th><th>Contrato</th><th>Tipo</th><th>Vigência</th></tr></thead><tbody>
          ${avs.map((c) => { const v = vigencia(c); return `<tr>${pode ? `<td class="sel"><input type="checkbox" data-av="${c.id}" aria-label="Marcar ${esc(c.titulo)}"></td>` : ''}
            <td data-label="Fornecedor"><div class="cell-title">${esc(F(c.fornecedor_id).nome)}</div></td>
            <td data-label="Contrato"><div class="clamp2">${esc(c.titulo)}</div><div class="cell-sub mono">${esc(c.pedido || '—')}</div></td>
            <td data-label="Tipo" class="small">${esc(U.tipoServicoTxt(c.tipo_servico) || 'Sem tipo')}</td>
            <td data-label="Vigência">${chip(v.cls, v.txt)}</td></tr>`; }).join('')}
          </tbody></table></div>` : '<div class="panel-body"><p class="muted" style="margin:0">Todos os contratos ativos estão em alguma pasta.</p></div>'}
      </details>`;
  };

  // ---------- Gaveta da pasta: calendário, opções do link, contratos, regra para contratos novos, responsável e acessos ----------
  const MESES_TXT = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
  function abrirPasta(id, rascunho, alvo) {
    const base = id ? PASTA(id) : null;
    if (id && !base) return;
    const p = rascunho || (base ? JSON.parse(JSON.stringify(base)) : { nome: '', descricao: '', calendario: 'mensal', dia_util: 1, horario: '08:00', meses: [], datas: [], pede: 'mes_anterior',
      ativa: true, responsavel: EU(), prazo_dias: null, cobranca: true, avaliacao: true, visibilidade: 'restrita', filtro: null });
    const nv = base ? nivelPasta(base) : 'dono';
    const pode = !base ? S.papel !== 'leitura' : podeEditarPasta(base), gere = !base || podeGerirPasta(base);
    if (!rascunho) {
      S.gaveta = { tipo: 'pasta', id: id || null, sel: new Set(S.base.contratos.filter((c) => id && c.pasta_id === id).map((c) => c.id)),
        comp: (S.base.compart || []).filter((c) => c.pasta_id === id).map((c) => ({ alvo_tipo: c.alvo_tipo, alvo: c.alvo, nivel: c.nivel })),
        regraOn: !!(base && base.filtro), cBusca: '', cVer: id ? 'marcados' : 'avulsos' };
    }
    const g = S.gaveta, dis = pode ? '' : 'disabled', padrao = !!(base && base.padrao);
    g.cal = p.calendario || 'mensal';
    const calBtn = (v, t) => `<button type="button" data-act="pasta-cal" data-v="${v}" aria-pressed="${g.cal === v}" ${dis || (padrao && v !== 'mensal') ? 'disabled' : ''}>${t}</button>`;
    const diaSel = `<label class="field"><span>Dia</span><select id="pa-dia" ${dis}><option value="0" ${Number(p.dia_util) === 0 ? 'selected' : ''}>Último dia útil do mês (pede o próprio mês)</option>
        ${Array.from({ length: 10 }, (_, i) => i + 1).map((n) => `<option value="${n}" ${Number(p.dia_util) === n ? 'selected' : ''}>${n}º dia útil do mês seguinte (pede o mês anterior)</option>`).join('')}</select></label>`;
    const horaSel = `<label class="field"><span>Horário</span><select id="pa-hora" ${dis}>${U.HORARIOS.map((h) => `<option ${p.horario === h ? 'selected' : ''}>${h}</option>`).join('')}</select></label>`;
    const usuariosEnvio = (S.base.equipe || []).filter((m) => ['admin', 'supervisor', 'analista'].includes(m.papel)).sort((a, b) => (a.nome || a.email).localeCompare(b.nome || b.email));
    const prev = { ...p, calendario: g.cal };
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">${id ? `${padrao ? 'Pasta padrão' : 'Pasta'} · ${esc(NIVEL_TXT[nv] || '')}` : 'Nova pasta'}</span><h2>${esc(p.nome || 'Cadastro de pasta')}</h2></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        ${!pode ? '<p class="hint" style="margin:0">Esta pasta foi compartilhada com você só para visualização.</p>' : ''}
        <div class="form-grid">
          <label class="field full"><span>Nome da pasta</span><input type="text" id="pa-nome" maxlength="80" value="${esc(p.nome || '')}" placeholder="Ex.: Serviços Spot de obras" ${dis}></label>
          <label class="field full"><span>Descrição <span class="hint">(opcional: para que serve a pasta)</span></span><input type="text" id="pa-desc" maxlength="300" value="${esc(p.descricao || '')}" ${dis}></label>
        </div>
        <section><div class="section-title"><h3>Quando o link sai</h3></div>
          <div class="seg seg-cal" role="group" aria-label="Calendário da pasta">${calBtn('mensal', 'Todo mês')}${calBtn('meses', 'Meses escolhidos')}${calBtn('datas', 'Datas marcadas')}${calBtn('manual', 'Só manual')}</div>
          ${padrao ? '<p class="hint" style="margin:6px 0 0">O Envio mensal é a rotina base: dispara todo mês.</p>' : ''}
          <div class="form-grid" style="margin-top:10px">
            ${g.cal === 'mensal' || g.cal === 'meses' ? diaSel + horaSel : ''}
            ${g.cal === 'meses' ? `<div class="field full"><span>Meses em que o link sai</span><div class="meses-grid">${MESES_TXT.map((m, i) => `<label class="check sm"><input type="checkbox" data-pmes value="${i + 1}" ${(p.meses || []).includes(i + 1) ? 'checked' : ''} ${dis}> ${m}</label>`).join('')}</div>
              <span class="hint">Ex.: mar, jun, set e dez para serviços trimestrais.</span></div>` : ''}
            ${g.cal === 'datas' ? `<div class="field full"><span>Datas (dias úteis)</span>
                <div class="datas-lista">${(p.datas || []).slice().sort().map((d) => `<span class="tag">${U.dataBR(d)} <button type="button" class="tag-x" data-act="pasta-rm-data" data-d="${d}" aria-label="Tirar ${U.dataBR(d)}" ${dis}>${ic.x}</button></span>`).join('') || '<span class="small muted">Nenhuma data marcada.</span>'}</div>
                ${pode ? `<div class="row" style="gap:8px;margin-top:6px"><input type="date" id="pa-nova-data" min="${U.hojeISO()}" style="width:auto"><button type="button" class="btn sm" data-act="pasta-add-data">${ic.mais} Adicionar data</button></div>` : ''}
                <span class="hint">Por exemplo, a data combinada para o fim do serviço. Sábado, domingo e feriado não são aceitos.</span></div>
              ${horaSel}
              <label class="field"><span>O link pede</span><select id="pa-pede" ${dis}><option value="mes_anterior" ${p.pede !== 'mes_atual' ? 'selected' : ''}>O mês anterior à data</option><option value="mes_atual" ${p.pede === 'mes_atual' ? 'selected' : ''}>O mês da data</option></select></label>` : ''}
            ${g.cal === 'manual' ? '<p class="hint full" style="margin:0">O link só sai quando alguém da pasta clicar em "Enviar agora" (na pasta ou no Envio do mês), na competência escolhida na tela.</p>' : ''}
          </div>
          ${g.cal !== 'manual' ? `<div class="auto-grid" style="margin-top:10px">
            <div style="min-width:0"><b>Disparo automático</b><div class="small muted" id="pa-prox">${esc(p.ativa === false ? 'Desligado: o link só sai pelo botão' : proxTxt(prev))}</div></div>
            <label class="switch"><input type="checkbox" id="pa-ativa" ${p.ativa !== false ? 'checked' : ''} ${dis} aria-label="Disparo automático"><i></i></label></div>` : ''}
        </section>
        <section><div class="section-title"><h3>Opções do link</h3></div>
          <div class="auto-grid">
            <div style="min-width:0"><b>Prazo para o fornecedor responder</b><div class="small muted">Em dias úteis. Vazio = o padrão (${prazoDias()} dias úteis).</div></div>
            <input type="number" id="pa-prazo" min="1" max="30" value="${esc(p.prazo_dias || '')}" placeholder="${prazoDias()}" style="width:90px" ${dis} aria-label="Prazo do link">
            <div style="min-width:0"><b>Cobrança de quem não respondeu</b><div class="small muted">Reenvio e lembretes automáticos (regra em Configurações > Link e cobrança).</div></div>
            <label class="switch"><input type="checkbox" id="pa-cob" ${p.cobranca !== false ? 'checked' : ''} ${dis} aria-label="Cobrança automática"><i></i></label>
            <div style="min-width:0"><b>Avaliação de satisfação junto</b><div class="small muted">O supervisor recebe a avaliação no mesmo envio do link.</div></div>
            <label class="switch"><input type="checkbox" id="pa-aval" ${p.avaliacao !== false ? 'checked' : ''} ${dis} aria-label="Avaliação junto"><i></i></label>
          </div>
        </section>
        <section id="pa-contratos-sec"><div class="section-title"><h3>Contratos da pasta <span class="muted" id="pa-ncontr">(${g.sel.size})</span></h3></div>
          <p class="hint" style="margin:0 0 8px">Cada contrato fica em uma pasta só: marcar aqui tira o contrato da pasta em que ele estava. Desmarcado, ele fica avulso.</p>
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <div class="search" style="flex:1 1 220px">${ic.busca}<input type="search" id="pa-cbusca" placeholder="Buscar fornecedor, pedido ou serviço" value="${esc(g.cBusca)}" aria-label="Buscar contrato"></div>
            <select id="pa-cver" aria-label="Mostrar" style="width:auto">${[['marcados', 'Só os da pasta'], ['avulsos', 'Avulsos'], ['todos', 'Todos os contratos ativos']].map(([v, t]) => `<option value="${v}" ${g.cVer === v ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
          <div id="pa-clista" class="pa-clista">${listaContratosPastaHTML(pode)}</div>
        </section>
        ${padrao ? '' : `<section><div class="section-title"><h3>Regra para contratos novos</h3></div>
          <label class="check"><input type="checkbox" id="pa-regra-on" ${g.regraOn ? 'checked' : ''} ${dis}> Contratos novos que cumprirem a regra entram sozinhos nesta pasta</label>
          ${g.regraOn ? filtroPastaHTML(pode, p.filtro || {}) : '<p class="hint" style="margin:6px 0 0">Sem regra, os contratos novos vão para o Envio mensal (se forem contínuos) ou ficam avulsos.</p>'}
        </section>`}
        <section id="pa-acessos"><div class="section-title"><h3>Responsável e acessos</h3></div>
          ${acessosPastaHTML(base, p, gere, usuariosEnvio)}
        </section>
      </div>
      <div class="drawer-foot">
        ${id && !padrao && gere && S.papel !== 'leitura' ? `<button class="btn danger" data-act="excluir-pasta">${ic.lixo} Excluir</button>` : ''}
        ${id && podeEnviarPasta(base) ? `<button class="btn" data-act="pasta-enviar" data-id="${id}">${ic.envio} Enviar agora</button>` : ''}<span class="spacer"></span>
        <button class="btn" data-act="fechar-gaveta">${pode ? 'Cancelar' : 'Fechar'}</button>
        ${pode ? `<button class="btn primary" data-act="salvar-pasta">${ic.ok} Salvar</button>` : ''}
      </div>`);
    if (alvo) { const x = document.getElementById(alvo); if (x) x.scrollIntoView({ block: 'start' }); }
    if (g.regraOn) atualizarPreviaFiltro();
  }
  // Lista de contratos na gaveta da pasta (busca e "mostrar" filtram sem recriar a gaveta)
  function listaContratosPastaHTML(pode) {
    const g = S.gaveta, t = (g.cBusca || '').trim().toLowerCase();
    const cs = S.base.contratos.filter((c) => (c.situacao === 'ativo' || g.sel.has(c.id)) && (S.mapF[c.fornecedor_id] || {}).id)
      .filter((c) => g.cVer === 'todos' || (g.cVer === 'marcados' ? g.sel.has(c.id) : !c.pasta_id || g.sel.has(c.id)))
      .filter((c) => !t || [F(c.fornecedor_id).nome, c.pedido, c.titulo].join(' ').toLowerCase().includes(t))
      .sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || (a.pedido || 0) - (b.pedido || 0));
    if (!cs.length) return `<p class="small muted" style="margin:8px 0">${g.cVer === 'marcados' ? 'Nenhum contrato na pasta. Escolha "Avulsos" ou "Todos os contratos ativos" para incluir.' : 'Nenhum contrato encontrado.'}</p>`;
    return cs.slice(0, 300).map((c) => {
      const atual = c.pasta_id && c.pasta_id !== g.id ? PASTA(c.pasta_id) : null, oculta = c.pasta_id && c.pasta_id !== g.id && !atual;
      const travado = !pode || (c.pasta_id && c.pasta_id !== g.id && !podePorNaPasta(c.pasta_id));
      const tipo = U.TIPOS_SERVICO[c.tipo_servico];
      return `<label class="pa-c${g.sel.has(c.id) ? ' marcado' : ''}"><input type="checkbox" data-pcontr="${c.id}" ${g.sel.has(c.id) ? 'checked' : ''} ${travado ? 'disabled' : ''}>
        <span class="pa-c-t"><b>${esc(F(c.fornecedor_id).nome)}</b><span class="small">${esc(c.titulo)} · <span class="mono">${esc(c.pedido || '—')}</span>${tipo ? ' · ' + esc(tipo[1]) : ''}</span>
          <span class="small muted">${g.sel.has(c.id) ? (c.pasta_id === g.id ? 'Nesta pasta' : atual ? `Vem da pasta ${esc(atual.nome)}` : oculta ? 'Vem de uma pasta que você não vê' : 'Vem dos avulsos')
            : atual ? `Na pasta ${esc(atual.nome)}${travado && pode ? ' (você não pode editar essa pasta)' : ''}` : oculta ? 'Numa pasta que você não vê' : 'Avulso'}${c.situacao !== 'ativo' ? ' · inativo' : ''}</span></span></label>`;
    }).join('') + (cs.length > 300 ? `<p class="small muted">E mais ${cs.length - 300}: use a busca.</p>` : '');
  }
  function atualizarListaPasta() {
    const g = S.gaveta, el = document.getElementById('pa-clista');
    if (!el) return;
    el.innerHTML = listaContratosPastaHTML(g.id ? podeEditarPasta(PASTA(g.id)) : S.papel !== 'leitura');
    const n = document.getElementById('pa-ncontr'); if (n) n.textContent = `(${g.sel.size})`;
  }
  // Regra (filtro) para contratos novos: tipo de serviço, supervisor, contato do serviço, equipe e texto
  function filtroPastaHTML(pode, f) {
    const dis = pode ? '' : 'disabled';
    const box = (k, lista) => lista.map(([v, t]) => `<label class="check sm"><input type="checkbox" data-fx="${k}" value="${esc(v)}" ${(f[k] || []).includes(v) ? 'checked' : ''} ${dis}> ${esc(t)}</label>`).join('');
    const grupo = (k, titulo, lista) => (lista.length ? `<details class="fx-grupo" ${(f[k] || []).length ? 'open' : ''}><summary>${titulo} <span class="muted">(${(f[k] || []).length} marcado${(f[k] || []).length === 1 ? '' : 's'})</span></summary><div class="fx-opcoes">${box(k, lista)}</div></details>` : '');
    const cols = (S.base.colaboradores || []).filter((c) => c.ativo).sort((a, b) => a.nome.localeCompare(b.nome));
    return `<div id="pa-filtro" class="pa-filtro">
      <p class="hint" style="margin:8px 0">O contrato novo entra se cumprir <b>todas</b> as regras marcadas (dentro de uma regra, vale qualquer item marcado). Os contratos que já existem não mudam de pasta.</p>
      <div class="fx-grupo aberto"><b class="small">Tipo de serviço</b><div class="fx-opcoes">${box('tipos', U.FILTRO_TIPOS)}</div></div>
      ${grupo('supervisores', 'Supervisor do contrato', supervisores().map((c) => [c.id, c.nome]))}
      ${grupo('contatos', 'Contato Klingele do serviço', cols.map((c) => [c.id, c.nome + (c.cargo ? ' · ' + c.cargo : '')]))}
      ${grupo('equipes', 'Equipe (supervisor ou contato é membro)', S.base.equipes.map((e) => [e.id, e.nome]))}
      <label class="field" style="margin-top:8px"><span>Texto <span class="hint">(fornecedor, código, pedido ou serviço)</span></span><input type="text" id="pa-ftexto" maxlength="80" value="${esc(f.texto || '')}" ${dis}></label>
      <div id="pa-previa" class="pa-previa" aria-live="polite"></div>
    </div>`;
  }
  function lerFiltroPasta() {
    const marc = (k) => Array.from(document.querySelectorAll(`#pa-filtro [data-fx="${k}"]:checked`)).map((b) => b.value);
    const tx = document.getElementById('pa-ftexto');
    return { tipos: marc('tipos'), supervisores: marc('supervisores'), contatos: marc('contatos'), equipes: marc('equipes'), texto: tx ? tx.value.trim() : '' };
  }
  function atualizarPreviaFiltro() {
    const el = document.getElementById('pa-previa');
    if (!el) return;
    const f = lerFiltroPasta();
    if (!U.filtroTemRegra(f)) { el.innerHTML = '<p class="small muted" style="margin:0">Marque pelo menos uma regra.</p>'; return; }
    const x = ctxRegra(), n = S.base.contratos.filter((c) => c.situacao === 'ativo' && U.contratoCumpreRegra(c, f, x)).length;
    el.innerHTML = `<p class="small" style="margin:0">Hoje, <b>${n}</b> contrato${n !== 1 ? 's' : ''} ativo${n !== 1 ? 's' : ''} cumpre${n !== 1 ? 'm' : ''} a regra. Ela vale para os contratos cadastrados daqui em diante; para trazer os atuais, marque-os na lista acima.</p>`;
  }
  // Responsável, quem vê, compartilhamento (ver, editar, gerir) e transferência: só quem gere a pasta altera
  function acessosPastaHTML(base, p, gere, usuariosEnvio) {
    const g = S.gaveta, padrao = !!(base && base.padrao), dono = base ? base.criado_por : EU();
    if (!gere) return `<p class="small" style="margin:0">Responsável: <b>${p.responsavel ? esc(nomeEquipe(p.responsavel)) : 'ninguém'}</b></p>
      <p class="small muted" style="margin:4px 0 0">${esc(base ? compartTxt(base) : '')}. Só quem gere a pasta (quem criou, quem recebeu "Pode gerir", os supervisores da pasta e os administradores) muda o responsável e os acessos.</p>`;
    const nivelSel = (attr, v) => `<select ${attr} aria-label="Permissão" class="sel-nivel">${NIVEIS_COMP.map(([k, t]) => `<option value="${k}" ${(v || 'ver') === k ? 'selected' : ''}>${t}</option>`).join('')}</select>`;
    const pessoas = g.comp.filter((c) => c.alvo_tipo === 'usuario');
    const disponiveis = (S.base.equipe || []).filter((m) => (m.email || '').toLowerCase() !== dono && !pessoas.some((c) => c.alvo === (m.email || '').toLowerCase()))
      .sort((a, b) => (a.nome || a.email).localeCompare(b.nome || b.email));
    return `<div class="form-grid">
        <label class="field"><span>Responsável <span class="hint">(recebe o resumo de cada disparo)</span></span><select id="pa-resp"><option value="">Ninguém</option>
          ${usuariosEnvio.map((m) => `<option value="${esc((m.email || '').toLowerCase())}" ${(m.email || '').toLowerCase() === (p.responsavel || '') ? 'selected' : ''}>${esc(m.nome || m.email)} · ${esc(PAPEL[m.papel] || m.papel)}</option>`).join('')}</select></label>
        ${padrao ? '<p class="small muted" style="margin:0;align-self:end">Todos veem o Envio mensal; administradores e supervisores gerem.</p>' : `<label class="field"><span>Quem vê</span><select id="pa-vis">${Object.entries(VIS_PASTA).map(([k, t]) => `<option value="${k}" ${(p.visibilidade || 'restrita') === k ? 'selected' : ''}>${t}</option>`).join('')}</select>
          <span class="hint">Dono: ${esc(nomeEquipe(dono || ''))}. Administradores gerem todas.</span></label>`}
      </div>
      <div id="pa-comp" class="pa-comp">
        <p class="hint" style="margin:8px 0 4px"><b>Pode ver</b> acompanha · <b>Pode editar</b> muda contratos, calendário e opções e envia · <b>Pode gerir</b> também muda acessos, responsável, transfere e exclui. Supervisor que participa da pasta sempre gere.</p>
        <div class="comp-bloco"><b class="small">Equipes <span class="muted">(todos da equipe, inclusive quem entrar depois)</span></b>
          ${S.base.equipes.length ? S.base.equipes.map((e) => { const c = g.comp.find((x) => x.alvo_tipo === 'equipe' && x.alvo === e.id), n = membrosDe(e.id).filter((m) => m.status === 'ativo').length;
            return `<div class="comp-linha"><label class="check sm"><input type="checkbox" data-ceq="${e.id}" ${c ? 'checked' : ''}> ${esc(e.nome)} <span class="muted">· ${n} membro${n !== 1 ? 's' : ''}</span></label>${nivelSel(`data-ceq-nivel="${e.id}"`, c && c.nivel)}</div>`; }).join('')
            : '<p class="small muted" style="margin:4px 0">Nenhuma equipe criada (Usuários > Equipes).</p>'}</div>
        <div class="comp-bloco"><b class="small">Pessoas</b>
          ${pessoas.map((c) => `<div class="comp-linha"><span class="small" style="min-width:0;overflow-wrap:anywhere">${esc(nomeEquipe(c.alvo))}</span>${nivelSel(`data-cp-nivel="${esc(c.alvo)}"`, c.nivel)}
            <button type="button" class="icon-btn sm" data-act="pasta-rm-pessoa" data-email="${esc(c.alvo)}" title="Tirar" aria-label="Tirar ${esc(nomeEquipe(c.alvo))}">${ic.x}</button></div>`).join('') || '<p class="small muted" style="margin:4px 0">Ninguém adicionado.</p>'}
          <select id="pa-pessoa" data-chg="pasta-add-pessoa" aria-label="Adicionar pessoa"><option value="">+ Compartilhar com uma pessoa…</option>${disponiveis.map((m) => `<option value="${esc((m.email || '').toLowerCase())}">${esc(m.nome || m.email)} · ${esc(PAPEL[m.papel] || m.papel)}</option>`).join('')}</select></div>
      </div>
      ${base && !padrao ? `<div class="comp-bloco"><b class="small">Transferir a pasta</b>
        <div class="row" style="gap:8px;margin-top:4px"><select id="pa-transf" aria-label="Transferir para" style="flex:1 1 200px"><option value="">Escolha quem passa a ser dono…</option>
          ${usuariosEnvio.filter((m) => (m.email || '').toLowerCase() !== dono).map((m) => `<option value="${esc((m.email || '').toLowerCase())}">${esc(m.nome || m.email)} · ${esc(PAPEL[m.papel] || m.papel)}</option>`).join('')}</select>
          <button type="button" class="btn sm" data-act="pasta-transferir">Transferir</button></div>
        <span class="hint">A pessoa vira dona e responsável; quem transferiu continua podendo gerir.</span></div>` : ''}`;
  }
  // Lê o compartilhamento do formulário
  function lerCompartPasta() {
    const g = S.gaveta;
    if (!document.getElementById('pa-comp')) return;
    const out = [];
    document.querySelectorAll('#pa-comp [data-ceq]').forEach((b) => { if (b.checked) out.push({ alvo_tipo: 'equipe', alvo: b.dataset.ceq, nivel: (document.querySelector(`#pa-comp [data-ceq-nivel="${b.dataset.ceq}"]`) || {}).value || 'ver' }); });
    g.comp.filter((c) => c.alvo_tipo === 'usuario').forEach((c) => { const s = document.querySelector(`#pa-comp [data-cp-nivel="${CSS.escape(c.alvo)}"]`); out.push({ alvo_tipo: 'usuario', alvo: c.alvo, nivel: s ? s.value : c.nivel }); });
    g.comp = out;
  }
  // Recria a gaveta mantendo o que foi digitado (ao trocar o calendário, datas, regra ou acessos)
  function rascunhoPasta() {
    lerCompartPasta();
    const g = S.gaveta, base = g.id ? PASTA(g.id) : null, v = (i) => document.getElementById(i);
    const r = { ...(base || {}), nome: v('pa-nome').value, descricao: v('pa-desc').value, calendario: g.cal,
      dia_util: v('pa-dia') ? Number(v('pa-dia').value) : (base || { dia_util: 1 }).dia_util, horario: v('pa-hora') ? v('pa-hora').value : (g.rasc || base || { horario: '08:00' }).horario,
      meses: document.querySelector('[data-pmes]') ? Array.from(document.querySelectorAll('[data-pmes]:checked')).map((b) => Number(b.value)) : (g.rasc || base || { meses: [] }).meses || [],
      datas: (g.rasc || base || { datas: [] }).datas || [], pede: v('pa-pede') ? v('pa-pede').value : (g.rasc || base || { pede: 'mes_anterior' }).pede,
      ativa: v('pa-ativa') ? v('pa-ativa').checked : (g.rasc || base || { ativa: true }).ativa !== false,
      prazo_dias: v('pa-prazo') && v('pa-prazo').value ? Number(v('pa-prazo').value) : null, cobranca: v('pa-cob') ? v('pa-cob').checked : true, avaliacao: v('pa-aval') ? v('pa-aval').checked : true,
      responsavel: v('pa-resp') ? v('pa-resp').value : (g.rasc || base || { responsavel: EU() }).responsavel, visibilidade: v('pa-vis') ? v('pa-vis').value : (base || { visibilidade: 'restrita' }).visibilidade,
      filtro: g.regraOn && document.getElementById('pa-filtro') ? lerFiltroPasta() : (g.rasc || base || {}).filtro || null };
    g.rasc = r;
    return r;
  }
  async function salvarPasta() {
    const r = rascunhoPasta(), g = S.gaveta, base = g.id ? PASTA(g.id) : null;
    const d = { nome: String(r.nome || '').trim(), descricao: String(r.descricao || '').trim(), calendario: r.calendario, dia_util: r.dia_util, horario: r.horario,
      meses: r.meses, datas: r.datas, pede: r.pede, ativa: r.ativa, prazo_dias: r.prazo_dias, cobranca: r.cobranca, avaliacao: r.avaliacao, contratos: [...g.sel] };
    if (!base || !base.padrao) d.regra = g.regraOn ? r.filtro : null;
    if (document.getElementById('pa-resp')) { d.responsavel = r.responsavel || ''; if (!base || !base.padrao) d.visibilidade = r.visibilidade; d.compartilhamentos = g.comp; }
    if (d.nome.length < 2 || d.nome.length > 80) { U.toast('Informe o nome da pasta (2 a 80 caracteres)', 'erro'); return; }
    if (d.calendario === 'meses' && !d.meses.length) { U.toast('Marque pelo menos um mês', 'erro'); return; }
    if (d.calendario === 'datas' && !d.datas.length) { U.toast('Adicione pelo menos uma data', 'erro'); return; }
    if (d.regra && !U.filtroTemRegra(d.regra)) { U.toast('Marque pelo menos uma regra (ou desligue a regra para contratos novos)', 'erro'); return; }
    try {
      const x = await API.salvarPasta(g.id, d);
      await recarregar(true); fecharGaveta(); renderView();
      U.toast(`Pasta salva · ${x.contratos} contrato${x.contratos !== 1 ? 's' : ''}${x.entraram ? ` (${x.entraram} entraram)` : ''}${x.sairam ? ` · ${x.sairam} ficaram avulsos` : ''}`);
    } catch (e) { U.toast(e.message, 'erro'); }
  }
  async function enviarPasta(id) {
    const p = PASTA(id);
    if (!p) return;
    if (!podeEnviarPeloApp()) { U.toast('Envio pelo app ainda não configurado: Configurações > Envio de e-mail pelo app', 'erro'); return; }
    if (!compLiberada(S.comp)) { U.toast(`${U.compLabel(S.comp)} ainda não terminou: escolha uma competência encerrada`, 'erro'); return; }
    const n = fornsDaPasta(id).length;
    if (!(await U.confirmar(`Enviar a pasta "${p.nome}" agora?`, `Os links de ${U.compLabel(S.comp)} de ${n} fornecedor${n !== 1 ? 'es' : ''} da pasta serão gerados e enviados agora, cada um só com os contratos desta pasta. Quem já recebeu não recebe de novo.`, 'Enviar agora'))) return;
    try {
      const r = await API.executarPasta(id, S.comp);
      await recarregar(true); fecharGaveta(); renderView();
      U.toast(`${r.enviados} e-mail${r.enviados !== 1 ? 's' : ''} enviado${r.enviados !== 1 ? 's' : ''}${r.ja_enviados ? ` · ${r.ja_enviados} já tinham recebido` : ''}${r.sem_email && r.sem_email.length ? ` · sem e-mail: ${r.sem_email.join(', ')}` : ''}`);
    } catch (e) { U.toast(e.message, 'erro'); }
  }
  function navHTML() {
    const cont = { envio: pendEnvioN(), receb: S.solic.filter((s) => s.status === 'recebido' && fornecedorMeu(s.fornecedor_id)).length,
      nf: S.med.filter((m) => medMeu(m) && proximaEtapa(m).agir).length,
      usuarios: pendentesParaMim().length };
    const atual = NAV.find((n) => n[0] === S.view) || NAV[0];
    const admin = S.papel === 'admin';
    return NAV.filter((n) => (n[0] !== 'usuarios' || podeAprovar()) && (n[0] !== 'hist' || S.papel !== 'leitura')).map(([k, t, i, curto, prim]) => {
      if (k === 'conf' && !admin) { t = 'Meu perfil'; curto = 'Perfil'; i = ic.usuarios; }
      const area = k === 'conf' && !admin ? 'Conta' : AREA_NAV[k];
      return `${area ? `<span class="nav-area">${area}</span>` : ''}<button type="button" data-view="${k}" class="${prim ? 'nav-prim' : 'nav-sec'}" title="${esc(t)}" aria-label="${esc(t)}${cont[k] ? ` (${cont[k]} pendente${cont[k] > 1 ? 's' : ''})` : ''}" ${S.view === k ? 'aria-current="page"' : ''}>${i}<span class="nav-t">${t}</span><span class="nav-c" aria-hidden="true">${curto}</span>${cont[k] ? `<span class="nav-count" title="Pendentes">${cont[k]}</span>` : ''}</button>`;
    }).join('')
      + `<button type="button" class="nav-mais ${atual[4] ? '' : 'ativo'}" data-act="nav-mais" aria-label="Mais seções" aria-expanded="false">${ic.menu}<span class="nav-c" aria-hidden="true">Mais</span></button>`
      // Celular e tablet: a conta (perfil, tema e Sair) também fica no menu "Mais", com nome e texto
      + `<div class="nav-conta"><button type="button" class="nc-user" data-act="ir-perfil">${railUserHTML()}</button>
          <div class="nc-acoes"><button type="button" class="btn sm ghost" data-act="tema">${U.tema.atual() === 'dark' ? ic.sol : ic.lua} <span>${U.tema.atual() === 'dark' ? 'Tema claro' : 'Tema escuro'}</span></button>
          <button type="button" class="btn sm nc-sair" data-act="sair">${ic.sair} <span>Sair</span></button></div></div>`;
  }
  function compPicker() {
    const opts = [];
    const ref = U.compAnterior();
    for (let i = 2; i >= -23; i--) opts.push(U.addMes(ref, i));
    if (!opts.includes(S.comp)) opts.push(S.comp);
    return `<div class="comp" role="group" aria-label="Competência">
      <button type="button" data-act="comp-ant" aria-label="Mês anterior">${ic.esq}</button>
      <label class="comp-label"><small>Competência</small><b>${esc(U.compLabel(S.comp))}</b>
        <select id="comp-sel" aria-label="Escolher competência">${opts.map((c) => `<option value="${c}" ${c === S.comp ? 'selected' : ''}>${U.compLabel(c)}</option>`).join('')}</select></label>
      <button type="button" data-act="comp-prox" aria-label="Próximo mês">${ic.dir}</button>
    </div>`;
  }
  function render() {
    if (!root.querySelector('.shell')) shell();
    root.querySelector('#nav').innerHTML = navHTML();
    const ru = root.querySelector('.rail-user'); if (ru) ru.innerHTML = railUserHTML();
    const [t, lead] = TITULOS[S.view];
    const banner = DEMO ? `<div class="demo-banner"><strong>Demonstração</strong><span class="demo-longo">Fornecedores, contatos e contratos foram importados da planilha. Envios, valores medidos e documentos são exemplos e permanecem apenas neste navegador.</span><span class="demo-curto">Dados de exemplo</span>
      <span class="spacer"></span><button class="btn sm" data-act="restaurar-demo"><span>Restaurar<span class="so-desk-i"> exemplo</span></span></button></div>` : '';
    const main = root.querySelector('#main');
    const tituloView = S.view === 'conf' && S.papel !== 'admin' ? 'Meu perfil' : t;
    const leadView = S.view === 'conf' && S.papel !== 'admin' ? 'Seus dados, e-mail de aviso e senha.' : lead;
    main.innerHTML = `${banner}<div class="page-head"><div><h1>${esc(tituloView)}</h1><p class="lead">${esc(leadView)}${escopoMeu() && ESCOPO_VIEWS.includes(S.view) ? ` <span class="chip accent plain">Meus contratos · ${esc(escopoRotulo())}</span>` : ''}</p></div>
      <div class="page-ctl">${escopoHTML()}${COMP_VIEWS.includes(S.view) ? compPicker() : ''}</div></div>
      <div id="view" class="stack view">${VIEWS[S.view]()}</div>`;
    document.title = `${tituloView} · BMK`;
    posRender();
  }
  function posRender() { rotularTabelas(document.getElementById('main')); if (S.view === 'conf') carregarMfa(); }
  // Celular: cada linha de tabela vira um cartão. O rótulo de cada célula vem do cabeçalho da coluna;
  // células vazias ("—") somem e o botão que repete a ação da linha (a linha inteira já abre) fica oculto.
  function rotularTabelas(raiz) {
    if (!raiz) return;
    raiz.querySelectorAll('table.tbl').forEach((t) => {
      const ths = [];
      t.querySelectorAll('thead tr:first-child th').forEach((th) => { const n = Number(th.getAttribute('colspan')) || 1; for (let i = 0; i < n; i++) ths.push(th.textContent.replace(/\s+/g, ' ').trim()); });
      if (!t.hasAttribute('data-sem-cartao')) t.classList.add('cards');
      const comCampos = !!t.querySelector('tbody input:not([type="checkbox"]):not([type="radio"]), tbody select');
      t.classList.toggle('com-campos', comCampos);
      const celulas = [];
      t.querySelectorAll('tbody tr, tfoot tr').forEach((tr) => {
        let col = 0;
        Array.from(tr.children).forEach((td, idx) => {
          const n = Number(td.getAttribute('colspan')) || 1;
          if (!td.hasAttribute('data-label')) td.setAttribute('data-label', n === 1 ? (ths[col] || '') : '');
          col += n;
          const txt = td.textContent.replace(/\s+/g, ' ').trim();
          const campos = !!td.querySelector('input, select, textarea, label');
          const botoes = td.querySelectorAll('button, a');
          const ch = td.querySelector('.chip');
          td.classList.toggle('m-vazio', !campos && !botoes.length && (txt === '' || txt === '—'));
          td.classList.toggle('m-oculto', !!tr.dataset.act && !campos && botoes.length === 1 && botoes[0].dataset.act === tr.dataset.act);
          celulas.push({ td, txt: txt.length, chip: ch ? ch.textContent.trim().length : 0, tag: !!td.querySelector('.tag'), campos, btn: !!td.querySelector('.btn'), primeira: idx === 0 });
        });
      });
      // Largura no cartão: 3 colunas para números curtos; se muitas células são longas, o cartão usa 2 colunas
      const largo3 = (c) => !c.campos && (c.txt > 16 || c.chip > 11 || c.btn);
      const resto = celulas.filter((c) => !c.primeira && !c.td.classList.contains('m-vazio') && !c.td.classList.contains('m-oculto') && !c.td.classList.contains('m-menos'));
      const dois = comCampos || (resto.length && resto.filter(largo3).length / resto.length > 0.4);
      t.classList.toggle('dois', !!dois);
      celulas.forEach((c) => {
        const cheio = !c.campos && (dois ? c.txt > 26 || c.chip > 20 || (c.tag && c.txt > 18) : c.txt > 34);
        c.td.classList.toggle('m-cheio', cheio);
        c.td.classList.toggle('m-largo', !dois && !cheio && largo3(c));
      });
    });
  }
  // Celular: no rodapé da gaveta ficam a ação principal e "Mais ações"; o X do topo substitui "Fechar"/"Cancelar"
  function ajustarRodape(g) {
    const foot = g.querySelector('.drawer-foot');
    if (!foot) return;
    const btns = Array.from(foot.children).filter((b) => b.classList.contains('btn'));
    btns.forEach((b) => { if (b.dataset.act === 'fechar-gaveta') b.classList.add('so-desk'); });
    const sec = btns.filter((b) => !b.classList.contains('primary') && !b.classList.contains('so-desk') && !b.classList.contains('fixo'));
    if (sec.length < 2) return;
    sec.forEach((b) => b.classList.add('sec'));
    const t = document.createElement('button');
    t.type = 'button'; t.className = 'btn foot-toggle'; t.dataset.act = 'foot-mais'; t.setAttribute('aria-expanded', 'false');
    t.textContent = `Mais ações (${sec.length})`;
    foot.insertBefore(t, foot.firstChild);
  }
  const telaLarga = () => !window.matchMedia || window.matchMedia('(min-width: 761px)').matches;
  const renderView = () => { const v = document.getElementById('view'); if (v) v.innerHTML = VIEWS[S.view](); root.querySelector('#nav').innerHTML = navHTML(); posRender(); };

  async function irPara(view) {
    if ((view === 'hist' && S.papel === 'leitura') || (view === 'usuarios' && !podeAprovar())) view = 'painel';
    S.view = view;
    try { history.replaceState(null, '', '#' + view); } catch (e) { /* sem histórico */ }
    render();
    window.scrollTo(0, 0);
    if (view === 'hist') carregarHistorico();
    if (view === 'envio' && !DEMO) API.conferirEnvios().then(() => recarregar()).then(() => { if (S.view === 'envio') renderView(); }).catch(() => {});
  }

  // =====================================================================
  //  PAINEL
  // =====================================================================
  function niceMax(v) {
    if (!v || v <= 0) return 1;
    const e = Math.pow(10, Math.floor(Math.log10(v))), n = v / e;
    return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * e;
  }
  function tipLinhas(linhas) { return esc(linhas.join('\n')); }

  function graficoFornecedores(meds) {
    const g = {};
    meds.forEach((m) => {
      const k = m.fornecedor_id;
      g[k] = g[k] || { f: F(k), contratado: 0, medido: null, itens: [] };
      g[k].contratado += num(m.valor_contratado) || 0;
      const md = m.status === 'sem_medicao' ? 0 : medido(m);
      if (md !== null) g[k].medido = (g[k].medido || 0) + md;
      g[k].itens.push(m);
    });
    const grupos = Object.values(g).sort((a, b) => b.contratado - a.contratado);
    if (!grupos.length) return '<div class="empty"><h3>Nada para comparar</h3><p>Gere os links do mês para criar as medições.</p></div>';
    const max = niceMax(Math.max(...grupos.map((x) => Math.max(x.contratado, x.medido || 0))));
    const ticks = [0, 0.25, 0.5, 0.75, 1];
    const linhas = grupos.map((x) => {
      const r = x.medido === null ? null : x.medido - x.contratado;
      const tip = [x.f.nome, `Contratado: ${U.brl(x.contratado)}`, `Medido: ${x.medido === null ? 'aguardando boletim' : U.brl(x.medido)}`,
        ...(r === null ? [] : [`Diferença: ${r > 0 ? '+' : ''}${U.brl(r)} (${U.pct(x.contratado ? r / x.contratado : null)})`]),
        ...x.itens.map((m) => `Pedido ${C(m.contrato_id).pedido}: ${medido(m) === null ? '—' : U.brl(medido(m))} de ${U.brl(m.valor_contratado)}`)];
      return `<div class="bullet-row" data-tip="${tipLinhas(tip)}" tabindex="0">
        <span class="bullet-name" title="${esc(x.f.nome)}">${esc(x.f.nome)}</span>
        <div class="bullet-track"><span class="grid"></span>
          <span class="bar ${x.medido === null ? 'pend' : ''}" style="width:${((x.medido === null ? x.contratado : x.medido) / max * 100).toFixed(2)}%"></span>
          <span class="tick" style="left:${(x.contratado / max * 100).toFixed(2)}%"></span></div>
        <div class="bullet-val"><b>${x.medido === null ? 'Aguardando' : U.compacto(x.medido)}</b><span class="muted small">de ${U.compacto(x.contratado)}</span></div>
      </div>`;
    }).join('');
    return `<div class="bullet">${linhas}
      <div class="bullet-axis"><span></span><div class="ticks">${ticks.map((t) => `<span style="left:${t * 100}%">${t === 0 ? '0' : U.compactoCurto(max * t)}</span>`).join('')}</div><span></span></div></div>`;
  }

  function graficoMeses() {
    const comps = [];
    for (let i = 5; i >= 0; i--) comps.push(U.addMes(S.comp, -i));
    const dados = comps.map((c) => {
      const ms = filtrarMed(S.periodo.filter((m) => m.competencia === c), false);
      const comMed = ms.filter((m) => medido(m) !== null || m.status === 'sem_medicao');
      return { c, contratado: soma(ms.map((m) => m.valor_contratado)), medido: soma(comMed.map((m) => (m.status === 'sem_medicao' ? 0 : medido(m)))), n: ms.length, rec: comMed.length };
    });
    const max = niceMax(Math.max(1, ...dados.map((d) => Math.max(d.contratado, d.medido))));
    return `<div class="cols" style="--n:${dados.length}">${dados.map((d) => {
      const tip = [U.compLabel(d.c), `Contratado: ${U.brl(d.contratado)}`, `Medido: ${U.brl(d.medido)}`, `${d.rec} de ${d.n} boletins com valor`];
      return `<button type="button" class="col ${d.c === S.comp ? 'sel' : ''}" data-act="ir-comp" data-comp="${d.c}" data-tip="${tipLinhas(tip)}" style="border:0;background:none;padding:0;cursor:pointer" aria-label="${esc(U.compLabel(d.c))}">
        <div class="stackcol">${d.n ? `<span class="b" style="height:${(d.medido / max * 100).toFixed(2)}%"></span><span class="t" style="bottom:calc(${(d.contratado / max * 100).toFixed(2)}% - 1.5px)"></span>` : ''}</div>
        <span class="lbl">${U.compCurta(d.c)}</span></button>`;
    }).join('')}</div>`;
  }

  // ---------- Filtros do painel (fornecedor, supervisor, tipo de serviço e etapa do fluxo) ----------
  const filtroAtivo = () => !!(S.f.pForn || S.f.pSup || S.f.pTipo || S.f.pEtapa);
  function filtrarMed(lista, comEtapa) {
    return lista.filter((m) => {
      const c = C(m.contrato_id);
      if (!medMeu(m)) return false;
      if (S.f.pForn && m.fornecedor_id !== S.f.pForn) return false;
      if (S.f.pSup && (S.f.pSup === 'sem' ? !!c.supervisor_id : c.supervisor_id !== S.f.pSup)) return false;
      if (S.f.pTipo) { const g = (U.TIPOS_SERVICO[c.tipo_servico] || [])[0]; if (S.f.pTipo === 'sem' ? !!c.tipo_servico : g !== S.f.pTipo) return false; }
      if (comEtapa && S.f.pEtapa && etapaFluxo(m).k !== S.f.pEtapa) return false;
      return true;
    });
  }
  function barraFiltros() {
    const forns = [...new Set(S.med.filter(medMeu).map((m) => m.fornecedor_id))].map(F).filter((f) => f.id).sort((a, b) => a.nome.localeCompare(b.nome));
    const sups = supervisores();
    const sel = (id, rot, opts, v) => `<label class="filtro"><span>${rot}</span><select id="${id}" aria-label="${rot}">${opts.map(([k, t]) => `<option value="${esc(k)}" ${v === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select></label>`;
    return `<div class="filtros" role="group" aria-label="Filtros do painel"><span class="filtros-ic" aria-hidden="true">${ic.filtro}</span>
      ${sel('pf-forn', 'Fornecedor', [['', 'Todos'], ...forns.map((f) => [f.id, f.nome])], S.f.pForn)}
      ${sel('pf-sup', 'Supervisor', [['', 'Todos'], ...sups.map((x) => [x.id, x.nome]), ['sem', 'Sem supervisor']], S.f.pSup)}
      ${sel('pf-tipo', 'Tipo de serviço', [['', 'Todos'], ['Fixo', 'Fixo'], ['Não fixo', 'Não fixo (spot)'], ['sem', 'Sem tipo']], S.f.pTipo)}
      ${sel('pf-etapa', 'Etapa', [['', 'Todas'], ...ETAPAS.map(([k, t]) => [k, t]), ['sem_medicao', 'Sem medição']], S.f.pEtapa)}
      ${filtroAtivo() ? `<button class="btn sm ghost" data-act="limpar-filtros">${ic.x} Limpar</button>` : ''}</div>`;
  }

  // Funil do fluxo do mês: quantas medições chegaram a cada etapa e quantas estão paradas nela
  function graficoFluxo(meds) {
    const base = meds.filter((m) => m.status !== 'sem_medicao');
    const ordem = ETAPAS.map(([k]) => k);
    const pos = base.map((m) => ordem.indexOf(etapaFluxo(m).k));
    const total = base.length;
    if (!total) return '<p class="muted">Nenhuma medição no filtro.</p>';
    const linhas = [['aguardando', 'Link enviado', 1], ['recebido', 'Boletim recebido', 2], ['conferido', 'Valores aprovados', 3], ['fs', 'F.S. lançada', 4],
      ['nf', 'F.S. enviada ao fornecedor', 5], ['servicos', 'NF recebida', 6], ['finalizado', 'NF em Serviços · finalizado', 7]];
    const parados = (k) => base.filter((m) => etapaFluxo(m).k === k).length;
    const semEnvio = parados('sem_envio');
    return `<div class="funil">${linhas.map(([k, t, i]) => {
      const n = pos.filter((p) => p >= i).length, aqui = parados(k);
      return `<div class="funil-row"><span class="funil-t">${esc(t)}</span>
        <div class="funil-track" role="img" aria-label="${esc(t)}: ${n} de ${total}"><i class="${k === 'finalizado' ? 'fim' : ''}" style="width:${(n / total * 100).toFixed(1)}%"></i></div>
        <span class="funil-n"><b>${n}</b><span class="muted">/${total}</span></span>
        ${k === 'finalizado' ? '<span></span>' : `<button type="button" class="funil-aqui ${aqui ? '' : 'zero'}" data-act="filtro-etapa" data-v="${k}" title="Exibir apenas as medições nesta etapa" ${aqui ? '' : 'disabled'}>${aqui} ${aqui === 1 ? 'parada' : 'paradas'}</button>`}</div>`;
    }).join('')}</div>
    ${semEnvio ? `<p class="small muted" style="margin-top:8px">${semEnvio} ${semEnvio > 1 ? 'medições' : 'medição'} sem link enviado. <button class="btn sm ghost" data-act="filtro-etapa" data-v="sem_envio">Ver</button></p>` : ''}`;
  }

  // Contratado e medido por grupo de tipo de serviço
  function graficoTipos(meds) {
    const grupos = [['Fixo', 'Fixo · locação e suporte'], ['Não fixo', 'Não fixo · spot'], ['sem', 'Sem tipo definido']].map(([k, t]) => {
      const ms = meds.filter((m) => { const g = (U.TIPOS_SERVICO[C(m.contrato_id).tipo_servico] || [])[0]; return k === 'sem' ? !g : g === k; });
      const comMed = ms.filter((m) => medido(m) !== null || m.status === 'sem_medicao');
      return { k, t, n: ms.length, contratado: soma(ms.map((m) => m.valor_contratado)), medido: comMed.length ? soma(comMed.map((m) => (m.status === 'sem_medicao' ? 0 : medido(m)))) : null };
    }).filter((g) => g.n);
    if (!grupos.length) return '<p class="muted">Nenhuma medição no filtro.</p>';
    const max = niceMax(Math.max(...grupos.map((g) => Math.max(g.contratado, g.medido || 0))));
    return `<div class="bullet">${grupos.map((g) => `<div class="bullet-row" data-tip="${tipLinhas([g.t, `${g.n} pedido${g.n > 1 ? 's' : ''}`, `Contratado: ${U.brl(g.contratado)}`, `Medido: ${g.medido === null ? 'aguardando' : U.brl(g.medido)}`])}" tabindex="0">
      <span class="bullet-name" title="${esc(g.t)}">${esc(g.t)}</span>
      <div class="bullet-track"><span class="grid"></span><span class="bar ${g.medido === null ? 'pend' : ''}" style="width:${((g.medido === null ? g.contratado : g.medido) / max * 100).toFixed(2)}%"></span>
        <span class="tick" style="left:${(g.contratado / max * 100).toFixed(2)}%"></span></div>
      <div class="bullet-val"><b>${g.medido === null ? 'Aguardando' : U.compacto(g.medido)}</b><span class="muted small">${g.n} pedido${g.n > 1 ? 's' : ''}</span></div></div>`).join('')}</div>`;
  }

  // Situação dos links do mês (barra segmentada)
  function graficoLinks(sols) {
    const grupos = [['Aguardando envio', ['gerado'], 'g0'], ['Enviado, sem resposta', ['enviado', 'aberto'], 'g1'], ['Recebido, a conferir', ['recebido'], 'g2'],
      ['Conferido', ['conferido'], 'g3'], ['Vencido', ['expirado'], 'g4']].map(([t, st, c]) => ({ t, c, n: sols.filter((x) => st.includes(x.status)).length }));
    const tot = grupos.reduce((a, g) => a + g.n, 0);
    if (!tot) return '<p class="muted">Nenhum link no filtro.</p>';
    return `<div class="segbar" role="img" aria-label="${esc(grupos.map((g) => `${g.t}: ${g.n}`).join(', '))}">${grupos.filter((g) => g.n).map((g) => `<i class="${g.c}" style="flex:${g.n}" data-tip="${tipLinhas([g.t, `${g.n} de ${tot}`])}"></i>`).join('')}</div>
      <ul class="seglegend">${grupos.map((g) => `<li><i class="${g.c}"></i><span>${esc(g.t)}</span><b>${g.n}</b></li>`).join('')}</ul>`;
  }

  // Vencimentos dos próximos 6 meses (barras) e lista com o aviso de cada contrato
  function graficoVencimentos(contratos) {
    const hoje = U.hojeISO(), comp0 = U.compDe(hoje);
    const meses = Array.from({ length: 6 }, (_, i) => U.addMes(comp0, i));
    const dados = meses.map((c) => ({ c, n: contratos.filter((k) => k.data_fim && U.compDe(k.data_fim) === c && k.data_fim >= hoje).length }));
    const max = Math.max(1, ...dados.map((d) => d.n));
    return `<div class="cols venc" style="--n:6">${dados.map((d) => `<div class="col" data-tip="${tipLinhas([U.compLabel(d.c), `${d.n} contrato${d.n !== 1 ? 's' : ''} vencendo`])}">
      <div class="stackcol">${d.n ? `<span class="b" style="height:${(d.n / max * 100).toFixed(1)}%"></span><span class="v">${d.n}</span>` : ''}</div><span class="lbl">${U.compCurta(d.c)}</span></div>`).join('')}</div>`;
  }
  function avisoHTML(c) {
    const a = alertaDe(c);
    if (!a || a.vencido) return '';
    if (a.avisado) return `<span class="small muted">${ic.sino} Avisado em ${U.dataBR(U.dataLocal(a.avisado.created_at))}</span>`;
    if (a.janela) return `<span class="small" style="color:var(--warn)">${ic.sino} Aviso pendente (${a.dias} dias antes)</span>`;
    return `<span class="small muted">${ic.sino} Aviso em ${U.dataBR(a.data)}</span>`;
  }

  // "Pendências": o que está parado com a equipe (ou nos seus contratos), com atalho para a tela já filtrada
  // Fornecedores marcados ("a Klingele envia documentos") sem documento no link do mês, a partir do último dia útil
  function docsPendN() {
    if (!compLiberada(S.comp)) return 0;
    return linhasEnvio().filter((x) => x.pid && pedeDocs(x.f) && fornecedorMeu(x.f.id)
      && !(x.s && (x.s.dispensa || ['recebido', 'conferido'].includes(x.s.status) || docsKlg(x.s.id).length))).length;
  }
  function pendenciasHTML() {
    const meds = S.med.filter((m) => m.status !== 'sem_medicao' && medMeu(m));
    const nf = (k) => meds.filter(FILTRO_NF[k]).length;
    const contr = S.base.contratos.filter((c) => c.situacao === 'ativo' && contratoMeu(c));
    const sol = S.solic.filter((s) => fornecedorMeu(s.fornecedor_id));
    const itens = [
      [pendEnvioN(), 'Links a enviar', 'Envio do mês', 'envio', ic.envio],
      [docsPendN(), 'Documentos da Klingele a anexar', 'O envio desses fornecedores aguarda', 'envio', ic.docs],
      [sol.filter((s) => s.status === 'expirado').length, 'Links vencidos sem resposta', 'Gerar novo link e reenviar', 'envio', ic.refazer],
      [sol.filter((s) => s.status === 'recebido').length, 'Boletins a conferir', 'Recebimentos', 'receb:receb:recebido', ic.receb],
      [nf('lancar'), 'F.S. a lançar', 'F.S. e notas fiscais', 'nf:nf:lancar', ic.nf],
      [nf('enviar'), 'F.S. a enviar ao fornecedor', 'F.S. e notas fiscais', 'nf:nf:enviar', ic.mail],
      [nf('conferir'), 'NF a conferir', 'Com alertas na conferência', 'nf:nf:conferir', ic.nf],
      [nf('aprovar_fs'), 'F.S. a aprovar', 'Aprovação interna', 'nf:nf:aprovar_fs', ic.ok],
      [nf('encaminhar'), 'NF a encaminhar a Serviços', 'F.S. aprovada e NF recebida', 'nf:nf:encaminhar', ic.envio],
      [contr.filter((c) => { const a = alertaDe(c); return a && a.janela && !a.avisado; }).length, 'Contratos a avisar', 'Prazo de aviso de vencimento', 'contr:contrFiltro:avisar', ic.sino],
      [S.papel === 'leitura' || escopoMeu() ? 0 : S.base.pastas.filter((p) => p.ativa === false && p.calendario !== 'manual' && podeEditarPasta(p) && fornsDaPasta(p.id).length).length, 'Pastas com disparo desligado', 'Ligue o disparo ou envie pelo botão', 'pastas', ic.pasta],
      [meusConvites().length, 'Convites de equipe', 'Aceite ou recuse em Meu perfil', 'conf', ic.pessoas, 'conf-equipes'],
      [S.papel === 'admin' ? (S.segPend || []).length : 0, 'Alertas de segurança', 'Tentativas bloqueadas e verificação do banco', 'hist:hist:seg', ic.alerta],
      ...(podeAprovar() ? [[pendentesParaMim().length, 'Cadastros a aprovar', S.papel === 'admin' ? 'Usuários' : 'Encaminhados a você ou a qualquer responsável', 'usuarios:usu:pendentes', ic.usuarios]] : [])
    ].filter((x) => x[0]);
    const quem = escopoMeu() ? 'nos seus contratos' : 'da equipe';
    return `<section class="panel pend-panel" aria-labelledby="pend-t">
      <div class="panel-head"><div><h2 id="pend-t">Pendências</h2>
        <span class="sub">${itens.length ? `${itens.reduce((a, x) => a + x[0], 0)} pendência${itens.reduce((a, x) => a + x[0], 0) !== 1 ? 's' : ''} ${quem} em ${esc(U.compLabel(S.comp))}` : `Nada parado ${quem} em ${esc(U.compLabel(S.comp))}`}</span></div></div>
      ${itens.length ? `<div class="pend-grid">${itens.map(([n, t2, sub, v, i, alvo]) => `<button type="button" class="pend-btn" data-act="ir-pend" data-v="${v}"${alvo ? ` data-alvo="${alvo}"` : ''}>
        <span class="pend-ic" aria-hidden="true">${i}</span><span class="pend-n">${n}</span><span class="pend-t"><b>${esc(t2)}</b><small>${esc(sub)}</small></span><span class="pend-ir" aria-hidden="true">${ic.dir}</span></button>`).join('')}</div>`
        : `<div class="panel-body"><p class="muted pend-ok">${ic.ok} Tudo em dia. As próximas etapas aparecem aqui conforme o fluxo avança.</p></div>`}
    </section>`;
  }

  VIEWS.painel = () => {
    const todasMeds = S.med.filter(medMeu);
    const sol0 = S.solic.filter((s) => s.status !== 'cancelado' && fornecedorMeu(s.fornecedor_id));
    if (!todasMeds.length && !sol0.length) {
      return `<div class="panel"><div class="empty"><h3>Nenhuma medição em ${esc(U.compLabel(S.comp))}</h3>
        <p>Gere os links do mês para solicitar os boletins. As medições de cada pedido aparecem aqui assim que os links são criados.</p>
        <button class="btn primary" data-view="envio">${ic.envio} Ir para o envio do mês</button></div></div>`;
    }
    const base = filtrarMed(todasMeds, false);
    const meds = filtrarMed(todasMeds, true);
    const fornsFiltro = new Set(meds.map((m) => m.fornecedor_id));
    const sol = sol0.filter((s) => !filtroAtivo() || fornsFiltro.has(s.fornecedor_id));
    const comMed = meds.filter((m) => medido(m) !== null && m.status !== 'sem_medicao');
    const totContr = soma(meds.map((m) => m.valor_contratado));
    const baseComp = soma(comMed.map((m) => m.valor_contratado));
    const totMed = soma(comMed.map(medido));
    const diff = totMed - baseComp;
    const receb = sol.filter((s) => ['recebido', 'conferido'].includes(s.status)).length;
    const aguard = sol.filter((s) => ['gerado', 'enviado', 'aberto'].includes(s.status)).length;
    const exp = sol.filter((s) => s.status === 'expirado').length;
    const validas = meds.filter((m) => m.status !== 'sem_medicao');
    const fin = validas.filter((m) => etapaFluxo(m).k === 'finalizado').length;
    const contrFiltro = S.base.contratos.filter((c) => c.situacao === 'ativo' && contratoMeu(c) && (!S.f.pForn || c.fornecedor_id === S.f.pForn)
      && (!S.f.pSup || (S.f.pSup === 'sem' ? !c.supervisor_id : c.supervisor_id === S.f.pSup))
      && (!S.f.pTipo || (S.f.pTipo === 'sem' ? !c.tipo_servico : (U.TIPOS_SERVICO[c.tipo_servico] || [])[0] === S.f.pTipo)));
    const vig = contrFiltro.map((c) => ({ c, v: vigencia(c), a: alertaDe(c) })).filter((x) => x.v.dias !== undefined && (x.v.dias <= 120 || (x.a && x.a.janela))).sort((a, b) => a.v.dias - b.v.dias);
    const aAvisar = contrFiltro.filter((c) => { const a = alertaDe(c); return a && a.janela && !a.avisado; }).length;
    const naJanela = contrFiltro.filter((c) => { const a = alertaDe(c); return a && a.janela; }).length;
    const acima = comMed.filter((m) => comparar(m).cls === 'crit').length;

    const linhas = meds.slice().sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || C(a.contrato_id).pedido - C(b.contrato_id).pedido).map((m) => {
      const c = C(m.contrato_id), f = F(m.fornecedor_id), r = comparar(m), v = vigencia(c), e = etapaFluxo(m);
      const s = S.solic.find((x) => x.id === m.solicitacao_id);
      const act = ['conferido', 'fs', 'nf', 'servicos', 'finalizado'].includes(e.k) ? 'abrir-nf' : s ? 'abrir-receb' : 'ir-pag';
      return `<tr class="click" data-act="${act}" data-s="${s ? s.id : ''}" data-m="${m.id}">
        <td><div class="cell-title">${esc(f.nome)}</div><div class="cell-sub">${esc(c.titulo)} · <span class="mono">${esc(c.pedido)}</span>${v.dias !== undefined && v.dias < 0 ? ' · ' + chip('crit', 'Contrato vencido') : ''}</div></td>
        <td>${chip(e.cls, e.txt)}</td>
        <td class="r num">${U.brl(m.valor_contratado)}</td>
        <td class="r num m-menos">${U.brl(m.valor_informado)}</td>
        <td class="r num m-menos">${U.brl(m.valor_lido)}</td>
        <td class="r num">${U.brl(m.valor_aprovado)}</td>
        <td class="r">${diffHTML(r)}</td>
        <td><div class="row" style="gap:4px">${chip(r.cls, r.txt)}${divergente(m) ? chip('warn', 'Informado ≠ lido') : ''}</div></td>
      </tr>`;
    }).join('');

    return `
      ${pendenciasHTML()}
      ${barraFiltros()}
      <div class="tiles">
        <div class="tile accent"><span class="label">Medido em ${esc(U.cap(U.mesNome(S.comp)))}</span><span class="v">${U.brl(totMed)}</span>
          <span class="d">${comMed.length} de ${meds.length} pedidos · contratado ${U.compacto(totContr)}</span></div>
        <div class="tile"><span class="label">Diferença sobre o contratado</span><span class="v ${diff > 0.5 ? 'diff-pos' : diff < -0.5 ? 'diff-neg' : ''}">${diff > 0 ? '+' : ''}${U.brl(diff)}</span>
          <span class="d">${U.pct(baseComp ? diff / baseComp : null)} nos medidos${acima ? ` · ${acima} acima` : ''}</span></div>
        <div class="tile"><span class="label">Boletins recebidos</span><span class="v">${receb} de ${sol.length}</span>
          <span class="d">${aguard} aguardando${exp ? ` · <b class="diff-pos">${exp} vencido${exp > 1 ? 's' : ''}</b>` : ''}</span></div>
        <div class="tile"><span class="label">Processos finalizados</span><span class="v">${fin} de ${validas.length}</span>
          <span class="d">NF encaminhada a Serviços · ${validas.length ? Math.round(fin / validas.length * 100) : 0}% do mês</span></div>
      </div>
      <div class="grid-2 igual">
        <section class="panel">
          <div class="panel-head"><div><h2>Andamento do mês</h2><span class="sub">Link > Boletim > Aprovação > F.S. > NF > Serviços · os links por fornecedor ficam no Envio do mês</span></div>
            ${S.f.pEtapa ? `<button class="btn sm ghost" data-act="filtro-etapa" data-v="">${ic.x} ${esc((ETAPA[S.f.pEtapa] || { txt: 'Sem medição' }).txt)}</button>` : ''}</div>
          <div class="panel-body">${graficoFluxo(base)}</div>
        </section>
        <section class="panel">
          <div class="panel-head"><div><h2>Vencimento dos contratos</h2><span class="sub">${naJanela} no prazo de aviso${aAvisar ? ` · <b style="color:var(--warn)">${aAvisar} sem aviso enviado</b>` : ''} · aviso ao supervisor ${esc(cfgv('alerta_venc_longo_dias', '42'))} dias antes (curtos: ${esc(cfgv('alerta_venc_curto_dias', '14'))})</span></div>
            <button class="btn sm ghost" data-act="ver-contr-avisar">Ver contratos</button></div>
          <div class="panel-body venc-lista">${vig.length ? vig.slice(0, 6).map((x) => `
            <div class="venc-item click" data-act="abrir-contr" data-c="${x.c.id}" tabindex="0">
              <div style="min-width:0"><div class="cell-title ellipsis">${esc(F(x.c.fornecedor_id).nome)}</div>
              <div class="cell-sub">Pedido <span class="mono">${esc(x.c.pedido)}</span> · fim ${U.dataBR(x.c.data_fim)}</div>${avisoHTML(x.c)}</div>${chip(x.v.cls, x.v.txt)}</div>`).join('')
            + (vig.length > 6 ? `<p class="small muted" style="margin:8px 0 0">E mais ${vig.length - 6} em Contratos.</p>` : '')
            : '<p class="muted" style="padding:8px 0">Nenhum contrato ativo vence nos próximos 120 dias.</p>'}</div>
        </section>
      </div>
      <div class="grid-2">
        <section class="panel">
          <div class="panel-head"><div><h2>Contratado x medido por fornecedor</h2><span class="sub">Barra: valor medido · Marcador: valor contratado</span></div>
            <div class="legend"><span><i class="sw-bar"></i>Medido</span><span><i class="sw-tick"></i>Contratado</span></div></div>
          <div class="panel-body">${graficoFornecedores(meds)}</div>
        </section>
        <div class="stack" style="gap:20px">
          <section class="panel">
            <div class="panel-head"><div><h2>Últimos 6 meses</h2><span class="sub">Selecione o mês para consultar${filtroAtivo() ? ' · com os filtros' : ''}</span></div></div>
            <div class="panel-body">${graficoMeses()}</div>
          </section>
          <section class="panel">
            <div class="panel-head"><div><h2>Por tipo de serviço</h2><span class="sub">Contratos fixos e spot da competência</span></div></div>
            <div class="panel-body">${graficoTipos(meds)}</div>
          </section>
        </div>
      </div>
      <details class="panel retratil-painel" data-lembrar="bmk-painel-comparativo" ${lembrado('bmk-painel-comparativo') ? 'open' : ''}>
        <summary class="panel-head" style="cursor:pointer;border-bottom:0"><div><h2>Comparativo por pedido</h2><span class="sub">${meds.length} pedido${meds.length !== 1 ? 's' : ''}${filtroAtivo() ? ' no filtro' : ''} · etapa, contratado, informado, lido, aprovado e diferença</span></div>
          <span class="row" style="gap:8px"><button class="btn sm" data-act="exportar-csv">${ic.baixar} Exportar CSV</button></span></summary>
        <div class="table-wrap"><table class="tbl">
          <thead><tr><th>Fornecedor / serviço</th><th>Etapa</th><th class="r">Contratado</th><th class="r">Informado</th><th class="r">Lido</th><th class="r">Aprovado</th><th class="r">Diferença</th><th>Situação</th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="8"><div class="empty"><h3>Nada neste filtro</h3><p>Ajuste ou limpe os filtros.</p></div></td></tr>'}</tbody>
          <tfoot><tr><td colspan="2">Total (${meds.length} pedidos)</td><td class="r num">${U.brl(totContr)}</td><td class="r num">${U.brl(soma(meds.map((m) => m.valor_informado)))}</td>
            <td class="r num">${U.brl(soma(meds.map((m) => m.valor_lido)))}</td><td class="r num">${U.brl(soma(meds.map((m) => m.valor_aprovado)))}</td><td></td><td></td></tr></tfoot>
        </table></div>
      </details>`;
  };
  // Painéis recolhíveis lembrados no navegador de cada pessoa
  const lembrado = (k) => { try { return localStorage.getItem(k) === '1'; } catch (e) { return false; } };

  function exportarCSV() {
    const cab = ['Competência', 'Fornecedor', 'Código', 'Pedido', 'Serviço', 'Tipo de serviço', 'Supervisor', 'Contratado', 'Informado', 'Lido', 'Aprovado', 'Diferença', 'Situação', 'Status',
      'Etapa do fluxo', 'Parcela', 'Folha de serviço', 'Valor da F.S.', 'F.S. aprovada em', 'NF', 'Situação da NF', 'Pagamento'];
    const lista = filtrarMed(S.med, true);
    const linhas = lista.map((m) => {
      const c = C(m.contrato_id), f = F(m.fornecedor_id), r = comparar(m);
      return [U.compLabel(S.comp), f.nome, f.codigo || '', c.pedido, c.titulo, U.tipoServicoTxt(c.tipo_servico), c.gestor || '', U.numBR(m.valor_contratado), U.numBR(m.valor_informado), U.numBR(m.valor_lido),
        U.numBR(m.valor_aprovado), r.diff === null ? '' : U.numBR(r.diff), r.txt, MED[m.status][0], etapaFluxo(m).txt, m.parcela ? parcelaTxt(m) : '', m.folha_numero || '',
        U.numBR(m.folha_valor), m.folha_aprovada_em ? U.dataBR(U.dataLocal(m.folha_aprovada_em)) : '', m.nota_fiscal || '',
        etapaNF(m).txt, m.data_pagamento ? U.dataBR(m.data_pagamento) : ''];
    });
    // Proteção contra injeção de fórmula: célula que começa com = + - @ tab ou CR ganha um apóstrofo
    const celula = (v) => { let t = String(v ?? ''); if (/^[=+\-@\t\r]/.test(t) && !/^-?\d[\d.,]*$/.test(t)) t = "'" + t; return `"${t.replace(/"/g, '""')}"`; };
    const csv = '﻿' + [cab, ...linhas].map((l) => l.map(celula).join(';')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `comparativo-${S.comp.slice(0, 7)}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    API.registrarEvento('exportação csv', 'medicoes', null, null, { competencia: S.comp, linhas: lista.length });
    U.toast(DEMO ? 'CSV gerado. Na demonstração o download pode não iniciar; no site publicado ele funciona normalmente.' : 'Arquivo CSV gerado');
  }

  VIEWS.colab = () => painelColaboradores();

  // =====================================================================
  //  ENVIO DO MÊS
  // =====================================================================
  VIEWS.envio = () => {
    const todas = linhasEnvio();
    const pSel = pastaFiltro();
    const lista = todas.filter((x) => !S.f.pasta || (S.f.pasta === 'avulsos' ? !x.pid : x.pid === S.f.pasta));
    const comLink = lista.filter((x) => x.pid);   // avulsos não contam no andamento: só saem pelo botão
    const sols = comLink.map((x) => x.s);
    const n = comLink.length;
    const gerados = sols.filter((s) => s && !['cancelado', 'expirado'].includes(s.status)).length;
    const enviados = sols.filter((s) => s && s.enviado_em && !['cancelado'].includes(s.status)).length;
    const recebidos = sols.filter((s) => s && ['recebido', 'conferido'].includes(s.status)).length;
    const pct = (v) => (n ? Math.round((v / n) * 100) : 0);
    const passo = (rot, v, extra) => `<div class="step"><span class="label">${rot}</span><span class="n">${v}<span class="muted" style="font-size:1rem;font-weight:500"> / ${n}</span></span>${extra || ''}<div class="bar"><i style="width:${pct(v)}%"></i></div></div>`;
    const mesAberto = !compLiberada(S.comp);
    const app = podeEnviarPeloApp();

    const itemHTML = (x) => {
      const f = x.f, s = x.s, pid = x.pid;
      const servs = s && s.status !== 'cancelado' ? servicosDoLink(s) : contratosDaPasta(pid, f.id).length ? contratosDaPasta(pid, f.id) : contratosPrevistos(f.id, pid);
      const mails = s ? destinatarios(s) : (f.contatos || []).filter((c) => c.recebe_boletim).map((c) => c.email);
      const envs = s ? enviosDa(s.id) : [];
      const ult = envs[0] || null, nEnv = envs.length;
      const pode = !pid || podeEnviarPasta(PASTA(pid)) || (!PASTA(pid) && S.papel !== 'leitura');
      let acts = '';
      const docsB = pedeDocs(f) && s && aindaValido(s) && !s.dispensa
        ? `<button class="btn sm ${docsKlg(s.id).length ? '' : 'primary'}" data-act="docs-klg" data-s="${s.id}" title="Documentos da Klingele que o fornecedor baixa no link">${ic.docs} <span>Docs<span class="so-desk-i"> da Klingele</span></span></button>` : '';
      const dispB = pode && S.papel !== 'leitura' && !(s && (s.dispensa || ['recebido', 'conferido'].includes(s.status))) && (s ? true : !!pid || !mesAberto)
        ? `<button class="icon-btn" data-act="dispensar" ${s && s.status !== 'cancelado' ? `data-s="${s.id}"` : `data-f="${f.id}" data-p="${pid || ''}"`} title="Sem medição este mês (desliga o envio só neste mês e nesta pasta)" aria-label="Sem medição este mês">${ic.pausa}</button>` : '';
      if (s && s.dispensa) acts = pode && S.papel !== 'leitura' ? `<button class="btn sm" data-act="reativar-envio" data-s="${s.id}">${ic.refazer} Reativar o envio</button>
          <button class="icon-btn" data-act="ver-email" data-s="${s.id}" title="Ver o link" aria-label="Ver o link">${ic.mail}</button>` : '';
      else if (!s || s.status === 'cancelado') acts = mesAberto || !pode ? dispB : (pedeDocs(f) ? `<button class="btn sm primary" data-act="docs-klg-gerar" data-f="${f.id}" data-p="${pid || ''}" title="Gera o link para anexar os documentos da Klingele">${ic.docs} Anexar docs da Klingele</button>` : '')
          + `<button class="btn sm ${pid && !pedeDocs(f) ? 'primary' : ''}" data-act="gerar-um" data-f="${f.id}" data-p="${pid || ''}">${ic.link} ${pid ? 'Gerar link' : 'Gerar link avulso'}</button>${dispB}`;
      else if (aindaValido(s)) {
        acts = `<button class="btn sm ${s.status === 'gerado' ? 'primary' : ''}" data-act="ver-email" data-s="${s.id}">${ic.mail} ${s.status === 'gerado' ? 'Ver e enviar' : '<span>Verificar<span class="so-desk-i"> e reenviar</span></span>'}</button>
          <button class="icon-btn" data-act="copiar-link" data-s="${s.id}" title="Copiar link do fornecedor" aria-label="Copiar link do fornecedor">${ic.copiar}</button>
          <button class="icon-btn" data-act="previa" data-s="${s.id}" title="Ver o que o fornecedor vê (não marca como aberto)" aria-label="Prévia do link">${ic.olho}</button>
          <button class="icon-btn" data-act="renovar" data-s="${s.id}" title="Gerar novo link (o atual deixa de valer)" aria-label="Gerar novo link">${ic.refazer}</button>
          <button class="icon-btn" data-act="cancelar" data-s="${s.id}" title="Cancelar solicitação" aria-label="Cancelar solicitação">${ic.x}</button>${dispB}`;
        if (docsB) acts = docsB + acts;
      } else if (['recebido', 'conferido'].includes(s.status)) {
        acts = `<button class="btn sm" data-act="abrir-receb" data-s="${s.id}">${ic.receb} Ver recebimento</button>
          <button class="icon-btn" data-act="ver-email" data-s="${s.id}" title="Ver envios deste link" aria-label="Ver envios">${ic.mail}</button>
          <button class="icon-btn" data-act="renovar" data-s="${s.id}" title="Liberar novo envio (gera outro link)" aria-label="Liberar novo envio">${ic.refazer}</button>`;
      } else {
        acts = `<button class="btn sm primary" data-act="renovar-reenviar" data-s="${s.id}">${ic.refazer} <span>Gerar novo link<span class="so-desk-i"> e reenviar</span></span></button>
          <button class="icon-btn" data-act="ver-email" data-s="${s.id}" title="Ver envios deste link" aria-label="Ver envios">${ic.mail}</button>${dispB}`;
      }
      return `<div class="send-item">
        <div class="who"><span class="cell-title">${esc(f.nome)}</span>
          <span class="cell-sub">Cód. <span class="mono">${esc(f.codigo || '—')}</span>${f.tipo_contrato ? ' · ' + esc(f.tipo_contrato) : ''}</span>
          <div class="row" style="margin-top:4px;gap:6px">${chipModalidade(modalidadeDe(f))}${porPasta ? '' : pastaChip(pid)}${chipSol(s)}${chipDocs(f, s)}${ult && ['falha', 'pendente', 'desconhecido', 'devolvido', 'spam', 'atrasado'].includes(ult.status) ? chipEnvio(ult) : ''}<span class="small muted">${esc(prazoTxt(s))}${s && s.status === 'recebido' ? 'Recebido em ' + U.dataHoraBR(s.recebido_em) : ''}</span></div>
          ${s && s.enviado_em ? `<span class="small muted">Último envio ${U.dataHoraBR(s.enviado_em)}${ult ? ' · ' + esc(TIPO_ENVIO[ult.tipo].toLowerCase() + ' ' + VIA_ENVIO[ult.via]) : ''}${ult && ult.status === 'entregue' && ult.entrega_em ? ' · entregue ' + U.dataHoraBR(ult.entrega_em) : ''}${nEnv > 1 ? ` · ${nEnv} envios` : ''}</span>` : ''}
          ${s && ['enviado', 'aberto'].includes(s.status) ? `<span class="small ${s.aberto_em ? 'muted' : ''}" ${s.aberto_em ? '' : 'style="color:var(--warn)"'}>${s.aberto_em ? 'Fornecedor abriu o link em ' + U.dataHoraBR(s.aberto_em) : 'Fornecedor ainda não abriu o link'}</span>` : ''}
          ${s && cobrancaTxt(s) ? `<span class="small" style="color:var(--info)">${ic.sino} ${esc(cobrancaTxt(s))}</span>` : ''}
          ${s && s.dispensa ? `<span class="small muted clamp2" title="${esc(s.dispensa_obs || '')}">${esc(dispensaTxt(s))}${s.dispensa_obs ? ' · “' + esc(s.dispensa_obs) + '”' : ''}</span>` : ''}
          ${pedeDocs(f) && s && !s.dispensa && aindaValido(s) && !docsKlg(s.id).length ? `<span class="small" style="color:var(--warn)">${s.docs_pedido_em ? `Documentos pedidos a ${esc((colabDocs(f) || {}).nome || 'quem marcou')} em ${U.dataHoraBR(s.docs_pedido_em)}${s.docs_aberto_em ? ' · link aberto' : ''}` : 'Documentos da Klingele ainda não pedidos ao colaborador'}</span>` : ''}
          ${s && s.envio_status === 'falha' && s.envio_erro ? `<span class="small clamp2" style="color:var(--crit)" title="${esc(s.envio_erro)}">${esc(s.envio_erro)}</span>` : ''}
          ${f.observacoes ? `<span class="small muted clamp2" title="${esc(f.observacoes)}">${esc(f.observacoes)}</span>` : ''}</div>
        <div class="svc"><ul>${servs.map((c) => { const v = vigencia(c); return `<li><span class="svc-t" title="${esc(c.titulo)}">${esc(c.titulo)}</span> <span class="mono muted">${esc(c.pedido)}</span>${v.dias !== undefined && v.dias < 0 ? ' ' + chip('crit', 'vigência encerrada') : ''}</li>`; }).join('') || '<li class="muted">Sem contrato ativo</li>'}</ul>
          <div class="mails">${mails.length ? mails.map((e) => `<span class="tag">${esc(e)}</span>`).join('') + (mails.length > 1 ? `<span class="tag mais-m">+${mails.length - 1}</span>` : '') : chip('warn', 'Sem e-mail cadastrado')}</div></div>
        <div class="acts">${acts}</div>
      </div>`;
    };
    // Por pasta (padrão) ou lista única. Cada grupo: calendário, próximo disparo, andamento e ações da pasta.
    const porPasta = S.f.envioVis !== 'lista' && !S.f.pasta;
    const grupo = (id, titulo, sub, extra, xs, vazio) => {
      const fechado = !!S.f.envioFechados[id], rec = xs.filter((x) => x.s && ['recebido', 'conferido'].includes(x.s.status)).length;
      return `<div class="grupo-envio${fechado ? ' fechado' : ''}">
        <div class="grupo-head"><button type="button" class="grupo-tg" data-act="grupo-envio" data-id="${id}" aria-expanded="${!fechado}">${ic.dir}<span class="gt">${titulo}</span><span class="c">${xs.length}</span></button>
          <span class="small muted gs">${sub}${xs.length ? ` · ${rec} de ${xs.length} respondido${xs.length > 1 ? 's' : ''}` : ''}</span>${extra}</div>
        ${fechado ? '' : xs.length ? xs.map(itemHTML).join('') : `<div class="grupo-vazio small muted">${vazio}</div>`}</div>`;
    };
    const acoesPasta = (p, xs) => {
      if (!p) return '';
      const faltam = xs.filter((x) => !x.s || x.s.status === 'cancelado').length, gerado = xs.filter((x) => x.s && x.s.status === 'gerado').length;
      const btns = [];
      if (!mesAberto && podeEnviarPasta(p) && (faltam || gerado)) {
        btns.push(app ? `<button class="btn sm primary" data-act="pasta-enviar" data-id="${p.id}">${ic.envio} Enviar agora (${faltam + gerado})</button>`
          : faltam ? `<button class="btn sm primary" data-act="gerar-pasta" data-id="${p.id}">${ic.link} Gerar ${faltam} link${faltam > 1 ? 's' : ''}</button>` : '');
      }
      btns.push(`<button class="btn sm ghost" data-act="abrir-pasta" data-id="${p.id}">${podeEditarPasta(p) ? 'Editar' : 'Ver'} pasta</button>`);
      return `<span class="row" style="gap:6px">${btns.join('')}</span>`;
    };
    let itens;
    if (porPasta) {
      const visiveis = S.base.pastas.filter(nivelPasta).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome));
      itens = visiveis.map((p) => {
        const xs = lista.filter((x) => x.pid === p.id);
        if (!xs.length && !p.padrao) return '';   // pasta que não pede este mês: fica só na página Pastas
        return grupo(p.id, `${ic.pasta}${esc(p.nome)}`, `${esc(U.calendarioTxt(p))} · ${esc(proxTxt(p))}`, acoesPasta(p, xs), xs, 'Nenhum contrato desta pasta vigente no mês.');
      }).join('');
      const outras = lista.filter((x) => x.pid && !PASTA(x.pid));
      if (outras.length) itens += grupo('_outras', 'Em pastas que você não vê', 'Saem no calendário dessas pastas', '', outras, '');
      const avs = lista.filter((x) => !x.pid);
      if (avs.length) itens += grupo('_avulsos', 'Contratos avulsos (sem pasta)', 'Sem envio automático: gere o link quando precisar ou ponha os contratos numa pasta',
        `<button class="btn sm ghost" data-act="ir-pastas">Organizar em pastas</button>`, avs, '');
    } else itens = lista.map(itemHTML).join('');
    const visSeg = `<div class="seg sm" role="group" aria-label="Visualização"><button type="button" data-act="envio-vis" data-v="pastas" aria-pressed="${porPasta}" ${S.f.pasta ? 'disabled title="Escolha &quot;Todas&quot; no filtro de pasta para agrupar"' : ''}>Por pasta</button><button type="button" data-act="envio-vis" data-v="lista" aria-pressed="${!porPasta}">Lista</button></div>`;
    const visiveisF = S.base.pastas.filter(nivelPasta).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome));
    const filtroPasta = `<label class="filtro-pasta"><span>Pasta</span><select id="f-pasta" aria-label="Filtrar por pasta"><option value="">Todas</option>
      ${visiveisF.map((p) => `<option value="${p.id}" ${S.f.pasta === p.id ? 'selected' : ''}>${esc(p.nome)}</option>`).join('')}<option value="avulsos" ${S.f.pasta === 'avulsos' ? 'selected' : ''}>Avulsos (sem pasta)</option></select></label>`;
    const cobAuto = cfgv('cobranca_automatica', 'true') === 'true';
    const devidas = S.solic.filter((x) => cobrancaEtapa(x).devida).length;
    const pendLembrete = mesAberto ? 0 : S.solic.filter((s) => ['enviado', 'aberto'].includes(s.status) && aindaValido(s)).length;
    const meu = escopoMeu();
    const botoes = app ? `${devidas ? `<button class="btn" data-act="cobrar-agora" title="Reenvia o link a quem passou do prazo sem responder (regra da cobrança automática)">${ic.sino} Cobrar agora (${devidas})</button>` : ''}
         ${pendLembrete ? `<button class="btn" data-act="lembrete-todos" title="Reenvia o mesmo link, mantendo o prazo de cada um${meu ? ' (todos os fornecedores, não só os seus)' : ''}">${ic.mail} Lembrete a quem não respondeu (${pendLembrete}${meu ? ' no total' : ''})</button>` : ''}
         ${pSel && !mesAberto && podeEnviarPasta(pSel) ? `<button class="btn primary" data-act="pasta-enviar" data-id="${pSel.id}">${ic.envio} Enviar a pasta agora</button>` : ''}` : '';
    const avisoMes = mesAberto ? `<span class="small muted">${esc(U.compLabel(S.comp))} ainda não terminou: os links deste mês saem a partir do último dia útil (${U.dataBR(U.ultimoDiaUtil(S.comp, S.fer))}) ou no mês seguinte, conforme cada pasta.</span>` : '';
    const pad = pastaPadrao(), podePad = pad && podeEditarPasta(pad);
    return `
      <div class="steps">${passo('Links do mês', n)}${passo('Links gerados', gerados)}${passo('E-mails enviados', enviados)}${passo('Respondidos', recebidos)}</div>
      ${pad ? `<section class="panel rotina-mes" id="sec-auto"><div class="rotina-linha">
          <div style="min-width:0"><b>${ic.pasta} ${esc(pad.nome)}</b> <span class="small muted">· ${esc(U.calendarioTxt(pad))} · ${esc(proxTxt(pad))}</span>
            ${!app ? '<div class="small muted">O disparo automático e a cobrança precisam do envio pelo app (Configurações > Envio de e-mail pelo app). Sem ele, gere os links e envie pelo Outlook.</div>' : ''}</div>
          <label class="check sm" title="${podePad ? 'Liga ou desliga o disparo automático do Envio mensal' : 'Administradores e supervisores alteram o Envio mensal'}"><span class="switch"><input type="checkbox" data-chg="toggle-auto" ${pad.ativa !== false ? 'checked' : ''} ${!app || !podePad ? 'disabled' : ''} aria-label="Disparo automático do Envio mensal"><i></i></span>Disparo automático</label>
          <label class="check sm" title="Cobrança de quem não respondeu (Configurações > Link e cobrança)"><span class="switch"><input type="checkbox" data-chg="toggle-cobranca" ${cobAuto ? 'checked' : ''} ${!app || S.papel !== 'admin' ? 'disabled' : ''} aria-label="Cobrança automática"><i></i></span>Cobrança</label>
          <span class="row" style="gap:6px"><button class="btn sm ghost" data-act="abrir-pasta" data-id="${pad.id}">${podePad ? 'Ajustar' : 'Ver'}</button><button class="btn sm ghost" data-act="ir-pastas">Todas as pastas</button></span>
        </div></section>` : ''}
      <section class="panel" id="sec-lista">
        <div class="panel-head"><div><h2>Solicitação de ${esc(U.compLabel(S.comp))}${pSel ? ` · ${esc(pSel.nome)}` : S.f.pasta === 'avulsos' ? ' · avulsos' : ''}</h2>
          <span class="sub">Um link de uso único por fornecedor e por pasta, só com os contratos daquela pasta · prazo de ${prazoDias()} dias úteis após o envio (ou o da pasta)${app ? '' : ' · pelo Outlook: abra o e-mail e registre o envio'}</span></div>
          <div class="row">${visSeg}${filtroPasta}${mesAberto ? avisoMes : botoes}</div></div>
        <div class="send-list${porPasta ? ' agrupada' : ''}">${itens || `<div class="empty"><h3>${S.f.pasta ? 'Nenhum fornecedor neste filtro' : 'Nada a enviar neste mês'}</h3><p>${S.f.pasta ? 'Escolha outra pasta ou "Todas".' : 'Ponha os contratos numa pasta (página Pastas) para eles entrarem no envio.'}</p></div>`}</div>
      </section>`;
  };

  // ---------- Contatos Klingele (colaboradores) ----------
  // Quem altera: administrador tudo; supervisor altera os cadastros, mas a marca de supervisor só a dele (não tira
  // a de outra pessoa nem desativa outro supervisor); analista inclui contatos simples e exclui os que não são
  // supervisores nem usuários do BMK. Os contratos de cada pessoa (atribuições) seguem com admin, supervisor e analista.
  const meuColabId = () => meuColab() || ((S.base.colaboradores || []).find((c) => (c.email || '').toLowerCase() === EU()) || {}).id || null;
  const podeAlterarColab = () => S.papel === 'admin' || S.papel === 'supervisor';
  const podeMarcarSup = (c) => S.papel === 'admin' || (S.papel === 'supervisor' && !!c && !!c.id && c.id === meuColabId());
  const podeDesativarColab = (c) => S.papel === 'admin' || (S.papel === 'supervisor' && (!c || !c.supervisor || c.id === meuColabId()));
  const podeExcluirColab = (c) => S.papel === 'admin' || (['supervisor', 'analista'].includes(S.papel) && !!c && !c.supervisor && !usuarioDoColab(c));
  const motivoColab = (c) => (S.papel === 'admin' ? '' : S.papel === 'supervisor' ? (c.supervisor && c.id !== meuColabId() ? 'A marca de supervisor de outra pessoa só o administrador altera.' : '')
    : S.papel === 'analista' ? 'Analista consulta os cadastros e atribui os contratos; as alterações ficam com administradores e supervisores.' : 'Perfil somente leitura.');
  // Contato Klingele que é usuário do BMK (mesmo e-mail na equipe)
  const usuarioDoColab = (c) => (c && c.email ? (S.base.equipe || []).find((e) => (e.email || '').toLowerCase() === c.email.toLowerCase()) : null) || null;
  function painelColaboradores() {
    const lista = (S.base.colaboradores || []).slice().sort((a, b) => (b.ativo - a.ativo) || ordemCol(a, b));
    const visiveis = contatosFornecedor();
    const linha = U.contatosTexto(visiveis);
    const quem = S.papel === 'admin' ? 'Você altera todos os cadastros.' : S.papel === 'supervisor' ? 'Você altera os cadastros; a marca de supervisor, só a sua.'
      : S.papel === 'analista' ? 'Você inclui contatos e atribui os contratos; as alterações nos cadastros ficam com administradores e supervisores.' : 'Somente consulta.';
    return `<section class="panel" id="sec-colab">
      <div class="panel-head"><div><h2>${lista.filter((c) => c.ativo).length} contato${lista.filter((c) => c.ativo).length !== 1 ? 's' : ''} · ${lista.filter((c) => c.ativo && c.supervisor).length} supervisor${lista.filter((c) => c.ativo && c.supervisor).length !== 1 ? 'es' : ''}</h2>
        <span class="sub">"Contato geral" aparece ao fornecedor nos serviços sem contato próprio (até 5). ${esc(quem)}</span></div>
        <div class="row" style="gap:8px"><div class="search">${ic.busca}<input type="search" id="colab-busca" placeholder="Buscar nome, cargo ou e-mail" aria-label="Buscar contato"></div>
        ${S.papel !== 'leitura' ? `<button class="btn sm primary" data-act="novo-colab">${ic.mais} Adicionar</button>` : ''}</div></div>
      <div id="colab-lista">${lista.map((c) => `<div class="colab-row" data-busca="${esc([c.nome, c.cargo, c.email].join(' ').toLowerCase())}" ${c.ativo ? '' : 'style="opacity:.55"'}>
          <div style="min-width:0"><div class="cell-title">${esc(c.nome)}${c.ativo ? '' : ' <span class="small muted">(inativo)</span>'}</div><div class="cell-sub">${esc(c.cargo || 'Cargo não informado')}${usuarioDoColab(c) ? ` · <span class="chip accent plain" title="Usuário do BMK">${esc(PAPEL[usuarioDoColab(c).papel] || 'Usuário')}</span>` : ''}</div></div>
          <div class="small" style="min-width:0;display:grid;gap:2px">${c.email ? `<span style="overflow-wrap:anywhere">${esc(c.email)}</span>` : '<span class="muted">Sem e-mail</span>'}${c.telefone ? `<span class="muted">${esc(c.telefone)}</span>` : ''}</div>
          <div class="flags">
            <label title="${podeAlterarColab() ? 'Aparece ao fornecedor nos serviços que não têm contato próprio' : 'Só administradores e supervisores alteram'}"><span class="switch"><input type="checkbox" data-chg="colab-flag" data-id="${c.id}" data-k="contato_fornecedor" ${c.contato_fornecedor ? 'checked' : ''} ${podeAlterarColab() ? '' : 'disabled'} aria-label="${esc(c.nome)}: contato geral do fornecedor"><i></i></span>Contato geral</label>
            <label title="${podeMarcarSup(c) ? 'Pode ser supervisor de contrato e recebe a avaliação' : S.papel === 'supervisor' ? 'Supervisor altera só a própria marca de supervisor' : 'Só o administrador altera a marca de supervisor de outra pessoa'}"><span class="switch"><input type="checkbox" data-chg="colab-flag" data-id="${c.id}" data-k="supervisor" ${c.supervisor ? 'checked' : ''} ${podeMarcarSup(c) ? '' : 'disabled'} aria-label="${esc(c.nome)}: supervisor"><i></i></span>Supervisor</label>
          </div>
          <span class="small muted colab-n">${(() => { const ns = S.base.contratos.filter((k) => k.situacao === 'ativo' && supsDe(k).includes(c.id)).length, nc = S.base.contratos.filter((k) => k.situacao === 'ativo' && ctsDe(k).includes(c.id)).length;
            return [ns ? `supervisor em ${ns}` : '', nc ? `contato em ${nc}` : ''].filter(Boolean).join(' · ') || 'sem contrato'; })()}</span>
          <button class="icon-btn" data-act="abrir-colab" data-id="${c.id}" title="${podeAlterarColab() ? 'Editar' : 'Ver e atribuir contratos'}" aria-label="${podeAlterarColab() ? 'Editar' : 'Ver'} ${esc(c.nome)}">${podeAlterarColab() ? ic.lapis : ic.olho}</button>
        </div>`).join('') || '<div class="empty"><h3>Nenhum colaborador cadastrado</h3><p>Cadastre quem atende os fornecedores e os supervisores dos contratos.</p></div>'}
        <p class="muted small colab-nada" hidden style="padding:14px 18px;margin:0">Nenhum contato com esta busca.</p></div>
      <div class="panel-body small" style="border-top:1px solid var(--line);color:var(--ink-2)">
        ${linha ? `Serviço sem contato próprio, no e-mail ao fornecedor: <span style="white-space:pre-wrap">Problemas com o link ou o código? Fale com: ${esc(linha)}</span>`
          : 'Nenhum contato geral: serviços sem contato próprio saem sem a linha de contato, e a página do link exibe "Fale com seu contato na Klingele".'}
        <div style="margin-top:4px">Cada serviço mostra os contatos dele (abra o contrato ou o contato para ligar). Serviços com contatos diferentes saem um por linha no e-mail.</div>
      </div>
    </section>`;
  }
  function abrirColaborador(id) {
    const c = id ? COL(id) : { nome: '', cargo: '', email: '', telefone: '', contato_fornecedor: true, supervisor: false, ativo: true, ordem: 0 };
    S.gaveta = { tipo: 'colab', id: id || null };
    // Novo contato: quem edita inclui (sem a marca de supervisor, que só o administrador dá a outra pessoa).
    // Contato existente: campos só para administrador e supervisor; contratos para quem edita.
    const dados = !id ? S.papel !== 'leitura' : podeAlterarColab(), dis = dados ? '' : 'disabled';
    const disSup = (id ? podeMarcarSup(c) : S.papel === 'admin') ? '' : 'disabled';
    const disAtivo = dados && podeDesativarColab(c) ? '' : 'disabled';
    const disAloc = S.papel === 'leitura' ? 'disabled' : '';
    S.gaveta.dados = !!dados;
    const lista = S.base.contratos.filter((k) => k.situacao === 'ativo' || (id && (supsDe(k).includes(id) || ctsDe(k).includes(id))))
      .sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || (a.pedido || 0) - (b.pedido || 0));
    S.gaveta.orig = { sup: lista.filter((k) => id && supsDe(k).includes(id)).map((k) => k.id), ct: lista.filter((k) => id && ctsDe(k).includes(id)).map((k) => k.id) };
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">${id ? 'Contato Klingele' : 'Novo contato Klingele'}</span><h2>${esc(c.nome || 'Cadastro de contato')}</h2></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <div class="form-grid">
          ${id && motivoColab(c) ? `<p class="hint full" style="margin:0">${esc(motivoColab(c))}</p>` : ''}
          <label class="field"><span>Nome</span><input type="text" id="fk-nome" maxlength="120" value="${esc(c.nome || '')}" ${dis}></label>
          <label class="field"><span>Cargo</span><input type="text" id="fk-cargo" maxlength="80" value="${esc(c.cargo || '')}" placeholder="Ex.: Analista de contratos" ${dis}></label>
          <label class="field"><span>E-mail</span><input type="email" id="fk-email" maxlength="254" value="${esc(c.email || '')}" placeholder="nome@klingele.com.br" ${dis}></label>
          <label class="field"><span>Telefone</span><input type="tel" id="fk-tel" maxlength="60" value="${esc(c.telefone || '')}" placeholder="(00) 0000-0000" ${dis}></label>
          <label class="field"><span>Ordem na lista <span class="hint">(menor aparece primeiro)</span></span><input type="number" id="fk-ordem" min="0" max="999" value="${esc(c.ordem ?? 0)}" ${dis}></label>
          <span></span>
          <label class="check"><input type="checkbox" id="fk-contato" ${c.contato_fornecedor ? 'checked' : ''} ${dis}> Contato geral (aparece ao fornecedor nos serviços sem contato próprio)</label>
          <label class="check"><input type="checkbox" id="fk-sup" ${c.supervisor ? 'checked' : ''} ${disSup}> Supervisor de contrato (recebe a avaliação e o aviso de vencimento)</label>
          <label class="check"><input type="checkbox" id="fk-ativo" ${c.ativo !== false ? 'checked' : ''} ${disAtivo}> Ativo</label>
        </div>
        <section><div class="section-title"><h3>Contratos</h3><span class="small muted" id="fk-resumo">${alocResumo(S.gaveta.orig.ct.length, S.gaveta.orig.sup.length)}</span></div>
          <p class="hint" style="margin:0 0 8px">Marque em quais contratos ativos este contato é <b>contato do serviço</b> (suporte ao fornecedor) e <b>supervisor</b> (avaliação e aviso de vencimento).</p>
          <div class="row" style="gap:8px;margin-bottom:8px"><div class="search" style="flex:1">${ic.busca}<input type="search" id="fk-busca" placeholder="Buscar fornecedor, pedido ou serviço" aria-label="Buscar contrato"></div>
            <label class="check sm"><input type="checkbox" id="fk-so-marcados"> Só os marcados</label></div>
          <div class="aloc" id="fk-aloc">${lista.map((k) => {
            const sp = U.TIPOS_SERVICO[k.tipo_servico];
            return `<div class="aloc-row" data-busca="${esc([F(k.fornecedor_id).nome, k.pedido, k.titulo].join(' ').toLowerCase())}">
              <div class="aloc-t"><b>${esc(F(k.fornecedor_id).nome)}</b><span class="cell-sub">${esc(k.titulo)} · <span class="mono">${esc(k.pedido || '—')}</span>${sp && sp[0] === 'Não fixo' ? ' · Spot' : ''}${k.situacao !== 'ativo' ? ' · inativo' : ''}</span></div>
              <label class="check sm"><input type="checkbox" data-aloc="ct" value="${k.id}" ${S.gaveta.orig.ct.includes(k.id) ? 'checked' : ''} ${disAloc}> Contato</label>
              <label class="check sm"><input type="checkbox" data-aloc="sup" value="${k.id}" ${S.gaveta.orig.sup.includes(k.id) ? 'checked' : ''} ${c.supervisor && !disAloc ? '' : 'disabled'}> Supervisor</label></div>`;
          }).join('') || '<p class="muted">Nenhum contrato ativo.</p>'}</div></section>
      </div>
      <div class="drawer-foot">
        ${id && podeExcluirColab(c) ? `<button class="btn danger" data-act="excluir-colab">${ic.lixo} Excluir</button>` : ''}<span class="spacer"></span>
        <button class="btn" data-act="fechar-gaveta">${S.papel === 'leitura' ? 'Fechar' : 'Cancelar'}</button>
        ${S.papel !== 'leitura' ? `<button class="btn primary" data-act="salvar-colab">${ic.ok} ${dados || !id ? 'Salvar' : 'Salvar contratos'}</button>` : ''}
      </div>`);
  }
  const alocResumo = (nc, ns) => `contato em ${nc} · supervisor em ${ns}`;
  const alocMarcados = (papel) => Array.from(document.querySelectorAll(`#fk-aloc [data-aloc="${papel}"]:checked:not(:disabled)`)).map((i) => i.value);
  function filtrarAloc() {
    const q = ((document.getElementById('fk-busca') || {}).value || '').trim().toLowerCase(), so = (document.getElementById('fk-so-marcados') || {}).checked;
    document.querySelectorAll('#fk-aloc .aloc-row').forEach((r) => {
      r.hidden = (q && !r.dataset.busca.includes(q)) || (so && !r.querySelector('[data-aloc]:checked'));
    });
  }
  async function salvarColaborador() {
    const g = (k) => document.getElementById('fk-' + k);
    const d = {
      nome: g('nome').value.trim(), cargo: g('cargo').value.trim() || null, email: g('email').value.trim().toLowerCase() || null,
      telefone: g('tel').value.trim() || null, ordem: Number(g('ordem').value) || 0,
      contato_fornecedor: g('contato').checked, supervisor: g('sup').checked, ativo: g('ativo').checked
    };
    if (d.nome.length < 2 || d.nome.length > 120) { U.toast('Informe o nome (2 a 120 caracteres)', 'erro'); return; }
    if (d.cargo && d.cargo.length > 80) { U.toast('Cargo com mais de 80 caracteres', 'erro'); return; }
    if (d.email && !U.emailValido(d.email)) { U.toast('E-mail inválido', 'erro'); return; }
    if (!U.telefoneValido(d.telefone)) { U.toast('Telefone inválido: utilize apenas números, espaço, parênteses, + e -', 'erro'); return; }
    if (!(Number.isInteger(d.ordem) && d.ordem >= 0 && d.ordem <= 999)) { U.toast('Ordem entre 0 e 999', 'erro'); return; }
    if (d.contato_fornecedor && !d.email && !d.telefone) { U.toast('Para aparecer ao fornecedor, informe e-mail ou telefone', 'erro'); return; }
    if (d.email && (S.base.colaboradores || []).some((x) => x.id !== S.gaveta.id && (x.email || '').toLowerCase() === d.email)) { U.toast('Já existe um colaborador com este e-mail', 'erro'); return; }
    const ct = alocMarcados('ct'), sup = d.supervisor ? alocMarcados('sup') : [];
    const mudou = (a, b) => a.length !== b.length || a.some((x) => !b.includes(x));
    try {
      // Sem permissão para o cadastro (analista): só os contratos da pessoa são gravados
      const r = S.gaveta.id && !S.gaveta.dados ? null : await API.salvarColaborador({ ...(S.gaveta.id ? { id: S.gaveta.id } : {}), ...d });
      const cid = S.gaveta.id || (r && r.id);
      if (cid && mudou(ct, S.gaveta.orig.ct)) await API.definirResponsavel(cid, 'contato', ct);
      if (cid && mudou(sup, S.gaveta.orig.sup)) await API.definirResponsavel(cid, 'supervisor', sup);
      await recarregar(true); fecharGaveta(); renderView();
      U.toast(d.supervisor && !d.email ? 'Salvo. Sem e-mail, este supervisor não recebe a avaliação nem o aviso de vencimento.' : 'Contato Klingele salvo');
    } catch (e) { U.toast(/duplicate|unique/i.test(e.message) ? 'Já existe um colaborador com este e-mail.' : e.message, 'erro'); }
  }

  function abrirSolicitacao(sid, opc) {
    const s = S.solic.find((x) => x.id === sid);
    if (!s) return;
    opc = opc || {};
    const f = F(s.fornecedor_id);
    const valida = aindaValido(s);
    const jaEnviado = !!s.enviado_em || enviosDa(sid).length > 0;
    const manter = !!opc.manter && jaEnviado;
    const contatos = f.contatos || [];
    const padrao = contatos.filter((c) => c.recebe_boletim).map((c) => c.email);
    const sel = opc.marcados || (padrao.length ? padrao : (s.emails_destino || []));
    const fora = (s.emails_destino || []).filter((e) => !contatos.some((c) => c.email === e));
    const { assunto, corpo } = emailDe(s, manter);
    const prazoNovo = U.dataLocal(U.fimPrazoISO(new Date().toISOString(), prazoDias(), S.fer));
    const fim = U.dataLocal(s.expira_em);
    const restam = U.diasUteisAte(fim, S.fer);
    const app = podeEnviarPeloApp();
    const scroll = opc.manterScroll && document.querySelector('#gaveta .drawer-body') ? document.querySelector('#gaveta .drawer-body').scrollTop : 0;
    S.gaveta = { tipo: 'solic', id: sid };

    let blocoAcao = '', rodape = '';
    if (valida) {
      blocoAcao = `<section>
        <div class="section-title"><h3>${jaEnviado ? 'Reenviar' : 'Enviar'}</h3></div>
        <div class="stack" style="gap:12px">
          <div class="field"><span>Para</span>
            <div class="stack" style="gap:6px">${contatos.map((c) => `<label class="check"><input type="checkbox" data-para value="${esc(c.email)}" ${sel.includes(c.email) ? 'checked' : ''}>
              <span style="overflow-wrap:anywhere">${esc(c.email)}</span><span class="small muted">${esc(c.nome || '')}</span>${c.recebe_boletim ? '' : chip('', 'fora da lista mensal')}</label>`).join('')
              || '<span class="small muted">Nenhum contato cadastrado.</span>'}
              ${fora.map((e) => `<label class="check"><input type="checkbox" data-para value="${esc(e)}" ${sel.includes(e) ? 'checked' : ''}><span>${esc(e)}</span><span class="small muted">usado no último envio</span></label>`).join('')}</div>
            <input type="text" id="em-extra" maxlength="600" placeholder="Outros e-mails, separados por vírgula" value="${esc(opc.extra || '')}" aria-label="Outros e-mails"></div>
          ${jaEnviado ? `<div class="field"><span>Prazo do link</span>
            <label class="check"><input type="radio" name="em-prazo" value="novo" data-chg="prazo-opcao" ${!manter ? 'checked' : ''}> Recomeçar o prazo: válido até ${U.dataBR(prazoNovo)} (${prazoDias()} dias úteis a partir de hoje)</label>
            <label class="check"><input type="radio" name="em-prazo" value="manter" data-chg="prazo-opcao" ${manter ? 'checked' : ''}> Manter o prazo atual (até ${U.dataBR(fim)}) e enviar como lembrete</label></div>`
            : `<span class="hint">O prazo de ${prazoDias()} dias úteis começa no envio: válido até ${U.dataBR(prazoNovo)}.</span>`}
          <details class="email-preview" ${app ? '' : 'open'}>
            <summary style="padding:10px 14px;cursor:pointer;font-weight:600">Texto do e-mail${app ? ' <span class="small muted" style="font-weight:400">(para o Outlook)</span>' : ''}</summary>
            <div class="hdr"><label class="row"><span class="k label">Assunto</span><input type="text" id="em-assunto" maxlength="400" value="${esc(assunto)}"></label></div>
            <textarea id="em-corpo" aria-label="Texto do e-mail" style="min-height:300px">${esc(corpo)}</textarea>
          </details>
        </div></section>`;
      rodape = `<button class="btn" data-act="copiar-email">${ic.copiar} Copiar texto</button>
        <a class="btn ${app ? '' : 'fixo'}" href="#" data-act="outlook">${ic.mail} Abrir no Outlook</a>
        <button class="btn ${app ? '' : 'primary'}" data-act="registrar-envio" data-s="${s.id}">${ic.ok} Registrar envio pelo Outlook</button>
        ${app ? `<button class="btn primary" data-act="enviar-um" data-s="${s.id}">${ic.envio} ${jaEnviado ? (manter ? 'Enviar lembrete' : 'Reenviar') : 'Enviar'} pelo app</button>` : ''}`;
    } else if (['recebido', 'conferido'].includes(s.status)) {
      blocoAcao = `<div class="demo-banner" style="background:var(--ok-soft);border-color:transparent"><span>O fornecedor já respondeu em ${U.dataHoraBR(s.recebido_em)}${s.respondido_por ? ' (' + esc(s.respondido_por) + ')' : ''}. Este link não aceita outro envio.</span></div>`;
      rodape = `<button class="btn" data-act="renovar" data-s="${s.id}">${ic.refazer} Liberar novo envio</button>
        <button class="btn primary" data-act="abrir-receb" data-s="${s.id}">${ic.receb} Ver recebimento</button>`;
    } else if (s.dispensa) {
      blocoAcao = '';
      rodape = S.papel !== 'leitura' ? `<button class="btn primary" data-act="reativar-envio" data-s="${s.id}">${ic.refazer} Reativar o envio</button>` : '';
    } else {
      blocoAcao = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><span>${s.status === 'cancelado' ? 'Solicitação cancelada.' : `O link venceu em ${U.dataBR(fim)}.`} Para o fornecedor enviar, gere um novo link: o atual continua inválido.</span></div>`;
      rodape = `<button class="btn primary" data-act="renovar-reenviar" data-s="${s.id}">${ic.refazer} Gerar novo link e reenviar</button>`;
    }

    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">Verificar e reenviar · ${esc(U.compLabel(s.competencia))}</span><h2>${esc(f.nome)}</h2>
        <div class="row">${chipSol(s)}${chipDocs(f, s)}${s.envio_status === 'falha' ? `<span class="chip crit"${s.envio_erro ? ` title="${esc(s.envio_erro)}"` : ''}>Falha no último envio</span>` : ''}</div></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <section>
          <div class="section-title"><h3>Situação do link</h3></div>
          <dl class="kv">
            <dt>Prazo</dt><dd>${valida ? `Válido até ${U.dataBR(fim)} <span class="muted">(${restam === 0 ? 'último dia' : restam + (restam === 1 ? ' dia útil' : ' dias úteis')})</span>` : ['recebido', 'conferido'].includes(s.status) ? 'Encerrado (já utilizado)' : s.status === 'cancelado' ? 'Cancelado' : `Venceu em ${U.dataBR(fim)}`}</dd>
            <dt>Último envio</dt><dd>${s.enviado_em ? `${U.dataHoraBR(s.enviado_em)} para ${esc((s.emails_destino || []).join(', '))}` : 'Ainda não enviado'}</dd>
            <dt>Fornecedor abriu</dt><dd>${s.aberto_em ? U.dataHoraBR(s.aberto_em) : s.enviado_em ? '<span style="color:var(--warn)">Ainda não abriu o link</span>' : '—'}</dd>
            <dt>Respondido</dt><dd>${s.recebido_em ? U.dataHoraBR(s.recebido_em) : '—'}</dd>
          </dl>
          <div class="link-box" style="margin-top:10px"><code>${esc(linkPortal(s))}</code>
            <button class="btn sm" data-act="copiar-link" data-s="${s.id}">${ic.copiar} Copiar</button>
            <button class="btn sm" data-act="previa" data-s="${s.id}" title="Abre a página do fornecedor sem marcar como aberta">${ic.olho} Ver como o fornecedor</button>
            ${DEMO && valida ? `<button class="btn sm ghost" data-act="simular" data-s="${s.id}">Simular resposta</button>` : ''}</div>
        </section>
        ${blocoDispensa(s)}
        ${blocoDocsKlg(s, f)}
        ${retratil('envios-solic', 'Envios deste link', null, '<div id="envios-lista"><p class="muted small">Carregando…</p></div>')}
        ${blocoAcao}
        ${correcoesSolicitacao(s)}
      </div>
      <div class="drawer-foot"><button class="btn ghost" data-act="fechar-gaveta">Fechar</button><span class="spacer"></span>${rodape}</div>`);
    if (scroll) document.querySelector('#gaveta .drawer-body').scrollTop = scroll;
    API.enviosDe(sid).then((lista) => {
      const box = document.getElementById('envios-lista');
      if (!box || !S.gaveta || S.gaveta.id !== sid) return;
      contarRetratil('envios-solic', lista.length);
      box.innerHTML = lista.length ? lista.map((e) => `<div class="envio-item">
          <div class="row between" style="flex-wrap:nowrap;gap:8px"><b>${esc(TIPO_ENVIO[e.tipo])} ${esc(VIA_ENVIO[e.via])}</b>${chipEnvio(e)}</div>
          <div class="small muted">${U.dataHoraBR(e.created_at)} · por ${esc(e.autor || 'sistema')}${e.prazo_ate ? ' · prazo até ' + U.dataBR(U.dataLocal(e.prazo_ate)) : ''}</div>
          <div class="mails" style="margin-top:4px">${(e.para || []).map((x) => `<span class="tag">${esc(x)}</span>`).join('')}</div>
          ${e.erro ? `<div class="small" style="color:var(--crit);margin-top:4px">${esc(e.erro)}</div>` : ''}
          ${e.corpo ? `<details style="margin-top:6px"><summary class="small" style="cursor:pointer">Ver texto enviado</summary>
            <div class="small" style="white-space:pre-wrap;overflow-wrap:anywhere;margin-top:6px;color:var(--ink-2)"><b>${esc(e.assunto || '')}</b>\n\n${esc(e.corpo)}</div></details>` : ''}
          ${S.papel === 'admin' && e.status !== 'pendente' ? `<div style="margin-top:6px"><button class="btn sm ghost perigo" data-act="envio-excluir" data-id="${e.id}">${ic.lixo} Excluir registro</button></div>` : ''}
        </div>`).join('') : '<p class="muted small">Nenhum envio registrado para este link.</p>';
    }).catch((e) => { const box = document.getElementById('envios-lista'); if (box) box.innerHTML = `<p class="small" style="color:var(--crit)">${esc(e.message)}</p>`; });
  }
  const lerEmailForm = () => {
    const marcados = Array.from(document.querySelectorAll('#gaveta [data-para]:checked')).map((i) => i.value);
    const extraTxt = (document.getElementById('em-extra') || {}).value || '';
    const extra = extraTxt.split(/[,;\s]+/).map((x) => x.trim()).filter(Boolean);
    const r = document.querySelector('#gaveta input[name="em-prazo"]:checked');
    return {
      para: Array.from(new Set(marcados.concat(extra).map((x) => x.toLowerCase()))), marcados, extra: extraTxt,
      assunto: (document.getElementById('em-assunto') || {}).value || '', corpo: (document.getElementById('em-corpo') || {}).value || '',
      manter: !!r && r.value === 'manter'
    };
  };
  // Correções do administrador: recebimento ou solicitação feitos por engano (com motivo, ficam no histórico)
  function correcoesSolicitacao(s) {
    if (S.papel !== 'admin' || !s) return '';
    const recebido = ['recebido', 'conferido'].includes(s.status);
    return `<section class="correcoes">
      <div class="section-title"><h3>Correções</h3><span class="small muted">Somente administrador · exige motivo</span></div>
      <p class="small muted">Para recebimentos ou envios registrados por engano. A exclusão é definitiva e fica registrada no histórico.</p>
      <div class="row">${recebido ? `<button class="btn danger" data-act="receb-excluir" data-s="${s.id}">${ic.lixo} Excluir recebimento</button>` : ''}
        <button class="btn ${recebido ? 'ghost perigo' : 'danger'}" data-act="solic-excluir" data-s="${s.id}">${ic.lixo} Excluir solicitação</button></div>
    </section>`;
  }
  // Janela com motivo obrigatório (e opções), usada nas exclusões e na limpeza do histórico
  function formularioMotivo({ titulo, texto, opcoes, rotulo, perigo }) {
    return new Promise((ok) => {
      const w = document.createElement('div');
      w.className = 'modal-wrap';
      const op = !opcoes ? '' : `<fieldset class="op-motivo"><legend class="small muted">${opcoes.tipo === 'check' ? 'Incluir' : 'Depois da exclusão'}</legend>${opcoes.itens.map(([v, t, marcado]) =>
        `<label class="check"><input type="${opcoes.tipo === 'check' ? 'checkbox' : 'radio'}" name="mt-op" value="${esc(v)}" ${marcado ? 'checked' : ''}> ${esc(t)}</label>`).join('')}</fieldset>`;
      w.innerHTML = `<div class="backdrop" data-x></div><form class="modal" role="dialog" aria-modal="true" aria-labelledby="mt-t" novalidate>
        <h2 id="mt-t">${esc(titulo)}</h2><p class="muted">${esc(texto)}</p>${op}
        <label class="field"><span>Motivo <span class="hint">(obrigatório, fica registrado)</span></span><textarea id="mt-motivo" rows="3" maxlength="500" required></textarea></label>
        <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-x>Voltar</button>
        <button type="submit" class="btn ${perigo ? 'danger' : 'primary'}">${esc(rotulo || 'Confirmar')}</button></div></form>`;
      const fim = (v) => { w.remove(); ok(v); };
      w.addEventListener('click', (e) => { if (e.target.closest('[data-x]')) fim(null); });
      w.querySelector('form').addEventListener('submit', (e) => {
        e.preventDefault();
        const motivo = w.querySelector('#mt-motivo').value.trim();
        if (motivo.length < 5) { U.toast('Informe o motivo (pelo menos 5 caracteres)', 'erro'); w.querySelector('#mt-motivo').focus(); return; }
        const marc = Array.from(w.querySelectorAll('[name="mt-op"]:checked')).map((i) => i.value);
        fim({ motivo, escolhas: marc, modo: marc[0] || null });
      });
      document.body.appendChild(w);
      w.querySelector('#mt-motivo').focus();
    });
  }
  async function aposExcluir(r, txt) {
    let extra = '';
    if (r && r.caminhos && r.caminhos.length) {
      const x = await API.removerArquivos(r.caminhos).catch((e) => ({ ok: false, erro: e.message }));
      extra = x.ok ? ` ${r.caminhos.length} arquivo(s) removido(s) do armazenamento.` : ` Os arquivos não foram removidos do armazenamento (${x.erro}).`;
    }
    fecharGaveta(); await recarregar(true); renderView(); U.toast(txt + extra);
  }
  function conferirPara(e) {
    if (!e.para.length) { U.toast('Escolha pelo menos um destinatário', 'erro'); return false; }
    const ruim = e.para.find((x) => !U.emailValido(x));
    if (ruim) { U.toast(`E-mail inválido: ${ruim}`, 'erro'); return false; }
    if (e.para.length > 15) { U.toast('Máximo de 15 destinatários', 'erro'); return false; }
    return true;
  }

  // =====================================================================
  //  RECEBIMENTOS
  // =====================================================================
  const GRUPO_RECEB = { aguardando: ['gerado', 'enviado', 'aberto'], recebido: ['recebido'], conferido: ['conferido'], encerrado: ['expirado', 'cancelado'] };
  VIEWS.receb = () => {
    const todas = S.solic.filter((s) => fornecedorMeu(s.fornecedor_id)).sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome));
    const cnt = (k) => todas.filter((s) => GRUPO_RECEB[k].includes(s.status)).length;
    const lista = S.f.receb === 'todos' ? todas : todas.filter((s) => GRUPO_RECEB[S.f.receb].includes(s.status));
    const seg = [['todos', 'Todos', todas.length], ['aguardando', 'Aguardando', cnt('aguardando')], ['recebido', 'A conferir', cnt('recebido')], ['conferido', 'Conferidos', cnt('conferido')], ['encerrado', 'Encerrados', cnt('encerrado')]];
    const linhas = lista.map((s) => {
      const f = F(s.fornecedor_id);
      const meds = S.med.filter((m) => m.fornecedor_id === s.fornecedor_id);
      const docs = S.docs.filter((d) => d.fornecedor_id === s.fornecedor_id && d.tipo !== 'klingele');
      const inf = meds.some((m) => m.valor_informado !== null) ? soma(meds.map((m) => m.valor_informado)) : null;
      const ct = soma(meds.map((m) => m.valor_contratado));
      const r = inf === null ? { cls: '', txt: '—' } : comparar({ valor_informado: inf, valor_contratado: ct, valor_aprovado: meds.every((m) => m.valor_aprovado !== null) ? soma(meds.map((m) => m.valor_aprovado)) : null, status: '' });
      return `<tr class="click" data-act="abrir-receb" data-s="${s.id}">
        <td><div class="cell-title">${esc(f.nome)}</div><div class="cell-sub">${meds.length} pedido${meds.length !== 1 ? 's' : ''}${s.respondido_por ? ' · ' + esc(s.respondido_por) : ''}</div></td>
        <td>${chipSol(s)}</td>
        <td class="num small">${s.enviado_em ? U.dataBR(U.dataLocal(s.enviado_em)) : '—'}</td>
        <td class="small">${s.recebido_em ? `<span class="num">${U.dataHoraBR(s.recebido_em)}</span>` : `<span class="muted">${esc(prazoTxt(s) || '—')}</span>`}</td>
        <td class="num">${docs.length || '—'}</td>
        <td class="r num">${U.brl(inf)}</td>
        <td class="r num">${U.brl(ct)}</td>
        <td>${r.txt === '—' ? '<span class="muted">—</span>' : chip(r.cls, r.txt)}${meds.some(divergente) ? ' ' + chip('warn', 'Informado ≠ lido') : ''}</td>
      </tr>`;
    }).join('');
    return `
      <div class="row between"><div class="seg" role="group" aria-label="Filtrar recebimentos">${seg.map(([k, t, c]) => `<button type="button" data-act="filtro-receb" data-v="${k}" aria-pressed="${S.f.receb === k}">${t}<span class="c">${c}</span></button>`).join('')}</div></div>
      <section class="panel"><div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fornecedor</th><th>Situação</th><th>Enviado</th><th>Recebido / prazo</th><th>Arquivos</th><th class="r">Informado</th><th class="r">Contratado</th><th>Comparativo</th></tr></thead>
        <tbody>${linhas || `<tr><td colspan="8"><div class="empty"><h3>Nenhum registro</h3><p>${S.solic.length ? 'Nenhuma solicitação neste filtro.' : 'Nenhum link gerado para ' + esc(U.compLabel(S.comp)) + '.'}</p></div></td></tr>`}</tbody>
      </table></div></section>`;
  };

  function docHTML(d, contratos) {
    const ext = U.extensao(d.nome_arquivo);
    const legivel = ['pdf', 'xlsx', 'xls', 'csv'].includes(ext);
    return `<div class="doc">
      <span class="ext ${esc(ext)}">${esc(ext)}</span>
      <div class="meta"><b class="mono" style="font-size:.84rem" title="${esc(d.nome_padrao || d.nome_arquivo)}">${esc(d.nome_padrao || d.nome_arquivo)}</b>
        <span class="small muted">${d.nome_padrao ? `Original: ${esc(d.nome_arquivo)} · ` : ''}${U.tamanho(d.tamanho)} · enviado ${d.enviado_por === 'equipe' ? 'pela equipe' : 'pelo fornecedor'} em ${U.dataHoraBR(d.created_at)}</span>
        <div class="row" style="gap:6px;margin-top:6px">
          ${d.tipo === 'klingele' ? `<span class="tag">${esc(U.TIPOS_DOC.klingele)}</span>` : `<select data-chg="doc-tipo" data-d="${d.id}" aria-label="Tipo do documento" style="width:auto">${Object.entries(U.TIPOS_DOC_TROCA).map(([k, v]) => `<option value="${k}" ${d.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select>`}
          ${contratos.length > 1 || !d.contrato_id ? `<select data-chg="doc-contrato" data-d="${d.id}" aria-label="Pedido do documento" style="width:auto"><option value="">Sem pedido</option>${contratos.map((c) => `<option value="${c.id}" ${d.contrato_id === c.id ? 'selected' : ''}>Pedido ${esc(c.pedido)}</option>`).join('')}</select>` : `<span class="tag">Pedido <span class="mono">${esc(C(d.contrato_id).pedido)}</span></span>`}
        </div>
        <div class="leitura" id="leit-${d.id}">${d.valor_lido !== null && d.valor_lido !== undefined ? `Valor lido: <b class="num">${U.brl(d.valor_lido)}</b>` : ''}</div>
      </div>
      <div class="acts">
        <button class="btn sm" data-act="doc-abrir" data-d="${d.id}">${ic.abrir} Abrir</button>
        <button class="icon-btn" data-act="doc-baixar" data-d="${d.id}" title="Baixar com o nome organizado" aria-label="Baixar">${ic.baixar}</button>
        ${legivel ? `<button class="btn sm" data-act="doc-ler" data-d="${d.id}">${ic.ler} Ler valor</button>` : ''}
        <button class="icon-btn" data-act="doc-rm" data-d="${d.id}" title="Excluir arquivo" aria-label="Excluir arquivo">${ic.lixo}</button>
      </div></div>`;
  }

  // Documento da Klingele (o fornecedor baixa no link): abrir, baixar e, enquanto o fornecedor não respondeu, remover
  function docKlgHTML(d) {
    const ext = U.extensao(d.nome_arquivo), s = S.solic.find((x) => x.id === d.solicitacao_id);
    const pode = S.papel !== 'leitura' && s && ['gerado', 'enviado', 'aberto'].includes(s.status);
    return `<div class="doc doc-klg">
      <span class="ext ${esc(ext)}">${esc(ext)}</span>
      <div class="meta"><b class="mono" style="font-size:.84rem" title="${esc(d.nome_padrao || d.nome_arquivo)}">${esc(d.nome_padrao || d.nome_arquivo)}</b>
        <span class="small muted">${d.nome_padrao ? `Original: ${esc(d.nome_arquivo)} · ` : ''}${U.tamanho(d.tamanho)} · ${d.enviado_por === 'colaborador' ? 'anexado pelo colaborador' : 'anexado pela equipe'} em ${U.dataHoraBR(d.created_at)}</span></div>
      <div class="acts">
        <button class="btn sm" data-act="doc-abrir" data-d="${d.id}">${ic.abrir} Abrir</button>
        <button class="icon-btn" data-act="doc-baixar" data-d="${d.id}" title="Baixar com o nome organizado" aria-label="Baixar">${ic.baixar}</button>
        ${pode ? `<button class="icon-btn" data-act="doc-klg-rm" data-d="${d.id}" title="Remover (o fornecedor deixa de ver)" aria-label="Remover documento">${ic.lixo}</button>` : ''}
      </div></div>`;
  }
  // Bloco da gaveta do link: documentos da Klingele, pedido ao colaborador e "sem medição neste mês"
  function blocoDocsKlg(s, f) {
    const dk = docsKlg(s.id), aberto = ['gerado', 'enviado', 'aberto'].includes(s.status) && !s.dispensa;
    if (!pedeDocs(f) && !dk.length) return '';
    const col = colabDocs(f), edita = S.papel !== 'leitura';
    const linhas = [
      `<dt>Quem envia</dt><dd>${col ? `${esc(col.nome)} <span class="muted">· ${esc(col.email)}</span>` : '<span class="muted">Sem colaborador com e-mail: o pedido vai aos analistas</span>'}</dd>`,
      `<dt>Pedido</dt><dd>${s.docs_pedido_em ? 'Enviado em ' + U.dataHoraBR(s.docs_pedido_em) : '<span class="muted">Ainda não pedido</span>'}${s.docs_aberto_em ? ` · aberto em ${U.dataHoraBR(s.docs_aberto_em)}` : ''}</dd>`,
      s.docs_enviado_em ? `<dt>Anexados</dt><dd>${U.dataHoraBR(s.docs_enviado_em)}${s.docs_por ? ' por ' + esc(s.docs_por) : ''}</dd>` : ''
    ].join('');
    return `<section id="sec-docs-klg">
      <div class="section-title"><h3>Documentos da Klingele para a medição (${dk.length})</h3>
        ${aberto && edita ? `<label class="btn sm ${dk.length ? '' : 'primary'}" for="anexo-klg">${ic.upload} Anexar</label><input type="file" id="anexo-klg" class="sr-only" multiple accept="${U.ACEITOS}" data-chg="anexar-klg">` : ''}</div>
      <p class="small muted">O fornecedor baixa estes documentos no link e depois envia o boletim pelo mesmo link.${pedeDocs(f) && !dk.length && aberto ? ' Enquanto não houver nenhum, o envio automático deste fornecedor aguarda.' : ''}</p>
      ${dk.map(docKlgHTML).join('')}
      ${pedeDocs(f) ? `<dl class="kv" style="margin-top:8px">${linhas}</dl>
      ${aberto ? `<div class="row" style="margin-top:8px;gap:6px">
        ${edita ? `<button class="btn sm" data-act="pedir-docs" data-s="${s.id}">${ic.mail} ${s.docs_pedido_em ? 'Pedir de novo ao colaborador' : 'Pedir ao colaborador'}</button>` : ''}
        ${s.docs_token ? `<button class="btn sm ghost" data-act="copiar-link-docs" data-s="${s.id}">${ic.copiar} Copiar link do colaborador</button>` : ''}
        <button class="btn sm ghost" data-act="previa-docs" data-s="${s.id}">${ic.olho} Ver como o colaborador</button>
        ${DEMO && s.docs_token ? `<button class="btn sm ghost" data-act="simular-docs" data-s="${s.id}">Simular resposta do colaborador</button>` : ''}</div>` : ''}` : ''}
    </section>`;
  }
  function blocoDispensa(s) {
    if (s.dispensa) {
      return `<div class="demo-banner dispensa-banner"><div style="min-width:0"><strong>${esc(U.DISPENSA_TXT[s.dispensa])}</strong>
        <p class="small" style="margin-top:4px">O envio deste fornecedor nesta pasta está desligado no mês. O contrato continua ativo.${s.dispensa_por ? ` Informado por ${esc(s.dispensa_por)}` : ''}${s.dispensa_em ? ` em ${U.dataHoraBR(s.dispensa_em)}` : ''}.</p>
        ${s.dispensa_obs ? `<p class="small" style="margin-top:4px">“${esc(s.dispensa_obs)}”</p>` : ''}</div>
        ${S.papel !== 'leitura' ? `<button class="btn sm" data-act="reativar-envio" data-s="${s.id}">${ic.refazer} Reativar o envio</button>` : ''}</div>`;
    }
    if (S.papel === 'leitura' || !['gerado', 'enviado', 'aberto', 'expirado'].includes(s.status)) return '';
    return `<section class="dispensa-box"><div class="row between" style="gap:8px"><span class="small muted">Não houve medição ou não há contrato neste mês? O envio é desligado só neste mês e nesta pasta.</span>
      <button class="btn sm ghost" data-act="dispensar" data-s="${s.id}">Sem medição este mês</button></div></section>`;
  }
  function abrirRecebimento(sid, manterScroll) {
    const s = S.solic.find((x) => x.id === sid);
    if (!s) return;
    const f = F(s.fornecedor_id);
    const meds = S.med.filter((m) => m.fornecedor_id === s.fornecedor_id).sort((a, b) => C(a.contrato_id).pedido - C(b.contrato_id).pedido);
    const contratos = meds.map((m) => C(m.contrato_id));
    const docs = S.docs.filter((d) => d.fornecedor_id === s.fornecedor_id && d.tipo !== 'klingele');
    const dk = S.docs.filter((d) => d.fornecedor_id === s.fornecedor_id && d.tipo === 'klingele');
    const scroll = manterScroll && document.querySelector('#gaveta .drawer-body') ? document.querySelector('#gaveta .drawer-body').scrollTop : 0;
    S.gaveta = { tipo: 'receb', id: sid };
    const aguardando = ['gerado', 'enviado', 'aberto'].includes(s.status);
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">Recebimento · ${esc(U.compLabel(s.competencia))}</span><h2>${esc(f.nome)}</h2>
        <div class="row">${chipSol(s)}<span class="small muted">${esc(prazoTxt(s))}</span></div></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <dl class="kv">
          <dt>E-mail enviado</dt><dd>${s.enviado_em ? `${U.dataHoraBR(s.enviado_em)} para ${esc((s.emails_destino || []).join(', '))}` : 'Ainda não enviado'}</dd>
          <dt>Link aberto</dt><dd>${s.aberto_em ? U.dataHoraBR(s.aberto_em) : '—'}</dd>
          <dt>Recebido</dt><dd>${s.recebido_em ? U.dataHoraBR(s.recebido_em) : '—'}${s.respondido_por ? ' · ' + esc(s.respondido_por) : ''}</dd>
          ${s.observacao_fornecedor ? `<dt>Observação</dt><dd>${esc(s.observacao_fornecedor)}</dd>` : ''}
        </dl>
        <section>
          <div class="section-title"><h3>Documentos (${docs.length})</h3>
            <label class="btn sm" for="anexo-file">${ic.upload} Anexar</label>
            <input type="file" id="anexo-file" class="sr-only" multiple accept="${U.ACEITOS}" data-chg="anexar"></div>
          ${docs.length ? docs.map((d) => docHTML(d, contratos)).join('') : `<p class="muted small">${aguardando ? 'Aguardando o fornecedor. Documentos recebidos por outro meio podem ser anexados aqui.' : 'Nenhum documento.'}</p>`}
        </section>
        ${dk.length ? retratil('receb-klg', 'Documentos da Klingele enviados ao fornecedor', dk.length, dk.map(docKlgHTML).join('')) : ''}
        <section>
          <div class="section-title"><h3>Conferência dos valores</h3>
            <button class="btn sm" data-act="usar-informados">Aprovar informados</button></div>
          <div class="table-wrap"><table class="tbl" id="tbl-conf">
            <thead><tr><th>Pedido</th><th class="r">Contratado</th><th class="r">Informado / lido</th><th>Aprovado</th><th>Situação</th></tr></thead>
            <tbody>${meds.map((m) => {
              const c = C(m.contrato_id), r = comparar(m);
              return `<tr data-m="${m.id}">
                <td><div class="cell-title mono">${esc(c.pedido)}</div><div class="cell-sub">${esc(c.titulo)}</div>
                  <div class="row" style="gap:4px;margin-top:4px">${chip(r.cls, r.txt)}${divergente(m) ? chip('warn', 'Informado ≠ lido') : ''}</div></td>
                <td class="r num">${U.brl(m.valor_contratado)}</td>
                <td class="r num">${U.brl(m.valor_informado)}<div class="cell-sub">lido ${U.brl(m.valor_lido)}</div></td>
                <td><input type="text" inputmode="decimal" data-k="valor_aprovado" value="${esc(U.numBR(m.valor_aprovado))}" placeholder="0,00" aria-label="Valor aprovado do pedido ${esc(c.pedido)}"></td>
                <td><select data-k="status" aria-label="Situação do pedido ${esc(c.pedido)}">${Object.entries(MED).map(([k, v]) => `<option value="${k}" ${m.status === k ? 'selected' : ''}>${v[0]}</option>`).join('')}</select></td>
              </tr>`;
            }).join('') || '<tr><td colspan="5" class="muted">Nenhum pedido vinculado.</td></tr>'}</tbody>
          </table></div>
        </section>
        <section>
          <div class="section-title"><h3>Contatos do fornecedor</h3><button class="btn sm ghost" data-act="abrir-forn" data-f="${f.id}">Editar fornecedor</button></div>
          ${(f.contatos || []).map((c) => `<div class="row" style="padding:6px 0;border-bottom:1px solid var(--line)"><span class="cell-title">${esc(c.nome || '—')}</span>
            <span class="tag">${esc(c.email)}</span>${c.telefone ? `<span class="small muted">${esc(c.telefone)}</span>` : ''}
            ${c.origem === 'fornecedor' ? chip('accent', 'Atualizado pelo fornecedor') : ''}${!c.recebe_boletim ? chip('', 'Não recebe boletim') : ''}</div>`).join('') || '<p class="muted">Sem contatos.</p>'}
        </section>
        ${correcoesSolicitacao(s)}
      </div>
      <div class="drawer-foot">
        ${aguardando ? `<button class="btn" data-act="marcar-recebido" data-s="${s.id}">Marcar como recebido</button>` : ''}
        ${aguardando ? `<button class="btn" data-act="ver-email" data-s="${s.id}">${ic.mail} E-mail</button>` : ''}
        <span class="spacer"></span>
        <button class="btn primary" data-act="salvar-conf" data-s="${s.id}">${ic.ok} Salvar conferência</button>
      </div>`);
    if (scroll) document.querySelector('#gaveta .drawer-body').scrollTop = scroll;
  }

  async function lerDocumento(id) {
    const d = S.docs.find((x) => x.id === id);
    const box = document.getElementById('leit-' + id);
    if (!d || !box) return;
    box.innerHTML = '<span class="muted">Lendo o arquivo…</span>';
    API.registrarEvento('documento lido', 'documentos', d.id, d.fornecedor_id, { arquivo: d.nome_arquivo });
    try {
      const blob = await API.baixarDocumento(d);
      const r = await U.lerValor(blob, d.nome_arquivo);
      if (!r.valor) { box.innerHTML = `<span class="muted">${esc(r.motivo || 'Total não identificado. Informe o valor manualmente.')}</span>`; return; }
      const conf = { alta: 'confiança alta', media: 'confiança média', baixa: 'confiança baixa' }[r.confianca] || '';
      box.innerHTML = `<span>Identificado: <b class="num">${U.brl(r.valor)}</b></span><span class="muted">${esc(r.rotulo || '')} · ${conf}</span>
        <button class="btn sm primary" data-act="usar-lido" data-d="${id}" data-v="${r.valor}">Usar como valor lido</button>
        ${r.candidatos.filter((c) => c.valor !== r.valor).slice(0, 3).map((c) => `<button class="btn sm ghost" data-act="usar-lido" data-d="${id}" data-v="${c.valor}" title="${esc(c.rotulo)}">${U.brl(c.valor)}</button>`).join('')}`;
    } catch (e) {
      box.innerHTML = `<span style="color:var(--crit)">${esc(e.message)}</span>`;
    }
  }

  async function usarLido(docId, valor) {
    const d = S.docs.find((x) => x.id === docId);
    await API.atualizarDocumento(docId, { valor_lido: valor });
    const contrato = d.contrato_id || (S.med.filter((m) => m.fornecedor_id === d.fornecedor_id).length === 1 ? S.med.find((m) => m.fornecedor_id === d.fornecedor_id).contrato_id : null);
    const m = contrato && S.med.find((x) => x.contrato_id === contrato);
    if (m) await API.salvarMedicao({ id: m.id, valor_lido: valor });
    await recarregar();
    U.toast(m ? `Valor lido registrado no pedido ${C(contrato).pedido}` : 'Valor lido salvo no documento. Escolha o pedido para levar ao comparativo.');
    const s = S.gaveta && S.gaveta.id;
    if (s) abrirRecebimento(s, true);
    renderView();
  }

  async function salvarConferencia(sid) {
    const s = S.solic.find((x) => x.id === sid);
    const linhas = document.querySelectorAll('#tbl-conf tbody tr[data-m]');
    const estados = [];
    for (const tr of linhas) {
      const id = tr.dataset.m;
      const val = tr.querySelector('[data-k="valor_aprovado"]').value;
      let status = tr.querySelector('[data-k="status"]').value;
      const v = val.trim() === '' ? null : U.parseValor(val);
      if (val.trim() !== '' && v === null) { U.toast('Valor aprovado inválido: ' + val, 'erro'); return; }
      if (v !== null && ['aguardando', 'recebido', 'em_conferencia'].includes(status)) status = 'aprovado';
      estados.push(status);
      await API.salvarMedicao({ id, valor_aprovado: v, status });
    }
    if (estados.length && estados.every((x) => ['aprovado', 'pago', 'sem_medicao'].includes(x)) && s.status === 'recebido') {
      await API.atualizarSolicitacao(s.id, { status: 'conferido', conferido_em: new Date().toISOString() });
    }
    await recarregar();
    U.toast('Conferência salva');
    abrirRecebimento(sid, true);
    renderView();
  }

  async function anexar(files) {
    const s = S.solic.find((x) => x.id === S.gaveta.id);
    const f = F(s.fornecedor_id);
    const meds = S.med.filter((m) => m.fornecedor_id === s.fornecedor_id);
    for (const file of files) {
      if (!U.MIME[U.extensao(file.name)]) { U.toast(`Tipo não aceito: ${file.name}`, 'erro'); continue; }
      if (file.size > 25 * 1048576) { U.toast(`Maior que 25 MB: ${file.name}`, 'erro'); continue; }
      const tipo = U.tipoPeloNome(file.name) || 'boletim';
      let valor = null;
      if (tipo === 'boletim') { const r = await U.lerValor(file, file.name); valor = r.valor && r.confianca !== 'baixa' ? r.valor : null; }
      try {
        await API.anexarDocumento({ solicitacao: s, fornecedor: f, competencia: s.competencia, file, tipo, contrato_id: meds.length === 1 ? meds[0].contrato_id : null, valor_lido: valor });
        if (valor !== null && meds.length === 1) await API.salvarMedicao({ id: meds[0].id, valor_lido: valor });
      } catch (e) { U.toast(e.message, 'erro'); }
    }
    await recarregar();
    U.toast('Documento anexado');
    abrirRecebimento(s.id, true);
    renderView();
  }

  // Baixa o arquivo com o nome organizado (AAAA-MM_MES_FORNECEDOR_TIPO)
  async function baixarDocumento(id) {
    const d = S.docs.find((x) => x.id === id);
    if (!d) return;
    try {
      API.registrarEvento('documento aberto', 'documentos', d.id, d.fornecedor_id, { arquivo: d.nome_padrao || d.nome_arquivo, download: true });
      const a = document.createElement('a');
      if (DEMO) {
        const blob = await API.baixarDocumento(d);
        a.href = URL.createObjectURL(blob);
        U.toast('Na demonstração o download pode não iniciar; no site publicado o arquivo é baixado com o nome organizado.');
      } else a.href = await API.urlDocumento(d, true);
      a.download = d.nome_padrao || d.nome_arquivo; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  async function abrirDocumento(id) {
    const d = S.docs.find((x) => x.id === id);
    try {
      API.registrarEvento('documento aberto', 'documentos', d.id, d.fornecedor_id, { arquivo: d.nome_arquivo });
      const url = await API.urlDocumento(d);
      if (!url) {
        if (d.exemplo || DEMO) { U.toast('Na demonstração os anexos de exemplo não ficam guardados. Use "Ler valor" para ver a leitura automática.'); return; }
        throw new Error('Arquivo não encontrado');
      }
      if (/^image\//.test(d.mime || '') || ['jpg', 'jpeg', 'png'].includes(U.extensao(d.nome_arquivo))) {
        const w = document.createElement('div');
        w.className = 'modal-wrap';
        w.innerHTML = `<div class="backdrop" data-x></div><div class="modal" style="width:min(900px,100%)"><div class="row between"><b>${esc(d.nome_arquivo)}</b><button class="icon-btn" data-x aria-label="Fechar">${ic.x}</button></div><img src="${esc(url)}" alt="${esc(d.nome_arquivo)}" style="max-height:calc(75vh / var(--z, 1));object-fit:contain;width:100%"></div>`;
        w.addEventListener('click', (e) => { if (e.target.closest('[data-x]')) w.remove(); });
        document.body.appendChild(w);
        return;
      }
      const a = document.createElement('a');
      a.href = url; a.target = '_blank'; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  // =====================================================================
  //  NOTAS FISCAIS (folha de serviço, pedido de compra, pedido da NF e conferência)
  // =====================================================================
  const NFS = { gerada: ['Link gerado', ''], enviada: ['Pedido enviado', 'info'], aberta: ['Fornecedor abriu', 'info'], recebida: ['Nota recebida', 'warn'],
    aprovada: ['NF aprovada', 'ok'], recusada: ['NF recusada', 'crit'], expirada: ['Prazo encerrado', 'crit'], cancelada: ['Cancelado', ''] };
  const NOTA_ST = { em_conferencia: ['Em conferência', 'warn'], aprovada: ['Aprovada', 'ok'], recusada: ['Recusada', 'crit'] };
  const LINK_TEMP = '(link temporário gerado no envio)';
  const PARC = (cid) => S.parc[cid] || null;
  const recentes = (a, b) => (a.created_at < b.created_at ? 1 : -1);
  const solicNF = (mid) => {
    const l = S.nfSolic.filter((n) => n.medicao_id === mid);
    return l.find((n) => !['expirada', 'cancelada', 'recusada'].includes(n.status)) || l.slice().sort(recentes)[0] || null;
  };
  const notasDe = (mid) => S.nfNotas.filter((n) => n.medicao_id === mid).slice().sort(recentes);
  const pedidosCompra = (m) => S.docs.filter((d) => d.tipo === 'pedido_compra' && d.contrato_id === m.contrato_id && d.competencia === m.competencia);
  const nfValida = (n) => !!n && ['gerada', 'enviada', 'aberta'].includes(n.status) && new Date(n.expira_em) > new Date();
  const nfPedida = (m) => S.nfSolic.some((n) => n.medicao_id === m.id && ['enviada', 'aberta', 'recebida', 'aprovada'].includes(n.status));
  const prazoNF = () => Number(cfgv('nf_prazo_dias_uteis', 7)) || 7;
  const cnpjsKlingele = () => String(cfgv('cnpj_klingele', '')).split(',').map((x) => x.trim()).filter(Boolean);
  const linkNF = (n) => (cfg.portalUrl ? cfg.portalUrl.replace(/portal\.html.*$/, 'nf.html') : new URL('nf.html', location.href).href.split('#')[0].split('?')[0]) + '#' + n.token;
  const parcelaTxt = (m) => { const c = C(m.contrato_id); return m.parcela ? m.parcela + (c.parcelas_total ? ' de ' + c.parcelas_total : '') : '—'; };
  const descricaoPadrao = (m, parcela) => {
    const c = C(m.contrato_id);
    return `${c.titulo} - referente a ${U.mesNome(m.competencia)}/${m.competencia.slice(0, 4)} - parcela ${parcela || '?'}${c.parcelas_total ? '/' + c.parcelas_total : ''} - pedido ${c.pedido}`;
  };
  // ---------------------------------------------------------------------
  //  Processo do mês após a medição: F.S. lançada > F.S. enviada ao fornecedor > NF recebida
  //  > F.S. aprovada (aprovações internas) > NF encaminhada a Serviços (fim). Aprovação da F.S. e NF correm em paralelo.
  // ---------------------------------------------------------------------
  const notaAtual = (mid) => notasDe(mid).find((x) => ['em_conferencia', 'aprovada'].includes(x.status)) || null;
  // finalizado_em sem encaminhado_em: processos encerrados antes de 28/10/2026 (fim na aprovação da F.S.)
  const encaminhado = (m) => !!(m.encaminhado_em || m.finalizado_em);
  const autoServicos = () => cfgv('nf_encaminhar_automatico', 'true') === 'true';
  const fsEnviada = (m) => !!notaAtual(m.id) || S.nfSolic.some((x) => x.medicao_id === m.id && ['enviada', 'aberta', 'recebida', 'aprovada'].includes(x.status));
  // Situação da NF (coluna "Nota fiscal")
  function etapaNF(m) {
    if (m.status === 'sem_medicao') return { k: 'sem', txt: 'Sem medição', cls: '' };
    const nota = notaAtual(m.id), n = solicNF(m.id);
    if (nota && nota.status === 'aprovada') return { k: 'aprovada', txt: `NF nº ${nota.numero}${m.encaminhado_em ? ' · em Serviços' : ' aprovada'}`, cls: 'ok' };
    if (nota) return { k: 'conferir', txt: nota.alertas ? `NF nº ${nota.numero} · ${nota.alertas} alerta${nota.alertas > 1 ? 's' : ''}` : `NF nº ${nota.numero} recebida`, cls: nota.alertas ? 'warn' : 'info' };
    if (!['aprovado', 'pago'].includes(m.status)) return { k: 'aprovar', txt: 'Medição não aprovada', cls: '' };
    if (!m.folha_numero || !m.parcela) {
      const p = PARC(m.contrato_id);
      return p && p.parcelas_total && !p.proxima_parcela ? { k: 'folha', txt: 'Sem parcela livre no contrato', cls: 'warn' } : { k: 'folha', txt: 'Aguardando a F.S.', cls: '' };
    }
    if (nfValida(n)) return n.status === 'gerada' ? { k: 'enviar', txt: 'F.S. a enviar', cls: '' } : { k: 'aguardando', txt: n.status === 'aberta' ? 'Fornecedor abriu o link' : 'Aguardando a NF', cls: 'info' };
    if (n && n.status === 'recusada') return { k: 'recusada', txt: 'NF recusada', cls: 'crit' };
    if (n && n.status !== 'cancelada') return { k: 'vencido', txt: 'Link da NF vencido', cls: 'crit' };
    return { k: 'pedir', txt: 'F.S. a enviar', cls: '' };
  }
  const fsDocs = (m) => S.docs.filter((d) => d.tipo === 'folha_servico' && d.contrato_id === m.contrato_id && d.competencia === m.competencia);
  // Situação da F.S. (coluna "F.S.")
  function etapaFS(m) {
    if (m.status === 'sem_medicao') return { k: 'sem', txt: 'Sem medição', cls: '' };
    if (encaminhado(m)) return { k: 'finalizado', txt: 'Finalizado', cls: 'ok' };
    if (m.folha_status === 'aprovada') return { k: 'aprovada', txt: 'Aprovada', cls: 'ok' };
    if (!['aprovado', 'pago'].includes(m.status)) return { k: 'aprovar', txt: 'Aprovar a medição', cls: '' };
    if (!m.folha_numero) return { k: 'lancar', txt: 'A lançar', cls: '' };
    if (!fsDocs(m).length) return { k: 'anexar', txt: 'Sem arquivo', cls: 'warn' };
    return { k: 'aprovar_fs', txt: 'A aprovar', cls: '' };
  }
  // Próxima ação da equipe (uma por medição): o que mostrar na lista e no topo da gaveta
  const ETAPA_NF = {
    sem: ['Sem medição', '', 'Abrir'], aprovar_med: ['Aprovar a medição', '', 'Abrir'], lancar: ['Lançar a F.S.', 'accent', 'Lançar F.S.'],
    enviar: ['Enviar a F.S. ao fornecedor', 'accent', 'Enviar F.S.'], aguardando: ['Aguardando a NF do fornecedor', 'info', 'Abrir'],
    conferir: ['Conferir a NF', 'warn', 'Conferir NF'], anexar: ['Anexar o arquivo da F.S.', 'warn', 'Anexar F.S.'],
    aprovar_fs: ['Aprovar a F.S.', 'accent', 'Aprovar F.S.'], encaminhar: ['Encaminhar a NF a Serviços', 'accent', 'Encaminhar'],
    finalizado: ['Finalizado', 'ok', 'Abrir']
  };
  function proximaEtapa(m) {
    const k = (() => {
      if (m.status === 'sem_medicao') return 'sem';
      if (encaminhado(m)) return 'finalizado';
      if (!['aprovado', 'pago'].includes(m.status)) return 'aprovar_med';
      if (!m.folha_numero || !m.parcela) return 'lancar';
      const nota = notaAtual(m.id);
      if (!nota && !fsEnviada(m)) return 'enviar';
      if (nota && nota.status === 'em_conferencia' && nota.alertas > 0) return 'conferir';
      if (m.folha_status !== 'aprovada') return fsDocs(m).length ? 'aprovar_fs' : 'anexar';
      if (!nota) return 'aguardando';
      return 'encaminhar';
    })();
    const [txt, cls, acao] = ETAPA_NF[k];
    return { k, txt, cls, acao, agir: ['lancar', 'enviar', 'conferir', 'anexar', 'aprovar_fs', 'encaminhar'].includes(k) };
  }
  const FILTRO_NF = {
    todos: () => true,
    lancar: (m) => proximaEtapa(m).k === 'lancar',
    enviar: (m) => proximaEtapa(m).k === 'enviar',
    aguardando: (m) => ['aguardando'].includes(etapaNF(m).k) && !encaminhado(m),
    conferir: (m) => etapaNF(m).k === 'conferir' && !encaminhado(m),
    aprovar_fs: (m) => !!m.folha_numero && m.folha_status !== 'aprovada' && !encaminhado(m) && m.status !== 'sem_medicao',
    encaminhar: (m) => proximaEtapa(m).k === 'encaminhar',
    finalizado: (m) => proximaEtapa(m).k === 'finalizado'
  };
  // Destinatários do encaminhamento a Serviços: Serviços + Ocorrência + o seu e-mail de aviso
  const destinatariosFS = () => {
    const l = (k) => String(cfgv(k, '')).split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);
    const eu = S.cad && (S.cad.email_aviso || (S.user && S.user.email));
    return [...new Set([...l('fs_emails_servicos'), ...l('fs_emails_ocorrencia'), ...(eu && U.emailValido(eu) ? [eu.toLowerCase()] : [])])];
  };

  VIEWS.nf = () => {
    const todas = S.med.filter((m) => m.status !== 'sem_medicao' && medMeu(m))
      .sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || C(a.contrato_id).pedido - C(b.contrato_id).pedido);
    const cnt = (k) => todas.filter(FILTRO_NF[k]).length;
    const f0 = FILTRO_NF[S.f.nf] ? S.f.nf : 'todos';
    const lista = todas.filter(FILTRO_NF[f0]);
    const seg = [['todos', 'Todos'], ['lancar', 'Lançar F.S.'], ['enviar', 'Enviar F.S.'], ['aguardando', 'Aguardando NF'], ['conferir', 'Conferir NF'],
      ['aprovar_fs', 'Aprovar F.S.'], ['encaminhar', 'Encaminhar'], ['finalizado', 'Finalizados']];
    const pend = todas.filter((m) => proximaEtapa(m).agir).length, fin = cnt('finalizado');
    const lancadas = todas.filter((m) => m.folha_numero);
    const semCnpj = !cnpjsKlingele().length;
    const semDest = !String(cfgv('fs_emails_servicos', '') + cfgv('fs_emails_ocorrencia', '')).trim();
    return `
      <div class="tiles">
        <div class="tile ${pend ? 'accent' : ''}"><span class="label">Pendências da equipe</span><span class="v">${pend}</span><span class="d">Lançar, enviar, conferir, aprovar ou encaminhar</span></div>
        <div class="tile"><span class="label">Aguardando o fornecedor</span><span class="v">${cnt('aguardando')}</span><span class="d">F.S. enviada, NF ainda não recebida</span></div>
        <div class="tile"><span class="label">Finalizados</span><span class="v">${fin} de ${todas.length}</span><span class="d">NF encaminhada a Serviços</span></div>
        <div class="tile"><span class="label">Valor das F.S.</span><span class="v">${U.compacto(soma(lancadas.map((m) => m.folha_valor ?? m.valor_aprovado)))}</span><span class="d">${lancadas.length} F.S. lançada${lancadas.length !== 1 ? 's' : ''}</span></div>
      </div>
      ${semDest ? `<div class="demo-banner"><span>Cadastre os e-mails de Serviços e Ocorrência: recebem a NF depois da aprovação da F.S.</span><span class="spacer"></span><button class="btn sm" data-act="ir-conf-fs">Cadastrar e-mails</button></div>` : ''}
      ${semCnpj ? `<div class="demo-banner"><span>Cadastre os CNPJs da Klingele: vão no e-mail ao fornecedor e na conferência da NF.</span><span class="spacer"></span><button class="btn sm" data-act="ir-conf-nf">Cadastrar CNPJs</button></div>` : ''}
      <section class="panel">
        <div class="panel-head"><div><h2>F.S. e notas fiscais de ${esc(U.compLabel(S.comp))}</h2>
          <span class="sub">F.S. lançada > enviada ao fornecedor > NF recebida > F.S. aprovada > NF encaminhada a Serviços</span></div></div>
        <div class="panel-body" style="padding-bottom:0"><div class="seg rolar" role="group" aria-label="Filtrar">${seg.map(([k, t]) => { const n = cnt(k); return `<button type="button" data-act="filtro-nf" data-v="${k}" aria-pressed="${f0 === k}" class="${n || k === 'todos' ? '' : 'vazio'}">${t}<span class="c">${n}</span></button>`; }).join('')}</div></div>
        <div class="table-wrap" style="margin-top:12px"><table class="tbl cards" id="tbl-nf">
          <thead><tr><th>Fornecedor / pedido</th><th>Parcela</th><th class="r">Aprovado</th><th>F.S.</th><th>Nota fiscal</th><th>Próxima etapa</th><th></th></tr></thead>
          <tbody>${lista.map((m) => {
            const c = C(m.contrato_id), f = F(m.fornecedor_id), e = etapaNF(m), fs = etapaFS(m), px = proximaEtapa(m);
            return `<tr class="click" data-act="abrir-nf" data-m="${m.id}">
              <td><div class="cell-title">${esc(f.nome)}</div><div class="cell-sub clamp2">Pedido <span class="mono">${esc(c.pedido)}</span> · ${esc(c.titulo)}</div></td>
              <td class="small" data-label="Parcela">${m.parcela ? `<b>${esc(parcelaTxt(m))}</b>` : '<span class="muted">—</span>'}</td>
              <td class="r num" data-label="Aprovado">${U.brl(m.valor_aprovado)}</td>
              <td class="small" data-label="F.S.">${m.folha_numero ? `<span class="mono">${esc(m.folha_numero)}</span><div style="margin-top:3px">${chip(fs.cls, fs.txt)}</div>` : '<span class="muted">—</span>'}</td>
              <td data-label="Nota fiscal">${['aprovar', 'folha', 'pedir', 'enviar'].includes(e.k) ? '<span class="muted">—</span>' : chip(e.cls, e.txt)}</td>
              <td data-label="Próxima etapa">${chip(px.cls, px.txt)}</td>
              <td class="r m-cheio" data-label=""><button class="btn sm ${px.agir ? 'primary' : ''}" data-act="abrir-nf" data-m="${m.id}">${ic.nf} ${esc(px.acao)}</button></td></tr>`;
          }).join('') || `<tr><td colspan="7"><div class="empty"><h3>${todas.length ? 'Nada neste filtro' : 'Nenhuma medição'}</h3><p>${todas.length ? 'Escolha outro filtro.' : 'As medições aparecem aqui depois de geradas no Envio do mês.'}</p></div></td></tr>`}</tbody>
        </table></div>
      </section>`;
  };

  function docNFHTML(d, rm) {
    const ext = U.extensao(d.nome_arquivo);
    return `<div class="doc"><span class="ext ${esc(ext)}">${esc(ext)}</span>
      <div class="meta"><b class="mono" style="font-size:.84rem" title="${esc(d.nome_padrao || d.nome_arquivo)}">${esc(d.nome_padrao || d.nome_arquivo)}</b>
        <span class="small muted">${U.tamanho(d.tamanho)} · ${d.enviado_por === 'equipe' ? 'anexado pela equipe' : 'enviado pelo fornecedor'} em ${U.dataHoraBR(d.created_at)}</span></div>
      <div class="acts"><button class="btn sm" data-act="doc-abrir" data-d="${d.id}">${ic.abrir} Abrir</button>
        <button class="icon-btn" data-act="doc-baixar" data-d="${d.id}" title="Baixar com o nome organizado" aria-label="Baixar">${ic.baixar}</button>
        ${rm ? `<button class="icon-btn" data-act="doc-rm" data-d="${d.id}" title="Excluir arquivo" aria-label="Excluir arquivo">${ic.lixo}</button>` : ''}</div></div>`;
  }
  const docsDaNota = (nota) => S.docs.filter((d) => d.solicitacao_nf_id === nota.solicitacao_nf_id && d.enviado_por === 'fornecedor'
    && Math.abs(new Date(d.created_at) - new Date(nota.created_at)) <= 60000);

  // Nota recebida (em conferência ou aprovada); compacta = sem a lista de conferência e sem os botões
  function notaHTML(nota, m, compacta, opcN) {
    opcN = opcN || {};
    const c = C(m.contrato_id), [stt, scl] = NOTA_ST[nota.status] || [nota.status, ''];
    const consulta = nota.modelo === 'nfe' && nota.chave ? 'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g='
      : nota.modelo === 'nfse' && nota.chave ? 'https://www.nfse.gov.br/ConsultaPublica' : null;
    const difValor = m.valor_aprovado !== null && Math.round(Number(nota.valor) * 100) !== Math.round(Number(m.valor_aprovado) * 100);
    const podeConferir = !compacta && !m.encaminhado_em && (nota.status === 'em_conferencia' || (nota.status === 'aprovada' && S.papel === 'admin' && m.status !== 'pago'));
    return `<div class="nf-nota">
      <div class="row between" style="flex-wrap:nowrap;gap:8px"><b>${esc(U.NF.MODELOS[nota.modelo] ? U.NF.MODELOS[nota.modelo][0] : nota.modelo)} nº ${esc(nota.numero)}${nota.serie ? ' · série ' + esc(nota.serie) : ''}</b>${chip(scl, stt)}</div>
      <dl class="kv" style="margin-top:8px">
        <dt>Valor</dt><dd><b class="num">${U.brl(nota.valor)}</b>${difValor ? ` <span class="chip warn">aprovado ${U.brl(m.valor_aprovado)}</span>` : ''}</dd>
        <dt>Emissão</dt><dd>${U.dataBR(nota.data_emissao)}</dd>
        ${nota.chave ? `<dt>Chave de acesso</dt><dd><span class="mono small">${esc(U.NF.formatarChave(nota.chave))}</span>
          <div class="row" style="gap:6px;margin-top:4px"><button class="btn sm" data-act="nf-copiar-chave" data-v="${esc(nota.chave)}">${ic.copiar} Copiar chave</button>
          ${consulta ? `<a class="btn sm ghost" href="${consulta}" target="_blank" rel="noopener noreferrer">${ic.abrir} Consultar ${nota.modelo === 'nfe' ? 'na SEFAZ' : 'no portal da NFS-e'}</a>` : ''}</div></dd>` : ''}
        ${nota.codigo_verificacao ? `<dt>Código de verificação</dt><dd class="mono">${esc(nota.codigo_verificacao)}</dd>` : ''}
        ${compacta ? '' : `${nota.cnpj_emitente ? `<dt>Emitente</dt><dd class="mono">${esc(U.cnpj(nota.cnpj_emitente))}</dd>` : ''}
        ${nota.cnpj_destinatario ? `<dt>Destinatário</dt><dd class="mono">${esc(U.cnpj(nota.cnpj_destinatario))}</dd>` : ''}
        <dt>Pedido / parcela</dt><dd><span class="mono">${esc(c.pedido)}</span> · parcela ${esc(parcelaTxt(m))}</dd>`}
        <dt>Enviada por</dt><dd>${esc(nota.responsavel || '—')} em ${U.dataHoraBR(nota.created_at)}</dd>
        ${nota.observacao ? `<dt>Observação</dt><dd>${esc(nota.observacao)}</dd>` : ''}
        ${nota.conferido_em ? `<dt>Conferida por</dt><dd>${esc(nota.conferido_por || '—')} em ${U.dataHoraBR(nota.conferido_em)}</dd>` : ''}
      </dl>
      <div class="stack" style="gap:8px;margin-top:10px">${docsDaNota(nota).map((d) => docNFHTML(d, false)).join('')}
        ${nota.xml !== null || nota.modelo !== 'fatura' ? `<div class="row"><button class="btn sm" data-act="nf-xml" data-id="${nota.id}" data-n="${esc(nota.numero)}">${ic.baixar} Baixar XML</button></div>` : ''}</div>
      ${compacta ? '' : `<div class="section-title" style="margin-top:12px"><h3>Conferência automática</h3>${nota.alertas ? chip('warn', `${nota.alertas} alerta${nota.alertas > 1 ? 's' : ''}`) : chip('ok', 'Sem pendências')}</div>
      ${conferenciaHTML(nota.validacoes)}`}
      ${podeConferir && !opcN.decisaoNoRodape ? `<div class="nf-decisao">
        ${nota.status === 'em_conferencia' ? `<div class="row"><button class="btn primary" data-act="nf-aprovar" data-id="${nota.id}">${ic.ok} Aprovar nota${nota.alertas ? ' (alertas conferidos)' : ''}</button>
          <button class="btn ghost" data-act="nf-recusar-abrir" data-id="${nota.id}">Recusar…</button></div>` : `<div class="row"><button class="btn ghost" data-act="nf-recusar-abrir" data-id="${nota.id}">Recusar nota aprovada…</button></div>`}
        <div class="nf-recusa" id="nf-recusa-${nota.id}" hidden>
          <label class="field"><span>Motivo da recusa <span class="hint">(aparece para o fornecedor no novo link)</span></span><textarea id="nf-motivo-${nota.id}" rows="2" maxlength="1000" placeholder="Ex.: emitir para o CNPJ da matriz; valor diferente da medição"></textarea></label>
          <div class="row"><button class="btn danger" data-act="nf-recusar" data-id="${nota.id}">${ic.x} Recusar nota</button></div></div></div>` : ''}
      ${podeConferir && opcN.decisaoNoRodape ? `<div class="nf-recusa" id="nf-recusa-${nota.id}" hidden>
          <label class="field"><span>Motivo da recusa <span class="hint">(aparece para o fornecedor no novo link)</span></span><textarea id="nf-motivo-${nota.id}" rows="2" maxlength="1000" placeholder="Ex.: emitir para o CNPJ da matriz; valor diferente da medição"></textarea></label>
          <div class="row"><button class="btn danger" data-act="nf-recusar" data-id="${nota.id}">${ic.x} Confirmar a recusa</button></div></div>` : ''}
    </div>`;
  }
  // Conferência automática: alertas à vista, itens conferidos recolhidos
  function conferenciaHTML(validacoes) {
    const v = validacoes || [], ok = v.filter((x) => x.nivel === 'ok'), resto = v.filter((x) => x.nivel !== 'ok');
    return `${resto.length ? U.NF.checklistHTML(resto) : '<p class="small muted">Nenhum alerta na conferência automática.</p>'}
      ${ok.length ? `<details class="campos"><summary>Itens conferidos sem pendência (${ok.length})</summary>${U.NF.checklistHTML(ok)}</details>` : ''}`;
  }
  const checklist = (itens) => `<ul class="nf-check">${itens.map(([ok, t]) => `<li class="${ok ? 'ok' : 'warn'}"><span class="ic" aria-hidden="true">${ok ? ic.ok : ic.alerta}</span><span>${esc(t)}</span></li>`).join('')}</ul>`;
  const cartao = (titulo, corpo, cls) => `<section class="nf-card ${cls || ''}"><h3>${titulo}</h3>${corpo}</section>`;
  // Passos do processo, no topo da gaveta
  function passosHTML(m) {
    const nota = notaAtual(m.id), fim = encaminhado(m);
    const passos = [['F.S. lançada', !!m.folha_numero], ['Enviada', fim || fsEnviada(m)], ['NF recebida', fim || !!nota], ['F.S. aprovada', fim || m.folha_status === 'aprovada'],
      ['Serviços', fim]];
    const atual = { lancar: 0, enviar: 1, aguardando: 2, conferir: 2, anexar: 3, aprovar_fs: 3, encaminhar: 4 }[proximaEtapa(m).k];
    return `<ol class="passos" aria-label="Andamento">${passos.map(([t, ok], i) => {
      const cls = ok ? 'ok' : i === atual ? 'atual' : '';
      return `<li class="${cls}"><span class="pn" aria-hidden="true">${ok ? ic.ok : i + 1}</span><span class="pt">${t}</span></li>`;
    }).join('')}</ol>`;
  }

  function abrirNF(mid, opc) {
    const m = S.med.find((x) => x.id === mid);
    if (!m) return;
    opc = opc || {};
    const c = C(m.contrato_id), f = F(m.fornecedor_id), p = PARC(c.id);
    const n = solicNF(m.id), nota = notaAtual(m.id), notas = notasDe(m.id), pcs = pedidosCompra(m), fds = fsDocs(m);
    const recusadas = notas.filter((x) => x.status === 'recusada');
    const aprovada = ['aprovado', 'pago'].includes(m.status);
    const fsAprovada = m.folha_status === 'aprovada', fim = encaminhado(m);
    const travadaFS = nfPedida(m) || fsAprovada;
    const valida = nfValida(n);
    const jaEnviado = !!n && (!!n.enviado_em || S.envios.some((x) => x.solicitacao_nf_id === n.id));
    const manter = !!opc.manter && jaEnviado;
    const app = podeEnviarPeloApp();
    const px = proximaEtapa(m);
    const scroll = opc.manterScroll && document.querySelector('#gaveta .drawer-body') ? document.querySelector('#gaveta .drawer-body').scrollTop : 0;
    S.gaveta = { tipo: 'nf', id: mid, form: !!opc.form, links: (S.gaveta && S.gaveta.tipo === 'nf' && S.gaveta.id === mid && S.gaveta.links) || null };
    const total = c.parcelas_total || null;
    const esgotado = !m.parcela && !!total && !!p && !p.proxima_parcela;
    const proxima = m.parcela || (p && p.proxima_parcela) || (total ? null : 1);
    // Formulário de e-mail ao fornecedor: no passo "Enviar F.S." ou quando pedido (reenviar/lembrar)
    const mostrarForm = valida && (n.status === 'gerada' || opc.form);

    // ---------- Blocos ----------
    const blocoFolhaForm = (semBotao) => {
      const opcoes = total ? Array.from({ length: total }, (_, i) => i + 1).filter((x) => x > (p ? p.parcelas_pagas_antes : 0)) : [];
      const padrao = proxima || opcoes[opcoes.length - 1] || 1;
      return `${esgotado ? `<div class="demo-banner" style="background:var(--warn-soft);border-color:transparent"><span>As ${total} parcelas do contrato já estão pagas ou lançadas. Se houve aditivo, aumente o total de parcelas no contrato.</span>
        <span class="spacer"></span><button class="btn sm" data-act="abrir-contr" data-c="${c.id}">Abrir contrato</button></div>` : ''}<div class="form-grid">
        <label class="field"><span>Número da F.S.</span><input type="text" id="nf-folha-num" maxlength="40" value="${esc(m.folha_numero || '')}" placeholder="Número no TOTVS"></label>
        <label class="field"><span>Data da F.S.</span><input type="date" id="nf-folha-data" min="${m.competencia}" max="${U.hojeISO()}" value="${esc(m.folha_data || U.hojeISO())}"></label>
        <label class="field"><span>Parcela</span>${total
          ? `<select id="nf-parcela" data-chg="nf-parcela" data-ant="${padrao}">${opcoes.map((x) => `<option value="${x}" ${x === padrao ? 'selected' : ''}>Parcela ${x} de ${total}${x === (p && p.proxima_parcela) ? ' (próxima)' : ''}</option>`).join('')}</select>`
          : `<input type="number" id="nf-parcela" data-chg="nf-parcela" data-ant="${padrao}" min="1" max="600" value="${esc(padrao)}">`}</label>
        <label class="field"><span>Valor da F.S. (R$)</span><input type="text" inputmode="decimal" id="nf-folha-valor" value="${esc(U.numBR(m.folha_valor ?? m.valor_aprovado))}" placeholder="0,00">
          <span class="hint">Aprovado na medição: ${U.brl(m.valor_aprovado)}</span></label>
        <label class="field full"><span>Descrição para a nota fiscal <span class="hint">(vai ao fornecedor)</span></span>
          <textarea id="nf-desc" rows="3" maxlength="1000" data-auto="${m.descricao_nf ? '0' : '1'}">${esc(m.descricao_nf || descricaoPadrao(m, padrao))}</textarea></label>
      </div>
      ${semBotao ? '' : `<div class="row" style="margin-top:8px"><button class="btn primary" data-act="nf-salvar-folha" data-m="${m.id}">${ic.ok} ${m.folha_numero ? 'Atualizar F.S.' : 'Lançar F.S.'}</button>
        ${m.folha_numero ? `<button class="btn ghost" data-act="nf-desfazer-folha" data-m="${m.id}">Desfazer lançamento</button>` : ''}</div>`}`;
    };
    const blocoFolhaResumo = () => `<dl class="kv"><dt>F.S.</dt><dd><span class="mono">${esc(m.folha_numero || '—')}</span> · ${U.dataBR(m.folha_data)}</dd>
        <dt>Parcela</dt><dd><b>${esc(parcelaTxt(m))}</b></dd><dt>Valor</dt><dd class="num">${U.brl(m.folha_valor ?? m.valor_aprovado)}</dd>
        <dt>Descrição para a nota</dt><dd style="white-space:pre-wrap">${esc(m.descricao_nf || '—')}</dd>
        ${fsAprovada ? `<dt>Aprovada por</dt><dd>${esc(m.folha_aprovada_por || '—')} em ${U.dataHoraBR(m.folha_aprovada_em)}</dd>` : ''}</dl>
      <span class="hint">${fim ? 'Processo finalizado.' : fsAprovada ? 'F.S. aprovada: para alterar, desfaça a aprovação.' : 'F.S. já enviada ao fornecedor: para alterar, cancele o envio (pedido da NF).'}</span>
      ${fsAprovada && !m.encaminhado_em && !fim ? `<div class="row" style="margin-top:8px"><button class="btn ghost" data-act="fs-desfazer" data-m="${m.id}">Desfazer aprovação da F.S.</button></div>` : ''}`;
    const blocoArquivos = () => `<div class="stack" style="gap:12px">
        <div><div class="section-title"><b class="small">Arquivo da F.S. (${fds.length})</b>
          ${fsAprovada ? '' : `<label class="btn sm" for="fs-file">${ic.upload} Anexar F.S.</label><input type="file" id="fs-file" class="sr-only" multiple accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls" data-chg="fs-anexar">`}</div>
          ${fds.length ? `<div class="stack" style="gap:8px">${fds.map((d) => docNFHTML(d, !fsAprovada && !nfPedida(m))).join('')}</div>` : '<p class="muted small">F.S. gerada no TOTVS, em PDF ou imagem. Imagens aparecem no corpo do e-mail ao fornecedor. Obrigatória para aprovar a F.S.</p>'}</div>
        <div><div class="section-title"><b class="small">Pedido de compra (${pcs.length}) <span class="muted" style="font-weight:400">· opcional</span></b>
          ${nfPedida(m) ? '' : `<label class="btn sm" for="nf-pc-file">${ic.upload} Anexar</label><input type="file" id="nf-pc-file" class="sr-only" multiple accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls" data-chg="nf-anexar-pc">`}</div>
          ${pcs.length ? `<div class="stack" style="gap:8px">${pcs.map((d) => docNFHTML(d, !nfPedida(m))).join('')}</div>` : ''}</div></div>`;
    const blocoEnvioForm = () => {
      const contatos = f.contatos || [];
      const marcados = opc.marcados || contatos.filter((x) => x.recebe_boletim).map((x) => x.email);
      const anexaveis = fds.concat(pcs);
      const anxSel = opc.anexos || anexaveis.map((d) => d.id);
      const anexosSel = anexaveis.filter((d) => anxSel.includes(d.id));
      const mail = emailNFDe(m, n, manter, anexosSel.map((d) => ({ nome: d.nome_padrao || d.nome_arquivo, url: LINK_TEMP })));
      const fimP = U.dataLocal(n.expira_em);
      const prazoNovo = U.dataLocal(U.fimPrazoISO(new Date().toISOString(), prazoNF(), S.fer));
      return `<div class="stack" style="gap:12px">
          <div class="field"><span>Para</span><div class="stack" style="gap:6px">${contatos.map((x) => `<label class="check"><input type="checkbox" data-para value="${esc(x.email)}" ${marcados.includes(x.email) ? 'checked' : ''}>
            <span style="overflow-wrap:anywhere">${esc(x.email)}</span><span class="small muted">${esc(x.nome || '')}</span></label>`).join('') || '<span class="small muted">Nenhum contato cadastrado.</span>'}</div>
            <input type="text" id="em-extra" maxlength="600" placeholder="Outros e-mails, separados por vírgula" value="${esc(opc.extra || '')}" aria-label="Outros e-mails"></div>
          <div class="field"><span>Anexos</span><div class="stack" style="gap:6px">${anexaveis.map((d) => `<label class="check"><input type="checkbox" data-anx value="${d.id}" data-chg="nf-anexos" ${anxSel.includes(d.id) ? 'checked' : ''}>
            <span class="mono small" style="overflow-wrap:anywhere">${esc(d.nome_padrao || d.nome_arquivo)}</span><span class="small muted">${d.tipo === 'folha_servico' ? 'F.S.' : 'pedido de compra'}${/\.(jpe?g|png)$/i.test(d.caminho || d.nome_arquivo) ? ' · imagem no corpo do e-mail' : ''}</span></label>`).join('')
            || '<span class="small muted">Nenhum arquivo anexado (opcional). Anexe a F.S. em "Arquivos".</span>'}</div>
            <span class="hint">Imagens (JPG/PNG) aparecem também no corpo do e-mail. Os arquivos vão em anexo (pelo app) e por link temporário.</span></div>
          ${jaEnviado ? `<div class="field"><span>Prazo do link</span>
            <label class="check"><input type="radio" name="em-prazo" value="novo" data-chg="prazo-opcao-nf" ${!manter ? 'checked' : ''}> Recomeçar o prazo: até ${U.dataBR(prazoNovo)}</label>
            <label class="check"><input type="radio" name="em-prazo" value="manter" data-chg="prazo-opcao-nf" ${manter ? 'checked' : ''}> Manter até ${U.dataBR(fimP)} e enviar como lembrete</label></div>`
            : `<span class="hint">Prazo de ${prazoNF()} dias úteis a partir do envio: até ${U.dataBR(prazoNovo)}.</span>`}
          <details class="email-preview">
            <summary style="padding:10px 14px;cursor:pointer;font-weight:600">Texto do e-mail</summary>
            <div class="hdr"><label class="row"><span class="k label">Assunto</span><input type="text" id="em-assunto" maxlength="400" value="${esc(mail.assunto)}"></label></div>
            <textarea id="em-corpo" aria-label="Texto do e-mail" style="min-height:320px">${esc(mail.corpo)}</textarea>
          </details>
        </div>`;
    };
    const blocoLink = () => {
      const fimP = U.dataLocal(n.expira_em), restam = U.diasUteisAte(fimP, S.fer);
      return `<dl class="kv"><dt>Enviada em</dt><dd>${n.enviado_em ? `${U.dataHoraBR(n.enviado_em)} <span class="small muted">para ${esc((n.emails_destino || []).join(', '))}</span>` : 'Ainda não enviada'}</dd>
          <dt>Prazo</dt><dd>Até ${U.dataBR(fimP)} <span class="muted">(${restam <= 0 ? 'último dia' : restam + (restam === 1 ? ' dia útil' : ' dias úteis')})</span></dd>
          <dt>Fornecedor</dt><dd>${n.aberto_em ? `Abriu o link em ${U.dataHoraBR(n.aberto_em)}` : n.enviado_em ? '<span style="color:var(--warn)">Ainda não abriu o link</span>' : '—'}</dd></dl>
        <div class="link-box" style="margin-top:10px"><code>${esc(linkNF(n))}</code>
          <button class="btn sm" data-act="nf-copiar-link" data-id="${n.id}">${ic.copiar} Copiar</button>
          <button class="btn sm" data-act="nf-previa" data-id="${n.id}" title="Abre a página do fornecedor sem marcar como aberta">${ic.olho} Ver como o fornecedor</button>
          ${DEMO ? `<button class="btn sm ghost" data-act="nf-simular" data-id="${n.id}">Simular envio da nota</button>` : ''}</div>`;
    };
    const blocoAprovar = (compacto, semBotao) => `${checklist([[!!m.folha_numero, 'F.S. lançada (número, data, parcela e valor)'], [fds.length > 0, 'Arquivo da F.S. anexado']])}
        <p class="small muted" style="margin-top:8px">Aprove depois das aprovações internas. A NF só vai a Serviços depois desta aprovação.</p>
        ${fds.length && semBotao ? '' : `<div class="row" style="margin-top:8px">${fds.length ? '' : `<label class="btn sm" for="fs-file2">${ic.upload} Anexar F.S.</label><input type="file" id="fs-file2" class="sr-only" multiple accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls" data-chg="fs-anexar">`}
          ${semBotao ? '' : `<button class="btn ${compacto ? '' : 'primary'}" data-act="fs-aprovar" data-m="${m.id}" ${m.folha_numero && fds.length ? '' : 'disabled title="Lance a F.S. e anexe o arquivo"'}>${ic.ok} Aprovar F.S.</button>`}</div>`}`;
    const blocoServicos = (semBotao) => {
      const para = destinatariosFS();
      const comAlerta = nota && nota.status === 'em_conferencia' && nota.alertas > 0;
      return `${checklist([[fsAprovada, 'F.S. aprovada'], [!!nota, nota ? `NF nº ${nota.numero} recebida${nota.status === 'aprovada' ? ' e aprovada' : comAlerta ? ` · ${nota.alertas} alerta(s) a conferir` : ''}` : 'NF recebida do fornecedor']])}
        <div class="field" style="margin-top:10px"><span>Destinatários</span><div class="mails">${para.map((x) => `<span class="tag">${esc(x)}</span>`).join('') || '<span class="small" style="color:var(--warn)">Nenhum: cadastre Serviços e Ocorrência em Configurações > Encaminhamento a Serviços.</span>'}</div>
          <span class="hint">Vão em anexo a NF, o XML (se houver) e a F.S. ${autoServicos() && app ? 'O encaminhamento é automático quando a F.S. está aprovada e a NF não tem alertas.' : app ? 'Encaminhamento manual (Configurações > Encaminhamento a Serviços).' : 'Sem envio pelo app: o e-mail abre no Outlook e o envio é registrado.'}</span></div>
        ${semBotao ? '' : `<div class="row" style="margin-top:10px"><button class="btn primary" data-act="serv-encaminhar" data-m="${m.id}" ${fsAprovada && nota ? '' : 'disabled title="Aguardando a F.S. aprovada e a NF"'}>${ic.envio} Encaminhar a Serviços</button></div>`}`;
    };

    // ---------- O que fazer agora ----------
    const agora = [];
    let rodape = '', arqNoAgora = false;
    if (px.k === 'aprovar_med') {
      const s = S.solic.find((x) => x.fornecedor_id === m.fornecedor_id && !['cancelado', 'expirado'].includes(x.status));
      agora.push(cartao('Aprovar a medição', `<p class="small">A medição está "${esc(MED[m.status][0])}". Aprove o valor em Recebimentos para lançar a F.S.</p>
        ${s ? `<div class="row" style="margin-top:8px"><button class="btn sm" data-act="abrir-receb" data-s="${s.id}">${ic.receb} Abrir recebimento</button></div>` : ''}`));
    } else if (px.k === 'lancar') {
      agora.push(cartao('Lançar a F.S.', `<p class="small muted" style="margin-bottom:10px">Registre a F.S. feita no TOTVS e anexe o arquivo.</p>${blocoFolhaForm(true)}`, 'principal'));
      rodape = `<button class="btn primary" data-act="nf-salvar-folha" data-m="${m.id}">${ic.ok} Lançar F.S.</button>`;
      agora.push(cartao('Arquivos', blocoArquivos())); arqNoAgora = true;
    } else if (px.k === 'enviar') {
      if (mostrarForm) {
        agora.push(cartao('Enviar a F.S. ao fornecedor', blocoEnvioForm(), 'principal'));
        rodape = `<button class="btn ghost" data-act="nf-cancelar" data-id="${n.id}">Cancelar envio</button>
          <button class="btn" data-act="nf-copiar-email">${ic.copiar} Copiar texto</button>
          <a class="btn ${app ? '' : 'fixo'}" href="#" data-act="nf-outlook">${ic.mail} Abrir no Outlook</a>
          <button class="btn ${app ? '' : 'primary'}" data-act="nf-registrar" data-id="${n.id}">${ic.ok} Registrar envio pelo Outlook</button>
          ${app ? `<button class="btn primary" data-act="nf-enviar" data-id="${n.id}">${ic.envio} Enviar pelo app</button>` : ''}`;
      } else if (n && ['recusada', 'expirada'].includes(n.status) || (n && !valida && n.status !== 'cancelada')) {
        agora.push(cartao('Enviar a F.S. de novo', `<p class="small">${n.status === 'recusada' ? 'A NF foi recusada. Gere um novo link: o e-mail ao fornecedor informa o motivo.' : `O link venceu em ${U.dataBR(U.dataLocal(n.expira_em))}.`}</p>
          `, 'principal'));
        rodape = `<button class="btn primary" data-act="nf-renovar" data-id="${n.id}">${ic.refazer} Gerar novo link</button>`;
      } else {
        const req = [[aprovada, 'Medição aprovada'], [!!(m.folha_numero && m.parcela), 'F.S. lançada com a parcela'], [!!m.descricao_nf, 'Descrição para a nota']];
        agora.push(cartao('Enviar a F.S. ao fornecedor', `${checklist(req)}
          <p class="small muted" style="margin-top:8px">${fds.length ? `${fds.length} arquivo(s) da F.S.` : 'Sem arquivo da F.S. anexado'}${pcs.length ? ` e ${pcs.length} pedido(s) de compra` : ''} para anexar. O fornecedor recebe o link para enviar a NF.</p>
          `, 'principal'));
        agora.push(cartao('Arquivos', blocoArquivos())); arqNoAgora = true;
        rodape = `<button class="btn primary" data-act="nf-gerar" data-m="${m.id}" ${req.every(([ok]) => ok) ? '' : 'disabled'}>${ic.envio} Preparar o e-mail ao fornecedor</button>`;
      }
    } else if (px.k === 'conferir') {
      agora.push(cartao('Conferir a NF', notaHTML(nota, m, false, { decisaoNoRodape: true }), 'principal'));
      rodape = `<button class="btn ghost" data-act="nf-recusar-abrir" data-id="${nota.id}">Recusar…</button>
        <button class="btn primary" data-act="nf-aprovar" data-id="${nota.id}">${ic.ok} Aprovar nota${nota.alertas ? ' (alertas conferidos)' : ''}</button>`;
    } else if (px.k === 'anexar' || px.k === 'aprovar_fs') {
      agora.push(cartao(px.k === 'anexar' ? 'Anexar o arquivo e aprovar a F.S.' : 'Aprovar a F.S.', blocoAprovar(false, true), 'principal'));
      rodape = `<button class="btn primary" data-act="fs-aprovar" data-m="${m.id}" ${m.folha_numero && fds.length ? '' : 'disabled title="Lance a F.S. e anexe o arquivo"'}>${ic.ok} Aprovar F.S.</button>`;
    } else if (px.k === 'aguardando') {
      agora.push(cartao('Aguardando a NF do fornecedor', blocoLink() + (mostrarForm ? '' : `<div class="row" style="margin-top:10px"><button class="btn sm ghost" data-act="nf-cancelar" data-id="${n.id}">Cancelar envio</button></div>`), 'principal'));
      if (!mostrarForm) rodape = `<button class="btn" data-act="nf-form" data-m="${m.id}">${ic.mail} Reenviar ou lembrar</button>`;
    } else if (px.k === 'encaminhar') {
      agora.push(cartao('Encaminhar a NF a Serviços', blocoServicos(true), 'principal'));
      rodape = `<button class="btn primary" data-act="serv-encaminhar" data-m="${m.id}">${ic.envio} Encaminhar a Serviços</button>`;
    } else if (px.k === 'finalizado') {
      agora.push(`<div class="demo-banner fim-ok"><span>${ic.ok}</span><span>${m.encaminhado_em
        ? `NF encaminhada a Serviços em ${U.dataHoraBR(m.encaminhado_em)}${m.encaminhado_por ? ` (${esc(m.encaminhado_por)})` : ''}. Processo finalizado.`
        : `F.S. aprovada em ${U.dataHoraBR(m.folha_aprovada_em || m.finalizado_em)}. Processo finalizado.`}</span></div>`);
    }
    // Trilha em paralelo: aprovação da F.S. enquanto a NF não chega, e a NF enquanto a F.S. não é aprovada
    if (['aguardando', 'conferir'].includes(px.k) && m.folha_numero && !fsAprovada && !(px.k === 'aguardando' && mostrarForm)) {
      agora.push(cartao('Aprovar a F.S. <span class="small muted" style="font-weight:400">· em paralelo</span>', blocoAprovar(true)));
    }
    if (['anexar', 'aprovar_fs'].includes(px.k) && valida && n.status !== 'gerada') {
      agora.push(cartao('Aguardando a NF do fornecedor <span class="small muted" style="font-weight:400">· em paralelo</span>', blocoLink() + `<div class="row" style="margin-top:10px"><button class="btn sm" data-act="nf-form" data-m="${m.id}">${ic.mail} Reenviar ou lembrar</button></div>`));
    }
    if (px.k === 'aguardando' && mostrarForm) {
      agora.push(cartao('Reenviar ou lembrar o fornecedor', blocoEnvioForm(), 'principal'));
      rodape = `<button class="btn ghost" data-act="nf-form-fechar" data-m="${m.id}">Voltar</button>
        <button class="btn" data-act="nf-copiar-email">${ic.copiar} Copiar texto</button>
        <a class="btn ${app ? '' : 'fixo'}" href="#" data-act="nf-outlook">${ic.mail} Abrir no Outlook</a>
        <button class="btn ${app ? '' : 'primary'}" data-act="nf-registrar" data-id="${n.id}">${ic.ok} Registrar pelo Outlook</button>
        ${app ? `<button class="btn primary" data-act="nf-enviar" data-id="${n.id}">${ic.envio} ${manter ? 'Enviar lembrete' : 'Reenviar'} pelo app</button>` : ''}`;
    }

    // ---------- Detalhes (recolhidos) ----------
    const det = [];
    if (px.k !== 'lancar' && aprovada) det.push(retratil('nf-d-fs', 'Folha de serviço', m.folha_numero ? '' : null, travadaFS || fim ? blocoFolhaResumo() : (m.folha_numero ? blocoFolhaForm() : '<p class="small muted">Ainda não lançada.</p>')));
    if (!arqNoAgora && aprovada) det.push(retratil('nf-d-arq', 'Arquivos da F.S. e pedido de compra', fds.length + pcs.length, blocoArquivos()));
    if (n && valida && !['aguardando'].includes(px.k) && !(px.k === 'enviar') && n.status !== 'gerada' && !(['anexar', 'aprovar_fs'].includes(px.k))) det.push(retratil('nf-d-link', 'Envio ao fornecedor', null, blocoLink()));
    if (nota && px.k !== 'conferir') det.push(retratil('nf-d-nota', 'Nota fiscal', null, notaHTML(nota, m, fim)));
    if (fsAprovada && !['encaminhar', 'finalizado'].includes(px.k)) det.push(retratil('nf-d-serv', 'Encaminhamento a Serviços', null, blocoServicos()));
    if (p && p.parcelas_total) det.push(retratil('nf-d-parc', 'Parcelas do contrato', `${p.pagas}/${p.parcelas_total}`, `<div class="parcelas">${barraParcelas(p)}
      <div class="row small" style="gap:14px"><span><b>${p.pagas}</b> paga${p.pagas !== 1 ? 's' : ''}${p.parcelas_pagas_antes ? ` (${p.parcelas_pagas_antes} antes do sistema)` : ''}</span><span><b>${p.lancadas}</b> lançada${p.lancadas !== 1 ? 's' : ''}</span><span><b>${p.a_pagar}</b> a pagar</span></div></div>
      <div class="row" style="margin-top:8px"><button class="btn sm ghost" data-act="abrir-contr" data-c="${c.id}">Editar contrato</button></div>`));
    const hist = `${recusadas.length ? `<div class="stack" style="gap:6px">${recusadas.map((x) => `<div class="envio-item"><div class="row between" style="flex-wrap:nowrap;gap:8px"><b>NF nº ${esc(x.numero)} · ${U.brl(x.valor)}</b>${chip('crit', 'Recusada')}</div>
        <div class="small muted">Recebida em ${U.dataHoraBR(x.created_at)} · recusada por ${esc(x.conferido_por || '—')} em ${U.dataHoraBR(x.conferido_em)}</div>
        <div class="small" style="margin-top:4px">Motivo: ${esc(x.motivo_recusa || '—')}</div></div>`).join('')}</div>` : ''}
      <div id="envios-nf"><p class="muted small">Carregando…</p></div>`;
    det.push(retratil('nf-d-hist', 'Histórico de envios' + (recusadas.length ? ' e notas recusadas' : ''), null, hist));

    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">F.S. e nota fiscal · ${esc(U.compLabel(m.competencia))}</span><h2>${esc(f.nome)}</h2>
        <div class="small muted">Pedido <span class="mono">${esc(c.pedido)}</span> · ${esc(c.titulo)} · aprovado ${U.brl(m.valor_aprovado)}${m.parcela ? ` · parcela ${esc(parcelaTxt(m))}` : ''}</div>
        ${m.status === 'sem_medicao' ? '' : passosHTML(m)}</div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <div class="stack" style="gap:12px">${agora.join('')}</div>
        <div class="stack nf-detalhes" style="gap:8px"><span class="label">Detalhes</span>${det.join('')}</div>
      </div>
      <div class="drawer-foot"><button class="btn ghost" data-act="fechar-gaveta">Fechar</button><span class="spacer"></span>${rodape}</div>`);
    if (scroll) document.querySelector('#gaveta .drawer-body').scrollTop = scroll;
    // Envios do pedido de NF e a Serviços, no histórico
    Promise.all([n ? API.enviosNF(n.id) : Promise.resolve([]), API.enviosMedicao(m.id)]).then(([lnf, lmed]) => {
      const box = document.getElementById('envios-nf');
      if (!box || !S.gaveta || S.gaveta.id !== mid) return;
      const todos = lnf.concat(lmed).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
      contarRetratil('nf-d-hist', todos.length + recusadas.length);
      const titulo = (x) => (x.medicao_id ? (x.tipo === 'nf_servicos' ? 'NF encaminhada a Serviços' : 'Aviso de F.S. aprovada') : `${TIPO_ENVIO[x.tipo] || x.tipo} da F.S. ao fornecedor`) + ' ' + (VIA_ENVIO[x.via] || '');
      box.innerHTML = todos.length ? todos.map((x) => `<div class="envio-item">
          <div class="row between" style="flex-wrap:nowrap;gap:8px"><b>${esc(titulo(x))}</b>${chipEnvio(x)}</div>
          <div class="small muted">${U.dataHoraBR(x.created_at)} · por ${esc(x.autor || 'sistema')}${x.prazo_ate ? ' · prazo até ' + U.dataBR(U.dataLocal(x.prazo_ate)) : ''}</div>
          <div class="mails" style="margin-top:4px">${(x.para || []).map((y) => `<span class="tag">${esc(y)}</span>`).join('')}</div>
          ${x.erro ? `<div class="small" style="color:var(--crit);margin-top:4px">${esc(x.erro)}</div>` : ''}</div>`).join('') : '<p class="muted small">Nenhum envio registrado.</p>';
    }).catch((err) => { const box = document.getElementById('envios-nf'); if (box) box.innerHTML = `<p class="small" style="color:var(--crit)">${esc(err.message)}</p>`; });
  }
  function barraParcelas(p) {
    const tot = p.parcelas_total, pagas = Math.min(p.pagas, tot), lanc = Math.min(p.lancadas, Math.max(tot - pagas, 0));
    return `<div class="parc-bar" role="img" aria-label="${pagas} de ${tot} parcelas pagas"><i class="pagas" style="width:${(pagas / tot * 100).toFixed(1)}%"></i><i class="lanc" style="width:${(lanc / tot * 100).toFixed(1)}%"></i></div>`;
  }
  function emailNFDe(m, n, manter, anexos) {
    const c = C(m.contrato_id), f = F(m.fornecedor_id);
    const rec = notasDe(m.id).find((x) => x.status === 'recusada' && x.solicitacao_nf_id === n.id);
    const prazoISO = manter ? n.expira_em : U.fimPrazoISO(new Date().toISOString(), prazoNF(), S.fer);
    const r = U.montarEmailNF({ modeloAssunto: cfgv('modelo_nf_assunto', ''), modeloCorpo: cfgv('modelo_nf_corpo', ''), fornecedor: f.nome, competencia: m.competencia,
      pedido: c.pedido, servico: c.titulo, parcela: m.parcela, parcelasTotal: c.parcelas_total, valor: m.valor_aprovado, folhaNumero: m.folha_numero, folhaData: m.folha_data,
      descricao: m.descricao_nf, link: linkNF(n), prazoISO, prazoDias: prazoNF(), suporte: contatosFornecedor(), suporteServicos: servicosSuporte([c]), cnpjs: cnpjsKlingele(), anexos,
      recusa: rec ? { numero: rec.numero, motivo: rec.motivo_recusa } : null });
    if (manter) r.assunto = 'LEMBRETE - ' + r.assunto;
    return r;
  }
  // Links temporários dos arquivos escolhidos (F.S. e pedido de compra), gerados uma vez por gaveta para o Outlook e o registro usarem os mesmos
  async function linksAnexosNF() {
    const m = S.med.find((x) => x.id === S.gaveta.id), n = solicNF(m.id);
    const ids = Array.from(document.querySelectorAll('#gaveta [data-anx]:checked')).map((i) => i.value);
    const docs = fsDocs(m).concat(pedidosCompra(m)).filter((d) => ids.includes(d.id));
    const chave = ids.slice().sort().join(',');
    if (S.gaveta.links && S.gaveta.links.chave === chave) return S.gaveta.links.lista;
    const dias = U.diffDias(U.hojeISO(), U.dataLocal(U.fimPrazoISO(new Date().toISOString(), prazoNF(), S.fer))) + 5;
    const lista = docs.length ? await API.linksPedidoCompra(docs, dias) : [];
    S.gaveta.links = { chave, lista, n: n && n.id };
    return lista;
  }
  // Texto final do e-mail: troca o marcador pelos links temporários
  async function emailNFFinal() {
    const e = lerEmailForm();
    const links = await linksAnexosNF();
    let corpo = e.corpo;
    links.forEach((l) => { corpo = corpo.split(`- ${l.nome}: ${LINK_TEMP}`).join(`- ${l.nome}: ${l.url}`); });
    return { ...e, corpo, anexos: links };
  }
  async function salvarFolha(mid) {
    const g = (id) => (document.getElementById(id) || {}).value || '';
    const num = g('nf-folha-num').trim(), data = g('nf-folha-data'), parcela = Number(g('nf-parcela')), desc = g('nf-desc').trim();
    const vtxt = g('nf-folha-valor').trim(), valor = vtxt ? U.parseValor(vtxt) : null;
    if (vtxt && (valor === null || !U.valorOk(valor))) { U.toast('Valor da F.S. inválido', 'erro'); return; }
    if (!/^[A-Za-z0-9./ -]{1,40}$/.test(num)) { U.toast('Informe o número da folha (letras, números, ponto, barra ou hífen)', 'erro'); return; }
    if (!data) { U.toast('Informe a data da folha', 'erro'); return; }
    if (!Number.isInteger(parcela) || parcela < 1) { U.toast('Escolha a parcela', 'erro'); return; }
    if (desc.length < 5) { U.toast('Escreva a descrição para a nota fiscal', 'erro'); return; }
    try {
      await API.lancarFolha(mid, num, data, parcela, desc, valor);
      await recarregar(true); renderView(); abrirNF(mid, { manterScroll: true });
      const m = S.med.find((x) => x.id === mid);
      U.toast(m && !fsDocs(m).length ? `F.S. lançada · parcela ${parcela}. Agora anexe o arquivo da F.S. e aprove.` : `F.S. lançada · parcela ${parcela}`);
    } catch (err) { U.toast(err.message, 'erro'); }
  }
  async function anexarPedidoCompra(files, tipo) {
    tipo = tipo || 'pedido_compra';
    const m = S.med.find((x) => x.id === S.gaveta.id), f = F(m.fornecedor_id);
    for (const file of files) {
      if (!U.MIME[U.extensao(file.name)]) { U.toast(`Tipo não aceito: ${file.name}`, 'erro'); continue; }
      if (file.size > 25 * 1048576) { U.toast(`Maior que 25 MB: ${file.name}`, 'erro'); continue; }
      if (!(await U.conferirAssinatura(file).catch(() => false))) { U.toast(`O conteúdo não corresponde ao tipo do arquivo: ${file.name}`, 'erro'); continue; }
      try { await API.anexarDocumento({ solicitacao: null, fornecedor: f, competencia: m.competencia, file, tipo, contrato_id: m.contrato_id, valor_lido: null }); }
      catch (err) { U.toast(err.message, 'erro'); }
    }
    await recarregar();
    U.toast(tipo === 'folha_servico' ? 'Arquivo da F.S. anexado' : 'Pedido de compra anexado');
    if (S.gaveta) { S.gaveta.links = null; abrirNF(S.gaveta.id, { manterScroll: true }); }
    renderView();
  }
  async function baixarXmlNF(id, numero) {
    try {
      const xml = await API.xmlNotaFiscal(id);
      if (!xml) { U.toast('Esta nota foi enviada sem XML', 'erro'); return; }
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([xml], { type: 'application/xml' }));
      a.download = `NF-${String(numero || 'nota').replace(/[^A-Za-z0-9-]/g, '')}.xml`; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    } catch (err) { U.toast(err.message, 'erro'); }
  }
  // Aviso da F.S. aprovada pelo Outlook (quando o envio pelo app não está configurado)
  async function avisoFSOutlook(mid, r) {
    if (!(r.para || []).length) { U.toast('Cadastre os e-mails de Serviços e Ocorrência em Configurações > Encaminhamento a Serviços', 'erro'); return; }
    if (!(await U.confirmar('Enviar o aviso pelo Outlook?', `O e-mail "${r.assunto}" abre pronto no Outlook para ${r.para.join(', ')}. Anexe a F.S. e envie; o envio fica registrado.`, 'Abrir no Outlook'))) return;
    const a = document.createElement('a'); a.href = U.mailto(r.para, r.assunto, r.corpo); document.body.appendChild(a); a.click(); a.remove();
    try { await API.registrarEnvioFS(mid, r.para, r.assunto, r.corpo); if (S.gaveta && S.gaveta.id === mid) abrirNF(mid, { manterScroll: true }); } catch (e) { U.toast(e.message, 'erro'); }
  }
  function simularNF(nid, previa) {
    const n = S.nfSolic.find((x) => x.id === nid);
    if (!n) return;
    const mid = S.gaveta && S.gaveta.id;
    fecharGaveta();
    const ov = document.createElement('div');
    ov.className = 'portal-overlay';
    ov.innerHTML = `<div class="sim-bar"><span>${previa ? '<b>Prévia do link da NF</b> · o que o fornecedor vê; nada é gravado e o link não é marcado como aberto'
      : '<b>Simulação do fornecedor</b> · demonstração: use "Gerar XML e PDF de exemplo" e envie a nota'}</span><button class="btn sm" data-sim="fechar">${ic.x} Fechar</button></div><div id="sim-nf"></div>`;
    document.body.appendChild(ov);
    document.body.style.overflow = 'hidden';
    const fechar = async () => { ov.remove(); document.body.style.overflow = ''; await recarregar(true); render(); if (mid) abrirNF(mid); };
    ov.querySelector('[data-sim="fechar"]').addEventListener('click', fechar);
    NotaFiscal.montar(ov.querySelector('#sim-nf'), previa ? null : n.token, { api: API, simulacao: !previa, previaId: previa ? n.id : null, aoFechar: fechar });
  }

  // =====================================================================
  //  PAGAMENTOS
  // =====================================================================
  const GRUPO_PAG = { aguardando: ['aguardando'], conferencia: ['recebido', 'em_conferencia'], aprovado: ['aprovado'], pago: ['pago'] };
  VIEWS.pag = () => {
    const todas = S.med.filter(medMeu).sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || C(a.contrato_id).pedido - C(b.contrato_id).pedido);
    const cnt = (k) => todas.filter((m) => GRUPO_PAG[k].includes(m.status)).length;
    const lista = S.f.pag === 'todos' ? todas : todas.filter((m) => GRUPO_PAG[S.f.pag].includes(m.status));
    const seg = [['todos', 'Todos', todas.length], ['aguardando', 'Aguardando', cnt('aguardando')], ['conferencia', 'Em conferência', cnt('conferencia')], ['aprovado', 'Aprovados', cnt('aprovado')], ['pago', 'Pagos', cnt('pago')]];
    const semMed = S.base.contratos.filter((c) => c.situacao === 'ativo' && contratoMeu(c) && !S.med.some((m) => m.contrato_id === c.id)).sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome));
    return `
      <div class="row between">
        <div class="seg" role="group" aria-label="Filtrar pagamentos">${seg.map(([k, t, c]) => `<button type="button" data-act="filtro-pag" data-v="${k}" aria-pressed="${S.f.pag === k}">${t}<span class="c">${c}</span></button>`).join('')}</div>
        <div class="row"><select id="inc-med" aria-label="Contrato para incluir" style="width:auto;max-width:320px"><option value="">Incluir pedido no mês…</option>
          ${semMed.map((c) => `<option value="${c.id}">${esc(F(c.fornecedor_id).nome)} · ${esc(c.pedido)}</option>`).join('')}</select>
          <button class="btn sm" data-act="incluir-med">${ic.mais} Incluir</button></div>
      </div>
      <section class="panel"><div class="table-wrap"><table class="tbl" id="tbl-pag">
        <thead><tr><th>Fornecedor / pedido</th><th>Parcela</th><th class="r">Contratado</th><th class="r">Medido</th><th>Aprovado</th><th>Nota fiscal</th><th>Pagamento</th><th>Situação</th></tr></thead>
        <tbody>${lista.map((m) => {
          const c = C(m.contrato_id), f = F(m.fornecedor_id);
          return `<tr data-m="${m.id}">
            <td><div class="cell-title">${esc(f.nome)}</div><div class="cell-sub clamp-m">Pedido <span class="mono">${esc(c.pedido)}</span>${c.gestor ? ' · ' + esc(c.gestor) : ''} · ${esc(c.titulo)}</div></td>
            <td class="small">${m.parcela ? `<b>${esc(parcelaTxt(m))}</b>` : '<span class="muted">—</span>'}</td>
            <td class="r num">${U.brl(m.valor_contratado)}</td>
            <td class="r num">${U.brl(m.valor_informado ?? m.valor_lido)}</td>
            <td><input type="text" inputmode="decimal" data-chg="med" data-k="valor_aprovado" value="${esc(U.numBR(m.valor_aprovado))}" placeholder="0,00" aria-label="Valor aprovado"></td>
            <td><input type="text" data-chg="med" data-k="nota_fiscal" value="${esc(m.nota_fiscal || '')}" placeholder="Nº NF" aria-label="Nota fiscal" style="min-width:90px">
              ${(() => { const e = etapaNF(m); return ['aprovada', 'conferir', 'aguardando', 'pedir', 'enviar', 'recusada', 'vencido'].includes(e.k) ? `<button type="button" class="chip-btn" data-act="abrir-nf" data-m="${m.id}" title="Abrir nota fiscal">${chip(e.cls, e.txt)}</button>` : ''; })()}</td>
            <td><input type="date" data-chg="med" data-k="data_pagamento" value="${esc(m.data_pagamento || '')}" aria-label="Data de pagamento" style="min-width:140px"></td>
            <td><select data-chg="med" data-k="status" aria-label="Situação">${Object.entries(MED).map(([k, v]) => `<option value="${k}" ${m.status === k ? 'selected' : ''}>${v[0]}</option>`).join('')}</select></td>
          </tr>`;
        }).join('') || `<tr><td colspan="8"><div class="empty"><h3>Nenhum pedido</h3><p>${S.med.length ? 'Nenhum pedido neste filtro.' : 'Gere os links do mês ou inclua um pedido manualmente.'}</p></div></td></tr>`}</tbody>
        <tfoot id="pag-total">${totaisPag(lista)}</tfoot>
      </table></div></section>`;
  };
  function totaisPag(lista) {
    const pagos = lista.filter((m) => m.status === 'pago');
    return `<tr><td colspan="2">Total (${lista.length})</td><td class="r num">${U.brl(soma(lista.map((m) => m.valor_contratado)))}</td>
      <td class="r num">${U.brl(soma(lista.map((m) => m.valor_informado ?? m.valor_lido)))}</td><td class="num">${U.brl(soma(lista.map((m) => m.valor_aprovado)))}</td>
      <td colspan="3" class="small">Pago: <span class="num">${U.brl(soma(pagos.map((m) => m.valor_aprovado)))}</span> em ${pagos.length} pedido${pagos.length !== 1 ? 's' : ''}</td></tr>`;
  }

  // =====================================================================
  //  AVALIAÇÃO DE SATISFAÇÃO
  // =====================================================================
  const AVS = { gerada: ['Link gerado', ''], enviada: ['Enviada ao supervisor', 'info'], aberta: ['Supervisor abriu', 'info'], respondida: ['Respondida', 'ok'],
    padrao: ['Resposta padrão', 'accent'], expirada: ['Prazo encerrado', 'crit'], cancelada: ['Cancelada', ''] };
  const chipAval = (a) => chip(AVS[a.status][1], AVS[a.status][0]);
  const avalPendente = (a) => ['gerada', 'enviada', 'aberta'].includes(a.status) && new Date(a.expira_em) > new Date();
  const avalVencida = (a) => a.status === 'expirada' || (['gerada', 'enviada', 'aberta'].includes(a.status) && new Date(a.expira_em) <= new Date());
  const linkAvaliacao = (a) => (cfg.portalUrl ? cfg.portalUrl.replace(/portal\.html.*$/, 'avaliacao.html') : new URL('avaliacao.html', location.href).href.split('#')[0].split('?')[0]) + '#' + a.token;
  const padraoAval = () => { try { const p = JSON.parse(cfgv('avaliacao_padrao', '') || 'null'); return U.notasCompletas(p) ? p : null; } catch (e) { return null; } };
  const prazoAval = () => Number(cfgv('avaliacao_prazo_dias_uteis', 7)) || 7;
  const GRUPO_AVAL = { pendentes: ['gerada', 'enviada', 'aberta'], respondidas: ['respondida', 'padrao'], encerradas: ['expirada', 'cancelada'] };
  function emailAvaliacaoDe(a, manter) {
    const prazoISO = manter ? a.expira_em : U.fimPrazoISO(new Date().toISOString(), prazoAval(), S.fer);
    const m = U.montarEmailAvaliacao({ modeloAssunto: cfgv('modelo_aval_assunto', ''), modeloCorpo: cfgv('modelo_aval_corpo', ''), supervisor: a.supervisor_nome,
      fornecedor: F(a.fornecedor_id).nome, competencia: a.competencia, servicos: (a.contratos || []).map(C), link: linkAvaliacao(a), prazoISO, prazoDias: prazoAval() });
    if (manter) m.assunto = 'LEMBRETE - ' + m.assunto;
    return m;
  }

  VIEWS.aval = () => {
    const todas = S.aval.filter((a) => !escopoMeu() || a.supervisor_id === meuSupervisor() || (a.contratos || []).some((id) => contratoEhMeu(S.mapC[id]))).sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || a.supervisor_nome.localeCompare(b.supervisor_nome));
    const ativas = todas.filter((a) => a.status !== 'cancelada');
    const resp = ativas.filter((a) => ['respondida', 'padrao'].includes(a.status));
    const media = resp.length ? Math.round((resp.reduce((t, a) => t + Number(a.nota_geral), 0) / resp.length) * 100) / 100 : null;
    const vencidas = ativas.filter(avalVencida);
    const aEnviar = ativas.filter((a) => a.status === 'gerada' && avalPendente(a)).length;
    const mesAberto = !compLiberada(S.comp);
    const app = podeEnviarPeloApp();
    const padrao = padraoAval();
    const cnt = (k) => todas.filter((a) => GRUPO_AVAL[k].includes(a.status)).length;
    const lista = S.f.aval === 'todos' ? todas : todas.filter((a) => GRUPO_AVAL[S.f.aval].includes(a.status));
    const seg = [['todos', 'Todas', todas.length], ['pendentes', 'Aguardando', cnt('pendentes')], ['respondidas', 'Respondidas', cnt('respondidas')], ['encerradas', 'Encerradas', cnt('encerradas')]];
    // contratos ativos da lista mensal sem supervisor (não geram avaliação)
    const semSup = S.base.contratos.filter((c) => c.situacao === 'ativo' && modalidadeDe(F(c.fornecedor_id)) && !(COL(c.supervisor_id) || {}).supervisor);

    const itens = lista.map((a) => {
      const f = F(a.fornecedor_id), co = COL(a.supervisor_id);
      const email = (co && co.email) || a.supervisor_email;
      let acts = '';
      if (avalPendente(a)) {
        acts = `<button class="btn sm ${a.status === 'gerada' ? 'primary' : ''}" data-act="ver-aval" data-a="${a.id}">${ic.mail} ${a.status === 'gerada' ? 'Ver e enviar' : '<span>Verificar<span class="so-desk-i"> e reenviar</span></span>'}</button>
          <button class="icon-btn" data-act="copiar-link-aval" data-a="${a.id}" title="Copiar link do supervisor" aria-label="Copiar link do supervisor">${ic.copiar}</button>
          <button class="icon-btn" data-act="previa-aval" data-a="${a.id}" title="Ver o que o supervisor vê (não marca como aberto)" aria-label="Prévia da avaliação">${ic.olho}</button>
          <button class="icon-btn" data-act="padrao-aval" data-a="${a.id}" title="Aplicar resposta padrão" aria-label="Aplicar resposta padrão">${ic.ok}</button>`;
      } else if (['respondida', 'padrao'].includes(a.status)) {
        acts = `<button class="btn sm" data-act="ver-aval" data-a="${a.id}">${ic.estrela} Ver notas</button>`;
      } else if (a.status === 'expirada' || avalVencida(a)) {
        acts = `<button class="btn sm primary" data-act="padrao-aval" data-a="${a.id}">${ic.ok} Aplicar resposta padrão</button>
          <button class="icon-btn" data-act="renovar-aval" data-a="${a.id}" title="Gerar novo link" aria-label="Gerar novo link">${ic.refazer}</button>
          <button class="icon-btn" data-act="ver-aval" data-a="${a.id}" title="Ver envios" aria-label="Ver envios">${ic.mail}</button>`;
      } else {
        acts = `<button class="btn sm" data-act="renovar-aval" data-a="${a.id}">${ic.refazer} Reabrir</button>`;
      }
      const fim = U.dataLocal(a.expira_em), r = U.diasUteisAte(fim, S.fer);
      return `<div class="send-item">
        <div class="who"><span class="cell-title">${esc(f.nome)}</span>
          <span class="cell-sub">Supervisor <b>${esc(a.supervisor_nome)}</b>${email ? ` · ${esc(email)}` : ''}</span>
          <div class="row" style="margin-top:4px;gap:6px">${chipAval(a)}${a.envio_status === 'falha' ? `<span class="chip crit"${a.envio_erro ? ` title="${esc(a.envio_erro)}"` : ''}>Falha no envio</span>` : ''}
            <span class="small muted">${avalPendente(a) ? `até ${U.dataBR(fim)} · ${r === 0 ? 'último dia' : r === 1 ? '1 dia útil' : r + ' dias úteis'}` : a.respondido_em ? 'em ' + U.dataHoraBR(a.respondido_em) : ''}</span></div>
          ${!email && avalPendente(a) ? `<span class="small" style="color:var(--warn)">Supervisor sem e-mail: cadastre em Contatos Klingele ou copie o link.</span>` : ''}
          ${a.status === 'padrao' ? `<span class="small muted">${esc(a.observacao || '')} · aplicada por ${esc(a.padrao_aplicado_por || '—')}</span>` : ''}</div>
        <div class="svc"><ul>${(a.contratos || []).map((id) => { const c = C(id); return `<li><span class="svc-t" title="${esc(c.titulo)}">${esc(c.titulo)}</span> <span class="mono muted">${esc(c.pedido)}</span>${c.tipo_servico ? ` <span class="muted so-desk-i">· ${esc(U.tipoServicoTxt(c.tipo_servico))}</span>` : ''}</li>`; }).join('')}</ul></div>
        <div class="acts">${['respondida', 'padrao'].includes(a.status) ? `<span class="nota-badge sm ${U.classeNota(a.nota_geral)}" title="Nota geral">${U.nota(a.nota_geral)}</span>` : ''}${acts}</div>
      </div>`;
    }).join('');

    // Média de cada item no mês (respondidas e resposta padrão)
    const barras = U.CATEGORIAS.map(([k, nome]) => {
      const vs = resp.map((a) => a.notas && a.notas[k]).filter((x) => Number.isInteger(x));
      const m = vs.length ? vs.reduce((t, x) => t + x, 0) / vs.length : null;
      return `<div class="cat-bar"><span>${esc(nome)}</span><div class="track"><i class="${m !== null && m < 6 ? 'crit' : m !== null && m < 8 ? 'warn' : ''}" style="width:${m === null ? 0 : (m / 10 * 100).toFixed(1)}%"></i></div><b>${U.nota(m)}</b></div>`;
    }).join('');

    // Nota geral por fornecedor nos últimos 6 meses
    const comps = []; for (let i = 5; i >= 0; i--) comps.push(U.addMes(S.comp, -i));
    const porForn = {};
    S.avalPeriodo.forEach((a) => { ((porForn[a.fornecedor_id] = porForn[a.fornecedor_id] || {})[a.competencia] = porForn[a.fornecedor_id][a.competencia] || []).push(a); });
    const fornIds = Object.keys(porForn).sort((x, y) => F(x).nome.localeCompare(F(y).nome));
    const mapa = fornIds.map((fid) => `<tr><td class="cell-title">${esc(F(fid).nome)}</td>${comps.map((c) => {
      const l = porForn[fid][c];
      if (!l) return '<td class="nota"><span class="muted">—</span></td>';
      const m = l.reduce((t, a) => t + Number(a.nota_geral), 0) / l.length;
      const pad = l.some((a) => a.status === 'padrao');
      return `<td class="nota"><span class="${U.classeNota(m)}" title="${esc(l.map((a) => `${a.supervisor_nome}: ${U.nota(a.nota_geral)}${a.status === 'padrao' ? ' (resposta padrão)' : ''}`).join('\n'))}">${U.nota(m)}</span>${pad ? '<sup>P</sup>' : ''}</td>`;
    }).join('')}</tr>`).join('');

    const botoes = mesAberto ? `<span class="small muted">${esc(U.compLabel(S.comp))} ainda não terminou. A avaliação é pedida depois do fim do mês.</span>`
      : `${vencidas.length ? `<button class="btn" data-act="padrao-vencidas" ${padrao ? '' : 'disabled title="Defina a resposta padrão em Configurações"'}>${ic.ok} Resposta padrão nas vencidas (${vencidas.length})</button>` : ''}
         ${app && aEnviar ? `<button class="btn primary" data-act="enviar-avals">${ic.envio} Enviar ${aEnviar} avaliaç${aEnviar > 1 ? 'ões' : 'ão'}</button>` : ''}
         <button class="btn ${!app || !aEnviar ? 'primary' : ''}" data-act="gerar-avals">${ic.link} Gerar avaliações</button>`;
    return `
      <div class="tiles">
        <div class="tile accent"><span class="label">Nota geral do mês</span><span class="v">${U.nota(media)}</span>
          <span class="d">Média de ${resp.length} avaliaç${resp.length !== 1 ? 'ões' : 'ão'} de ${esc(U.cap(U.mesNome(S.comp)))}${media === null ? '' : media >= 8 ? ' · boa' : media >= 6 ? ' · atenção' : ' · crítica'}</span></div>
        <div class="tile"><span class="label">Respondidas</span><span class="v">${ativas.filter((a) => a.status === 'respondida').length} de ${ativas.length}</span>
          <span class="d">${ativas.filter((a) => a.status === 'padrao').length} com resposta padrão</span></div>
        <div class="tile"><span class="label">Aguardando o supervisor</span><span class="v">${ativas.filter(avalPendente).length}</span>
          <span class="d">${vencidas.length ? `<b class="diff-pos">${vencidas.length} com prazo encerrado</b>` : 'Nenhuma vencida'}</span></div>
        <div class="tile"><span class="label">Resposta padrão</span><span class="v" style="font-size:1.2rem">${padrao ? `Notas ${U.nota(U.mediaNotas(padrao))} de média` : 'Não definida'}</span>
          <span class="d">${padrao ? 'Quando o supervisor não responde' : '<a href="#conf" data-view="conf">Defina em Configurações</a>'}</span></div>
      </div>
      <section class="panel">
        <div class="panel-head"><div><h2>Avaliações de ${esc(U.compLabel(S.comp))}</h2>
          <span class="sub">Uma por fornecedor e supervisor · link de uso único, ${prazoAval()} dias úteis${app ? '' : ' · pelo Outlook: abra, envie e registre'}</span></div>
          <div class="row">${botoes}</div></div>
        <div class="panel-body" style="padding-bottom:0"><div class="seg" role="group" aria-label="Filtrar avaliações">${seg.map(([k, t, c]) => `<button type="button" data-act="filtro-aval" data-v="${k}" aria-pressed="${S.f.aval === k}">${t}<span class="c">${c}</span></button>`).join('')}</div></div>
        ${semSup.length ? `<div class="panel-body" style="padding-bottom:0"><div class="demo-banner"><span>${semSup.length} contrato${semSup.length > 1 ? 's' : ''} ativo${semSup.length > 1 ? 's' : ''} da lista mensal sem supervisor não gera${semSup.length > 1 ? 'm' : ''} avaliação: ${esc(semSup.slice(0, 4).map((c) => F(c.fornecedor_id).nome + ' (' + c.pedido + ')').join(', '))}${semSup.length > 4 ? '…' : ''}.</span>
          <span class="spacer"></span><button class="btn sm" data-view="contr">Abrir contratos</button></div></div>` : ''}
        <div class="send-list" style="margin-top:12px">${itens || `<div class="empty"><h3>${todas.length ? 'Nenhuma avaliação neste filtro' : 'Nenhuma avaliação gerada'}</h3><p>${todas.length ? 'Escolha outro filtro.' : mesAberto ? 'Disponível depois do fim do mês.' : 'Use "Gerar avaliações" para criar uma por fornecedor e supervisor.'}</p></div>`}</div>
      </section>
      <div class="grid-2">
        <section class="panel">
          <div class="panel-head"><div><h2>Nota geral por fornecedor</h2><span class="sub">Últimos 6 meses · P = resposta padrão</span></div></div>
          <div class="table-wrap"><table class="tbl mapa-notas"><thead><tr><th>Fornecedor</th>${comps.map((c) => `<th class="r" style="text-align:center">${U.compCurta(c)}</th>`).join('')}</tr></thead>
            <tbody>${mapa || `<tr><td colspan="7" class="muted">Sem avaliações respondidas no período.</td></tr>`}</tbody></table></div>
        </section>
        <section class="panel">
          <div class="panel-head"><div><h2>Média por item</h2><span class="sub">${esc(U.compLabel(S.comp))} · escala de 1 a 10</span></div></div>
          <div class="panel-body">${resp.length ? `<div class="cat-bars">${barras}</div>` : '<p class="muted">Sem respostas neste mês.</p>'}</div>
        </section>
      </div>`;
  };

  function abrirAvaliacao(aid, opc) {
    const a = S.aval.find((x) => x.id === aid);
    if (!a) return;
    opc = opc || {};
    const f = F(a.fornecedor_id), co = COL(a.supervisor_id);
    const valida = avalPendente(a);
    const respondida = ['respondida', 'padrao'].includes(a.status);
    const jaEnviado = !!a.enviado_em || S.envios.some((e) => e.avaliacao_id === a.id);
    const manter = !!opc.manter && jaEnviado;
    const emailSup = (co && co.email) || a.supervisor_email;
    const sel = opc.marcados || (emailSup ? [emailSup] : []);
    const fim = U.dataLocal(a.expira_em), restam = U.diasUteisAte(fim, S.fer);
    const prazoNovo = U.dataLocal(U.fimPrazoISO(new Date().toISOString(), prazoAval(), S.fer));
    const app = podeEnviarPeloApp();
    const scroll = opc.manterScroll && document.querySelector('#gaveta .drawer-body') ? document.querySelector('#gaveta .drawer-body').scrollTop : 0;
    S.gaveta = { tipo: 'aval', id: aid };
    let bloco = '', rodape = '';
    if (respondida) {
      bloco = `<section>
        <div class="section-title"><h3>Notas</h3><span class="nota-badge ${U.classeNota(a.nota_geral)}" title="Nota geral (média)">${U.nota(a.nota_geral)}</span></div>
        <div class="cat-bars">${U.CATEGORIAS.map(([k, nome]) => { const v = a.notas ? a.notas[k] : null; return `<div class="cat-bar"><span>${esc(nome)}</span><div class="track"><i class="${v < 6 ? 'crit' : v < 8 ? 'warn' : ''}" style="width:${(v || 0) * 10}%"></i></div><b>${esc(v ?? '—')}</b></div>`; }).join('')}</div>
        <dl class="kv" style="margin-top:12px">
          <dt>${a.status === 'padrao' ? 'Registro' : 'Respondido por'}</dt><dd>${a.status === 'padrao' ? `Resposta padrão aplicada por ${esc(a.padrao_aplicado_por || '—')}` : esc(a.respondido_por || '—')} em ${U.dataHoraBR(a.respondido_em)}</dd>
          <dt>Observação</dt><dd>${a.observacao ? esc(a.observacao) : '<span class="muted">—</span>'}</dd>
        </dl></section>`;
      rodape = '';
    } else if (valida) {
      bloco = `<section>
        <div class="section-title"><h3>${jaEnviado ? 'Reenviar' : 'Enviar'} ao supervisor</h3></div>
        <div class="stack" style="gap:12px">
          <div class="field"><span>Para</span>
            ${emailSup ? `<label class="check"><input type="checkbox" data-para value="${esc(emailSup)}" ${sel.includes(emailSup) ? 'checked' : ''}><span style="overflow-wrap:anywhere">${esc(emailSup)}</span><span class="small muted">${esc(a.supervisor_nome)}</span></label>`
              : '<span class="small" style="color:var(--warn)">Supervisor sem e-mail cadastrado. Informe um e-mail abaixo ou cadastre em Contatos Klingele.</span>'}
            <input type="text" id="em-extra" maxlength="600" placeholder="Outros e-mails, separados por vírgula" value="${esc(opc.extra || '')}" aria-label="Outros e-mails"></div>
          ${jaEnviado ? `<div class="field"><span>Prazo do link</span>
            <label class="check"><input type="radio" name="em-prazo" value="novo" data-chg="prazo-opcao-aval" ${!manter ? 'checked' : ''}> Recomeçar o prazo: válido até ${U.dataBR(prazoNovo)}</label>
            <label class="check"><input type="radio" name="em-prazo" value="manter" data-chg="prazo-opcao-aval" ${manter ? 'checked' : ''}> Manter o prazo atual (até ${U.dataBR(fim)}) e enviar como lembrete</label></div>`
            : `<span class="hint">O prazo de ${prazoAval()} dias úteis começa no envio: válido até ${U.dataBR(prazoNovo)}.</span>`}
          <details class="email-preview" ${app ? '' : 'open'}>
            <summary style="padding:10px 14px;cursor:pointer;font-weight:600">Texto do e-mail${app ? ' <span class="small muted" style="font-weight:400">(para o Outlook)</span>' : ''}</summary>
            <div class="hdr"><label class="row"><span class="k label">Assunto</span><input type="text" id="em-assunto" maxlength="400" value="${esc(emailAvaliacaoDe(a, manter).assunto)}"></label></div>
            <textarea id="em-corpo" aria-label="Texto do e-mail" style="min-height:300px">${esc(emailAvaliacaoDe(a, manter).corpo)}</textarea>
          </details>
        </div></section>`;
      rodape = `<button class="btn ghost" data-act="cancelar-aval" data-a="${a.id}">Cancelar avaliação</button>
        <button class="btn" data-act="padrao-aval" data-a="${a.id}">${ic.ok} Resposta padrão</button>
        <button class="btn" data-act="copiar-email">${ic.copiar} Copiar texto</button>
        <a class="btn ${app ? '' : 'fixo'}" href="#" data-act="outlook">${ic.mail} Abrir no Outlook</a>
        <button class="btn ${app ? '' : 'primary'}" data-act="registrar-envio-aval" data-a="${a.id}">${ic.ok} Registrar envio pelo Outlook</button>
        ${app ? `<button class="btn primary" data-act="enviar-aval" data-a="${a.id}">${ic.envio} ${jaEnviado ? (manter ? 'Enviar lembrete' : 'Reenviar') : 'Enviar'} pelo app</button>` : ''}`;
    } else {
      bloco = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><span>${a.status === 'cancelada' ? 'Avaliação cancelada.' : `O prazo terminou em ${U.dataBR(fim)} sem resposta.`} Aplique a resposta padrão (com a aprovação do supervisor) ou gere um novo link.</span></div>`;
      rodape = `${a.status !== 'cancelada' ? `<button class="btn primary" data-act="padrao-aval" data-a="${a.id}">${ic.ok} Aplicar resposta padrão</button>` : ''}
        <button class="btn" data-act="renovar-aval" data-a="${a.id}">${ic.refazer} Gerar novo link</button>`;
    }
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">Avaliação de satisfação · ${esc(U.compLabel(a.competencia))}</span><h2>${esc(f.nome)}</h2>
        <div class="row">${chipAval(a)}<span class="small muted">Supervisor ${esc(a.supervisor_nome)}</span></div></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <section>
          <div class="section-title"><h3>Pedidos avaliados</h3></div>
          <ul style="margin:0;padding-left:18px">${(a.contratos || []).map((id) => { const c = C(id); return `<li>${esc(c.titulo)} <span class="mono muted">${esc(c.pedido)}</span>${c.tipo_servico ? ` · ${esc(U.tipoServicoTxt(c.tipo_servico))}` : ''}</li>`; }).join('')}</ul>
        </section>
        ${!respondida ? `<section>
          <div class="section-title"><h3>Situação do link</h3></div>
          <dl class="kv">
            <dt>Prazo</dt><dd>${valida ? `Válido até ${U.dataBR(fim)} <span class="muted">(${restam === 0 ? 'último dia' : restam + (restam === 1 ? ' dia útil' : ' dias úteis')})</span>` : a.status === 'cancelada' ? 'Cancelada' : `Terminou em ${U.dataBR(fim)}`}</dd>
            <dt>Último envio</dt><dd>${a.enviado_em ? `${U.dataHoraBR(a.enviado_em)} para ${esc((a.emails_destino || []).join(', '))}` : 'Ainda não enviado'}</dd>
            <dt>Supervisor abriu</dt><dd>${a.aberto_em ? U.dataHoraBR(a.aberto_em) : a.enviado_em ? '<span style="color:var(--warn)">Ainda não abriu o link</span>' : '—'}</dd>
          </dl>
          ${valida ? `<div class="link-box" style="margin-top:10px"><code>${esc(linkAvaliacao(a))}</code>
            <button class="btn sm" data-act="copiar-link-aval" data-a="${a.id}">${ic.copiar} Copiar</button>
            <button class="btn sm" data-act="previa-aval" data-a="${a.id}">${ic.olho} Ver como o supervisor</button>
            ${DEMO ? `<button class="btn sm ghost" data-act="simular-aval" data-a="${a.id}">Simular resposta</button>` : ''}</div>` : ''}
        </section>` : ''}
        ${bloco}
        ${retratil('envios-aval', 'Envios desta avaliação', null, '<div id="envios-aval"><p class="muted small">Carregando…</p></div>')}
      </div>
      <div class="drawer-foot"><button class="btn ghost" data-act="fechar-gaveta">Fechar</button><span class="spacer"></span>${rodape}</div>`);
    if (scroll) document.querySelector('#gaveta .drawer-body').scrollTop = scroll;
    API.enviosAvaliacao(aid).then((lista) => {
      const box = document.getElementById('envios-aval');
      if (!box || !S.gaveta || S.gaveta.id !== aid) return;
      contarRetratil('envios-aval', lista.length);
      box.innerHTML = lista.length ? lista.map((e) => `<div class="envio-item">
          <div class="row between" style="flex-wrap:nowrap;gap:8px"><b>${esc(TIPO_ENVIO[e.tipo])} ${esc(VIA_ENVIO[e.via])}</b>${chipEnvio(e)}</div>
          <div class="small muted">${U.dataHoraBR(e.created_at)} · por ${esc(e.autor || 'sistema')}${e.prazo_ate ? ' · prazo até ' + U.dataBR(U.dataLocal(e.prazo_ate)) : ''}</div>
          <div class="mails" style="margin-top:4px">${(e.para || []).map((x) => `<span class="tag">${esc(x)}</span>`).join('')}</div>
          ${e.erro ? `<div class="small" style="color:var(--crit);margin-top:4px">${esc(e.erro)}</div>` : ''}
        </div>`).join('') : '<p class="muted small">Nenhum envio registrado.</p>';
    }).catch((e) => { const box = document.getElementById('envios-aval'); if (box) box.innerHTML = `<p class="small" style="color:var(--crit)">${esc(e.message)}</p>`; });
  }
  async function aplicarPadraoUma(aid) {
    const a = S.aval.find((x) => x.id === aid);
    const p = padraoAval();
    if (!p) { U.toast('Defina a resposta padrão em Configurações > Avaliação de satisfação', 'erro'); return; }
    const aviso = avalPendente(a) ? ' O link do supervisor deixa de valer.' : '';
    if (!(await U.confirmar('Aplicar a resposta padrão?', `${F(a.fornecedor_id).nome}: notas padrão (média ${U.nota(U.mediaNotas(p))}) com a observação "Resposta aprovada pelo supervisor ${a.supervisor_nome}". Confirme que ${a.supervisor_nome} aprovou o uso da resposta padrão.${aviso}`, 'Aplicar resposta padrão'))) return;
    try { await API.aplicarRespostaPadrao(aid); await recarregar(); renderView(); if (S.gaveta && S.gaveta.id === aid) abrirAvaliacao(aid); U.toast('Resposta padrão aplicada'); }
    catch (e) { U.toast(e.message, 'erro'); }
  }
  function simularAvaliacao(aid, previa) {
    const a = S.aval.find((x) => x.id === aid);
    if (!a) return;
    fecharGaveta();
    const ov = document.createElement('div');
    ov.className = 'portal-overlay';
    ov.innerHTML = `<div class="sim-bar"><span>${previa ? '<b>Prévia da avaliação</b> · o que o supervisor vê; nada é gravado e o link não é marcado como aberto'
      : '<b>Simulação do supervisor</b> · demonstração: a resposta é registrada como se o supervisor tivesse respondido'}</span><button class="btn sm" data-sim="fechar">${ic.x} Fechar</button></div><div id="sim-aval"></div>`;
    document.body.appendChild(ov);
    document.body.style.overflow = 'hidden';
    const fechar = async () => { ov.remove(); document.body.style.overflow = ''; if (!previa) { await recarregar(); render(); } };
    ov.querySelector('[data-sim="fechar"]').addEventListener('click', fechar);
    Avaliacao.montar(ov.querySelector('#sim-aval'), previa ? null : a.token, { api: API, simulacao: !previa, previaId: previa ? a.id : null, aoFechar: fechar });
  }

  // =====================================================================
  //  FORNECEDORES
  // =====================================================================
  VIEWS.forn = () => {
    const q = S.f.forn.trim().toLowerCase();
    const todos = S.base.fornecedores.filter((f) => fornecedorMeu(f.id));
    const emPasta = (f) => S.base.contratos.some((c) => c.fornecedor_id === f.id && c.situacao === 'ativo' && c.pasta_id);
    const filtros = { todos: () => true, lista: (f) => f.ativo && emPasta(f), fora: (f) => f.ativo && !emPasta(f), inativos: (f) => !f.ativo };
    const lista = todos.filter(filtros[S.f.fornFiltro]).filter((f) => !q || [f.nome, f.codigo, f.cnpj, ...(f.contatos || []).map((c) => c.email + ' ' + (c.nome || ''))].join(' ').toLowerCase().includes(q));
    const seg = [['lista', 'Em pastas'], ['fora', 'Sem pasta'], ['todos', 'Todos'], ['inativos', 'Inativos']];
    return `
      <div class="row between">
        <div class="row"><div class="search">${ic.busca}<input type="search" id="busca-forn" placeholder="Buscar nome, código, CNPJ, e-mail" value="${esc(S.f.forn)}" aria-label="Buscar fornecedor"></div>
          <div class="seg" role="group" aria-label="Filtrar fornecedores">${seg.map(([k, t]) => `<button type="button" data-act="filtro-forn" data-v="${k}" aria-pressed="${S.f.fornFiltro === k}">${t}<span class="c">${todos.filter(filtros[k]).length}</span></button>`).join('')}</div></div>
        <button class="btn primary" data-act="novo-forn">${ic.mais} Novo fornecedor</button>
      </div>
      <section class="panel"><div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fornecedor</th><th>CNPJ</th><th>E-mails</th><th>Contratos ativos</th><th>Pastas</th></tr></thead>
        <tbody>${lista.map((f) => {
          const n = S.base.contratos.filter((c) => c.fornecedor_id === f.id && c.situacao === 'ativo').length;
          return `<tr class="click" data-act="abrir-forn" data-f="${f.id}">
            <td><div class="cell-title">${esc(f.nome)}${f.docs_klingele ? ' <span class="chip info plain" title="A Klingele envia documentos para a medição">Docs da Klingele</span>' : ''}</div><div class="cell-sub clamp-m">Cód. <span class="mono">${esc(f.codigo || '—')}</span>${f.tipo_contrato ? ' · ' + esc(f.tipo_contrato) : ''}${f.observacoes ? ' · ' + esc(f.observacoes) : ''}</div></td>
            <td class="num small">${esc(f.cnpj || '—')}</td>
            <td><div class="mails">${(f.contatos || []).map((c) => `<span class="tag">${esc(c.email)}</span>`).join('') || chip('warn', 'Sem e-mail')}</div></td>
            <td class="num">${n}</td>
            <td><div class="row" style="gap:4px">${[...new Set(S.base.contratos.filter((c) => c.fornecedor_id === f.id && c.situacao === 'ativo').map((c) => c.pasta_id || ''))].map((pid) => pastaChip(pid || null)).join('') || '<span class="muted">—</span>'}</div></td>
          </tr>`;
        }).join('') || '<tr><td colspan="5"><div class="empty"><h3>Nenhum fornecedor encontrado</h3><p>Ajuste a busca ou o filtro.</p></div></td></tr>'}</tbody>
      </table></div></section>`;
  };

  async function abrirFornecedor(id) {
    const f = id ? F(id) : { nome: '', codigo: null, cnpj: '', telefone: '', tipo_contrato: null, deseja_enviar: false, observacoes: '', ativo: true, contatos: [] };
    S.gaveta = { tipo: 'forn', id: id || null, contatos: (f.contatos || []).map((c) => ({ ...c })), hist: null };
    desenharFornecedor();
    if (id) {
      try {
        const [meds, hist, avals] = await Promise.all([API.medicoesFornecedor(id), API.historico({ fornecedor_id: id, limite: 40 }), API.avaliacoesFornecedor(id).catch(() => [])]);
        if (S.gaveta && S.gaveta.tipo === 'forn' && S.gaveta.id === id) { syncContatosForn(); S.gaveta.meds = meds; S.gaveta.hist = hist; S.gaveta.avals = avals; desenharFornecedor(true); }
      } catch (e) { U.toast(e.message, 'erro'); }
    }
  }
  function lerFormForn() {
    const g = (k) => document.getElementById('ff-' + k);
    if (!g('nome')) return null;
    return {
      nome: g('nome').value.trim(), codigo: g('codigo').value ? Number(g('codigo').value) : null, cnpj: U.cnpj(g('cnpj').value.trim()) || null,
      telefone: g('telefone').value.trim() || null, tipo_contrato: g('tipo').value || null, observacoes: g('obs').value.trim() || null,
      deseja_enviar: g('envio').checked, ativo: g('ativo').checked,
      docs_klingele: g('docs').checked, docs_colaborador_id: g('docs').checked ? (g('docs-colab').value || null) : ((F(S.gaveta && S.gaveta.id) || {}).docs_colaborador_id || null)
    };
  }
  function desenharFornecedor(manter) {
    const gv = S.gaveta;
    const base = gv.id ? F(gv.id) : {};
    const f = manter && document.getElementById('ff-nome') ? { ...base, ...lerFormForn() } : (gv.id ? base : { ativo: true });
    const scroll = manter && document.querySelector('#gaveta .drawer-body') ? document.querySelector('#gaveta .drawer-body').scrollTop : 0;
    const contratos = gv.id ? S.base.contratos.filter((c) => c.fornecedor_id === gv.id) : [];
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">${gv.id ? 'Fornecedor' : 'Novo fornecedor'}</span><h2>${esc(f.nome || 'Cadastro de fornecedor')}</h2></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <div class="form-grid">
          <label class="field full"><span>Nome</span><input type="text" id="ff-nome" value="${esc(f.nome || '')}" required></label>
          <label class="field"><span>Código Klingele</span><input type="number" id="ff-codigo" value="${esc(f.codigo ?? '')}"></label>
          <label class="field"><span>CNPJ</span><input type="text" id="ff-cnpj" value="${esc(f.cnpj || '')}" placeholder="00.000.000/0000-00"></label>
          <label class="field"><span>Telefone</span><input type="tel" id="ff-telefone" value="${esc(f.telefone || '')}"></label>
          <label class="field"><span>Tipo de contrato</span><select id="ff-tipo"><option value="">—</option>${['FIXO', 'NÃO FIXO'].map((t) => `<option ${f.tipo_contrato === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
          <label class="field full"><span>Observações</span><textarea id="ff-obs" rows="2" style="min-height:64px">${esc(f.observacoes || '')}</textarea></label>
          <label class="check"><input type="checkbox" id="ff-envio" ${f.deseja_enviar ? 'checked' : ''}> Envia boletim de medição todo mês <span class="hint">(contratos novos dele entram no Envio mensal)</span></label>
          <label class="check"><input type="checkbox" id="ff-ativo" ${f.ativo !== false ? 'checked' : ''}> Fornecedor ativo</label>
          <div class="field full docs-klg-box">
            <label class="check"><input type="checkbox" id="ff-docs" data-chg="ff-docs" ${f.docs_klingele ? 'checked' : ''}> A Klingele envia documentos para a medição
              <span class="hint">(no último dia útil do mês o colaborador recebe o pedido; o fornecedor baixa os documentos no link do boletim)</span></label>
            <div class="docs-klg-sel" ${f.docs_klingele ? '' : 'hidden'}>
              <label class="field"><span>Quem envia os documentos</span><select id="ff-docs-colab">
                <option value="">${esc('Você (' + ((S.base.colaboradores || []).find((c) => (c.email || '').toLowerCase() === EU()) || { nome: 'quem marcou' }).nome + ')')}</option>
                ${(S.base.colaboradores || []).filter((c) => (c.ativo && c.email) || c.id === f.docs_colaborador_id).sort((a, b) => a.nome.localeCompare(b.nome)).map((c) => `<option value="${c.id}" ${f.docs_colaborador_id === c.id ? 'selected' : ''}>${esc(c.nome)}${c.cargo ? ' · ' + esc(c.cargo) : ''}</option>`).join('')}
              </select></label>
              <span class="hint">O colaborador recebe um link sem login: anexa os documentos (o link do boletim vai ao fornecedor) ou informa que não houve medição ou não há contrato no mês. ${f.docs_analista ? 'Quem marcou: ' + esc(f.docs_analista) + ' (é avisado das respostas).' : 'Você é avisado das respostas.'}</span>
            </div>
          </div>
        </div>
        <section>
          <div class="section-title"><h3>Contatos de e-mail</h3><button class="btn sm" data-act="ff-add-contato">${ic.mais} Adicionar</button></div>
          <div class="stack" style="gap:8px" id="ff-contatos">${gv.contatos.map((c, i) => `
            <div class="contact-row ${c.remover ? 'removed' : ''}">
              <input type="text" placeholder="Nome" data-fc="${i}" data-k="nome" value="${esc(c.nome || '')}" aria-label="Nome">
              <input type="email" class="c-mail" placeholder="email@empresa.com.br" data-fc="${i}" data-k="email" value="${esc(c.email || '')}" aria-label="E-mail">
              <input type="tel" placeholder="Telefone" data-fc="${i}" data-k="telefone" value="${esc(c.telefone || '')}" aria-label="Telefone">
              <label class="check small"><input type="checkbox" data-fc="${i}" data-k="recebe_boletim" ${c.recebe_boletim !== false ? 'checked' : ''}> Recebe</label>
              <button class="icon-btn" data-act="ff-rm-contato" data-i="${i}" aria-label="${c.remover ? 'Manter' : 'Remover'} contato">${c.remover ? ic.refazer : ic.lixo}</button>
            </div>${c.origem === 'fornecedor' ? `<span class="small" style="margin-top:-4px">${chip('accent', 'Atualizado pelo fornecedor em ' + U.dataBR(U.dataLocal(c.updated_at)))}</span>` : ''}`).join('') || '<p class="muted">Nenhum contato.</p>'}</div>
        </section>
        ${gv.id ? `<section><div class="section-title"><h3>Contratos (${contratos.length})</h3></div>
          ${contratos.map((c) => { const v = vigencia(c); return `<div class="row between" style="padding:8px 0;border-bottom:1px solid var(--line);flex-wrap:nowrap">
            <div style="min-width:0"><div class="cell-title">${esc(c.titulo)}</div><div class="cell-sub">Pedido <span class="mono">${esc(c.pedido)}</span> · ${U.brl(c.valor_mensal)}/mês${c.tipo_servico ? ' · ' + esc(U.tipoServicoTxt(c.tipo_servico)) : ''}${c.gestor ? ' · supervisor ' + esc(c.gestor) : ''}</div></div>${chip(v.cls, v.txt)}</div>`; }).join('') || '<p class="muted">Sem contratos.</p>'}</section>
          ${retratil('forn-aval', 'Avaliações de satisfação', gv.avals ? gv.avals.length : null, `
          ${gv.avals ? (gv.avals.length ? `<div class="table-wrap"><table class="tbl"><thead><tr><th>Competência</th><th>Supervisor</th><th class="r">Nota geral</th><th>Observação</th></tr></thead><tbody>
            ${gv.avals.slice(0, 12).map((a) => `<tr><td>${U.compLabel(a.competencia)}</td><td class="small">${esc(a.supervisor_nome)}</td>
              <td class="r"><span class="nota-badge sm ${U.classeNota(a.nota_geral)}">${U.nota(a.nota_geral)}</span></td>
              <td class="small">${a.status === 'padrao' ? chip('accent', 'Resposta padrão') + ' ' : ''}${esc(a.observacao || '')}</td></tr>`).join('')}
            </tbody></table></div>` : '<p class="muted">Nenhuma avaliação respondida.</p>') : '<p class="muted">Carregando…</p>'}`)}
          ${retratil('forn-comp', 'Últimas competências', gv.meds ? gv.meds.length : null, `
          ${gv.meds ? (gv.meds.length ? `<div class="table-wrap"><table class="tbl"><thead><tr><th>Competência</th><th>Pedido</th><th class="r">Contratado</th><th class="r">Medido</th><th>Situação</th></tr></thead><tbody>
            ${gv.meds.slice(0, 18).map((m) => `<tr><td>${U.compLabel(m.competencia)}</td><td class="mono">${esc(C(m.contrato_id).pedido)}</td><td class="r num">${U.brl(m.valor_contratado)}</td><td class="r num">${U.brl(medido(m))}</td><td>${chipMed(m)}</td></tr>`).join('')}
            </tbody></table></div>` : '<p class="muted">Nenhuma medição registrada.</p>') : '<p class="muted">Carregando…</p>'}`)}
          ${S.papel === 'leitura' ? '' : retratil('forn-hist', 'Histórico', gv.hist ? gv.hist.length : null,
            gv.hist ? (gv.hist.length ? `<div class="timeline">${gv.hist.slice(0, 15).map(itemHist).join('')}</div>${gv.hist.length > 15 ? '<p class="small muted" style="margin-top:8px">Registros completos na página Histórico.</p>' : ''}` : '<p class="muted">Nenhum registro.</p>') : '<p class="muted">Carregando…</p>')}` : ''}
      </div>
      <div class="drawer-foot">
        ${gv.id ? `<button class="btn danger" data-act="excluir-forn">${ic.lixo} Excluir</button>` : ''}<span class="spacer"></span>
        <button class="btn" data-act="fechar-gaveta">Cancelar</button>
        <button class="btn primary" data-act="salvar-forn">${ic.ok} Salvar</button>
      </div>`);
    if (scroll) document.querySelector('#gaveta .drawer-body').scrollTop = scroll;
  }
  async function salvarFornecedor() {
    syncContatosForn();
    const gv = S.gaveta, dados = lerFormForn();
    if (!dados.nome || dados.nome.length < 2 || dados.nome.length > 200) { U.toast('Informe o nome do fornecedor (2 a 200 caracteres)', 'erro'); return; }
    if (dados.cnpj && !U.cnpjValido(dados.cnpj)) { U.toast('CNPJ inválido: confira os dígitos', 'erro'); return; }
    if (dados.codigo !== null && !(Number.isInteger(dados.codigo) && dados.codigo > 0)) { U.toast('Código deve ser um número inteiro positivo', 'erro'); return; }
    if (!U.telefoneValido(dados.telefone)) { U.toast('Telefone inválido: utilize apenas números, espaço, parênteses, + e -', 'erro'); return; }
    if (dados.observacoes && dados.observacoes.length > 2000) { U.toast('Observações com mais de 2.000 caracteres', 'erro'); return; }
    const ativosC = gv.contatos.filter((c) => !c.remover);
    const ruins = ativosC.filter((c) => !U.emailValido(c.email));
    if (ruins.length) { U.toast(`E-mail inválido: ${ruins[0].email || '(vazio)'}`, 'erro'); return; }
    if (ativosC.some((c) => !U.telefoneValido((c.telefone || '').trim()))) { U.toast('Telefone de contato inválido', 'erro'); return; }
    const mailsC = ativosC.map((c) => c.email.trim().toLowerCase());
    if (new Set(mailsC).size !== mailsC.length) { U.toast('Há e-mails repetidos nos contatos', 'erro'); return; }
    try {
      const f = await API.salvarFornecedor({ ...(gv.id ? { id: gv.id } : {}), ...dados });
      const orig = gv.id ? (F(gv.id).contatos || []) : [];
      for (const c of gv.contatos) {
        if (c.remover) { if (c.id) await API.excluirContato(c.id); continue; }
        const o = orig.find((x) => x.id === c.id);
        const dadosC = { fornecedor_id: f.id, nome: (c.nome || '').trim() || null, email: c.email.trim().toLowerCase(), telefone: (c.telefone || '').trim() || null, recebe_boletim: c.recebe_boletim !== false };
        if (!c.id) await API.salvarContato({ ...dadosC, origem: 'equipe' });
        else if (!o || o.nome !== dadosC.nome || o.email !== dadosC.email || (o.telefone || null) !== dadosC.telefone || o.recebe_boletim !== dadosC.recebe_boletim) await API.salvarContato({ id: c.id, ...dadosC });
      }
      await recarregar(true);
      fecharGaveta();
      U.toast('Fornecedor salvo');
      renderView();
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  // =====================================================================
  //  CONTRATOS
  // =====================================================================
  VIEWS.contr = () => {
    const q = S.f.contr.trim().toLowerCase();
    const todos = S.base.contratos.filter(contratoMeu);
    const filtros = {
      ativos: (c) => c.situacao === 'ativo',
      vencendo: (c) => { const v = vigencia(c); return v.dias !== undefined && v.dias >= 0 && v.dias <= 90; },
      vencidos: (c) => { const v = vigencia(c); return v.dias !== undefined && v.dias < 0; },
      avisar: (c) => { const a = alertaDe(c); return !!a && a.janela; },
      todos: () => true
    };
    const resps = [...new Set(todos.flatMap((c) => [...supsDe(c), ...ctsDe(c)]))].map(COL).filter(Boolean).sort((a, b) => a.nome.localeCompare(b.nome));
    const respOk = (c) => !S.f.gestor || (S.f.gestor === 'sem-sup' ? !supsDe(c).length : S.f.gestor === 'sem-ct' ? !ctsDe(c).length
      : supsDe(c).includes(S.f.gestor) || ctsDe(c).includes(S.f.gestor));
    const tipoOk = (c) => !S.f.tipoServ || (S.f.tipoServ === 'sem' ? !c.tipo_servico
      : S.f.tipoServ === 'Fixo' || S.f.tipoServ === 'Não fixo' ? (U.TIPOS_SERVICO[c.tipo_servico] || [])[0] === S.f.tipoServ : c.tipo_servico === S.f.tipoServ);
    const pastaOk = (c) => !S.f.contrPasta || (S.f.contrPasta === 'avulsos' ? !c.pasta_id : c.pasta_id === S.f.contrPasta);
    const lista = todos.filter(filtros[S.f.contrFiltro]).filter(respOk).filter(tipoOk).filter(pastaOk)
      .filter((c) => !q || [F(c.fornecedor_id).nome, c.pedido, c.titulo, c.gestor, ...nomesCol(supsDe(c)), ...nomesCol(ctsDe(c)), U.tipoServicoTxt(c.tipo_servico)].join(' ').toLowerCase().includes(q))
      .sort((a, b) => F(a.fornecedor_id).nome.localeCompare(F(b.fornecedor_id).nome) || a.pedido - b.pedido);
    const seg = [['ativos', 'Ativos'], ['avisar', 'No prazo de aviso'], ['vencendo', 'Vencem em 90 dias'], ['vencidos', 'Vencidos'], ['todos', 'Todos']];
    const semTipo = todos.filter((c) => c.situacao === 'ativo' && !c.tipo_servico).length;
    const opTipo = [['', 'Todos os tipos'], ['Fixo', 'Fixo (todos)'], ['locacao', 'Fixo · Locação'], ['suporte_tecnico', 'Fixo · Suporte técnico'],
      ['Não fixo', 'Não fixo (todos)'], ['servico_especifico', 'Não fixo · Serviço específico'], ['servico_unico', 'Não fixo · Serviço único'], ['sem', 'Sem tipo definido']];
    return `
      <div class="row between">
        <div class="row"><div class="search">${ic.busca}<input type="search" id="busca-contr" placeholder="Buscar fornecedor, pedido ou serviço" value="${esc(S.f.contr)}" aria-label="Buscar contrato"></div>
          <div class="seg" role="group" aria-label="Filtrar contratos">${seg.map(([k, t]) => `<button type="button" data-act="filtro-contr" data-v="${k}" aria-pressed="${S.f.contrFiltro === k}">${t}<span class="c">${todos.filter(filtros[k]).length}</span></button>`).join('')}</div>
          <select id="f-tipo-serv" aria-label="Tipo de serviço" style="width:auto">${opTipo.map(([k, t]) => `<option value="${esc(k)}" ${S.f.tipoServ === k ? 'selected' : ''}>${esc(t)}</option>`).join('')}</select>
          <select id="f-gestor" aria-label="Responsável Klingele" style="width:auto"><option value="">Todos os responsáveis</option>
            <option value="sem-sup" ${S.f.gestor === 'sem-sup' ? 'selected' : ''}>Sem supervisor</option><option value="sem-ct" ${S.f.gestor === 'sem-ct' ? 'selected' : ''}>Sem contato do serviço</option>
            ${resps.map((x) => `<option value="${x.id}" ${S.f.gestor === x.id ? 'selected' : ''}>${esc(x.nome)}</option>`).join('')}</select>
          <select id="f-contr-pasta" aria-label="Pasta" style="width:auto"><option value="">Todas as pastas</option>${S.base.pastas.filter(nivelPasta).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome)).map((p) => `<option value="${p.id}" ${S.f.contrPasta === p.id ? 'selected' : ''}>${esc(p.nome)}</option>`).join('')}
            <option value="avulsos" ${S.f.contrPasta === 'avulsos' ? 'selected' : ''}>Avulsos (sem pasta)</option></select></div>
        <button class="btn primary" data-act="novo-contr">${ic.mais} Novo contrato</button>
      </div>
      ${semTipo ? `<div class="demo-banner"><span>${semTipo} contrato${semTipo > 1 ? 's' : ''} ativo${semTipo > 1 ? 's' : ''} sem tipo de serviço (Fixo ou Não fixo).</span>
        <span class="spacer"></span><button class="btn sm" data-act="filtro-tipo-sem">Exibir contratos sem tipo</button></div>` : ''}
      <section class="panel"><div class="table-wrap"><table class="tbl">
        <thead><tr><th>Fornecedor / serviço</th><th>Pedido</th><th>Tipo</th><th>Responsáveis</th><th>Início</th><th>Fim</th><th>Vigência</th><th>Parcelas</th><th class="r">Mensal</th><th class="r">Total</th></tr></thead>
        <tbody>${lista.map((c) => { const v = vigencia(c); const t = U.TIPOS_SERVICO[c.tipo_servico]; return `<tr class="click" data-act="abrir-contr" data-c="${c.id}">
          <td><div class="cell-title">${esc(F(c.fornecedor_id).nome)}</div><div class="cell-sub clamp-m">${esc(c.titulo)}</div>${c.situacao === 'ativo' ? `<div class="m-menos" style="margin-top:3px">${pastaChip(c.pasta_id)}</div>` : ''}</td>
          <td class="mono">${esc(c.pedido)}</td>
          <td class="small m-menos">${t ? `<b>${esc(t[0])}</b><div class="cell-sub">${esc(t[1])}</div>` : '<span class="muted">—</span>'}</td>
          <td class="small m-menos">${respCelula(c)}</td>
          <td class="num small m-menos">${U.dataBR(c.data_inicio)}</td><td class="num small">${U.dataBR(c.data_fim)}</td>
          <td>${chip(v.cls, v.txt)}${avisoHTML(c) ? `<div class="m-menos" style="margin-top:3px">${avisoHTML(c)}</div>` : ''}</td><td class="small">${parcelasCelula(c)}</td><td class="r num">${U.brl(c.valor_mensal)}</td><td class="r num m-menos">${U.brl(c.valor_total)}</td></tr>`; }).join('')
          || '<tr><td colspan="10"><div class="empty"><h3>Nenhum contrato encontrado</h3><p>Ajuste a busca ou o filtro.</p></div></td></tr>'}</tbody>
        <tfoot><tr><td colspan="8">${lista.length} contrato${lista.length !== 1 ? 's' : ''}</td><td class="r num">${U.brl(soma(lista.map((c) => c.valor_mensal)))}</td><td class="r num">${U.brl(soma(lista.map((c) => c.valor_total)))}</td></tr></tfoot>
      </table></div></section>`;
  };

  function respCelula(c) {
    const sups = nomesCol(supsDe(c)), cts = nomesCol(ctsDe(c));
    const semEmail = supsDe(c).some((x) => !(COL(x) || {}).email);
    return `<div>${sups.length ? `<b>${esc(sups[0])}</b>${sups.length > 1 ? ` <span class="muted">+${sups.length - 1}</span>` : ''}` : esc(c.gestor || '—')}</div>
      <div class="cell-sub">Contato: ${cts.length ? esc(cts.join(', ')) : 'gerais'}</div>${semEmail ? '<div class="cell-sub" style="color:var(--warn)">supervisor sem e-mail</div>' : ''}`;
  }
  function parcelasCelula(c) {
    const p = PARC(c.id);
    if (!c.parcelas_total) return '<span class="muted">—</span>';
    const pagas = p ? p.pagas : Number(c.parcelas_pagas_antes || 0), falta = p ? p.a_pagar : Math.max(c.parcelas_total - pagas, 0);
    return `<b>${pagas}/${esc(c.parcelas_total)}</b> pagas<div class="cell-sub">${falta ? `faltam ${falta}` : 'todas pagas'}${p && p.lancadas ? ` · ${p.lancadas} lançada${p.lancadas > 1 ? 's' : ''}` : ''}</div>`;
  }
  // Estimativa: meses do início do contrato até a competência anterior, menos as parcelas já pagas no sistema
  function estimarPagasAntes() {
    const ini = document.getElementById('fc-inicio').value, total = Number(document.getElementById('fc-parcelas').value) || null;
    if (!ini) { U.toast('Informe a data de início do contrato', 'erro'); return; }
    const ate = U.compAnterior();
    const meses = (Number(ate.slice(0, 4)) - Number(ini.slice(0, 4))) * 12 + Number(ate.slice(5, 7)) - Number(ini.slice(5, 7));
    const p = S.gaveta && S.gaveta.id ? PARC(S.gaveta.id) : null;
    let v = Math.max(0, meses - (p ? p.pagas_sistema : 0));
    if (total) v = Math.min(v, total);
    if (p && p.ultima_parcela) v = Math.min(v, p.ultima_parcela - 1);
    document.getElementById('fc-pagas-antes').value = v;
    U.toast(`${v} parcela${v !== 1 ? 's' : ''}: meses de ${U.dataBR(ini)} até antes de ${U.compLabel(ate)}${p && p.pagas_sistema ? `, menos ${p.pagas_sistema} paga${p.pagas_sistema > 1 ? 's' : ''} no sistema` : ''}. Confira e salve.`);
  }

  // Pasta do contrato: só as pastas que a pessoa edita (Envio mensal: quem edita contratos); contrato novo pode seguir a regra
  function pastaSelectContrato(c, id) {
    const atual = c.pasta_id || null, travado = !!atual && !podePorNaPasta(atual);
    const ps = S.base.pastas.filter((p) => nivelPasta(p)).sort((a, b) => (b.padrao - a.padrao) || a.nome.localeCompare(b.nome));
    if (travado) return `<input type="text" value="${esc((PASTA(atual) || {}).nome || 'Pasta que você não vê')}" disabled><input type="hidden" id="fc-pasta" value="__manter"><span class="hint">Só quem edita esta pasta muda o contrato de pasta.</span>`;
    return `<select id="fc-pasta">${id ? '' : '<option value="__regra">Automático: regra das pastas (contínuo vai ao Envio mensal; spot fica avulso)</option>'}
      ${ps.map((p) => `<option value="${p.id}" ${atual === p.id ? 'selected' : ''} ${podePorNaPasta(p.id) ? '' : 'disabled'}>${esc(p.nome)}${p.padrao ? ' (padrão)' : ''} · ${esc(U.calendarioTxt(p))}</option>`).join('')}
      <option value="" ${id && !atual ? 'selected' : ''}>Avulso (sem pasta: link só pelo botão)</option></select>`;
  }
  function abrirContrato(id) {
    const c = id ? C(id) : { situacao: 'ativo' };
    S.gaveta = { tipo: 'contr', id: id || null, sups: supsDe(c).slice(), cts: ctsDe(c).slice(), gestor: c.gestor || '' };
    const fs = S.base.fornecedores.slice().sort((a, b) => a.nome.localeCompare(b.nome));
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">${id ? 'Contrato · pedido ' + esc(c.pedido) : 'Novo contrato'}</span><h2>${esc(id ? F(c.fornecedor_id).nome : 'Cadastro de contrato')}</h2></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body"><div class="form-grid">
        <label class="field full"><span>Fornecedor</span><select id="fc-forn"><option value="">Escolha…</option>${fs.map((f) => `<option value="${f.id}" ${c.fornecedor_id === f.id ? 'selected' : ''}>${esc(f.nome)}</option>`).join('')}</select></label>
        <label class="field"><span>Pedido</span><input type="number" id="fc-pedido" value="${esc(c.pedido ?? '')}"></label>
        <label class="field"><span>Tipo de serviço</span><select id="fc-tipo-serv">${U.opcoesTipoServico(c.tipo_servico, 'Escolha…')}</select></label>
        <label class="field full"><span>Serviço</span><input type="text" id="fc-titulo" value="${esc(c.titulo || '')}"></label>
        <label class="field full"><span>Pasta <span class="hint">(quando o link deste contrato sai)</span></span>${pastaSelectContrato(c, id)}</label>
        <div class="full section-title" style="margin-top:6px"><h3>Responsáveis Klingele</h3></div>
        <div class="field full" id="fc-resp">${respHTML()}</div>
        <label class="field"><span>Início</span><input type="date" id="fc-inicio" value="${esc(c.data_inicio || '')}"></label>
        <label class="field"><span>Meses de vigência</span><input type="number" id="fc-meses" min="1" value="${esc(c.meses_vigencia ?? '')}"></label>
        <label class="field"><span>Data final</span><input type="date" id="fc-fim" value="${esc(c.data_fim || '')}"></label>
        <label class="field"><span>Situação</span><select id="fc-sit">${[['ativo', 'Ativo'], ['finalizado', 'Finalizado'], ['nao_iniciado', 'Não iniciado'], ['suspenso', 'Suspenso']].map(([k, t]) => `<option value="${k}" ${c.situacao === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="field"><span>Valor mensal (R$)</span><input type="text" inputmode="decimal" id="fc-mensal" value="${esc(U.numBR(c.valor_mensal))}"></label>
        <label class="field"><span>Valor total (R$)</span><input type="text" inputmode="decimal" id="fc-total" value="${esc(U.numBR(c.valor_total))}">
          <span class="hint" id="fc-sug"></span></label>
        <div class="full section-title" style="margin-top:6px"><h3>Aviso de vencimento</h3></div>
        <label class="field"><span>Avisar com antecedência (dias)</span><input type="number" id="fc-alerta" min="1" max="365" value="${esc(c.alerta_dias ?? '')}" placeholder="Automático: ${id ? U.alertaDias({ ...c, alerta_dias: null }, S.base.config) : cfgv('alerta_venc_longo_dias', '42')} dias">
          <span class="hint">Vazio: acima de ${esc(cfgv('alerta_venc_limite_curto', '42'))} dias de contrato avisa ${esc(cfgv('alerta_venc_longo_dias', '42'))} dias antes; curtos, ${esc(cfgv('alerta_venc_curto_dias', '14'))}.</span></label>
        <div class="field"><span>Situação do aviso</span>${(() => {
          const a = id ? alertaDe(c) : null;
          if (!a) return '<span class="small muted">Contrato ativo com data final recebe o aviso.</span>';
          const para = [...supsDe(c).map((x) => (COL(x) || {}).email), ...String(cfgv('alerta_venc_emails', '')).split(',').map((x) => x.trim())].filter(Boolean);
          return `<span class="small">${a.vencido ? 'Contrato já venceu.' : a.avisado ? `Aviso enviado em ${U.dataHoraBR(a.avisado.created_at)} para ${esc((a.avisado.para || []).join(', '))}` : a.janela ? '<b style="color:var(--warn)">No prazo de aviso: ainda não avisado.</b>' : `Aviso automático em ${U.dataBR(a.data)} (${a.dias} dias antes).`}</span>
            <span class="hint">Para: ${para.length ? esc([...new Set(para)].join(', ')) : '<span style="color:var(--warn)">sem destinatário (e-mail do supervisor ou lista em Configurações)</span>'}</span>
            ${!a.vencido ? `<div class="row" style="margin-top:4px"><button class="btn sm" type="button" data-act="venc-avisar" data-c="${c.id}">${ic.sino} ${a.avisado ? 'Avisar de novo' : 'Avisar agora'}</button></div>` : ''}`;
        })()}</div>
        <div class="full section-title" style="margin-top:6px"><h3>Parcelas</h3></div>
        <label class="field"><span>Total de parcelas</span><input type="number" id="fc-parcelas" min="1" max="600" value="${esc(c.parcelas_total ?? (id ? '' : ''))}" placeholder="Ex.: 12">
          <span class="hint">Normalmente igual aos meses de vigência.</span></label>
        <label class="field"><span>Parcelas pagas antes do sistema</span>
          <div class="row" style="flex-wrap:nowrap"><input type="number" id="fc-pagas-antes" min="0" max="600" value="${esc(c.parcelas_pagas_antes ?? 0)}"><button class="btn sm" type="button" data-act="estimar-pagas">Calcular</button></div>
          <span class="hint">Parcelas quitadas antes do uso do sistema. As pagas no sistema são somadas automaticamente.</span></label>
        ${id && PARC(id) && c.parcelas_total ? `<div class="full parcelas">${barraParcelas(PARC(id))}<div class="row small" style="gap:14px"><span><b>${PARC(id).pagas}</b> pagas (${PARC(id).parcelas_pagas_antes} antes do sistema + ${PARC(id).pagas_sistema} no sistema)</span>
          <span><b>${PARC(id).lancadas}</b> lançada${PARC(id).lancadas !== 1 ? 's' : ''} sem pagamento</span><span><b>${PARC(id).a_pagar}</b> a pagar</span>${PARC(id).proxima_parcela ? `<span>próxima: <b>${PARC(id).proxima_parcela}</b></span>` : ''}</div></div>` : ''}
      </div></div>
      <div class="drawer-foot">
        ${id && S.papel !== 'leitura' ? `<button class="btn danger" data-act="excluir-contr">${ic.lixo} Excluir</button>` : ''}<span class="spacer"></span>
        <button class="btn" data-act="fechar-gaveta">Cancelar</button>
        <button class="btn primary" data-act="salvar-contr">${ic.ok} Salvar</button>
      </div>`);
    sugerirTotal();
  }
  // Supervisores (avaliação e aviso de vencimento) e contatos do serviço (suporte ao fornecedor) do contrato
  function respHTML() {
    const g = S.gaveta, sups = g.sups, cts = g.cts;
    const item = (id, papel, i) => {
      const x = COL(id) || { nome: '(removido)' }, principal = papel === 'sup' && i === 0;
      return `<span class="resp-chip${principal ? ' principal' : ''}"><span class="resp-n"><b>${esc(x.nome)}</b><small>${principal ? 'Principal' : esc(x.cargo || '')}${x.email ? '' : `${principal || x.cargo ? ' · ' : ''}<span class="aviso">sem e-mail</span>`}</small></span>
        ${papel === 'sup' && i > 0 ? `<button type="button" class="icon-btn sm" data-act="resp-principal" data-id="${id}" title="Tornar principal" aria-label="Tornar ${esc(x.nome)} o supervisor principal">${ic.estrela}</button>` : ''}
        <button type="button" class="icon-btn sm" data-act="resp-rm" data-papel="${papel}" data-id="${id}" title="Remover" aria-label="Remover ${esc(x.nome)}">${ic.x}</button></span>`;
    };
    const opcoes = (lista, ja) => lista.filter((x) => !ja.includes(x.id)).map((x) => `<option value="${x.id}">${esc(x.nome)}${x.cargo ? ' · ' + esc(x.cargo) : ''}${x.email ? '' : ' (sem e-mail)'}</option>`).join('');
    const ativos = (S.base.colaboradores || []).filter((x) => x.ativo).sort((a, b) => a.nome.localeCompare(b.nome));
    const gerais = contatosFornecedor().map((x) => x.nome);
    return `<div class="resp-bloco"><span class="resp-rot">Supervisores <span class="hint">recebem a avaliação de satisfação e o aviso de vencimento e renovação</span></span>
        <div class="resp-lista">${sups.map((id, i) => item(id, 'sup', i)).join('') || '<span class="small muted">Nenhum supervisor</span>'}</div>
        ${sups.length < 10 ? `<select data-chg="resp-add" data-papel="sup" aria-label="Adicionar supervisor"><option value="">+ Adicionar supervisor…</option>${opcoes(supervisores(), sups)}</select>` : ''}
        ${!sups.length && g.gestor ? `<span class="hint">Gestor da planilha: ${esc(g.gestor)}. Cadastre-o como supervisor em Contatos Klingele.</span>` : ''}</div>
      <div class="resp-bloco"><span class="resp-rot">Contatos do serviço <span class="hint">aparecem ao fornecedor como suporte, no e-mail e na página do link</span></span>
        <div class="resp-lista">${cts.map((id) => item(id, 'ct')).join('') || `<span class="small muted">Nenhum: o fornecedor vê os contatos gerais${gerais.length ? ` (${esc(gerais.join(', '))})` : ''}</span>`}</div>
        ${cts.length < 10 ? `<select data-chg="resp-add" data-papel="ct" aria-label="Adicionar contato do serviço"><option value="">+ Adicionar contato…</option>${opcoes(ativos, cts)}</select>` : ''}</div>`;
  }
  const atualizarResp = () => { const el = document.getElementById('fc-resp'); if (el) el.innerHTML = respHTML(); };
  function sugerirTotal() {
    const m = U.parseValor(document.getElementById('fc-mensal')?.value), n = Number(document.getElementById('fc-meses')?.value);
    const el = document.getElementById('fc-sug');
    if (el) el.innerHTML = m && n ? `Mensal × meses = ${U.brl(m * n)} <button class="btn sm ghost" data-act="usar-total" data-v="${m * n}">Usar</button>` : '';
  }
  async function salvarContrato() {
    const g = (k) => document.getElementById('fc-' + k).value;
    const sup = COL(S.gaveta.sups[0]);
    const orig = S.gaveta.id ? C(S.gaveta.id) : {};
    const dados = {
      fornecedor_id: g('forn'), pedido: g('pedido') ? Number(g('pedido')) : null, titulo: g('titulo').trim(),
      tipo_servico: g('tipo-serv') || null, supervisor_id: sup ? sup.id : null,
      // vários supervisores e contatos; o 1º supervisor é o principal (recebe o nome de gestor)
      supervisores: S.gaveta.sups.slice(), contatos: S.gaveta.cts.slice(),
      // sem supervisor escolhido, mantém o gestor que veio da planilha
      gestor: sup ? sup.nome : (orig.supervisor_id ? null : orig.gestor || null),
      data_inicio: g('inicio') || null, meses_vigencia: g('meses') ? Number(g('meses')) : null, data_fim: g('fim') || null, situacao: g('sit'),
      valor_mensal: U.parseValor(g('mensal')) || 0, valor_total: U.parseValor(g('total')) || 0,
      parcelas_total: g('parcelas') ? Number(g('parcelas')) : null, parcelas_pagas_antes: g('pagas-antes') ? Number(g('pagas-antes')) : 0,
      alerta_dias: g('alerta') ? Number(g('alerta')) : null
    };
    const pasta = g('pasta');
    if (pasta !== '__manter' && pasta !== '__regra') { dados.pasta_id = pasta || null; if (!S.gaveta.id || (orig.pasta_id || null) !== dados.pasta_id) dados.pasta_escolhida = true; }
    if (dados.alerta_dias !== null && !(Number.isInteger(dados.alerta_dias) && dados.alerta_dias >= 1 && dados.alerta_dias <= 365)) { U.toast('Antecedência do aviso entre 1 e 365 dias', 'erro'); return; }
    if (!dados.fornecedor_id || dados.titulo.length < 2) { U.toast('Escolha o fornecedor e descreva o serviço', 'erro'); return; }
    if (!S.gaveta.id && !dados.tipo_servico) { U.toast('Escolha o tipo de serviço (Fixo ou Não fixo)', 'erro'); return; }
    if (dados.titulo.length > 300) { U.toast('Descrição do serviço com mais de 300 caracteres', 'erro'); return; }
    if (dados.pedido !== null && !(Number.isInteger(dados.pedido) && dados.pedido > 0)) { U.toast('Número do pedido inválido', 'erro'); return; }
    if (dados.meses_vigencia !== null && !(dados.meses_vigencia >= 1 && dados.meses_vigencia <= 240)) { U.toast('Meses de vigência entre 1 e 240', 'erro'); return; }
    if (dados.data_inicio && dados.data_fim && dados.data_fim < dados.data_inicio) { U.toast('A data final é anterior ao início', 'erro'); return; }
    if (dados.valor_mensal < 0 || dados.valor_total < 0 || dados.valor_mensal > 1e9) { U.toast('Valores do contrato inválidos', 'erro'); return; }
    if (dados.parcelas_total !== null && !(Number.isInteger(dados.parcelas_total) && dados.parcelas_total >= 1 && dados.parcelas_total <= 600)) { U.toast('Total de parcelas entre 1 e 600', 'erro'); return; }
    if (!(Number.isInteger(dados.parcelas_pagas_antes) && dados.parcelas_pagas_antes >= 0 && dados.parcelas_pagas_antes <= 600)
      || (dados.parcelas_total && dados.parcelas_pagas_antes > dados.parcelas_total)) { U.toast('As parcelas pagas antes não podem passar do total', 'erro'); return; }
    try {
      await API.salvarContrato({ ...(S.gaveta.id ? { id: S.gaveta.id } : {}), ...dados });
      await recarregar(true); fecharGaveta(); U.toast('Contrato salvo'); renderView();
    } catch (e) { U.toast(/duplicate|unique/i.test(e.message) ? 'Já existe um contrato com este pedido.' : e.message, 'erro'); }
  }

  // =====================================================================
  //  USUÁRIOS (só administrador): cadastro pelo site, aprovação e perfis
  // =====================================================================
  const USU_ST = { pendente: ['Aguardando aprovação', 'warn'], aprovado: ['Aprovado', 'ok'], recusado: ['Recusado', 'crit'], bloqueado: ['Bloqueado', 'crit'] };
  const PAPEL = { admin: 'Administrador', supervisor: 'Supervisor', analista: 'Analista', leitura: 'Somente leitura' };
  const chipUsu = (u) => chip(USU_ST[u.status][1], USU_ST[u.status][0]);
  VIEWS.usuarios = () => {
    if (!podeAprovar()) return '<section class="panel"><div class="empty"><h3>Acesso restrito</h3><p>A gestão de usuários é feita por administradores e supervisores.</p></div></section>';
    const abas = `<div class="seg abas-usu" role="group" aria-label="Usuários ou equipes"><button type="button" data-act="usu-aba" data-v="usuarios" aria-pressed="${S.f.usuAba !== 'equipes'}">Usuários</button>
      <button type="button" data-act="usu-aba" data-v="equipes" aria-pressed="${S.f.usuAba === 'equipes'}">Equipes<span class="c">${S.base.equipes.length}</span></button></div>`;
    if (S.f.usuAba === 'equipes') return abas + equipesHTML();
    const q = S.f.usuBusca.trim().toLowerCase();
    const grupos = { pendentes: ['pendente'], aprovados: ['aprovado'], recusados: ['recusado', 'bloqueado'], todos: ['pendente', 'aprovado', 'recusado', 'bloqueado'] };
    const todos = S.usuarios;
    const lista = todos.filter((u) => grupos[S.f.usu].includes(u.status))
      .filter((u) => !q || [u.nome, u.usuario, u.email, u.cargo].join(' ').toLowerCase().includes(q));
    const seg = [['pendentes', 'Aguardando'], ['aprovados', 'Aprovados'], ['recusados', 'Recusados e bloqueados'], ['todos', 'Todos']];
    const nome = (id) => { const u = todos.find((x) => x.id === id); return u ? u.nome : null; };
    const pend = todos.filter((u) => u.status === 'pendente');
    return `${abas}
      <div class="tiles">
        <div class="tile ${pend.length ? 'accent' : ''}"><span class="label">Aguardando aprovação</span><span class="v">${pend.length}</span><span class="d">${pend.filter(paraMim).length} para você${S.papel === 'supervisor' ? ' · você aprova analista e somente leitura' : ''}</span></div>
        <div class="tile"><span class="label">Usuários aprovados</span><span class="v">${todos.filter((u) => u.status === 'aprovado').length}</span><span class="d">${['admin', 'supervisor', 'analista', 'leitura'].map((k) => `${todos.filter((u) => u.status === 'aprovado' && u.papel === k).length} ${PAPEL[k].toLowerCase()}`).join(' · ')}</span></div>
        <div class="tile"><span class="label">Recusados ou bloqueados</span><span class="v">${todos.filter((u) => ['recusado', 'bloqueado'].includes(u.status)).length}</span><span class="d">Sem acesso aos dados</span></div>
        <div class="tile"><span class="label">Cadastro pelo site</span><span class="v" style="font-size:1.2rem">${cfgv('cadastro_aberto', 'true') === 'true' ? 'Aberto' : 'Fechado'}</span>
          <span class="d">${cfgv('cadastro_dominios', '') ? 'Só ' + esc(cfgv('cadastro_dominios', '')) : 'Qualquer e-mail (com aprovação)'} · <a href="#conf" data-act="ir-conf-cad">Ajustar</a></span></div>
      </div>
      <div class="row between">
        <div class="row"><div class="search">${ic.busca}<input type="search" id="usu-busca" placeholder="Buscar nome, usuário, e-mail" value="${esc(S.f.usuBusca)}" aria-label="Buscar usuário"></div>
          <div class="seg" role="group" aria-label="Filtrar usuários">${seg.map(([k, t]) => `<button type="button" data-act="filtro-usu" data-v="${k}" aria-pressed="${S.f.usu === k}">${t}<span class="c">${todos.filter((u) => grupos[k].includes(u.status)).length}</span></button>`).join('')}</div></div>
        ${DEMO ? `<button class="btn" data-act="demo-login">${ic.olho} Ver telas de entrar e criar conta</button>` : ''}
      </div>
      <section class="panel"><div class="table-wrap"><table class="tbl">
        <thead><tr><th>Usuário</th><th>Situação</th><th>Perfil</th><th>Contato Klingele / supervisor</th><th>Responsável</th><th></th></tr></thead>
        <tbody>${lista.map((u) => `<tr class="click" data-act="abrir-usu" data-id="${u.id}">
          <td><div class="cell-title">${esc(u.nome)}</div><div class="cell-sub"><span class="mono">${esc(u.usuario)}</span> · ${esc(u.email)}${u.cargo ? ' · ' + esc(u.cargo) : ''}</div>
            <div class="cell-sub">Criado em ${U.dataHoraBR(u.created_at)}</div></td>
          <td>${chipUsu(u)}${u.motivo && u.status !== 'aprovado' ? `<div class="cell-sub clamp-m">${esc(u.motivo)}</div>` : ''}</td>
          <td class="small">${u.papel ? esc(PAPEL[u.papel]) : '<span class="muted">—</span>'}${u.papel === 'supervisor' && u.admin_id ? `<div class="cell-sub">ligado a ${esc(nome(u.admin_id) || '—')}</div>` : ''}</td>
          <td class="small m-menos">${u.colaborador_id ? esc((COL(u.colaborador_id) || {}).nome || '—') : '<span class="muted">—</span>'}${u.supervisor_id ? `<div class="cell-sub">acompanha ${esc((COL(u.supervisor_id) || {}).nome || '—')}</div>` : ''}</td>
          <td class="small m-menos">${esc(nome(u.aprovador_id) || (u.status === 'pendente' ? 'Qualquer perfil de administração' : '—'))}</td>
          <td class="r">${!podeEditarUsuario(u) ? `<button class="btn sm" data-act="abrir-usu" data-id="${u.id}">${ic.olho} Ver</button>`
            : u.status === 'pendente' ? `<button class="btn sm primary" data-act="abrir-usu" data-id="${u.id}">${ic.ok} Analisar</button>` : `<button class="btn sm" data-act="abrir-usu" data-id="${u.id}">${ic.lapis} Editar</button>`}</td>
        </tr>`).join('') || `<tr><td colspan="6"><div class="empty"><h3>${todos.length ? 'Ninguém neste filtro' : 'Nenhum usuário'}</h3><p>${S.f.usu === 'pendentes' ? 'Nenhum cadastro aguardando aprovação.' : 'Ajuste a busca ou o filtro.'}</p></div></td></tr>`}</tbody>
      </table></div></section>`;
  };
  // Supervisor não altera administradores nem outros supervisores, nem cadastros encaminhados a outro responsável
  function podeEditarUsuario(u) {
    if (S.papel === 'admin') return true;
    if (S.papel !== 'supervisor') return false;
    const eu = u.id === meuUsuarioId();
    if (!eu && (u.papel === 'admin' || u.papel === 'supervisor')) return false;
    return !(u.status === 'pendente' && u.aprovador_id && u.aprovador_id !== meuUsuarioId());
  }
  function abrirUsuario(id) {
    const u = S.usuarios.find((x) => x.id === id);
    if (!u) return;
    S.gaveta = { tipo: 'usu', id };
    const admin = S.papel === 'admin', edita = podeEditarUsuario(u);
    const admins = S.usuarios.filter((x) => x.status === 'aprovado' && x.papel === 'admin');
    const resps = S.usuarios.filter((x) => x.status === 'aprovado' && (x.papel === 'admin' || x.papel === 'supervisor'));
    const nomeU = (uid) => (S.usuarios.find((x) => x.id === uid) || {}).nome;
    const cols = (S.base.colaboradores || []).slice().sort((a, b) => a.nome.localeCompare(b.nome));
    const sups = supervisores();
    const opt = (lista, v, vazio) => `<option value="">${esc(vazio)}</option>` + lista.map((x) => `<option value="${x.id}" ${v === x.id ? 'selected' : ''}>${esc(x.nome)}${x.cargo ? ' · ' + esc(x.cargo) : ''}</option>`).join('');
    const optResp = `<option value="">Qualquer perfil de administração</option>
      <optgroup label="Administradores">${resps.filter((x) => x.papel === 'admin').map((x) => `<option value="${x.id}" ${u.aprovador_id === x.id ? 'selected' : ''}>${esc(x.nome)}</option>`).join('')}</optgroup>
      ${resps.some((x) => x.papel === 'supervisor') ? `<optgroup label="Supervisores">${resps.filter((x) => x.papel === 'supervisor').map((x) => `<option value="${x.id}" ${u.aprovador_id === x.id ? 'selected' : ''}>${esc(x.nome)}${x.admin_id ? ' · ligado a ' + esc(nomeU(x.admin_id) || '—') : ''}</option>`).join('')}</optgroup>` : ''}`;
    const eu = u.email === (S.user || {}).email;
    const papeis = Object.entries(PAPEL).filter(([k]) => admin || ['analista', 'leitura'].includes(k) || k === u.papel);
    const dis = (cond) => (cond ? 'disabled' : '');
    const col = u.colaborador_id ? COL(u.colaborador_id) : null;
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">Usuário · <span class="mono">${esc(u.usuario)}</span></span><h2>${esc(u.nome)}</h2>
        <div class="row">${chipUsu(u)}${u.papel ? `<span class="chip">${esc(PAPEL[u.papel])}</span>` : ''}<span class="small muted">${esc(u.email)}</span></div></div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        ${!edita ? `<div class="demo-banner"><span>${u.status === 'pendente' ? `Cadastro encaminhado a ${esc(nomeU(u.aprovador_id) || 'outro responsável')}.` : 'Somente um administrador altera administradores e supervisores.'} Você pode consultar os dados.</span></div>`
          : u.status === 'pendente' ? `<div class="demo-banner"><span>Cadastro criado em ${U.dataHoraBR(u.created_at)}${u.aprovador_id ? ` e encaminhado para ${esc(nomeU(u.aprovador_id) || 'um responsável')}` : ' para qualquer perfil de administração'}. Escolha o perfil e aprove, ou recuse com o motivo.${S.papel === 'supervisor' ? ' Como supervisor, você aprova como analista ou somente leitura.' : ''}</span></div>` : ''}
        <section>
          <div class="section-title"><h3>Situação e perfil</h3></div>
          <div class="form-grid">
            <label class="field"><span>Situação</span><select id="us-status" ${dis(eu || !edita)}>${Object.entries(USU_ST).map(([k, v]) => `<option value="${k}" ${u.status === k ? 'selected' : ''}>${v[0]}</option>`).join('')}</select></label>
            <label class="field"><span>Perfil</span><select id="us-papel" ${dis(eu || !edita)}><option value="">Escolha…</option>${papeis.map(([k, v]) => `<option value="${k}" ${u.papel === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
              <span class="hint">Administrador: acesso completo. Supervisor: abaixo do administrador e ligado a ele; opera o mês e aprova analistas e somente leitura. Analista: operação mensal. Somente leitura: consulta.</span></label>
            <label class="field" id="us-admin-campo" ${u.papel === 'supervisor' ? '' : 'hidden'}><span>Administrador do supervisor</span><select id="us-admin" ${dis(!admin)}>${opt(admins, u.admin_id || (admin && !u.admin_id ? meuUsuarioId() : null), 'Escolha…')}</select>
              <span class="hint">O supervisor fica ligado a este administrador (padrão: quem aprova).</span></label>
            <label class="field"><span>Responsável pela aprovação</span><select id="us-aprov" ${dis(!admin)}>${optResp}</select>
              <span class="hint">Administrador ou supervisor que recebe o pedido. Supervisor: o administrador dele recebe cópia.</span></label>
            <label class="field"><span>Motivo <span class="hint">(obrigatório ao recusar ou bloquear; o usuário vê)</span></span><input type="text" id="us-motivo" maxlength="500" value="${esc(u.motivo || '')}" ${dis(!edita)}></label>
          </div>
          ${eu ? '<p class="hint" style="margin-top:6px">Você não pode alterar a sua própria situação nem o seu perfil.</p>' : ''}
        </section>
        <section>
          <div class="section-title"><h3>Contato Klingele e contratos</h3></div>
          <div class="form-grid">
            <label class="field"><span>Contato Klingele (é esta pessoa)</span><select id="us-col" ${dis(!edita)}>${opt(cols, u.colaborador_id, u.status === 'aprovado' ? 'Nenhum' : 'Criado ao aprovar')}</select>
              <span class="hint">Ao aprovar como administrador, supervisor ou analista, o contato é criado em Contatos Klingele (ou ligado ao que tem o mesmo e-mail). Nome, cargo e telefone acompanham o usuário.</span></label>
            <label class="field"><span>Acompanha os contratos de <span class="hint">(opcional)</span></span><select id="us-sup" ${dis(!edita)}>${opt(sups, u.supervisor_id, 'Ninguém')}</select>
              <span class="hint">Supervisor cujos contratos aparecem em “Meus contratos” para este usuário.</span></label>
          </div>
          ${col ? `<p class="small muted" style="margin-top:6px">${esc(col.nome)}${col.supervisor ? ' · supervisor' : ''}${col.ativo ? '' : ' · inativo'} · ${(() => { const ns = S.base.contratos.filter((k) => k.situacao === 'ativo' && supsDe(k).includes(col.id)).length, nc = S.base.contratos.filter((k) => k.situacao === 'ativo' && ctsDe(k).includes(col.id)).length; return [ns ? `supervisor em ${ns}` : '', nc ? `contato em ${nc}` : ''].filter(Boolean).join(' · ') || 'sem contrato ligado'; })()}
            <button type="button" class="btn sm ghost" data-act="abrir-colab" data-id="${col.id}">${ic.lapis} Ligar contratos</button></p>` : ''}
        </section>
        <section>
          <div class="section-title"><h3>Dados</h3></div>
          <div class="form-grid">
            <label class="field"><span>Nome</span><input type="text" id="us-nome" maxlength="120" value="${esc(u.nome)}" ${dis(!edita)}></label>
            <label class="field"><span>Usuário <span class="hint">(login)</span></span><input type="text" id="us-usuario" maxlength="30" value="${esc(u.usuario)}" ${dis(!edita)}></label>
            <label class="field"><span>Cargo</span><input type="text" id="us-cargo" maxlength="80" value="${esc(u.cargo || '')}" ${dis(!edita)}></label>
            <label class="field"><span>Telefone</span><input type="tel" id="us-tel" maxlength="60" value="${esc(u.telefone || '')}" ${dis(!edita)}></label>
            <label class="field full"><span>E-mail de aviso <span class="hint">(recebe a NF encaminhada a Serviços das F.S. aprovadas por este usuário; vazio = ${esc(u.email)})</span></span><input type="email" id="us-aviso" maxlength="254" value="${esc(u.email_aviso || '')}" ${dis(!edita)}></label>
          </div>
          <dl class="kv" style="margin-top:10px"><dt>E-mail de login</dt><dd>${esc(u.email)}</dd><dt>Decidido por</dt><dd>${u.decidido_por ? `${esc(u.decidido_por)} em ${U.dataHoraBR(u.decidido_em)}` : '—'}</dd></dl>
        </section>
      </div>
      <div class="drawer-foot"><button class="btn ghost" data-act="fechar-gaveta">Fechar</button><span class="spacer"></span>
        ${!edita ? '' : u.status === 'pendente' && !eu ? `<button class="btn danger" data-act="usu-rapido" data-v="recusado">${ic.x} Recusar</button><button class="btn primary" data-act="usu-rapido" data-v="aprovado">${ic.ok} Aprovar</button>`
          : `<button class="btn primary" data-act="salvar-usuario">${ic.ok} Salvar</button>`}
      </div>`);
    const sp = document.getElementById('us-papel');
    if (sp) sp.addEventListener('change', () => { const c = document.getElementById('us-admin-campo'); if (c) c.hidden = sp.value !== 'supervisor'; });
  }
  async function salvarUsuario(statusForcado) {
    const el = (k) => document.getElementById('us-' + k);
    const g = (k) => (el(k) || {}).value || '';
    const u = S.usuarios.find((x) => x.id === S.gaveta.id);
    const eu = u.email === (S.user || {}).email;
    const d = { nome: g('nome').trim(), usuario: g('usuario').trim(), cargo: g('cargo').trim() || null, telefone: g('tel').trim() || null, email_aviso: g('aviso').trim().toLowerCase() || null,
      supervisor_id: g('sup') || null, colaborador_id: g('col') || null, motivo: g('motivo').trim() || null };
    if (el('aprov') && !el('aprov').disabled) d.aprovador_id = g('aprov') || null;
    if (!eu) { d.status = statusForcado || g('status'); d.papel = g('papel') || null; }
    if (S.papel === 'admin' && (d.papel || u.papel) === 'supervisor') d.admin_id = g('admin') || null;
    if (d.status === 'aprovado' && !d.papel) { U.toast('Escolha o perfil para aprovar', 'erro'); el('papel').focus(); return; }
    if (S.papel === 'supervisor' && d.papel && !['analista', 'leitura'].includes(d.papel) && d.papel !== u.papel) { U.toast('O supervisor aprova só como analista ou somente leitura', 'erro'); return; }
    if (['recusado', 'bloqueado'].includes(d.status) && (d.motivo || '').length < 3) { U.toast('Informe o motivo (o usuário verá este texto)', 'erro'); el('motivo').focus(); return; }
    if (!U.usuarioValido(d.usuario)) { U.toast('Usuário inválido: de 3 a 30 letras, números, ponto, hífen ou sublinhado', 'erro'); return; }
    if (d.email_aviso && !U.emailValido(d.email_aviso)) { U.toast('E-mail de aviso inválido', 'erro'); return; }
    if (!U.telefoneValido(d.telefone)) { U.toast('Telefone inválido', 'erro'); return; }
    try {
      const r = await API.salvarUsuario(u.id, d);
      if (eu) S.cad = { ...(S.cad || {}), supervisor_id: d.supervisor_id, colaborador_id: (r && r.colaborador_id) || d.colaborador_id, nome: d.nome || (S.cad || {}).nome };
      S.usuarios = await API.usuarios();
      await recarregar(true); fecharGaveta(); renderView();
      const novo = S.usuarios.find((x) => x.id === u.id) || {};
      const col = novo.colaborador_id && !u.colaborador_id ? COL(novo.colaborador_id) : null;
      U.toast(d.status && d.status !== u.status ? `${u.nome}: ${USU_ST[d.status][0].toLowerCase()}${d.status === 'aprovado' ? ' como ' + PAPEL[d.papel].toLowerCase() : ''}${col ? ' · contato Klingele criado' : ''}` : 'Usuário salvo');
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  // =====================================================================
  //  EQUIPES DE TRABALHO (Usuários > Equipes): criar, convidar, aceitar
  // =====================================================================
  const ST_MEMBRO = { ativo: ['Membro', 'ok'], convidado: ['Convite enviado', 'info'], recusado: ['Recusou', ''] };
  function equipesHTML() {
    const eqs = S.base.equipes;
    return `<section class="panel"><div class="panel-head"><div><h2>Equipes</h2><span class="sub">Um usuário pode estar em mais de uma equipe. Pastas compartilhadas com a equipe aparecem para todos os membros, inclusive quem entrar depois.</span></div>
        <button class="btn sm primary" data-act="nova-equipe">${ic.mais} Nova equipe</button></div>
      ${eqs.length ? `<div class="table-wrap"><table class="tbl"><thead><tr><th>Equipe</th><th>Membros</th><th>Convites</th><th>Pastas compartilhadas</th><th></th></tr></thead><tbody>
        ${eqs.map((e) => { const ms = membrosDe(e.id), at = ms.filter((m) => m.status === 'ativo'), cv = ms.filter((m) => m.status === 'convidado');
          const np = (S.base.compart || []).filter((c) => c.alvo_tipo === 'equipe' && c.alvo === e.id).length;
          return `<tr class="click" data-act="abrir-equipe" data-id="${e.id}"><td><div class="cell-title">${esc(e.nome)}</div><div class="cell-sub">${e.descricao ? esc(e.descricao) + ' · ' : ''}criada por ${esc(nomeEquipe(e.criado_por))}</div></td>
            <td class="small">${at.length} · ${esc(at.slice(0, 4).map((m) => nomeEquipe(m.email)).join(', '))}${at.length > 4 ? '…' : ''}</td>
            <td class="num">${cv.length || '—'}</td><td class="num">${np || '—'}</td>
            <td class="r"><button class="btn sm" data-act="abrir-equipe" data-id="${e.id}">${gereEquipe(e) ? `${ic.lapis} Gerenciar` : `${ic.olho} Ver`}</button></td></tr>`; }).join('')}
      </tbody></table></div>` : '<div class="panel-body"><p class="muted" style="margin:0">Nenhuma equipe. Crie uma equipe e convide os usuários; depois, compartilhe pastas com todos da equipe.</p></div>'}
    </section>`;
  }
  function abrirEquipe(id) {
    const e = id ? S.mapEq[id] : { nome: '', descricao: '', criado_por: EU() };
    if (!e) return;
    const gere = !id || gereEquipe(e), dis = gere ? '' : 'disabled';
    S.gaveta = { tipo: 'equipe', id: id || null };
    const ms = id ? membrosDe(id).slice().sort((a, b) => (a.status === b.status ? nomeEquipe(a.email).localeCompare(nomeEquipe(b.email)) : a.status === 'ativo' ? -1 : 1)) : [];
    const fora = (S.base.equipe || []).filter((q) => !ms.some((m) => m.email === (q.email || '').toLowerCase() && m.status !== 'recusado'))
      .sort((a, b) => (a.nome || a.email).localeCompare(b.nome || b.email));
    const pastas = id ? (S.base.compart || []).filter((c) => c.alvo_tipo === 'equipe' && c.alvo === id).map((c) => ({ p: S.mapPasta[c.pasta_id], nivel: c.nivel })).filter((x) => x.p) : [];
    gaveta(`
      <div class="drawer-head"><div class="t"><span class="label">${id ? 'Equipe' : 'Nova equipe'}</span><h2>${esc(e.nome || 'Cadastro de equipe')}</h2>
        ${id ? `<div class="row"><span class="small muted">Criada por ${esc(nomeEquipe(e.criado_por))}</span></div>` : ''}</div>
        <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">
        <div class="form-grid">
          <label class="field full"><span>Nome da equipe</span><input type="text" id="eq-nome" maxlength="80" value="${esc(e.nome || '')}" placeholder="Ex.: Manutenção" ${dis}></label>
          <label class="field full"><span>Descrição <span class="hint">(opcional)</span></span><input type="text" id="eq-desc" maxlength="300" value="${esc(e.descricao || '')}" ${dis}></label>
        </div>
        ${!id ? '<p class="hint">Depois de criar, convide os usuários. Quem cria já entra como membro.</p>' : `
        <section><div class="section-title"><h3>Membros e convites (${ms.length})</h3></div>
          <div class="membros">${ms.map((m) => `<div class="membro"><div style="min-width:0"><b>${esc(nomeEquipe(m.email))}</b><div class="small muted" style="overflow-wrap:anywhere">${esc(m.email)}${m.email === e.criado_por ? ' · criou a equipe' : ''}${m.status === 'convidado' ? ` · convidado em ${U.dataHoraBR(m.convidado_em)}` : ''}</div></div>
            ${chip(ST_MEMBRO[m.status][1], ST_MEMBRO[m.status][0])}
            ${gere && m.email !== e.criado_por ? `<button type="button" class="icon-btn sm" data-act="equipe-tirar" data-email="${esc(m.email)}" title="${m.status === 'convidado' ? 'Cancelar convite' : 'Tirar da equipe'}" aria-label="Tirar ${esc(nomeEquipe(m.email))}">${ic.x}</button>` : ''}</div>`).join('')}</div>
        </section>
        ${gere ? `<section><div class="section-title"><h3>Convidar</h3></div>
          ${fora.length ? `<div class="convidar">${fora.map((q) => `<label class="check sm"><input type="checkbox" data-conv value="${esc((q.email || '').toLowerCase())}"> ${esc(q.nome || q.email)} <span class="muted">· ${esc(PAPEL[q.papel] || q.papel)}</span></label>`).join('')}</div>
            <div class="row" style="margin-top:8px"><button class="btn primary" data-act="equipe-convidar">${ic.mail} Enviar convite</button><span class="small muted">O convidado aceita ou recusa em Meu perfil (e recebe o aviso por e-mail, se o envio pelo app estiver configurado).</span></div>`
            : '<p class="small muted" style="margin:0">Todos os usuários já estão na equipe ou convidados.</p>'}</section>` : ''}
        <section><div class="section-title"><h3>Pastas compartilhadas com a equipe (${pastas.length})</h3></div>
          ${pastas.map((x) => `<div class="small">${ic.pasta} ${esc(x.p.nome)} · ${({ editar: 'pode editar', gerir: 'pode gerir' })[x.nivel] || 'pode ver'}</div>`).join('') || '<p class="small muted" style="margin:0">Nenhuma. Compartilhe na própria pasta (menu Pastas).</p>'}</section>`}
      </div>
      <div class="drawer-foot">
        ${id && gere ? `<button class="btn danger" data-act="excluir-equipe">${ic.lixo} Excluir</button>` : ''}
        ${id && minhasEquipes().includes(id) && e.criado_por !== EU() ? `<button class="btn" data-act="equipe-sair" data-id="${id}">Sair da equipe</button>` : ''}<span class="spacer"></span>
        <button class="btn" data-act="fechar-gaveta">${gere ? 'Cancelar' : 'Fechar'}</button>
        ${gere ? `<button class="btn primary" data-act="salvar-equipe">${ic.ok} ${id ? 'Salvar' : 'Criar equipe'}</button>` : ''}
      </div>`);
  }
  async function salvarEquipe() {
    const d = { nome: document.getElementById('eq-nome').value.trim(), descricao: document.getElementById('eq-desc').value.trim() };
    if (d.nome.length < 2 || d.nome.length > 80) { U.toast('Informe o nome da equipe (2 a 80 caracteres)', 'erro'); return; }
    try {
      const novo = !S.gaveta.id;
      const r = await API.salvarEquipe(S.gaveta.id, d);
      await recarregar(true); renderView();
      if (novo) { abrirEquipe(r.id); U.toast('Equipe criada. Agora convide os usuários.'); } else { fecharGaveta(); U.toast('Equipe salva'); }
    } catch (e) { U.toast(e.message, 'erro'); }
  }
  async function convidarEquipe() {
    const emails = Array.from(document.querySelectorAll('[data-conv]:checked')).map((b) => b.value);
    if (!emails.length) { U.toast('Marque quem será convidado', 'erro'); return; }
    try {
      const r = await API.convidarEquipe(S.gaveta.id, emails);
      await recarregar(true); renderView(); abrirEquipe(S.gaveta.id);
      U.toast(`${r.convidados} convite${r.convidados !== 1 ? 's' : ''} enviado${r.convidados !== 1 ? 's' : ''}`);
    } catch (e) { U.toast(e.message, 'erro'); }
  }

  // =====================================================================
  //  HISTÓRICO
  // =====================================================================
  const ROT_CAMPO = { valor_aprovado: 'Aprovado', valor_informado: 'Informado', valor_lido: 'Lido', valor_contratado: 'Contratado', status: 'Situação', nota_fiscal: 'NF',
    data_pagamento: 'Pagamento', deseja_enviar: 'Envio mensal', email: 'E-mail', nome: 'Nome', telefone: 'Telefone', valor_mensal: 'Valor mensal', valor_total: 'Valor total',
    data_fim: 'Fim', data_inicio: 'Início', titulo: 'Serviço', gestor: 'Gestor', situacao: 'Situação', observacoes: 'Observações', origem: 'Origem',
    recebe_boletim: 'Recebe boletim', pedido: 'Pedido', cnpj: 'CNPJ', codigo: 'Código', ativo: 'Ativo', tipo_contrato: 'Tipo', principal: 'Principal',
    tipo_servico: 'Tipo de serviço', tipo: 'Tipo do documento', nome_padrao: 'Nome do arquivo', cargo: 'Cargo', contato_fornecedor: 'Contato do fornecedor',
    supervisor: 'Supervisor', ordem: 'Ordem', parcela: 'Parcela', folha_numero: 'Folha', folha_data: 'Data da folha', descricao_nf: 'Descrição da NF',
    parcelas_total: 'Total de parcelas', parcelas_pagas_antes: 'Pagas antes do sistema', folha_valor: 'Valor da F.S.', folha_status: 'Situação da F.S.',
    alerta_dias: 'Aviso (dias antes)', finalizado_em: 'Finalizado em', supervisor_id: 'Supervisor', supervisores: 'Supervisores', contatos: 'Contatos Klingele' };
  const ENT = { fornecedores: 'Fornecedor', contatos: 'Contato', contratos: 'Contrato', medicoes: 'Medição', solicitacoes: 'Solicitação', documentos: 'Documento',
    acesso: 'Acesso', configuracoes: 'Configuração', avaliacoes: 'Avaliação', colaboradores: 'Contato Klingele', solicitacoes_nf: 'Pedido de NF', notas_fiscais: 'Nota fiscal',
    usuarios: 'Usuário', pastas_envio: 'Pasta de envio', equipes: 'Equipe' };
  function fmtValor(k, v) {
    if (v === null || v === undefined || v === '') return '—';
    if (Array.isArray(v)) return v.length ? v.map((x) => (COL(x) || {}).nome || x).join(', ') : '—';
    if (k === 'supervisor_id') return (COL(v) || {}).nome || String(v);
    if (typeof v === 'boolean') return v ? 'Sim' : 'Não';
    if (/^valor/.test(k)) return U.brl(v);
    if (k === 'status' && MED[v]) return MED[v][0];
    if (k === 'tipo_servico') return U.tipoServicoTxt(v) || v;
    if (k === 'tipo' && U.TIPOS_DOC[v]) return U.TIPOS_DOC[v];
    if (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) return U.dataBR(v);
    return String(v);
  }
  function itemHist(h) {
    const d = h.detalhes || {};
    let det = '';
    if (h.acao === 'alteração') {
      det = Object.entries(d).filter(([k, v]) => v && typeof v === 'object' && 'para' in v && ROT_CAMPO[k]).slice(0, 5)
        .map(([k, v]) => `${ROT_CAMPO[k]}: ${fmtValor(k, v.de)} > ${fmtValor(k, v.para)}`).join(' · ');
    } else if (d.para) det = 'Para ' + [].concat(d.para).join(', ');
    else if (d.arquivos !== undefined) det = `${d.arquivos} arquivo${d.arquivos !== 1 ? 's' : ''}${d.competencia ? ' · ' + d.competencia : ''}`;
    else if (h.entidade === 'usuarios') det = [d.usuario ? 'Usuário ' + d.usuario : '', d.email, d.papel ? 'Perfil ' + d.papel : '', d.supervisor ? 'Supervisor ' + d.supervisor : ''].filter(Boolean).join(' · ');
    else if (d.aviso_para) det = [d.folha ? 'F.S. ' + d.folha : '', d.valor !== undefined && d.valor !== null ? U.brl(d.valor) : '', 'Aviso para ' + [].concat(d.aviso_para).join(', ') + (d.aviso_enviado === false ? ' (não saiu pelo app)' : '')].filter(Boolean).join(' · ');
    else if (h.entidade === 'notas_fiscais' || (h.entidade === 'medicoes' && /folha|F\.S\./.test(h.acao)) || h.entidade === 'solicitacoes_nf') det = [d.numero ? 'NF ' + d.numero : '',
      d.pedido ? 'Pedido ' + d.pedido : '', d.folha ? 'Folha ' + d.folha : '', d.parcela ? 'Parcela ' + d.parcela + (d.parcelas_total ? '/' + d.parcelas_total : '') : '',
      d.valor !== undefined && d.valor !== null ? U.brl(d.valor) : '', d.alertas ? d.alertas + ' alerta(s)' : '', d.motivo ? 'Motivo: ' + d.motivo : '', d.responsavel,
      d.competencia ? 'Competência ' + d.competencia : ''].filter(Boolean).join(' · ');
    else if (h.entidade === 'pastas_envio') det = d.pastas ? 'Pastas: ' + ([].concat(d.pastas).join(', ') || 'nenhuma')
      : [d.nome, d.tipo === 'filtro' ? 'por filtro' : '', d.dia_util !== undefined ? (Number(d.dia_util) === 0 ? 'último dia útil' : d.dia_util + 'º dia útil') : '', d.horario, d.fornecedores !== undefined && d.fornecedores !== null ? d.fornecedores + ' fornecedor(es)' : '',
        d.visibilidade ? { restrita: 'restrita', todos_ver: 'todos veem', todos_editar: 'todos editam' }[d.visibilidade] : '', d.compartilhamentos ? 'compartilhada com ' + d.compartilhamentos : ''].filter(Boolean).join(' · ');
    else if (h.entidade === 'equipes') det = [d.nome, d.convidados !== undefined ? d.convidados + ' convidado(s)' : '', d.email ? nomeEquipe(d.email) : ''].filter(Boolean).join(' · ');
    else if (h.entidade === 'avaliacoes') det = [d.supervisor ? 'Supervisor ' + d.supervisor : '', d.responsavel, d.nota_geral !== undefined && d.nota_geral !== null ? 'Nota geral ' + U.nota(d.nota_geral) : '',
      d.competencia ? 'Competência ' + d.competencia : ''].filter(Boolean).join(' · ');
    else det = [d.email, d.pedido ? 'Pedido ' + d.pedido : '', d.titulo, d.arquivo, d.competencia ? 'Competência ' + d.competencia : ''].filter(Boolean).join(' · ') || (d.nome || '');
    if (d.ip && d.ip !== 'sem-ip') det = (det ? det + ' · ' : '') + 'IP ' + d.ip;
    const f = h.fornecedor_id && S.mapF[h.fornecedor_id] ? S.mapF[h.fornecedor_id].nome : '';
    return `<div class="tl-item"><span class="tl-when">${U.dataHoraBR(h.created_at)}</span>
      <div class="tl-what"><span><b>${esc(U.cap(h.acao).replace(/^E-Mail/, 'E-mail'))}</b> <span class="muted">· ${esc(ENT[h.entidade] || h.entidade)}${f ? ' · ' + esc(f) : ''}</span></span>
      ${det ? `<span class="d">${esc(det)}</span>` : ''}<span class="small muted">por ${esc(h.autor || 'sistema')}${h.arquivado_em ? ` · <span class="chip plain">Limpo</span> ${esc(limpoTxt(h).replace(/^limpo /, ''))}` : ''}</span></div></div>`;
  }
  // ---------- Histórico por período (admin e analista) ----------
  const periodoPadrao = () => ({ de: U.addDias(U.hojeISO(), -30), ate: U.hojeISO() });
  function periodoHist() {
    if (!S.f.histDe || !S.f.histAte) Object.assign(S.f, { histDe: periodoPadrao().de, histAte: periodoPadrao().ate });
    return { de: S.f.histDe, ate: S.f.histAte };
  }
  // Registros limpos continuam guardados: saem da lista, voltam com "Mostrar limpos" e sempre aparecem na busca
  const limpoTxt = (x) => (x.arquivado_em ? `limpo em ${U.dataBR(U.dataLocal(x.arquivado_em))}${x.arquivado_por ? ' por ' + x.arquivado_por : ''}` : '');
  const textoHist = {
    envios: (e) => [F(e.fornecedor_id).nome, tipoEnvioTxt(e), (e.para || []).join(' '), e.assunto, e.autor, U.compLabel(e.competencia)].join(' '),
    ativ: (h) => [h.acao, ENT[h.entidade] || h.entidade, h.fornecedor_id && S.mapF[h.fornecedor_id] ? S.mapF[h.fornecedor_id].nome : '', detalheHist(h), h.autor].join(' '),
    rotina: (r) => [r.origem, resultadoRotina(r)].join(' '),
    seg: (e) => [e.tipo, GRAV_SEG[e.gravidade] ? GRAV_SEG[e.gravidade][0] : e.gravidade, e.ip, e.email, detalheSeg(e)].join(' ')
  };
  // ---------- Segurança: tentativas bloqueadas e verificação do banco (administradores) ----------
  // Verificação do banco (dentro do painel Segurança)
  function verificacaoHTML() {
    const v = S.segVerif, nv = (S.segPend || []).length;
    const itens = v ? v.itens.slice().sort((a, b) => ['critico', 'alerta', 'info', 'ok'].indexOf(a.situacao) - ['critico', 'alerta', 'info', 'ok'].indexOf(b.situacao)) : [];
    const r = v ? v.resumo : null;
    return `<div class="stack" id="conf-verif">
      <div class="row between"><div><b>Verificação do banco</b><div class="small muted">Confere tabelas, funções, arquivos, chaves, cadastros repetidos, senha padrão e tentativas bloqueadas. Roda também às 08:00 e 16:00.</div></div>
        <div class="row" style="gap:6px">${nv ? `<button class="btn sm" data-act="ir-pend" data-v="hist:hist:seg">${ic.alerta} ${nv} não visto${nv > 1 ? 's' : ''}</button>` : ''}
          <button class="btn sm primary" data-act="seg-verificar">${ic.refazer} Verificar agora</button></div></div>
      ${!v ? '<p class="muted small" style="margin:0">Clique em "Verificar agora" para conferir o banco.</p>' : `
        <div class="row" style="gap:6px">${r.critico ? chip('crit', r.critico + ' crítico' + (r.critico > 1 ? 's' : '')) : ''}${r.alerta ? chip('warn', r.alerta + ' alerta' + (r.alerta > 1 ? 's' : '')) : ''}
          ${chip('ok', r.ok + ' ok')}${r.info ? chip('', r.info + ' informação' + (r.info > 1 ? 'ões' : '')) : ''}<span class="small muted">Verificado em ${U.dataHoraBR(v.verificado_em)}${v.demonstracao ? ' · na demonstração, os itens do banco aparecem como numa instalação nova' : ''}</span></div>
        <ul class="verif">${itens.filter((i) => i.situacao !== 'ok').map((i) => `<li class="verif-${i.situacao}"><span class="verif-ic" aria-hidden="true">${i.situacao === 'info' ? ic.sino : ic.alerta}</span>
          <div style="min-width:0"><b>${esc(i.titulo)}</b> ${chipSeg(i.situacao)}<div class="small muted">${esc(i.detalhe || '')}</div></div></li>`).join('')}</ul>
        ${itens.some((i) => i.situacao === 'ok') ? `<details class="campos"><summary>Itens em ordem (${itens.filter((i) => i.situacao === 'ok').length})</summary>
          <ul class="verif" style="margin-top:6px">${itens.filter((i) => i.situacao === 'ok').map((i) => `<li class="verif-ok"><span class="verif-ic" aria-hidden="true">${ic.ok}</span>
            <div style="min-width:0"><b>${esc(i.titulo)}</b><div class="small muted">${esc(i.detalhe || '')}</div></div></li>`).join('')}</ul></details>` : ''}
        ${v.duplicados && v.duplicados.length ? `<div><b>Cadastros repetidos para conferir</b>
          <ul class="dup-lista">${v.duplicados.map((g) => `<li>${chipSeg(g.gravidade)} <b>${esc(g.tipo)}</b> · ${esc(g.chave || '')}
            <div class="small muted">${g.itens.map((x) => esc([x.nome || x.email || x.titulo, x.codigo ? 'cód. ' + x.codigo : '', x.pedido ? 'pedido ' + x.pedido : '', x.cnpj ? U.cnpj(x.cnpj) : ''].filter(Boolean).join(' · '))).join(' | ')}</div></li>`).join('')}</ul>
          <p class="small muted" style="margin:6px 0 0">Corrija juntando ou ajustando os cadastros (Fornecedores e Contatos Klingele). Depois rode o 01_estrutura.sql de novo para criar as travas que faltarem.</p></div>` : ''}`}
    </div>`;
  }
  // Confirmação de entrega pelo webhook do Resend (dentro de Envio pelo app)
  const NOME_AVISO = { 'email.sent': ['Aceito', 'info'], 'email.delivered': ['Entregue', 'ok'], 'email.delivery_delayed': ['Atrasado', 'warn'], 'email.bounced': ['Devolvido', 'crit'],
    'email.complained': ['Spam', 'crit'], 'email.failed': ['Falhou', 'crit'], 'email.suppressed': ['Bloqueado', 'crit'], 'email.opened': ['Aberto', ''], 'email.clicked': ['Clicado', ''] };
  function erroResend(txt) {
    let m = String(txt || '');
    try { const j = JSON.parse(m); m = j.message || j.error || m; } catch (e) { /* texto simples */ }
    if (/domain.*not verified|verify a domain|testing emails/i.test(m)) return m + ' · Verifique o domínio do remetente em Resend > Domains (sem isso, o Resend só entrega para o seu próprio e-mail).';
    if (/api key is invalid|invalid api key|missing api key|restricted/i.test(m)) return m + ' · Confira a chave da API (permissão de envio) e salve de novo.';
    return m;
  }
  function blocoWebhook() {
    const w = S.webhookSit, te = S.emailTeste;
    const url = (cfg.supabaseUrl || 'https://SEU-PROJETO.supabase.co').replace(/\/$/, '') + '/functions/v1/resend-webhook';
    const resend = cfgv('email_provedor', 'resend') === 'resend';
    const teste = !te || !te.teste ? '' : !te.pronto ? `<div class="small muted">Teste enviado para ${esc(te.para)} às ${U.dataHoraBR(te.em)}: aguardando a resposta do serviço. <button type="button" class="btn sm ghost" data-act="email-teste-ver">Atualizar</button></div>`
      : te.ok ? `<div class="row small" style="gap:6px">Teste de ${U.dataHoraBR(te.em)}: ${chip('ok', 'Aceito pelo serviço')}${(te.avisos || []).map((a) => chip((NOME_AVISO[a.tipo] || ['', ''])[1], (NOME_AVISO[a.tipo] || [a.tipo])[0])).join('')}
          ${resend && !(te.avisos || []).some((a) => a.tipo === 'email.delivered') ? '<span class="muted">aguardando o aviso de entrega</span>' : ''}<button type="button" class="btn sm ghost" data-act="email-teste-ver">Atualizar</button></div>`
      : `<div class="small" style="color:var(--crit)">Teste de ${U.dataHoraBR(te.em)} recusado (HTTP ${esc(te.http || '—')}): ${esc(erroResend(te.erro))}</div>`;
    return `<div class="webhook stack" id="conf-webhook">
      <div><b>Teste e confirmação de entrega</b><div class="small muted">${resend ? 'O Resend avisa o app quando cada e-mail é entregue, atrasa, volta (endereço que não existe) ou é marcado como spam. O resultado aparece no envio de cada fornecedor e no Histórico.' : 'A confirmação de entrega pelo webhook está disponível com o Resend.'}</div></div>
      <div class="row" style="gap:8px"><button class="btn" data-act="email-teste">${ic.mail} Enviar e-mail de teste</button><span class="small muted">vai para o seu e-mail de aviso</span></div>
      ${teste}
      ${resend ? `<div class="row" style="gap:6px">${w && w.segredo ? chip('ok', 'Segredo do webhook cadastrado') : chip('warn', 'Webhook sem segredo')}${w && w.ultimo_em ? chip('ok', 'Último aviso: ' + U.dataHoraBR(w.ultimo_em)) : chip('', 'Nenhum aviso recebido')}</div>
      ${w && (w.entregues_7d || w.devolvidos_7d || w.sem_aviso) ? `<div class="small muted">Últimos 7 dias: ${w.entregues_7d} entregue(s) · ${w.devolvidos_7d} devolvido(s) ou spam${w.sem_aviso ? ` · <b style="color:var(--warn)">${w.sem_aviso} sem aviso há mais de 2 horas</b>` : ''}</div>` : ''}
      <label class="field"><span>Endereço do webhook <span class="hint">(cole no Resend)</span></span>
        <div class="row" style="flex-wrap:nowrap"><input type="text" id="cw-url" readonly value="${esc(url)}" aria-label="Endereço do webhook"><button class="btn sm" type="button" data-act="copiar-webhook">${ic.copiar} Copiar</button></div></label>
      <label class="field"><span>Segredo de assinatura <span class="hint">(Signing secret do webhook, começa com whsec_; fica criptografado)</span></span>
        <div class="row" style="flex-wrap:nowrap"><input type="password" id="cw-segredo" autocomplete="off" maxlength="220" placeholder="${w && w.segredo ? 'Cadastrado. Informe outro só para substituir.' : 'whsec_...'}" aria-label="Segredo do webhook">
          <button class="btn sm primary" type="button" data-act="salvar-webhook">${ic.ok} Salvar</button></div></label>
      <details class="campos"><summary>Como ligar o Resend, passo a passo (6)</summary><ol class="small passos">
        <li><b>Resend > Domains</b>: adicione e verifique o domínio do remetente (registros DNS). Sem isso, o Resend só entrega para o seu próprio e-mail.</li>
        <li><b>Resend > API Keys</b>: crie uma chave com <i>Sending access</i>. Aqui ao lado, escolha Resend, informe o remetente do domínio verificado, cole a chave e salve.</li>
        <li><b>Supabase > Edge Functions</b>: <i>Deploy a new function</i> > <i>Via Editor</i>, nome <span class="mono">resend-webhook</span>, cole o arquivo <span class="mono">supabase/functions/resend-webhook/index.ts</span> do pacote e publique. Em <i>Details</i>, desligue <i>Verify JWT with legacy secret</i>.</li>
        <li><b>Resend > Webhooks > Add Webhook</b>: cole o endereço acima e marque <span class="mono">email.sent</span>, <span class="mono">email.delivered</span>, <span class="mono">email.delivery_delayed</span>, <span class="mono">email.bounced</span>, <span class="mono">email.complained</span>, <span class="mono">email.failed</span> e <span class="mono">email.suppressed</span>.</li>
        <li>No webhook criado, copie o <i>Signing secret</i> (whsec_...) e salve no campo acima.</li>
        <li>Clique em <b>Enviar e-mail de teste</b>: em segundos aparece "Aceito pelo serviço" e, com o webhook ligado, "Entregue".</li></ol></details>` : ''}
    </div>`;
  }
  const GRAV_SEG = { critico: ['Crítico', 'crit'], alerta: ['Alerta', 'warn'], info: ['Informação', ''], ok: ['Ok', 'ok'] };
  const chipSeg = (g) => chip((GRAV_SEG[g] || ['', ''])[1], (GRAV_SEG[g] || [g])[0]);
  function detalheSeg(e) {
    const d = e.detalhes || {};
    return [d.usuario ? 'usuário ' + d.usuario : '', d.fornecedor ? 'fornecedor ' + d.fornecedor : '', d.de && d.para ? `de ${d.de} para ${d.para}` : '',
      d.papel_na_equipe ? 'liberado na equipe como ' + (PAPEL[d.papel_na_equipe] || d.papel_na_equipe) : '', d.limite ? 'limite ' + d.limite : '',
      d.link ? 'link …' + d.link : '', d.detalhe || '', d.situacao ? 'cadastro ' + d.situacao : ''].filter(Boolean).join(' · ');
  }
  const cacheTxtHist = new WeakMap();
  function filtrarHist(aba, lista) {
    const q = String(S.f.histBusca || '').trim().toLowerCase();
    const txt = (x) => { let s = cacheTxtHist.get(x); if (s === undefined) { s = textoHist[aba](x).toLowerCase(); cacheTxtHist.set(x, s); } return s; };
    if (q) return lista.filter((x) => txt(x).includes(q));
    return S.f.histLimpos ? lista : lista.filter((x) => !x.arquivado_em);
  }
  async function carregarHistorico() {
    const p = periodoHist();
    try {
      const [envios, hist, rotina, seg] = await Promise.all([API.envios({ ...p, limite: 2000 }), API.historico({ ...p, limite: 2000 }), API.rotinaLog({ ...p, limite: 500 }),
        S.papel === 'admin' && API.eventosSeguranca ? API.eventosSeguranca({ ...p, limite: 2000 }) : Promise.resolve([])]);
      S.cache = { envios, hist, rotina, seg, periodo: { ...p } };
      if (S.view === 'hist') renderView();
    } catch (e) { U.toast(e.message, 'erro'); }
  }
  function resultadoRotina(r) {
    const d = r.detalhes || {};
    if (r.origem === 'cobrança automática' || r.origem === 'cobrança manual') {
      return d.ok === false ? (d.erro || 'Falhou') : `${d.reenvios ?? 0} reenvio(s) com novo prazo · ${d.lembretes ?? 0} lembrete(s) semanal(is)${d.sem_email && d.sem_email.length ? ' · sem e-mail: ' + d.sem_email.join(', ') : ''}`;
    }
    if (d.competencia !== undefined) return d.ok === false ? (d.erro || 'Não enviado') : `Competência ${d.competencia} · ${d.enviados ?? 0} enviado(s)${d.sem_email && d.sem_email.length ? ' · sem e-mail: ' + d.sem_email.join(', ') : ''}`;
    return [d.links_expirados !== undefined ? `${d.links_expirados} link(s) expirado(s)` : '', d.avaliacoes_expiradas ? `${d.avaliacoes_expiradas} avaliação(ões) vencida(s)` : '',
      d.links_nf_expirados ? `${d.links_nf_expirados} link(s) de NF vencido(s)` : '',
      d.contratos_vencendo_60d !== undefined ? `${d.contratos_vencendo_60d} contrato(s) com vencimento em até 60 dias` : '',
      d.avisos_vencimento && d.avisos_vencimento.avisados ? `${d.avisos_vencimento.avisados} aviso(s) de vencimento enviado(s)` : '',
      d.avisos_vencimento && d.avisos_vencimento.sem_destinatario ? `${d.avisos_vencimento.sem_destinatario} contrato(s) sem destinatário para o aviso` : ''].filter(Boolean).join(' · ') || '—';
  }
  const tipoEnvioTxt = (e) => `${e.avaliacao_id ? 'Avaliação · ' : e.solicitacao_nf_id ? 'Nota fiscal · ' : e.autor === 'cobrança automática' ? 'Cobrança · ' : ''}${TIPO_ENVIO[e.tipo] || e.tipo} ${VIA_ENVIO[e.via] || ''}`.trim();
  const detalheHist = (h) => { const t = document.createElement('div'); t.innerHTML = itemHist(h); const d = t.querySelector('.d'); return d ? d.textContent : ''; };
  // Planilha do período e da aba abertos (abre no Excel)
  function exportarHistorico() {
    const c = S.cache, p = c.periodo || periodoHist();
    let cab, linhas, nome;
    if (S.f.hist === 'envios') {
      cab = ['Data', 'Competência', 'Fornecedor', 'Tipo', 'Para', 'Assunto', 'Entrega', 'Erro', 'Registrado por', 'Limpo'];
      linhas = filtrarHist('envios', c.envios).map((e) => [U.dataHoraBR(e.created_at), U.compLabel(e.competencia), F(e.fornecedor_id).nome, tipoEnvioTxt(e), (e.para || []).join(', '), e.assunto || '',
        (ST_ENVIO[e.status] || [e.status])[0], e.erro || '', e.autor || '', limpoTxt(e)]);
      nome = 'emails';
    } else if (S.f.hist === 'ativ') {
      cab = ['Data', 'Ação', 'Registro', 'Fornecedor', 'Detalhes', 'Por', 'Limpo'];
      linhas = filtrarHist('ativ', c.hist.filter((h) => !S.f.histForn || h.fornecedor_id === S.f.histForn))
        .map((h) => [U.dataHoraBR(h.created_at), U.cap(h.acao), ENT[h.entidade] || h.entidade, h.fornecedor_id && S.mapF[h.fornecedor_id] ? S.mapF[h.fornecedor_id].nome : '', detalheHist(h), h.autor || 'sistema', limpoTxt(h)]);
      nome = 'atividades';
    } else if (S.f.hist === 'seg') {
      cab = ['Data', 'Gravidade', 'O que aconteceu', 'IP', 'E-mail', 'Detalhes', 'Visto'];
      linhas = filtrarHist('seg', c.seg || []).map((e) => [U.dataHoraBR(e.created_at), (GRAV_SEG[e.gravidade] || [e.gravidade])[0], e.tipo, e.ip || '', e.email || '', detalheSeg(e),
        e.visto_em ? `${U.dataHoraBR(e.visto_em)}${e.visto_por ? ' por ' + e.visto_por : ''}` : '']);
      nome = 'seguranca';
    } else {
      cab = ['Data', 'Origem', 'Resultado', 'Limpo'];
      linhas = filtrarHist('rotina', c.rotina).map((r) => [U.dataHoraBR(r.executado_em), r.origem, resultadoRotina(r), limpoTxt(r)]);
      nome = 'rotina';
    }
    const celula = (v) => { let t = String(v ?? ''); if (/^[=+\-@\t\r]/.test(t)) t = "'" + t; return `"${t.replace(/"/g, '""')}"`; };
    const csv = '﻿' + [cab, ...linhas].map((l) => l.map(celula).join(';')).join('\r\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    a.download = `historico-${nome}-${p.de}-a-${p.ate}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    API.registrarEvento('exportação do histórico', 'historico', null, null, { de: p.de, ate: p.ate, aba: nome, linhas: linhas.length });
    U.toast(DEMO ? 'Planilha gerada. Na prévia o download pode não iniciar; no site publicado ele funciona.' : `Planilha gerada (${linhas.length} linhas)`);
  }
  async function limparHistorico() {
    const p = S.cache.periodo || periodoHist();
    const r = await formularioMotivo({
      titulo: 'Limpar histórico do período',
      texto: `Período de ${U.dataBR(p.de)} a ${U.dataBR(p.ate)}. Nada é apagado: os registros escolhidos saem da lista para reduzir o excesso de informação, mas continuam guardados. Eles voltam com "Mostrar limpos" e sempre aparecem na busca. A limpeza fica registrada com o motivo.`,
      opcoes: { tipo: 'check', itens: [['atividades', 'Atividades', true], ['emails', 'E-mails enviados (os envios em andamento continuam na lista)', false], ['rotina', 'Execuções da rotina', false]] },
      rotulo: 'Limpar período'
    });
    if (!r) return;
    if (!r.escolhas.length) { U.toast('Escolha o que será limpo', 'erro'); return; }
    try {
      const x = await API.limparHistorico(p.de, p.ate, r.escolhas, r.motivo);
      await carregarHistorico();
      U.toast(`Saíram da lista ${x.atividades} atividade(s), ${x.emails} e-mail(s)${x.emails_mantidos ? ` (${x.emails_mantidos} em andamento continuam)` : ''} e ${x.rotina} execução(ões). Nada foi apagado: use "Mostrar limpos" ou a busca.`);
    } catch (e) { U.toast(e.message, 'erro'); }
  }
  VIEWS.hist = () => {
    if (S.papel === 'leitura') return '<section class="panel"><div class="empty"><h3>Acesso restrito</h3><p>O histórico está disponível para administradores e analistas.</p></div></section>';
    const p = periodoHist();
    const carregado = S.cache.periodo && S.cache.periodo.de === p.de && S.cache.periodo.ate === p.ate;
    const seg = [['envios', 'E-mails enviados'], ['ativ', 'Atividades'], ['rotina', 'Rotina 8h/16h'], ...(S.papel === 'admin' ? [['seg', 'Segurança']] : [])];
    if (S.f.hist === 'seg' && S.papel !== 'admin') S.f.hist = 'ativ';
    const atalhos = [['mes', 'Este mês'], ['mes-ant', 'Mês anterior'], ['30', 'Últimos 30 dias'], ['90', 'Últimos 90 dias']];
    const topo = `<section class="panel periodo-hist">
        <div class="panel-body periodo-linha">
          <label class="filtro"><span>De</span><input type="date" id="hist-de" value="${esc(p.de)}" max="${U.hojeISO()}"></label>
          <label class="filtro"><span>Até</span><input type="date" id="hist-ate" value="${esc(p.ate)}" max="${U.hojeISO()}"></label>
          <button class="btn primary" data-act="hist-periodo">${ic.busca} Consultar</button>
          <div class="periodo-atalhos">${atalhos.map(([k, t]) => `<button type="button" class="btn sm ghost" data-act="hist-atalho" data-v="${k}">${t}</button>`).join('')}</div>
          <span class="spacer"></span>
          <button class="btn" data-act="hist-exportar" ${carregado ? '' : 'disabled'}>${ic.baixar} Exportar planilha</button>
          ${S.papel === 'admin' ? `<button class="btn" data-act="hist-limpar" ${carregado ? '' : 'disabled'} title="Tira os registros da lista sem apagar">${ic.lixo} Limpar período</button>` : ''}
        </div>
      </section>
      <div class="row between"><div class="seg" role="group" aria-label="Seção do histórico">${seg.map(([k, t]) => `<button type="button" data-act="aba-hist" data-v="${k}" aria-pressed="${S.f.hist === k}">${t}${carregado ? `<span class="c">${filtrarHist(k, { envios: S.cache.envios, ativ: S.cache.hist, rotina: S.cache.rotina, seg: S.cache.seg || [] }[k]).length}</span>` : ''}</button>`).join('')}</div>
      <div class="row hist-filtros"><div class="search">${ic.busca}<input type="search" id="hist-busca" placeholder="Buscar em tudo, inclusive limpos" value="${esc(S.f.histBusca || '')}" aria-label="Buscar no histórico"></div>
        ${carregado ? (() => { const n = ({ envios: S.cache.envios, ativ: S.cache.hist, rotina: S.cache.rotina, seg: S.cache.seg }[S.f.hist] || []).filter((x) => x.arquivado_em).length;
          return n ? `<div class="seg" role="group" aria-label="Registros limpos"><button type="button" data-act="hist-limpos" data-v="0" aria-pressed="${!S.f.histLimpos}">Ocultar limpos</button><button type="button" data-act="hist-limpos" data-v="1" aria-pressed="${!!S.f.histLimpos}">Mostrar limpos<span class="c">${n}</span></button></div>` : ''; })() : ''}</div>
      ${S.f.hist === 'ativ' ? `<select id="hist-forn" aria-label="Filtrar por fornecedor" style="width:auto;max-width:320px"><option value="">Todos os fornecedores</option>${S.base.fornecedores.map((f) => `<option value="${f.id}" ${S.f.histForn === f.id ? 'selected' : ''}>${esc(f.nome)}</option>`).join('')}</select>` : ''}
      ${S.f.hist === 'rotina' ? `<button class="btn" data-act="executar-rotina">${ic.refazer} Executar agora</button>` : ''}</div>`;
    if (!carregado) return topo + '<section class="panel"><div class="empty"><p>Carregando o histórico do período…</p></div></section>';
    const periodoTxt = `de ${U.dataBR(p.de)} a ${U.dataBR(p.ate)}`;
    const aviso = String(S.f.histBusca || '').trim() ? '<p class="small muted hist-aviso">A busca inclui os registros limpos (marcados como “limpo”).</p>' : '';
    const tagLimpo = (x) => (x.arquivado_em ? ` <span class="chip plain" title="${esc(limpoTxt(x))}">Limpo</span>` : '');
    if (S.f.hist === 'envios') {
      const grupos = {};
      filtrarHist('envios', S.cache.envios).forEach((e) => { (grupos[e.competencia] = grupos[e.competencia] || []).push(e); });
      const comps = Object.keys(grupos).sort().reverse();
      return topo + aviso + (comps.length ? comps.map((c) => `<section class="panel"><div class="panel-head"><div><h2>${esc(U.compLabel(c))}</h2><span class="sub">${grupos[c].length} envio${grupos[c].length > 1 ? 's' : ''} no período</span></div></div>
        <div class="table-wrap"><table class="tbl"><thead><tr><th>Fornecedor</th><th>Tipo</th><th>Para</th><th>Assunto</th><th>Enviado em</th><th>Entrega</th></tr></thead><tbody>
        ${grupos[c].map((e) => `<tr class="click" data-act="ver-envio" data-s="${e.id}"><td class="cell-title">${esc(F(e.fornecedor_id).nome)}</td>
          <td class="small">${esc(tipoEnvioTxt(e))}</td><td class="small">${esc((e.para || []).join(', '))}</td>
          <td class="small m-menos">${esc(e.assunto || '')}</td><td class="num small">${U.dataHoraBR(e.created_at)}</td><td>${chipEnvio(e)}${tagLimpo(e)}</td></tr>`).join('')}
        </tbody></table></div></section>`).join('') : `<section class="panel"><div class="empty"><h3>Nenhum e-mail ${esc(periodoTxt)}</h3><p>Constam aqui os envios feitos pelo app e os envios pelo Outlook registrados no sistema.</p></div></section>`);
    }
    if (S.f.hist === 'ativ') {
      const lista = filtrarHist('ativ', S.cache.hist.filter((h) => !S.f.histForn || h.fornecedor_id === S.f.histForn));
      return topo + aviso + `<section class="panel"><div class="panel-body"><div class="timeline">${lista.slice(0, 500).map(itemHist).join('') || `<p class="muted">Nenhuma atividade ${esc(periodoTxt)}.</p>`}</div>
        ${lista.length > 500 ? `<p class="small muted" style="margin-top:10px">Exibindo 500 de ${lista.length} registros. A planilha exportada contém todos.</p>` : ''}</div></section>`;
    }
    if (S.f.hist === 'seg') {
      const lista = filtrarHist('seg', S.cache.seg || []), nv = lista.filter((e) => !e.visto_em && e.gravidade !== 'info').length;
      return topo + aviso + `<section class="panel"><div class="panel-head"><div><h2>Tentativas bloqueadas e alertas</h2>
          <span class="sub">O banco registra sozinho: links inválidos repetidos, senha errada repetida, busca de contas, excesso de pedidos, conta criada com e-mail de outra pessoa e o que a verificação de segurança encontrar. Os registros não podem ser apagados.</span></div>
          ${nv ? `<button class="btn sm" data-act="seg-vistos">${ic.ok} Marcar ${nv} como visto${nv > 1 ? 's' : ''}</button>` : ''}</div>
        <div class="table-wrap"><table class="tbl tbl-seg"><thead><tr><th>Quando</th><th>Gravidade</th><th>O que aconteceu</th><th>Origem</th><th>Visto</th></tr></thead><tbody>
        ${lista.slice(0, 500).map((e) => `<tr${!e.visto_em && e.gravidade !== 'info' ? ' class="seg-novo"' : ''}><td class="num small">${U.dataHoraBR(e.created_at)}</td><td>${chipSeg(e.gravidade)}</td>
          <td><div class="cell-title" style="font-weight:500">${esc(e.tipo)}</div>${detalheSeg(e) ? `<div class="cell-sub">${esc(detalheSeg(e))}</div>` : ''}</td>
          <td class="small"><span class="mono">${esc(e.ip || '—')}</span>${e.email ? `<div class="cell-sub" style="overflow-wrap:anywhere">${esc(e.email)}</div>` : ''}</td>
          <td class="small">${e.visto_em ? `${U.dataBR(U.dataLocal(e.visto_em))}${e.visto_por ? `<div class="cell-sub">${esc(e.visto_por)}</div>` : ''}` : '<span class="muted">—</span>'}</td></tr>`).join('')
          || `<tr><td colspan="5" class="muted">Nenhuma tentativa bloqueada ${esc(periodoTxt)}.</td></tr>`}</tbody></table></div></section>`;
    }
    return topo + aviso + `<section class="panel"><div class="panel-head"><div><h2>Execuções da rotina</h2><span class="sub">08:00 e 16:00 · encerramento de links vencidos, conferência de envios e avisos</span></div></div>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Executado em</th><th>Origem</th><th>Resultado</th></tr></thead><tbody>
      ${filtrarHist('rotina', S.cache.rotina).map((r) => `<tr><td class="num">${U.dataHoraBR(r.executado_em)}</td><td>${esc(r.origem)}${tagLimpo(r)}</td><td class="small" ${(r.detalhes || {}).ok === false ? 'style="color:var(--crit)"' : ''}>${esc(resultadoRotina(r))}</td></tr>`).join('')
        || `<tr><td colspan="3" class="muted">Nenhuma execução ${esc(periodoTxt)}.</td></tr>`}</tbody></table></div></section>`;
  };
  function verEnvio(id) {
    const e = (S.cache.envios || []).find((x) => x.id === id);
    if (!e) return;
    S.gaveta = { tipo: 'envio', id };
    gaveta(`<div class="drawer-head"><div class="t"><span class="label">${e.avaliacao_id ? 'Avaliação de satisfação · ' : e.solicitacao_nf_id ? 'Pedido de nota fiscal · ' : ''}${esc(TIPO_ENVIO[e.tipo] || e.tipo)} ${esc(VIA_ENVIO[e.via])} · ${esc(U.compLabel(e.competencia))}</span><h2>${esc(F(e.fornecedor_id).nome)}</h2>
      <div class="row">${chipEnvio(e)}<span class="small muted">${U.dataHoraBR(e.created_at)} · por ${esc(e.autor || 'sistema')}</span></div></div>
      <button class="icon-btn" data-act="fechar-gaveta" aria-label="Fechar">${ic.x}</button></div>
      <div class="drawer-body">${e.erro ? `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><span>${esc(e.erro)}</span></div>`
        : e.entrega_detalhe ? `<p class="small muted" style="margin:0">${esc(e.entrega_detalhe)}${e.entrega_em ? ' · ' + U.dataHoraBR(e.entrega_em) : ''}</p>` : ''}
        <div class="email-preview"><div class="hdr">
        <div class="row"><span class="k label">Para</span><span>${esc((e.para || []).join(', '))}</span></div>
        <div class="row"><span class="k label">Assunto</span><span>${esc(e.assunto || '')}</span></div>
        <div class="row"><span class="k label">Prazo</span><span>${e.prazo_ate ? U.dataBR(U.dataLocal(e.prazo_ate)) : '—'}</span></div></div>
        <div style="padding:14px;white-space:pre-wrap;overflow-wrap:anywhere;font-size:.92rem">${esc(e.corpo || '')}</div></div></div>
      <div class="drawer-foot"><button class="btn" data-act="fechar-gaveta">Fechar</button><span class="spacer"></span>
        ${S.papel === 'admin' && e.status !== 'pendente' ? `<button class="btn danger" data-act="envio-excluir" data-id="${e.id}">${ic.lixo} Excluir registro</button>` : ''}</div>`);
  }

  // =====================================================================
  //  CONFIGURAÇÕES
  // =====================================================================
  // Equipes (convites para aceitar) e pastas sob a responsabilidade da pessoa, dentro do perfil
  function blocoEquipesPastas() {
    const conv = meusConvites(), minhas = S.base.equipes.filter((e) => minhasEquipes().includes(e.id)), assumidas = S.base.pastas.filter(minhaPasta);
    return `<div class="perfil-extra" id="conf-equipes">
        <div class="row between"><b>Minhas equipes</b>${podeAprovar() ? `<button class="btn sm ghost" data-act="ir-equipes">${ic.pessoas} Gerenciar equipes</button>` : ''}</div>
        ${conv.map((m) => { const e = S.mapEq[m.equipe_id]; return `<div class="convite"><span class="pasta-ic" aria-hidden="true">${ic.pessoas}</span>
          <div style="min-width:0"><b>Convite: ${esc(e.nome)}</b><div class="small muted">De ${esc(nomeEquipe(m.convidado_por || e.criado_por))} em ${U.dataHoraBR(m.convidado_em)}${e.descricao ? ' · ' + esc(e.descricao) : ''}</div></div>
          <div class="row" style="gap:6px"><button class="btn sm" data-act="convite-recusar" data-id="${e.id}">Recusar</button><button class="btn sm primary" data-act="convite-aceitar" data-id="${e.id}">${ic.ok} Aceitar</button></div></div>`; }).join('')}
        <div class="mails">${minhas.map((e) => `<span class="tag">${esc(e.nome)}${e.criado_por === EU() ? '' : ` <button type="button" class="tag-x" data-act="equipe-sair" data-id="${e.id}" title="Sair da equipe" aria-label="Sair da equipe ${esc(e.nome)}">${ic.x}</button>`}</span>`).join('') || (conv.length ? '' : '<span class="small muted">Você não participa de nenhuma equipe.</span>')}</div>
      </div>
      <div class="perfil-extra" id="conf-pastas">
        <div class="row between"><b>Pastas sob sua responsabilidade</b><button class="btn sm ghost" data-act="ir-pastas">${ic.pasta} Pastas</button></div>
        <div class="small muted">${assumidas.length ? `Você é responsável por <b>${esc(assumidas.map((p) => p.nome).join(', '))}</b>: a cada disparo, o resumo vai para o seu e-mail de aviso.`
          : 'Nenhuma. O responsável de cada pasta é escolhido na própria pasta (menu Pastas).'}</div>
      </div>`;
  }
  // Link do fornecedor (validade e contatos mostrados), ao lado da cobrança
  function painelLinkFornecedor(sup) {
    return `<section class="panel" id="conf-link">
          <div class="panel-head"><div><h2>Link do fornecedor</h2><span class="sub">Uso único · encerrado pela rotina das 08:00 e 16:00</span></div></div>
          <div class="panel-body stack">
            <div class="row" style="align-items:flex-end"><label class="field" style="flex:0 1 200px"><span>Validade (dias úteis)</span><input type="number" id="cf-prazo" min="1" max="30" value="${esc(prazoDias())}"></label>
              <button class="btn primary" data-act="salvar-prazo">${ic.ok} Salvar prazo</button></div>
            <div class="field"><span>Contatos Klingele para o fornecedor <span class="hint">(até 5)</span></span>
              <p class="small muted">Aparecem na página do link e no e-mail (<span class="mono">{SUPORTE}</span>).</p>
              <div class="mails" style="margin:4px 0">${sup.map((c) => `<span class="tag">${esc(c.nome)}${c.cargo ? ' · ' + esc(c.cargo) : ''}</span>`).join('') || '<span class="small muted">Nenhum contato marcado para o fornecedor.</span>'}</div>
              <div class="row"><button class="btn" data-act="ir-colab">${ic.pessoas} Editar contatos Klingele</button></div></div>
          </div>
        </section>`;
  }
  function painelPerfil(cad, titulo, extras) {
    return `<section class="panel">
          <div class="panel-head"><div><h2>${titulo || 'Meu perfil'}</h2><span class="sub">${esc((S.user || {}).email || '')}${cad.usuario ? ` · usuário <span class="mono">${esc(cad.usuario)}</span>` : ''} · ${esc(PAPEL[S.papel] || S.papel || '')}</span></div></div>
          <div class="panel-body form-grid">
            <label class="field"><span>Nome</span><input type="text" id="mp-nome" maxlength="120" value="${esc(cad.nome || '')}"></label>
            <label class="field"><span>Telefone</span><input type="tel" id="mp-tel" maxlength="60" value="${esc(cad.telefone || '')}"></label>
            <label class="field full"><span>E-mail de aviso <span class="hint">(recebe a NF encaminhada a Serviços das F.S. que você aprovar; vazio = seu e-mail de login)</span></span>
              <input type="email" id="mp-aviso" maxlength="254" value="${esc(cad.email_aviso || '')}" placeholder="${esc((S.user || {}).email || '')}"></label>
            <div class="full row"><button class="btn primary" data-act="salvar-perfil">${ic.ok} Salvar</button>
              <button class="btn" data-act="trocar-senha">${ic.lapis} Trocar senha</button></div>
          </div>
          ${extras ? `<div class="panel-body stack perfil-extras">${blocoEquipesPastas()}</div>` : ''}
        </section>`;
  }
  // Quem não é administrador vê apenas a própria conta: perfil, visão "Meus contratos" e verificação em duas etapas
  function confPessoal() {
    const cad = S.cad || {}, sup = meuSupervisor(), n = sup ? S.base.contratos.filter((c) => supsDe(c).includes(sup) && c.situacao === 'ativo').length : 0;
    return `<div class="grid-2" id="conf-perfil">
        ${painelPerfil(cad, 'Seus dados')}
        <section class="panel">
          <div class="panel-head"><div><h2>Minha conta</h2><span class="sub">Acesso ${esc((PAPEL[S.papel] || '').toLowerCase())}${S.papel === 'leitura' ? ': consulta, sem alterações' : ''}</span></div></div>
          <div class="panel-body stack">
            ${S.papel === 'supervisor' ? `<div><b>Supervisor</b><div class="small muted">Ligado ao administrador <b>${esc(cad.admin || '—')}</b>. Você aprova, em Usuários, os cadastros encaminhados a você (ou a qualquer responsável) como analista ou somente leitura.</div></div>` : ''}
            <div><b>Meus contratos</b><div class="small muted">${temEscopo() ? `${sup ? `Supervisor: <b>${esc(COL(sup).nome)}</b> · ${n} contrato${n !== 1 ? 's' : ''} ativo${n !== 1 ? 's' : ''}. ` : ''}${meuColab() ? `Contato Klingele: <b>${esc(COL(meuColab()).nome)}</b>. ` : ''}Use “Meus contratos” no topo das telas para ver só os seus (e os fornecedores das suas pastas).`
              : 'Sem supervisor ou contato Klingele ligado ao seu usuário. Peça a um administrador para ligar em Usuários, ou assuma uma pasta abaixo; depois, “Meus contratos” aparece no topo das telas.'}</div></div>
            <div class="row between" style="flex-wrap:nowrap"><div><b>Verificação em duas etapas</b><div class="small muted">Código do aplicativo autenticador a cada login nesta conta.</div></div>
              <span id="mfa-status" class="row" style="flex-wrap:nowrap">${DEMO ? '<span class="small muted">No site publicado</span>' : '<span class="small muted">Verificando…</span>'}</span></div>
            <p class="small muted">A sessão encerra após ${INATIVIDADE_MIN} minutos sem uso. As configurações do sistema (e-mails, modelos, rotina e prazos) ficam com os administradores.</p>
            ${blocoEquipesPastas()}
          </div>
        </section>
      </div>`;
  }
  VIEWS.conf = () => {
    if (S.papel !== 'admin') return confPessoal();
    const ano = U.hojeISO().slice(0, 4);
    const fer = S.base.feriados.filter((f) => f.data >= `${ano}-01-01`);
    const exemplo = S.base.fornecedores.find((f) => f.deseja_enviar) || S.base.fornecedores[0];
    const prev = exemplo ? U.montarEmail({ modeloAssunto: cfgv('modelo_assunto', ''), modeloCorpo: cfgv('modelo_corpo', ''), fornecedor: exemplo.nome, competencia: S.comp,
      servicos: contratosPrevistos(exemplo.id), link: '[link único do fornecedor]', prazoISO: U.fimPrazoISO(new Date().toISOString(), prazoDias(), S.fer), prazoDias: prazoDias(),
      suporte: contatosFornecedor(), suporteServicos: servicosSuporte(contratosPrevistos(exemplo.id)) }) : null;
    const sup = contatosFornecedor();
    const padrao = padraoAval() || {};
    const exAval = S.base.contratos.find((c) => c.situacao === 'ativo' && COL(c.supervisor_id));
    const prevAval = exAval ? U.montarEmailAvaliacao({ modeloAssunto: cfgv('modelo_aval_assunto', ''), modeloCorpo: cfgv('modelo_aval_corpo', ''), supervisor: COL(exAval.supervisor_id).nome,
      fornecedor: F(exAval.fornecedor_id).nome, competencia: S.comp, servicos: [exAval], link: '[link único do supervisor]',
      prazoISO: U.fimPrazoISO(new Date().toISOString(), prazoAval(), S.fer), prazoDias: prazoAval() }) : null;
    const campos = (l) => `<details class="campos"><summary>Campos automáticos (${l.length})</summary><div>${l.map((k) => `<span class="mono">{${k}}</span>`).join(' ')}</div></details>`;
    const secoes = [['conf-perfil', 'Meu perfil e cadastro'], ['conf-fluxo', 'Link e cobrança'], ['conf-fs', 'Encaminhamento a Serviços'], ['conf-venc', 'Vencimentos'], ['conf-modelo', 'Modelo do e-mail'],
      ['conf-email', 'Envio pelo app'], ['conf-seg', 'Segurança'], ['conf-fer', 'Feriados e rotina'], ['conf-nf', 'Nota fiscal'], ['conf-aval', 'Avaliação']];
    const cad = S.cad || {};
    const exM = S.med.find((m) => m.folha_numero) || S.med[0];
    const exNota = exM ? notaAtual(exM.id) : null;
    const prevFS = exM ? U.montarEmailFS({ modeloAssunto: cfgv('modelo_fs_assunto', ''), modeloCorpo: cfgv('modelo_fs_corpo', ''), fornecedor: F(exM.fornecedor_id).nome, competencia: exM.competencia,
      pedido: C(exM.contrato_id).pedido, servico: C(exM.contrato_id).titulo, folha: exM.folha_numero || 'FS-0000', folhaData: exM.folha_data, parcela: exM.parcela || 1,
      parcelasTotal: C(exM.contrato_id).parcelas_total, valor: exM.folha_valor ?? exM.valor_aprovado, aprovadoPor: (S.user || {}).email,
      anexos: [{ nome: 'nota-fiscal.pdf' }, { nome: 'NF.xml' }, { nome: 'folha-de-servico.pdf' }],
      nfModelo: exNota ? exNota.modelo : 'nfe', nfNumero: exNota ? exNota.numero : '1234', nfSerie: exNota ? exNota.serie : null, nfValor: exNota ? exNota.valor : exM.valor_aprovado,
      nfEmissao: exNota ? exNota.data_emissao : U.hojeISO() }) : null;
    const sw = (k, txt, sub) => `<div class="row between" style="flex-wrap:nowrap"><div><b>${txt}</b>${sub ? `<div class="small muted">${sub}</div>` : ''}</div>
      <label class="switch"><input type="checkbox" data-cfg="${k}" ${cfgv(k, 'true') === 'true' ? 'checked' : ''} aria-label="${esc(txt)}"><i></i></label></div>`;
    const num = (id, k, rot, min, max, p, hint) => `<label class="field"><span>${rot}</span><input type="number" id="${id}" min="${min}" max="${max}" value="${esc(cfgv(k, p))}">${hint ? `<span class="hint">${hint}</span>` : ''}</label>`;
    return `
      <nav class="conf-nav" aria-label="Seções das configurações">${secoes.map(([id, t]) => `<button type="button" class="btn sm" data-act="ir-sec" data-alvo="${id}">${t}</button>`).join('')}</nav>
      <div class="grid-2" id="conf-perfil">
        ${painelPerfil(cad, null, true)}
        <section class="panel" id="conf-cad">
          <div class="panel-head"><div><h2>Cadastro de usuários</h2><span class="sub">Contas criadas no site aguardam a aprovação do responsável escolhido (administrador ou supervisor) ou de qualquer perfil de administração</span></div>
            ${S.papel === 'admin' ? `<button class="btn sm" data-view="usuarios">${ic.usuarios} Usuários${S.usuarios.filter((u) => u.status === 'pendente').length ? ` (${S.usuarios.filter((u) => u.status === 'pendente').length})` : ''}</button>` : ''}</div>
          <div class="panel-body stack">
            ${sw('cadastro_aberto', 'Permitir criar conta pelo site', 'Quando desativado, somente usuários já cadastrados têm acesso.')}
            <label class="field"><span>Domínios de e-mail aceitos <span class="hint">(separados por vírgula; vazio = qualquer e-mail, ainda com aprovação)</span></span>
              <input type="text" id="cc-dominios" maxlength="300" value="${esc(cfgv('cadastro_dominios', ''))}" placeholder="klingele.com.br"></label>
            <div class="row"><button class="btn primary" data-act="salvar-cadastro">${ic.ok} Salvar</button></div>
            <p class="hint" style="margin:0">Quem tem acesso, perfis e equipes: em Usuários.</p>
          </div>
        </section>
      </div>
      <div class="grid-2" id="conf-fluxo">
        ${painelLinkFornecedor(sup)}
        <section class="panel">
          <div class="panel-head"><div><h2>Cobrança de quem não respondeu</h2><span class="sub">No horário do Envio mensal, somente em dias úteis, para os links das pastas com cobrança ligada (opção de cada pasta).</span></div></div>
          <div class="panel-body stack">
            ${sw('cobranca_automatica', 'Cobrança automática', 'Requer o envio pelo app configurado.')}
            <div class="form-grid">
              ${num('cb-reenvio', 'cobranca_reenvio_dias', '1ª cobrança: novo prazo (dias úteis)', 1, 30, '10', 'Vencido o prazo do link, reenvia com este prazo.')}
              ${num('cb-max', 'cobranca_lembretes_max', 'Lembretes semanais (quantidade)', 0, 12, '4', 'Depois do novo prazo, ao longo do mês.')}
              ${num('cb-int', 'cobranca_intervalo_dias', 'Intervalo dos lembretes (dias)', 1, 30, '7', '7 = uma vez por semana.')}
              ${num('cb-sem', 'cobranca_semanal_dias', 'Prazo de cada lembrete (dias úteis)', 1, 30, '5', 'O link fica válido até o próximo lembrete.')}
            </div>
            <div class="row"><button class="btn primary" data-act="salvar-fluxo">${ic.ok} Salvar</button></div>
          </div>
        </section>
      </div>
      <div class="grid-2" id="conf-fs">
        <section class="panel">
          <div class="panel-head"><div><h2>Encaminhamento da NF a Serviços</h2><span class="sub">Fim do processo: a NF do fornecedor vai a Serviços depois da aprovação da F.S., com a NF, o XML e a F.S. em anexo</span></div></div>
          <div class="panel-body stack">
            ${sw('nf_encaminhar_automatico', 'Encaminhamento automático', 'Com a F.S. aprovada, a NF vai sozinha quando chega sem alertas (ou depois da conferência). Desligado: botão "Encaminhar a Serviços".')}
            <label class="field"><span>Serviços <span class="hint">(até 10, separados por vírgula)</span></span><input type="text" id="fs-servicos" maxlength="1000" value="${esc(cfgv('fs_emails_servicos', ''))}" placeholder="servicos@klingele.com.br"></label>
            <label class="field"><span>Ocorrência <span class="hint">(até 10)</span></span><input type="text" id="fs-ocorrencia" maxlength="1000" value="${esc(cfgv('fs_emails_ocorrencia', ''))}" placeholder="ocorrencia@klingele.com.br"></label>
            <label class="field"><span>Assunto</span><input type="text" id="fs-assunto" maxlength="400" value="${esc(cfgv('modelo_fs_assunto', ''))}"></label>
            <label class="field"><span>Corpo</span><textarea id="fs-corpo" rows="9" style="min-height:200px">${esc(cfgv('modelo_fs_corpo', ''))}</textarea></label>
            ${campos(['FORNECEDOR', 'PEDIDO', 'SERVICO', 'MES', 'ANO', 'FOLHA', 'PARCELA', 'VALOR', 'APROVADO_POR', 'NF_TIPO', 'NF_NUMERO', 'NF_VALOR', 'NF_EMISSAO', 'DESCRICAO', 'ANEXOS'])}
            <div class="row"><button class="btn primary" data-act="salvar-conf-fs">${ic.ok} Salvar</button></div>
          </div>
        </section>
        <details class="panel" ${telaLarga() ? 'open' : ''}>
          <summary class="panel-head" style="cursor:pointer"><div><h2>Prévia do e-mail a Serviços</h2><span class="sub">${exM ? esc(F(exM.fornecedor_id).nome) : ''}</span></div></summary>
          <div class="panel-body">${prevFS ? `<p class="cell-title" style="margin-bottom:10px">${esc(prevFS.assunto)}</p><div style="white-space:pre-wrap;font-size:.9rem;color:var(--ink-2);overflow-wrap:anywhere">${esc(prevFS.corpo)}</div>` : '<p class="muted">Sem medição no mês.</p>'}</div>
        </details>
      </div>
      <div class="grid-2" id="conf-venc">
        <section class="panel">
          <div class="panel-head"><div><h2>Aviso de vencimento dos contratos</h2><span class="sub">Enviado ao supervisor do contrato e à lista abaixo pela rotina das 08:00 e 16:00</span></div></div>
          <div class="panel-body stack">
            ${sw('alerta_venc_automatico', 'Aviso automático', 'Um aviso por contrato e data final.')}
            <div class="form-grid">
              ${num('av-longo', 'alerta_venc_longo_dias', 'Contratos longos e spot: avisar (dias antes)', 1, 999, '42')}
              ${num('av-curto', 'alerta_venc_curto_dias', 'Contratos curtos: avisar (dias antes)', 1, 999, '14', '7 a 14 = uma a duas semanas.')}
              ${num('av-limite', 'alerta_venc_limite_curto', 'Contrato curto: até quantos dias de duração', 1, 999, '42', 'Acima disso o contrato é longo.')}
            </div>
            <label class="field"><span>Também avisar <span class="hint">(até 10 e-mails, separados por vírgula)</span></span><input type="text" id="av-emails" maxlength="1000" value="${esc(cfgv('alerta_venc_emails', ''))}" placeholder="contratos@klingele.com.br"></label>
            <p class="hint">Cada contrato pode ter a sua antecedência (Contratos > Aviso de vencimento).</p>
          </div>
        </section>
        <section class="panel">
          <div class="panel-head"><div><h2>E-mail do aviso de vencimento</h2>${campos(['SUPERVISOR', 'FORNECEDOR', 'PEDIDO', 'SERVICO', 'DATA_INICIO', 'DATA_FIM', 'DIAS'])}</div></div>
          <div class="panel-body stack">
            <label class="field"><span>Assunto</span><input type="text" id="av-assunto" maxlength="400" value="${esc(cfgv('modelo_venc_assunto', ''))}"></label>
            <label class="field"><span>Corpo</span><textarea id="av-corpo" rows="9" style="min-height:200px">${esc(cfgv('modelo_venc_corpo', ''))}</textarea></label>
            <div class="row"><button class="btn primary" data-act="salvar-conf-venc">${ic.ok} Salvar</button></div>
          </div>
        </section>
      </div>
      <div class="grid-2" id="conf-modelo">
        <section class="panel">
          <div class="panel-head"><div><h2>Modelo do e-mail</h2>${campos(['FORNECEDOR', 'MES', 'ANO', 'SERVICOS', 'LINK', 'PRAZO_DIAS', 'PRAZO_DATA', 'SUPORTE'])}</div></div>
          <div class="panel-body stack">
            <label class="field"><span>Assunto</span><input type="text" id="cf-assunto" value="${esc(cfgv('modelo_assunto', ''))}"></label>
            <label class="field"><span>Corpo</span><textarea id="cf-corpo" rows="14" style="min-height:280px">${esc(cfgv('modelo_corpo', ''))}</textarea></label>
            <div class="row"><button class="btn primary" data-act="salvar-modelo">${ic.ok} Salvar modelo</button></div>
          </div>
        </section>
        <details class="panel" ${telaLarga() ? 'open' : ''}>
          <summary class="panel-head" style="cursor:pointer"><div><h2>Prévia</h2><span class="sub">${exemplo ? esc(exemplo.nome) + ' · ' + esc(U.compLabel(S.comp)) : ''}</span></div></summary>
          <div class="panel-body">${prev ? `<p class="cell-title" style="margin-bottom:10px">${esc(prev.assunto)}</p><div style="white-space:pre-wrap;font-size:.9rem;color:var(--ink-2);overflow-wrap:anywhere">${esc(prev.corpo)}</div>` : ''}</div>
        </details>
      </div>
      <section class="panel" id="conf-email">
          <div class="panel-head"><div><h2>Envio de e-mail pelo app</h2><span class="sub">Necessário para o envio pelo app e para o envio automático</span></div>
            <div class="row">${S.emailCfg && S.emailCfg.chave ? chip('ok', 'Chave cadastrada') : chip('warn', 'Sem chave')}${podeEnviarPeloApp() ? chip('ok', 'Envio habilitado') : ''}</div></div>
          <div class="panel-body email-cols"><div class="form-grid">
            <label class="field"><span>Serviço de e-mail</span><select id="ce-provedor">${[['resend', 'Resend'], ['brevo', 'Brevo']].map(([k, t]) => `<option value="${k}" ${cfgv('email_provedor', 'resend') === k ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
            <label class="field"><span>Nome do remetente</span><input type="text" id="ce-nome" maxlength="80" value="${esc(cfgv('email_remetente_nome', 'Klingele Paper & Packing'))}"></label>
            <label class="field"><span>E-mail do remetente <span class="hint">(verificado)</span></span><input type="email" id="ce-remetente" maxlength="254" value="${esc(cfgv('email_remetente', ''))}" placeholder="contratos@empresa.com.br"></label>
            <label class="field"><span>Responder para <span class="hint">(recebe as respostas)</span></span><input type="email" id="ce-resposta" maxlength="254" value="${esc(cfgv('email_resposta', ''))}" placeholder="seu.email@empresa.com.br"></label>
            <label class="field"><span>Cópia de cada envio para</span><input type="email" id="ce-copia" maxlength="254" value="${esc(cfgv('email_copia', ''))}" placeholder="opcional"></label>
            <label class="field"><span>Limite de e-mails por dia <span class="hint">(app e envio automático)</span></span><input type="number" id="ce-limite" min="1" max="5000" value="${esc(cfgv('email_limite_dia', '300'))}"></label>
            <label class="field"><span>Endereço do site <span class="hint">(usado no link)</span></span>
              <div class="row" style="flex-wrap:nowrap"><input type="text" id="ce-site" maxlength="200" value="${esc(cfgv('site_url', ''))}" placeholder="https://seu-site.netlify.app"><button class="btn sm" type="button" data-act="usar-site">Usar este</button></div></label>
            <label class="field full"><span>Chave da API do serviço <span class="hint">(armazenada com criptografia; não é exibida novamente)</span></span>
              <input type="password" id="ce-chave" autocomplete="off" maxlength="400" placeholder="${S.emailCfg && S.emailCfg.chave ? 'Chave cadastrada. Informe outra somente para substituí-la.' : 'Cole a chave da API'}"></label>
            <div class="full row"><button class="btn primary" data-act="salvar-email">${ic.ok} Salvar</button></div>
          </div>
          ${blocoWebhook()}</div>
        </section>
      <section class="panel" id="conf-seg">
        <div class="panel-head"><div><h2>Segurança</h2><span class="sub">Verificação em duas etapas, proteções do sistema e verificação do banco</span></div></div>
        <div class="panel-body seg-cols"><div class="stack">
            <div class="row between" style="flex-wrap:nowrap"><div><b>Verificação em duas etapas</b><div class="small muted">Código do aplicativo autenticador a cada login nesta conta.</div></div>
              <span id="mfa-status" class="row" style="flex-wrap:nowrap">${DEMO ? '<span class="small muted">No site publicado</span>' : '<span class="small muted">Verificando…</span>'}</span></div>
            <div class="row between" style="flex-wrap:nowrap"><div><b>Exigir de toda a equipe</b><div class="small muted">Quem não ativar não vê os dados. Ative na sua conta antes.</div></div>
              <label class="switch"><input type="checkbox" data-chg="exigir-mfa" ${cfgv('exigir_mfa', 'false') === 'true' ? 'checked' : ''} aria-label="Exigir verificação em duas etapas"><i></i></label></div>
            <details class="campos"><summary>Proteções ativas (10)</summary>
            <ul class="small" style="margin:6px 0 0;padding-left:18px;display:grid;gap:4px;color:var(--ink-2)">
              <li>Sessão encerra após ${INATIVIDADE_MIN} minutos sem uso e ao fechar o navegador.</li>
              <li>Perfis: admin, supervisor, analista e somente leitura; o banco confere cada ação. Só a conta aprovada do e-mail tem acesso (conta nova com o e-mail de outra pessoa não herda nada).</li>
              <li>Entrar pelo usuário: o e-mail só é devolvido com a senha certa; 10 senhas erradas bloqueiam o usuário por 15 minutos; limite por IP real (o IP escrito pelo navegador não vale).</li>
              <li>Cadastros repetidos barrados no banco: CNPJ, nome de fornecedor (sem acento, LTDA, ME...), e-mail de contato e e-mail da equipe.</li>
              <li>Tentativas bloqueadas ficam registradas em Histórico > Segurança, sem possibilidade de apagar.</li>
              <li>Link do fornecedor: uso único, prazo, bloqueio após 15 links inválidos por hora e até 20 tentativas de envio por hora.</li>
              <li>Arquivos: apenas PDF, Excel, CSV, JPG e PNG, com conteúdo conferido, até 20 por link e 25 MB cada; arquivos repetidos exigem confirmação.</li>
              <li>Abrir documento e exportar planilha ficam registrados no histórico, que não pode ser editado.</li>
              <li>Limite de requisições na API: 240 por minuto por pessoa da equipe, 60 por minuto por IP nos links e teto geral; uploads até 100 por hora por IP.</li>
              <li>E-mails: até ${esc(cfgv('email_limite_dia', '300'))} por dia; envios em massa saem em lote para não estourar o limite do serviço de e-mail.</li>
            </ul></details>
</div>
          ${verificacaoHTML()}</div>
      </section>
      <div class="grid-2">
        <section class="panel" id="conf-fer">
          <div class="panel-head"><div><h2>Feriados e dias úteis</h2><span class="sub">Dias úteis: segunda a sexta-feira, exceto os feriados abaixo. Base dos prazos, do envio automático e da cobrança.</span></div></div>
          <div class="panel-body stack">
            <p class="small muted" style="margin:0">Hoje é ${esc(U.DIAS_SEMANA[U.diaSemana(U.hojeISO())])}, ${U.dataBR(U.hojeISO())}. Último dia útil deste mês: <b>${U.dataBR(U.ultimoDiaUtil(U.compDe(U.hojeISO()), S.fer))}</b>.</p>
            <div class="row"><input type="date" id="cf-f-data" style="width:auto" aria-label="Data">
              <input type="text" id="cf-f-nome" maxlength="120" placeholder="Descrição (ex.: feriado municipal)" style="flex:1 1 200px;width:auto" aria-label="Descrição">
              <button class="btn" data-act="add-feriado">${ic.mais} Adicionar</button></div>
            <div class="table-wrap" style="max-height:360px;overflow-y:auto"><table class="tbl" data-sem-cartao><tbody>${fer.map((f) => `<tr><td class="num">${U.dataBR(f.data)}<div class="cell-sub">${U.DIAS_SEMANA[U.diaSemana(f.data)]}</div></td><td style="overflow-wrap:anywhere">${esc(f.nome)}</td>
              <td class="r"><button class="icon-btn" data-act="rm-feriado" data-d="${f.data}" aria-label="Remover data">${ic.lixo}</button></td></tr>`).join('')}</tbody></table></div>
          </div>
        </section>
        <section class="panel" id="conf-rotina">
          <div class="panel-head"><div><h2>Conexão e rotina</h2></div></div>
          <div class="panel-body stack">
            <dl class="kv"><dt>Modo</dt><dd>${DEMO ? 'Demonstração (dados locais)' : 'Supabase'}</dd>
              <dt>Projeto</dt><dd class="mono">${esc(cfg.supabaseUrl || '—')}</dd>
              <dt>Chave no navegador</dt><dd>Publicável (somente leitura do portal; dados protegidos por login)</dd>
              <dt>Rotina</dt><dd>08:00 e 16:00 (Brasília) pelo pg_cron, com chamada à API para manter o projeto ativo</dd></dl>
            <div class="row"><button class="btn" data-act="executar-rotina">${ic.refazer} Executar rotina agora</button>
              ${DEMO ? '<button class="btn danger" data-act="restaurar-demo">Restaurar dados de exemplo</button>' : ''}</div>
          </div>
        </section>
      </div>
      <div class="grid-2" id="conf-nf">
        <section class="panel">
          <div class="panel-head"><div><h2>Nota fiscal</h2><span class="sub">CNPJs aceitos como destinatário e prazo do link</span></div></div>
          <div class="panel-body stack">
            <label class="field"><span>CNPJs da Klingele <span class="hint">(um por linha, até 20; aceita alfanumérico)</span></span>
              <textarea id="cn-cnpjs" rows="4" maxlength="800" placeholder="00.000.000/0001-00">${esc(cnpjsKlingele().map(U.cnpj).join('\n'))}</textarea></label>
            <div class="row" style="align-items:flex-end"><label class="field" style="flex:0 1 220px"><span>Validade do link da NF (dias úteis)</span><input type="number" id="cn-prazo" min="1" max="30" value="${esc(prazoNF())}"></label>
              <button class="btn primary" data-act="salvar-conf-nf">${ic.ok} Salvar</button></div>
            <details class="campos"><summary>Como a nota é conferida (5)</summary>
            <ul class="small" style="margin:6px 0 0;padding-left:18px;display:grid;gap:4px;color:var(--ink-2)">
              <li>O link vai junto com a F.S. (número, parcela e descrição), depois de lançada. Arquivos da F.S. e o pedido de compra são opcionais.</li>
              <li>O fornecedor anexa pelo menos um arquivo (nota em PDF ou imagem, XML, fatura ou recibo), podendo enviar mais de um.</li>
              <li>NF-e com XML: o banco confere chave de acesso, emitente, destinatário, número, valor, pedido, ambiente e protocolo de autorização. Sem XML, a chave (se informada) é conferida e a nota segue com alerta.</li>
              <li>NFS-e: com XML do padrão nacional ou municipal os dados são lidos; sem XML, a nota segue com alerta para conferência no site da prefeitura.</li>
              <li>A assinatura digital não é validada aqui: use "Consultar na SEFAZ" na nota para a confirmação oficial.</li>
            </ul></details>
          </div>
        </section>
        <section class="panel">
          <div class="panel-head"><div><h2>E-mail da F.S. ao fornecedor (pedido da NF)</h2>${campos(['FORNECEDOR', 'MES', 'ANO', 'PEDIDO', 'SERVICO', 'PARCELA', 'PARCELAS', 'VALOR', 'FOLHA', 'DESCRICAO', 'CNPJ_KLINGELE', 'ANEXOS', 'LINK', 'PRAZO_DIAS', 'PRAZO_DATA', 'SUPORTE'])}</div></div>
          <div class="panel-body stack">
            <label class="field"><span>Assunto</span><input type="text" id="cn-assunto" maxlength="400" value="${esc(cfgv('modelo_nf_assunto', ''))}"></label>
            <label class="field"><span>Corpo</span><textarea id="cn-corpo" rows="12" style="min-height:260px">${esc(cfgv('modelo_nf_corpo', ''))}</textarea></label>
            <div class="row"><button class="btn primary" data-act="salvar-modelo-nf">${ic.ok} Salvar modelo</button></div>
          </div>
        </section>
      </div>
      <div class="grid-2" id="conf-aval">
        <section class="panel">
          <div class="panel-head"><div><h2>Resposta padrão e prazo</h2><span class="sub">Aplicada na ausência de resposta, com a observação "Resposta aprovada pelo supervisor (nome)"</span></div></div>
          <div class="panel-body stack">
            <div class="padrao-grid">${U.CATEGORIAS.map(([k, nome]) => `<label class="field"><span>${esc(nome)}</span><select data-padrao="${k}" aria-label="Nota padrão de ${esc(nome)}"><option value="">—</option>${Array.from({ length: 10 }, (_, i) => i + 1).map((n) => `<option ${padrao[k] === n ? 'selected' : ''}>${n}</option>`).join('')}</select></label>`).join('')}</div>
            <div class="nota-resumo"><span class="label">Nota geral padrão</span><span class="nota-badge sm ${U.classeNota(U.mediaNotas(padrao))}" id="padrao-media">${U.nota(U.mediaNotas(padrao))}</span></div>
            <div class="row" style="align-items:flex-end"><label class="field" style="flex:0 1 220px"><span>Validade do link (dias úteis)</span><input type="number" id="ca-prazo" min="1" max="30" value="${esc(prazoAval())}"></label>
              <button class="btn primary" data-act="salvar-padrao-aval">${ic.ok} Salvar</button>
              ${padraoAval() ? '<button class="btn ghost" data-act="limpar-padrao-aval">Remover resposta padrão</button>' : ''}</div>
          </div>
        </section>
        <section class="panel">
          <div class="panel-head"><div><h2>E-mail da avaliação ao supervisor</h2>${campos(['SUPERVISOR', 'FORNECEDOR', 'MES', 'ANO', 'SERVICOS', 'LINK', 'PRAZO_DIAS', 'PRAZO_DATA'])}</div></div>
          <div class="panel-body stack">
            <label class="field"><span>Assunto</span><input type="text" id="ca-assunto" maxlength="400" value="${esc(cfgv('modelo_aval_assunto', ''))}"></label>
            <label class="field"><span>Corpo</span><textarea id="ca-corpo" rows="12" style="min-height:240px">${esc(cfgv('modelo_aval_corpo', ''))}</textarea></label>
            <div class="row"><button class="btn primary" data-act="salvar-modelo-aval">${ic.ok} Salvar modelo</button></div>
            ${prevAval ? `<details><summary class="small" style="cursor:pointer">Prévia (${esc(F(exAval.fornecedor_id).nome)})</summary>
              <p class="cell-title" style="margin:10px 0 6px">${esc(prevAval.assunto)}</p><div class="small" style="white-space:pre-wrap;color:var(--ink-2);overflow-wrap:anywhere">${esc(prevAval.corpo)}</div></details>` : ''}
          </div>
        </section>
      </div>`;
  };

  // =====================================================================
  //  GAVETA, DICA E SIMULAÇÃO DO FORNECEDOR
  // =====================================================================
  function gaveta(html) {
    let g = document.getElementById('gaveta');
    if (!g) {
      g = document.createElement('div');
      g.id = 'gaveta';
      document.body.appendChild(g);
      document.body.style.overflow = 'hidden';
    }
    g.innerHTML = `<div class="backdrop" data-act="fechar-gaveta"></div><aside class="drawer" role="dialog" aria-modal="true">${html}</aside>`;
    rotularTabelas(g);
    ajustarRodape(g);
  }
  function fecharGaveta() {
    const g = document.getElementById('gaveta');
    if (g) g.remove();
    document.body.style.overflow = '';
    S.gaveta = null;
  }

  let tip = null;
  document.addEventListener('mouseover', (e) => {
    const t = e.target.closest('[data-tip]');
    if (!t) { if (tip) tip.hidden = true; return; }
    if (!tip) { tip = document.createElement('div'); tip.className = 'tip'; document.body.appendChild(tip); }
    const linhas = t.getAttribute('data-tip').split('\n');
    tip.innerHTML = `<b>${esc(linhas[0])}</b>${linhas.slice(1).map((l) => `<div>${esc(l)}</div>`).join('')}`;
    tip.hidden = false;
  });
  document.addEventListener('mousemove', (e) => {
    if (!tip || tip.hidden) return;
    // Telas muito grandes usam zoom na página (CSS): o mouse vem em pixels da tela e a posição é em pixels do layout
    const z = parseFloat(getComputedStyle(document.documentElement).zoom) || 1;
    const w = tip.offsetWidth * z, h = tip.offsetHeight * z;
    let x = e.clientX + 14, y = e.clientY + 14;
    if (x + w > window.innerWidth - 8) x = e.clientX - w - 14;
    if (y + h > window.innerHeight - 8) y = e.clientY - h - 14;
    tip.style.left = Math.max(8, x) / z + 'px'; tip.style.top = Math.max(8, y) / z + 'px';
  });

  function simular(sid, previa) {
    const s = S.solic.find((x) => x.id === sid);
    if (!s) return;
    fecharGaveta();
    const ov = document.createElement('div');
    ov.className = 'portal-overlay';
    ov.innerHTML = `<div class="sim-bar"><span>${previa ? '<b>Prévia do link</b> · o que o fornecedor vê; nada é gravado e o link não é marcado como aberto'
      : '<b>Simulação do fornecedor</b> · demonstração: o envio é registrado como se o fornecedor tivesse respondido'}</span><button class="btn sm" data-sim="fechar">${ic.x} Fechar</button></div><div id="sim-portal"></div>`;
    document.body.appendChild(ov);
    document.body.style.overflow = 'hidden';
    const fechar = async () => { ov.remove(); document.body.style.overflow = ''; if (!previa) { await recarregar(true); render(); } };
    ov.querySelector('[data-sim="fechar"]').addEventListener('click', fechar);
    Portal.montar(ov.querySelector('#sim-portal'), previa ? null : s.token, { api: API, simulacao: !previa, previaId: previa ? s.id : null, aoFechar: fechar });
  }

  // Página do colaborador (documentos da Klingele): prévia (nada é gravado) ou simulação na demonstração
  function simularDocs(sid, previa) {
    const s = S.solic.find((x) => x.id === sid);
    if (!s) return;
    fecharGaveta();
    const ov = document.createElement('div');
    ov.className = 'portal-overlay';
    ov.innerHTML = `<div class="sim-bar"><span>${previa ? '<b>Prévia da página do colaborador</b> · o que ele vê; nada é gravado'
      : '<b>Simulação do colaborador</b> · demonstração: a resposta é registrada como se o colaborador tivesse respondido'}</span><button class="btn sm" data-sim="fechar">${ic.x} Fechar</button></div><div id="sim-docs"></div>`;
    document.body.appendChild(ov);
    document.body.style.overflow = 'hidden';
    const fechar = async () => { ov.remove(); document.body.style.overflow = ''; await recarregar(true); render(); abrirSolicitacao(sid); };
    ov.querySelector('[data-sim="fechar"]').addEventListener('click', fechar);
    Documentos.montar(ov.querySelector('#sim-docs'), previa ? null : s.docs_token, { api: API, simulacao: !previa, previaId: previa ? s.id : null, aoFechar: fechar });
  }
  // Janela "Sem medição este mês": motivo e observação (o contrato continua ativo)
  function formularioDispensa(nome, comp) {
    return new Promise((ok) => {
      const w = document.createElement('div');
      w.className = 'modal-wrap';
      w.innerHTML = `<div class="backdrop" data-x></div><form class="modal" role="dialog" aria-modal="true" aria-labelledby="dp-t" novalidate>
        <h2 id="dp-t">Sem medição em ${esc(U.compLabel(comp))}</h2>
        <p class="muted">${esc(nome)}: o envio do link é desligado só neste mês e nesta pasta. O contrato continua ativo e volta no mês seguinte.</p>
        <fieldset class="op-motivo"><legend class="small muted">Motivo</legend>
          <label class="check"><input type="radio" name="dp-motivo" value="sem_medicao" checked> ${esc(U.DISPENSA_TXT.sem_medicao)}</label>
          <label class="check"><input type="radio" name="dp-motivo" value="sem_contrato"> ${esc(U.DISPENSA_TXT.sem_contrato)}</label></fieldset>
        <label class="field"><span>Observação <span class="hint">(opcional)</span></span><textarea id="dp-obs" rows="3" maxlength="1000"></textarea></label>
        <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" data-x>Voltar</button>
        <button type="submit" class="btn primary">Desligar o envio no mês</button></div></form>`;
      const fim = (v) => { w.remove(); ok(v); };
      w.addEventListener('click', (e) => { if (e.target.closest('[data-x]')) fim(null); });
      w.querySelector('form').addEventListener('submit', (e) => {
        e.preventDefault();
        fim({ motivo: (w.querySelector('[name="dp-motivo"]:checked') || {}).value || 'sem_medicao', obs: w.querySelector('#dp-obs').value.trim() });
      });
      document.body.appendChild(w);
      w.querySelector('[name="dp-motivo"]').focus();
    });
  }
  // Documentos da Klingele anexados pela equipe (no link do fornecedor)
  async function anexarKlg(files) {
    const s = S.solic.find((x) => x.id === S.gaveta.id);
    if (!s) return;
    const f = F(s.fornecedor_id);
    let n = 0;
    for (const file of files) {
      if (!U.MIME[U.extensao(file.name)]) { U.toast(`Tipo não aceito: ${file.name}`, 'erro'); continue; }
      if (file.size > 25 * 1048576) { U.toast(`Maior que 25 MB: ${file.name}`, 'erro'); continue; }
      if (docsKlg(s.id).length + n >= 15) { U.toast('No máximo 15 documentos da Klingele por link', 'erro'); break; }
      try { await API.anexarDocumento({ solicitacao: s, fornecedor: f, competencia: s.competencia, file, tipo: 'klingele' }); n++; }
      catch (e) { U.toast(e.message, 'erro'); }
    }
    await recarregar();
    renderView();
    abrirSolicitacao(s.id, { manterScroll: true });
    if (n) U.toast(s.status === 'gerado' ? `${n} documento(s) anexado(s). Agora envie o link ao fornecedor.` : `${n} documento(s) anexado(s): o fornecedor já vê no link.`);
  }

  // =====================================================================
  //  EVENTOS
  // =====================================================================
  const acoes = {
    'docs-klg': (el) => { abrirSolicitacao(el.dataset.s); setTimeout(() => { const x = document.getElementById('sec-docs-klg'); if (x) x.scrollIntoView({ block: 'start' }); }, 30); },
    'docs-klg-gerar': async (el) => {
      try {
        const r = await API.gerarSolicitacoes(S.comp, [el.dataset.f], el.dataset.p || null);
        await recarregar(); renderView();
        if (!r[0]) { U.toast('Nenhum contrato desta pasta para pedir neste mês (ou já estão em outro link)', 'erro'); return; }
        acoes['docs-klg']({ dataset: { s: r[0].id } });
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'pedir-docs': async (el) => {
      const s = S.solic.find((x) => x.id === el.dataset.s), f = s && F(s.fornecedor_id), col = colabDocs(f);
      if (!(await U.confirmar(s.docs_pedido_em ? 'Pedir os documentos de novo?' : 'Pedir os documentos ao colaborador?',
        `${col ? col.nome + ' (' + col.email + ')' : 'Os analistas'} recebe${col ? '' : 'm'} por e-mail o link para anexar os documentos de ${f.nome} ou informar que não houve medição.`, 'Enviar pedido'))) return;
      try { const r = await API.pedirDocsKlingele(s.id); await recarregar(); abrirSolicitacao(s.id, { manterScroll: true }); renderView(); U.toast(`Pedido enviado${r.para ? ' para ' + r.para : ''}`); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'copiar-link-docs': (el) => { const s = S.solic.find((x) => x.id === el.dataset.s); if (s && s.docs_token) U.copiar(linkDocs(s), 'Link do colaborador copiado'); },
    'previa-docs': (el) => simularDocs(el.dataset.s, true),
    'simular-docs': (el) => simularDocs(el.dataset.s, false),
    'doc-klg-rm': async (el) => {
      const d = S.docs.find((x) => x.id === el.dataset.d);
      if (!d || !(await U.confirmar('Remover este documento?', `${d.nome_padrao || d.nome_arquivo} sai do link: o fornecedor deixa de ver.`, 'Remover', true))) return;
      try { await API.excluirDocumento(d); await recarregar(); renderView(); if (S.gaveta && S.gaveta.tipo === 'solic') abrirSolicitacao(S.gaveta.id, { manterScroll: true }); else if (S.gaveta && S.gaveta.tipo === 'receb') abrirRecebimento(S.gaveta.id, true); U.toast('Documento removido'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'dispensar': async (el) => {
      const s = el.dataset.s ? S.solic.find((x) => x.id === el.dataset.s) : null, f = F(s ? s.fornecedor_id : el.dataset.f);
      const r = await formularioDispensa(f.nome, s ? s.competencia : S.comp);
      if (!r) return;
      try {
        const x = await API.dispensarEnvio(s ? s.id : null, r.motivo, r.obs, s ? null : f.id, s ? null : S.comp, s ? null : (el.dataset.p || null));
        await recarregar(); renderView();
        if (S.gaveta && S.gaveta.tipo === 'solic') abrirSolicitacao(x.id || S.gaveta.id);
        U.toast(`${f.nome}: envio desligado em ${U.compLabel(s ? s.competencia : S.comp)} (${U.DISPENSA_TXT[r.motivo].toLowerCase()})`);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'reativar-envio': async (el) => {
      const s = S.solic.find((x) => x.id === el.dataset.s);
      if (!s || !(await U.confirmar('Reativar o envio deste mês?', `O link de ${F(s.fornecedor_id).nome} volta a "gerado" com prazo novo e os pedidos voltam a aguardar a medição.`, 'Reativar'))) return;
      try { await API.reativarEnvio(s.id); await recarregar(); renderView(); if (S.gaveta && S.gaveta.tipo === 'solic') abrirSolicitacao(s.id); U.toast('Envio reativado'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'tema': () => {
      U.tema.alternar();
      const t = document.getElementById('tema-txt'), i = document.getElementById('tema-ic'), escuro = U.tema.atual() === 'dark';
      if (t) t.textContent = escuro ? 'Tema claro' : 'Tema escuro';
      if (i) i.innerHTML = escuro ? ic.sol : ic.lua;
      const nav = root.querySelector('#nav'), aberta = !!root.querySelector('.shell.nav-aberta');
      if (nav && S.base) { nav.innerHTML = navHTML(); if (aberta) { const b = nav.querySelector('.nav-mais'); if (b) b.setAttribute('aria-expanded', 'true'); } }
    },
    'nav-mais': () => {
      const sh = root.querySelector('.shell');
      if (!sh) return;
      const aberta = sh.classList.toggle('nav-aberta');
      const b = sh.querySelector('.nav-mais'); if (b) b.setAttribute('aria-expanded', String(aberta));
    },
    'foot-mais': (el) => {
      const f = el.closest('.drawer-foot');
      const aberto = f.classList.toggle('aberto');
      el.setAttribute('aria-expanded', String(aberto));
      el.textContent = aberto ? 'Menos ações' : `Mais ações (${f.querySelectorAll('.sec').length})`;
    },
    // Visão "Todos" ou "Meus contratos" (lembrada neste navegador)
    'escopo': (el) => {
      S.escopo = el.dataset.v === 'meus' ? 'meus' : 'todos';
      try { localStorage.setItem('bmk-escopo', S.escopo); } catch (e) { /* navegador sem armazenamento */ }
      S.f.pSup = ''; render();
    },
    'nova-pasta': () => abrirPasta(null),
    'abrir-pasta': (el) => abrirPasta(el.dataset.id, null, el.dataset.alvo),
    'pasta-cal': (el) => { if (!S.gaveta || S.gaveta.tipo !== 'pasta') return; const r = rascunhoPasta(); r.calendario = el.dataset.v; S.gaveta.cal = el.dataset.v; abrirPasta(S.gaveta.id, r); },
    'pasta-add-data': () => {
      const i = document.getElementById('pa-nova-data'), d = i && i.value;
      if (!d) { U.toast('Escolha a data', 'erro'); return; }
      if (!U.ehDiaUtil(d, S.fer)) { U.toast(`${U.dataBR(d)} não é dia útil (sábado, domingo ou feriado)`, 'erro'); return; }
      const r = rascunhoPasta(); if (!r.datas.includes(d)) r.datas = [...r.datas, d].sort(); abrirPasta(S.gaveta.id, r, 'pa-nova-data');
    },
    'pasta-rm-data': (el) => { const r = rascunhoPasta(); r.datas = r.datas.filter((x) => x !== el.dataset.d); abrirPasta(S.gaveta.id, r); },
    'pasta-transferir': async () => {
      const g = S.gaveta, p = PASTA(g.id), s = document.getElementById('pa-transf'), para = s && s.value;
      if (!p || !para) { U.toast('Escolha para quem transferir', 'erro'); return; }
      if (!(await U.confirmar(`Transferir a pasta "${p.nome}"?`, `${nomeEquipe(para)} passa a ser dono e responsável. Você continua podendo gerir a pasta.`, 'Transferir'))) return;
      try { await API.transferirPasta(p.id, para); await recarregar(true); abrirPasta(p.id); renderView(); U.toast('Pasta transferida'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'avulsos-mover': async () => {
      const ids = Array.from(document.querySelectorAll('[data-av]:checked')).map((b) => b.dataset.av), dest = (document.getElementById('av-destino') || {}).value;
      if (!ids.length) { U.toast('Marque os contratos', 'erro'); return; }
      if (!dest) { U.toast('Escolha a pasta de destino', 'erro'); return; }
      try { const r = await API.moverContratos(ids, dest); await recarregar(true); renderView(); U.toast(`${r.movidos} contrato${r.movidos !== 1 ? 's' : ''} na pasta ${PASTA(dest).nome}`); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'gerar-pasta': async (el) => {
      const p = PASTA(el.dataset.id);
      try { const r = await API.gerarSolicitacoes(S.comp, null, p.id); await recarregar(); renderView(); U.toast(`${r.length} link${r.length !== 1 ? 's' : ''} da pasta ${p.nome} pronto${r.length !== 1 ? 's' : ''}. Abra cada um para enviar pelo Outlook.`); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'pasta-rm-pessoa': (el) => { const r = rascunhoPasta(); S.gaveta.comp = S.gaveta.comp.filter((c) => !(c.alvo_tipo === 'usuario' && c.alvo === el.dataset.email)); abrirPasta(S.gaveta.id, r, 'pa-acessos'); },
    'grupo-envio': (el) => { S.f.envioFechados[el.dataset.id] = !S.f.envioFechados[el.dataset.id]; renderView(); },
    'envio-vis': (el) => { S.f.envioVis = el.dataset.v === 'pastas' ? 'pastas' : 'lista'; try { localStorage.setItem('bmk-envio-vis', S.f.envioVis); } catch (e) { /* sem armazenamento */ } renderView(); },
    // Equipes
    'usu-aba': (el) => { S.f.usuAba = el.dataset.v; renderView(); },
    'ir-equipes': async () => { S.f.usuAba = 'equipes'; await irPara('usuarios'); },
    'nova-equipe': () => abrirEquipe(null),
    'abrir-equipe': (el) => abrirEquipe(el.dataset.id),
    'salvar-equipe': () => salvarEquipe(),
    'equipe-convidar': () => convidarEquipe(),
    'excluir-equipe': async () => {
      const e = S.mapEq[S.gaveta.id];
      if (!e || !(await U.confirmar(`Excluir a equipe "${e.nome}"?`, 'Os membros saem da equipe e as pastas compartilhadas com ela deixam de aparecer para eles (o compartilhamento com pessoas continua).', 'Excluir', true))) return;
      try { await API.excluirEquipe(e.id); await recarregar(true); fecharGaveta(); renderView(); U.toast('Equipe excluída'); } catch (x) { U.toast(x.message, 'erro'); }
    },
    'equipe-tirar': async (el) => {
      const e = S.mapEq[S.gaveta.id], em = el.dataset.email;
      if (!e || !(await U.confirmar(`Tirar ${nomeEquipe(em)} da equipe?`, 'A pessoa deixa de ver as pastas compartilhadas com a equipe.', 'Tirar', true))) return;
      try { await API.removerMembroEquipe(e.id, em); await recarregar(true); renderView(); abrirEquipe(e.id); U.toast('Pessoa removida da equipe'); } catch (x) { U.toast(x.message, 'erro'); }
    },
    'equipe-sair': async (el) => {
      const e = S.mapEq[el.dataset.id];
      if (!e || !(await U.confirmar(`Sair da equipe "${e.nome}"?`, 'Você deixa de ver as pastas compartilhadas com a equipe. Para voltar, peça um novo convite.', 'Sair'))) return;
      try { await API.removerMembroEquipe(e.id, EU()); await recarregar(true); fecharGaveta(); renderView(); U.toast('Você saiu da equipe'); } catch (x) { U.toast(x.message, 'erro'); }
    },
    'convite-aceitar': async (el) => { try { await API.responderConvite(el.dataset.id, true); await recarregar(true); renderView(); U.toast('Convite aceito: você entrou na equipe'); } catch (x) { U.toast(x.message, 'erro'); } },
    'convite-recusar': async (el) => { try { await API.responderConvite(el.dataset.id, false); await recarregar(true); renderView(); U.toast('Convite recusado'); } catch (x) { U.toast(x.message, 'erro'); } },
    'salvar-pasta': () => salvarPasta(),
    'pasta-enviar': (el) => enviarPasta(el.dataset.id),
    'pasta-filtrar': async (el) => { S.f.pasta = el.dataset.id; await irPara('envio'); const x = document.getElementById('sec-lista'); if (x) x.scrollIntoView({ block: 'start' }); },
    'excluir-pasta': async () => {
      const p = PASTA(S.gaveta.id), n = S.base.contratos.filter((c) => c.pasta_id === (p || {}).id).length;
      if (!p || !(await U.confirmar(`Excluir a pasta "${p.nome}"?`, `${n} contrato${n !== 1 ? 's' : ''} da pasta fica${n !== 1 ? 'm' : ''} avulso${n !== 1 ? 's' : ''} (sem envio automático). Os links já enviados e o histórico continuam.`, 'Excluir', true))) return;
      try { const r = await API.excluirPasta(p.id); if (S.f.pasta === p.id) S.f.pasta = ''; await recarregar(true); fecharGaveta(); renderView(); U.toast(`Pasta excluída · ${r.avulsos || 0} contrato${r.avulsos === 1 ? '' : 's'} avulso${r.avulsos === 1 ? '' : 's'}`); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'resp-rm': (el) => { const l = el.dataset.papel === 'sup' ? S.gaveta.sups : S.gaveta.cts; const i = l.indexOf(el.dataset.id); if (i >= 0) l.splice(i, 1); atualizarResp(); },
    'resp-principal': (el) => { const l = S.gaveta.sups, i = l.indexOf(el.dataset.id); if (i > 0) { l.splice(i, 1); l.unshift(el.dataset.id); } atualizarResp(); },
    'ir-perfil': async () => { await irPara('conf'); const x = document.getElementById('conf-perfil'); if (x && S.papel === 'admin') x.scrollIntoView({ block: 'start' }); },
    // "Pendências" no painel: abre a tela já no filtro da pendência
    'ir-pend': async (el) => {
      const [v, chave, valor] = el.dataset.v.split(':');
      if (chave) S.f[chave] = valor;
      await irPara(v);
      const x = el.dataset.alvo && document.getElementById(el.dataset.alvo); if (x) x.scrollIntoView({ block: 'start' });
    },
    'ir-sec': (el) => { const alvo = document.getElementById(el.dataset.alvo); if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' }); },
    'sair': async () => {
      const sh = root.querySelector('.shell'); if (sh) sh.classList.remove('nav-aberta');
      if (DEMO) { if (await U.confirmar('Sair?', 'Na demonstração não há conta: mostramos a tela de entrada como o colaborador vê no site publicado.', 'Ver a tela de entrada')) { const b = acoes['demo-login']; if (b) b(); else telaLogin(null, { previa: true }); } return; }
      if (!(await U.confirmar('Sair do BMK?', 'Você volta para a tela de entrada. Envios e rascunhos já salvos continuam no servidor.', 'Sair'))) return;
      await API.sair(); location.reload();
    },
    'comp-ant': () => mudarComp(U.addMes(S.comp, -1)),
    'comp-prox': () => mudarComp(U.addMes(S.comp, 1)),
    'ir-comp': (el) => mudarComp(el.dataset.comp),
    'fechar-gaveta': fecharGaveta,
    'exportar-csv': exportarCSV,
    'ir-pag': () => irPara('pag'),
    'restaurar-demo': async () => {
      if (!(await U.confirmar('Restaurar dados de exemplo?', 'Os envios, valores e alterações feitos nesta demonstração serão apagados deste navegador.', 'Restaurar', true))) return;
      API.restaurar(); S.comp = U.compAnterior(); await recarregar(true); render(); U.toast('Dados de exemplo restaurados');
    },
    // Envio
    'gerar-um': async (el) => {
      try { const r = await API.gerarSolicitacoes(S.comp, [el.dataset.f], el.dataset.p || null); await recarregar(); renderView(); if (r[0]) abrirSolicitacao(r[0].id); else U.toast('Nenhum contrato desta pasta para pedir neste mês (ou já estão em outro link)', 'erro'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'ver-email': (el) => abrirSolicitacao(el.dataset.s),
    'previa': (el) => simular(el.dataset.s, true),
    'copiar-link': (el) => { const s = S.solic.find((x) => x.id === el.dataset.s); if (s) U.copiar(linkPortal(s), 'Link copiado'); },
    'copiar-email': () => { const e = lerEmailForm(); U.copiar(`Para: ${e.para.join(', ')}\nAssunto: ${e.assunto}\n\n${e.corpo}`, 'E-mail copiado'); },
    'outlook': (el, ev) => {
      const e = lerEmailForm();
      el.setAttribute('href', U.mailto(e.para, e.assunto, e.corpo));
      setTimeout(() => U.toast('Depois de enviar pelo Outlook, clique em “Registrar envio”.'), 400);
      return 'default';
    },
    'registrar-envio': async (el) => {
      const e = lerEmailForm();
      if (!conferirPara(e)) return;
      try {
        const s = await API.registrarEnvio(el.dataset.s, e.para, e.assunto, e.corpo, e.manter);
        await recarregar(); renderView(); abrirSolicitacao(s.id);
        U.toast(`${e.manter ? 'Lembrete registrado' : 'Envio registrado'}. Link válido até ${U.dataBR(U.dataLocal(s.expira_em))}.`);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'renovar-reenviar': async (el) => {
      if (!(await U.confirmar('Gerar novo link e reenviar?', 'Um link novo será criado com prazo recomeçado. O link antigo continua sem valer. Em seguida, escolha os destinatários e envie.', 'Gerar novo link'))) return;
      try { const s = await API.renovarLink(el.dataset.s); await recarregar(); renderView(); abrirSolicitacao(s.id); U.toast('Novo link gerado. Prossiga com o envio ao fornecedor.'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'lembrete-todos': async () => {
      const n = S.solic.filter((s) => ['enviado', 'aberto'].includes(s.status) && aindaValido(s)).length;
      if (!(await U.confirmar('Enviar lembrete?', `${n} fornecedor${n !== 1 ? 'es' : ''} que receberam o link de ${U.compLabel(S.comp)} e ainda não responderam vão receber o mesmo link de novo, com o assunto "LEMBRETE" e o prazo mantido.`, 'Enviar lembrete'))) return;
      try {
        const r = await API.lembretePendentes(S.comp);
        await recarregar(); renderView();
        U.toast(`${r.enviados} lembrete${r.enviados !== 1 ? 's' : ''} enviado${r.enviados !== 1 ? 's' : ''}${r.sem_email && r.sem_email.length ? ` · sem e-mail: ${r.sem_email.join(', ')}` : ''}`);
        if (!DEMO) setTimeout(async () => { await API.conferirEnvios().catch(() => {}); await recarregar(); if (S.view === 'envio') renderView(); }, 8000);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'renovar': async (el) => {
      if (!(await U.confirmar('Gerar novo link?', 'O link atual deixa de funcionar e o prazo recomeça. Depois, envie o e-mail de novo ao fornecedor.', 'Gerar novo link'))) return;
      try { const s = await API.renovarLink(el.dataset.s); await recarregar(); renderView(); abrirSolicitacao(s.id); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'cancelar': async (el) => {
      if (!(await U.confirmar('Cancelar solicitação?', 'O link deixa de funcionar. Você pode gerar outro depois.', 'Cancelar solicitação', true))) return;
      try { await API.cancelarSolicitacao(el.dataset.s); await recarregar(); renderView(); U.toast('Solicitação cancelada'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'simular': (el) => simular(el.dataset.s),
    'enviar-um': async (el) => {
      const e = lerEmailForm();
      if (!conferirPara(e)) return;
      const sid = el.dataset.s;
      const sx = S.solic.find((x) => x.id === sid);
      if (sx && pedeDocs(F(sx.fornecedor_id)) && !docsKlg(sid).length
        && !(await U.confirmar('Enviar sem os documentos da Klingele?', `${F(sx.fornecedor_id).nome} faz a medição com documentos da Klingele e o link ainda não tem nenhum. Enviar mesmo assim?`, 'Enviar sem documentos'))) return;
      try {
        const r = await API.reenviar(sid, e.para, e.manter);
        await recarregar(); renderView(); abrirSolicitacao(sid);
        const ate = U.dataBR(U.dataLocal(r.expira_em));
        U.toast(r.tipo === 'lembrete' ? `Lembrete enviado. Prazo mantido até ${ate}.` : r.tipo === 'reenvio' ? `Link reenviado. Novo prazo até ${ate}.` : `E-mail enviado. Prazo até ${ate}.`);
        if (!DEMO) setTimeout(async () => { await API.conferirEnvios().catch(() => {}); await recarregar(); if (S.view === 'envio') renderView(); if (S.gaveta && S.gaveta.id === sid) abrirSolicitacao(sid, { manterScroll: true }); }, 8000);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'mfa-ativar': () => fluxoAtivarMfa(true),
    'mfa-desativar': async (el) => {
      const obrig = cfgv('exigir_mfa', 'false') === 'true';
      if (!(await U.confirmar('Desativar a verificação em duas etapas?', obrig ? 'A equipe exige essa verificação: no próximo login você terá de ativar de novo.' : 'O acesso a esta conta passa a exigir apenas e-mail e senha.', 'Desativar', true))) return;
      try { await API.mfaRemover(el.dataset.id); U.toast('Verificação em duas etapas desativada'); carregarMfa(); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'usar-site': () => { const i = document.getElementById('ce-site'); if (i) i.value = location.origin + location.pathname.replace(/[^/]*$/, '').replace(/\/$/, ''); },
    'salvar-email': async () => {
      const g = (k) => document.getElementById('ce-' + k).value.trim();
      const site = g('site').replace(/\/$/, ''), rem = g('remetente'), resp = g('resposta'), cc = g('copia'), chave = g('chave');
      if (site && !/^https:\/\/[^\s/]+(\/\S*)?$/.test(site)) { U.toast('O endereço do site precisa começar com https://', 'erro'); return; }
      for (const [rot, v] of [['remetente', rem], ['responder para', resp], ['cópia para', cc]]) if (v && !U.emailValido(v)) { U.toast(`E-mail inválido em "${rot}"`, 'erro'); return; }
      if (g('nome').length > 80) { U.toast('Nome do remetente muito longo', 'erro'); return; }
      const limite = Number(g('limite'));
      if (!(Number.isInteger(limite) && limite >= 1 && limite <= 5000)) { U.toast('Limite de e-mails por dia entre 1 e 5.000', 'erro'); return; }
      try {
        await API.salvarConfig('email_provedor', g('provedor'));
        await API.salvarConfig('email_remetente_nome', g('nome') || 'Klingele Paper & Packing');
        await API.salvarConfig('email_remetente', rem);
        await API.salvarConfig('email_resposta', resp);
        await API.salvarConfig('email_copia', cc);
        await API.salvarConfig('site_url', site);
        await API.salvarConfig('email_limite_dia', limite);
        if (chave) await API.definirChaveEmail(chave);
        document.getElementById('ce-chave').value = '';
        await recarregar(true); renderView(); U.toast('Configuração de e-mail salva');
      } catch (e) { U.toast(e.message, 'erro'); }
    },

    // F.S. aprovada e fim do processo
    'fs-aprovar': async (el) => {
      const mid = el.dataset.m, m = S.med.find((x) => x.id === mid), nota = notaAtual(mid);
      const depois = nota ? (autoServicos() ? 'Com a NF já recebida, ela é encaminhada a Serviços.' : 'Em seguida, encaminhe a NF a Serviços.') : 'A NF vai a Serviços quando o fornecedor enviar.';
      if (!(await U.confirmar('Aprovar a F.S.?', `${F(m.fornecedor_id).nome} · pedido ${C(m.contrato_id).pedido} · F.S. ${m.folha_numero} (${U.brl(m.folha_valor ?? m.valor_aprovado)}). Confirme que as aprovações internas foram concluídas. ${depois}`, 'Aprovar F.S.'))) return;
      try {
        let anexos = [];
        try { anexos = await API.linksPedidoCompra(fsDocs(m), 60); } catch (e) { anexos = []; }
        const r = await API.aprovarFolha(mid, anexos);
        await recarregar(); renderView(); abrirNF(mid);
        const msg = { encaminhado: 'F.S. aprovada. NF encaminhada a Serviços: processo finalizado.', nf: 'F.S. aprovada. A NF vai a Serviços quando o fornecedor enviar.',
          conferencia: 'F.S. aprovada. Confira os alertas da NF para encaminhar a Serviços.', pronto: 'F.S. aprovada. Encaminhe a NF a Serviços.',
          sem_destinatario: 'F.S. aprovada. Cadastre os e-mails de Serviços e Ocorrência para encaminhar a NF.' }[r.situacao] || 'F.S. aprovada.';
        U.toast(msg, r.situacao === 'sem_destinatario' ? 'erro' : undefined);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'serv-encaminhar': async (el) => {
      const mid = el.dataset.m, m = S.med.find((x) => x.id === mid), nota = notaAtual(mid);
      if (!nota) return;
      const conf = nota.status === 'em_conferencia' ? (nota.alertas ? ` A nota tem ${nota.alertas} alerta(s): ao encaminhar, ela fica aprovada com os alertas conferidos.` : ' A nota fica aprovada no encaminhamento.') : '';
      if (!(await U.confirmar('Encaminhar a NF a Serviços?', `NF nº ${nota.numero} (${U.brl(nota.valor)}) de ${F(m.fornecedor_id).nome}, com a F.S. ${m.folha_numero}.${conf} O processo do mês fica finalizado.`, 'Encaminhar'))) return;
      try {
        let anexos = [];
        try { anexos = await API.linksPedidoCompra(fsDocs(m), 60); } catch (e) { anexos = []; }
        const r = await API.encaminharServicos(mid, anexos);
        if (r.enviado) {
          await recarregar(); renderView(); abrirNF(mid);
          U.toast(`NF encaminhada a Serviços (${(r.para || []).length} e-mail(s)). Processo finalizado.`);
          return;
        }
        // Sem envio pelo app: abre no Outlook e registra
        if (!(r.para || []).length) { U.toast('Cadastre os e-mails de Serviços e Ocorrência em Configurações > Encaminhamento a Serviços', 'erro'); return; }
        const a = document.createElement('a'); a.href = U.mailto(r.para, r.assunto, r.corpo); document.body.appendChild(a); a.click(); a.remove();
        if (!(await U.confirmar('Registrar o encaminhamento?', `O e-mail "${r.assunto}" abriu no Outlook para ${r.para.join(', ')}. Anexe a NF, o XML e a F.S., envie e confirme aqui.`, 'Registrar envio'))) return;
        await API.registrarEncaminhamentoServicos(mid, r.para, r.assunto, r.corpo);
        await recarregar(); renderView(); abrirNF(mid);
        U.toast('Encaminhamento registrado. Processo finalizado.');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-form': (el) => abrirNF(el.dataset.m, { form: true, manterScroll: true }),
    'nf-form-fechar': (el) => abrirNF(el.dataset.m),
    'nf-recusar-abrir': (el) => {
      const b = document.getElementById('nf-recusa-' + el.dataset.id);
      if (!b) return;
      b.hidden = !b.hidden;
      if (!b.hidden) { b.scrollIntoView({ block: 'center', behavior: 'smooth' }); const ta = b.querySelector('textarea'); if (ta) setTimeout(() => ta.focus(), 250); }
    },
    'fs-desfazer': async (el) => {
      if (!(await U.confirmar('Desfazer a aprovação da F.S.?', 'A F.S. volta para "A aprovar" e a NF não vai a Serviços até a nova aprovação.', 'Desfazer', true))) return;
      try { await API.desfazerAprovacaoFolha(el.dataset.m); await recarregar(); renderView(); abrirNF(el.dataset.m, { manterScroll: true }); U.toast('Aprovação desfeita'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'fs-reavisar': (el) => {
      const m = S.med.find((x) => x.id === el.dataset.m), c = C(m.contrato_id);
      const e = U.montarEmailFS({ modeloAssunto: cfgv('modelo_fs_assunto', ''), modeloCorpo: cfgv('modelo_fs_corpo', ''), fornecedor: F(m.fornecedor_id).nome, competencia: m.competencia,
        pedido: c.pedido, servico: c.titulo, folha: m.folha_numero, folhaData: m.folha_data, parcela: m.parcela, parcelasTotal: c.parcelas_total, valor: m.folha_valor ?? m.valor_aprovado,
        aprovadoPor: m.folha_aprovada_por, anexos: [], descricao: m.descricao_nf });
      avisoFSOutlook(m.id, { para: destinatariosFS(), assunto: e.assunto, corpo: e.corpo });
    },
    // Painel
    'limpar-filtros': () => { Object.assign(S.f, { pForn: '', pSup: '', pTipo: '', pEtapa: '' }); renderView(); },
    'filtro-etapa': (el) => { S.f.pEtapa = el.dataset.v || ''; renderView(); },
    'ver-contr-avisar': () => { S.f.contrFiltro = 'avisar'; irPara('contr'); },
    // Cobrança
    'cobrar-agora': async () => {
      const n = S.solic.filter((x) => cobrancaEtapa(x).devida).length;
      if (!(await U.confirmar('Cobrar agora?', `${n} fornecedor${n !== 1 ? 'es' : ''} passaram do prazo sem responder. O link é reenviado com novo prazo (${cfgv('cobranca_reenvio_dias', '10')} dias úteis na 1ª cobrança, ${cfgv('cobranca_semanal_dias', '5')} nos lembretes semanais).`, 'Cobrar agora'))) return;
      try {
        const r = await API.cobrancaExecutar(); await recarregar(); renderView();
        U.toast(`${r.reenvios} reenvio(s) e ${r.lembretes} lembrete(s) enviados${r.sem_email && r.sem_email.length ? ` · sem e-mail: ${r.sem_email.join(', ')}` : ''}`);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'ir-conf-fluxo': async () => { await irPara('conf'); const x = document.getElementById('conf-fluxo'); if (x) x.scrollIntoView({ block: 'start' }); },
    'ir-conf-fs': async () => { await irPara('conf'); const x = document.getElementById('conf-fs'); if (x) x.scrollIntoView({ block: 'start' }); },
    // Usuários
    'filtro-usu': (el) => { S.f.usu = el.dataset.v; renderView(); },
    'abrir-usu': (el) => abrirUsuario(el.dataset.id),
    'salvar-usuario': () => salvarUsuario(),
    'usu-rapido': (el) => salvarUsuario(el.dataset.v),
    'ir-conf-cad': async () => { await irPara('conf'); const x = document.getElementById('conf-cad'); if (x) x.scrollIntoView({ block: 'start' }); },
    'demo-login': () => telaLogin(null, { previa: true }),
    // Configurações: perfil, cadastro, fluxo do mês, F.S. aprovada e vencimentos
    'salvar-perfil': async () => {
      const g = (k) => document.getElementById('mp-' + k).value.trim();
      const d = { nome: g('nome'), telefone: g('tel') || null, email_aviso: g('aviso').toLowerCase() || null };
      if (d.nome.length < 2) { U.toast('Informe o nome', 'erro'); return; }
      if (d.email_aviso && !U.emailValido(d.email_aviso)) { U.toast('E-mail de aviso inválido', 'erro'); return; }
      if (!U.telefoneValido(d.telefone)) { U.toast('Telefone inválido', 'erro'); return; }
      try { S.cad = { ...(S.cad || {}), ...(await API.salvarMeuPerfil(d)), telefone: d.telefone }; renderView(); U.toast('Perfil salvo'); }
      catch (e) { U.toast(/Cadastro não encontrado|meu_perfil_salvar/.test(e.message) ? 'Rode o 04_usuarios.sql no Supabase para usar o perfil.' : e.message, 'erro'); }
    },
    'trocar-senha': () => { if (DEMO) { U.toast('A demonstração não utiliza senha. No site publicado, a senha é alterada nesta opção.'); return; } telaNovaSenha(); },
    'salvar-cadastro': async () => {
      const v = document.getElementById('cc-dominios').value.trim().toLowerCase().replace(/\s+/g, '');
      if (v && !/^@?[a-z0-9.-]+\.[a-z]{2,}(,@?[a-z0-9.-]+\.[a-z]{2,}){0,9}$/.test(v)) { U.toast('Domínios inválidos (ex.: klingele.com.br)', 'erro'); return; }
      try { await API.salvarConfig('cadastro_dominios', v.split(',').filter(Boolean).join(', ')); await recarregar(true); renderView(); U.toast('Cadastro salvo'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-fluxo': async () => {
      const g = (id) => Number(document.getElementById(id).value);
      const campos = [['cobranca_reenvio_dias', g('cb-reenvio'), 1, 30], ['cobranca_lembretes_max', g('cb-max'), 0, 12], ['cobranca_intervalo_dias', g('cb-int'), 1, 30], ['cobranca_semanal_dias', g('cb-sem'), 1, 30]];
      const ruim = campos.find(([, v, a, b]) => !(Number.isInteger(v) && v >= a && v <= b));
      if (ruim) { U.toast(`Valor fora do limite (${ruim[2]} a ${ruim[3]})`, 'erro'); return; }
      try { for (const [k, v] of campos) await API.salvarConfig(k, v); await recarregar(true); renderView(); U.toast('Cobrança salva'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-conf-fs': async () => {
      const g = (id) => document.getElementById(id).value;
      const lista = (t) => t.split(/[,;\s]+/).map((x) => x.trim().toLowerCase()).filter(Boolean);
      const sv = lista(g('fs-servicos')), oc = lista(g('fs-ocorrencia'));
      const ruim = sv.concat(oc).find((e) => !U.emailValido(e));
      if (ruim) { U.toast(`E-mail inválido: ${ruim}`, 'erro'); return; }
      if (sv.length > 10 || oc.length > 10) { U.toast('Até 10 e-mails em cada lista', 'erro'); return; }
      if (!g('fs-assunto').trim()) { U.toast('Informe o assunto', 'erro'); return; }
      try {
        await API.salvarConfig('fs_emails_servicos', sv.join(',')); await API.salvarConfig('fs_emails_ocorrencia', oc.join(','));
        await API.salvarConfig('modelo_fs_assunto', g('fs-assunto')); await API.salvarConfig('modelo_fs_corpo', g('fs-corpo'));
        await recarregar(true); renderView(); U.toast('Aviso da F.S. salvo');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-conf-venc': async () => {
      const g = (id) => document.getElementById(id).value;
      const nums = [['alerta_venc_longo_dias', Number(g('av-longo'))], ['alerta_venc_curto_dias', Number(g('av-curto'))], ['alerta_venc_limite_curto', Number(g('av-limite'))]];
      if (nums.some(([, v]) => !(Number.isInteger(v) && v >= 1 && v <= 999))) { U.toast('Dias do aviso entre 1 e 999', 'erro'); return; }
      const em = g('av-emails').split(/[,;\s]+/).map((x) => x.trim().toLowerCase()).filter(Boolean);
      const ruim = em.find((e) => !U.emailValido(e));
      if (ruim) { U.toast(`E-mail inválido: ${ruim}`, 'erro'); return; }
      if (em.length > 10) { U.toast('Até 10 e-mails', 'erro'); return; }
      try {
        for (const [k, v] of nums) await API.salvarConfig(k, v);
        await API.salvarConfig('alerta_venc_emails', em.join(','));
        await API.salvarConfig('modelo_venc_assunto', g('av-assunto')); await API.salvarConfig('modelo_venc_corpo', g('av-corpo'));
        await recarregar(true); renderView(); U.toast('Aviso de vencimento salvo');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Histórico por período e correções
    'hist-periodo': () => {
      const de = document.getElementById('hist-de').value, ate = document.getElementById('hist-ate').value;
      if (!de || !ate) { U.toast('Informe as duas datas do período', 'erro'); return; }
      if (de > ate) { U.toast('A data inicial deve ser anterior à data final', 'erro'); return; }
      if (U.diffDias(de, ate) > 731) { U.toast('Consulte no máximo dois anos por vez', 'erro'); return; }
      Object.assign(S.f, { histDe: de, histAte: ate }); S.cache = { envios: null, hist: null, rotina: null }; renderView(); carregarHistorico();
    },
    'hist-atalho': (el) => {
      const h = U.hojeISO(), m = U.compDe(h);
      const p = { mes: [m, h], 'mes-ant': [U.addMes(m, -1), U.fimMes(U.addMes(m, -1))], 30: [U.addDias(h, -30), h], 90: [U.addDias(h, -90), h] }[el.dataset.v];
      Object.assign(S.f, { histDe: p[0], histAte: p[1] }); S.cache = { envios: null, hist: null, rotina: null }; renderView(); carregarHistorico();
    },
    'hist-exportar': () => exportarHistorico(),
    'hist-limpar': () => limparHistorico(),
    'receb-excluir': async (el) => {
      const s = S.solic.find((x) => x.id === el.dataset.s), f = F(s.fornecedor_id);
      const r = await formularioMotivo({ titulo: 'Excluir recebimento', rotulo: 'Excluir recebimento', perigo: true,
        texto: `${f.nome} · ${U.compLabel(s.competencia)}. Os arquivos recebidos e os valores informados serão excluídos e os pedidos voltam para "Aguardando".`,
        opcoes: { tipo: 'radio', itens: [['reabrir', 'Gerar novo link para o fornecedor reenviar', true], ['cancelar', 'Cancelar a solicitação', false]] } });
      if (!r) return;
      try { const x = await API.excluirRecebimento(s.id, r.motivo, r.modo || 'reabrir'); await aposExcluir(x, x.modo === 'cancelar' ? 'Recebimento excluído e solicitação cancelada.' : 'Recebimento excluído. O novo link está pronto para envio.'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'solic-excluir': async (el) => {
      const s = S.solic.find((x) => x.id === el.dataset.s), f = F(s.fornecedor_id);
      const r = await formularioMotivo({ titulo: 'Excluir solicitação', rotulo: 'Excluir solicitação', perigo: true,
        texto: `${f.nome} · ${U.compLabel(s.competencia)}. A solicitação, o link, os registros de envio, os arquivos recebidos e as medições sem valores aprovados serão excluídos. Use quando o link foi gerado ou enviado por engano.` });
      if (!r) return;
      try { const x = await API.excluirSolicitacao(s.id, r.motivo); await aposExcluir(x, `Solicitação excluída (${x.envios} registro(s) de envio, ${x.medicoes} medição(ões)).`); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'envio-excluir': async (el) => {
      const r = await formularioMotivo({ titulo: 'Excluir registro de envio', rotulo: 'Excluir registro', perigo: true,
        texto: 'O registro deste e-mail será excluído. Se for o único envio do link e o fornecedor ainda não o abriu, o link volta para "Link gerado". O e-mail já entregue não é recolhido.' });
      if (!r) return;
      try {
        await API.excluirEnvioEmail(el.dataset.id, r.motivo);
        const volta = S.gaveta && S.gaveta.tipo === 'solic' ? S.gaveta.id : null;
        fecharGaveta(); await recarregar(); if (S.view === 'hist') await carregarHistorico(); else renderView();
        if (volta && S.solic.some((x) => x.id === volta)) abrirSolicitacao(volta);
        U.toast('Registro de envio excluído');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Recebimentos
    'filtro-receb': (el) => { S.f.receb = el.dataset.v; renderView(); },
    'abrir-receb': (el) => { if (el.dataset.s) abrirRecebimento(el.dataset.s); },
    'doc-abrir': (el) => abrirDocumento(el.dataset.d),
    'doc-ler': (el) => lerDocumento(el.dataset.d),
    'usar-lido': (el) => usarLido(el.dataset.d, Number(el.dataset.v)),
    'doc-rm': async (el) => {
      const d = S.docs.find((x) => x.id === el.dataset.d);
      if (!(await U.confirmar('Excluir arquivo?', `"${d.nome_arquivo}" será apagado do armazenamento.`, 'Excluir', true))) return;
      try {
        await API.excluirDocumento(d); await recarregar();
        if (S.gaveta && S.gaveta.tipo === 'nf') { S.gaveta.links = null; abrirNF(S.gaveta.id, { manterScroll: true }); } else if (S.gaveta) abrirRecebimento(S.gaveta.id, true);
        renderView();
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'usar-informados': () => {
      document.querySelectorAll('#tbl-conf tbody tr[data-m]').forEach((tr) => {
        const m = S.med.find((x) => x.id === tr.dataset.m);
        const inp = tr.querySelector('[data-k="valor_aprovado"]');
        if (m && m.valor_informado !== null && !inp.value) { inp.value = U.numBR(m.valor_informado); const sel = tr.querySelector('[data-k="status"]'); if (['aguardando', 'recebido', 'em_conferencia'].includes(sel.value)) sel.value = 'aprovado'; }
      });
      U.toast('Valores preenchidos. Clique em “Salvar conferência”.');
    },
    'salvar-conf': (el) => salvarConferencia(el.dataset.s),
    'marcar-recebido': async (el) => {
      const s = S.solic.find((x) => x.id === el.dataset.s);
      try {
        await API.atualizarSolicitacao(s.id, { status: 'recebido', recebido_em: new Date().toISOString(), respondido_por: 'equipe (recebimento manual)' });
        for (const m of S.med.filter((x) => x.fornecedor_id === s.fornecedor_id && x.status === 'aguardando')) await API.salvarMedicao({ id: m.id, status: 'recebido' });
        await recarregar(); abrirRecebimento(s.id, true); renderView(); U.toast('Marcado como recebido');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Pagamentos
    'filtro-pag': (el) => { S.f.pag = el.dataset.v; renderView(); },
    'incluir-med': async () => {
      const id = document.getElementById('inc-med').value;
      if (!id) { U.toast('Escolha o pedido', 'erro'); return; }
      try { await API.incluirMedicao(C(id), S.comp); await recarregar(); renderView(); U.toast('Pedido incluído na competência'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Fornecedores
    'filtro-forn': (el) => { S.f.fornFiltro = el.dataset.v; renderView(); },
    'novo-forn': () => abrirFornecedor(null),
    'abrir-forn': (el, ev) => { if (ev.target.closest('.switch')) return; abrirFornecedor(el.dataset.f); },
    'ff-add-contato': () => { syncContatosForn(); S.gaveta.contatos.push({ nome: '', email: '', telefone: '', recebe_boletim: true }); desenharFornecedor(true); },
    'ff-rm-contato': (el) => { syncContatosForn(); const i = Number(el.dataset.i), c = S.gaveta.contatos[i]; if (c.id) c.remover = !c.remover; else S.gaveta.contatos.splice(i, 1); desenharFornecedor(true); },
    'salvar-forn': salvarFornecedor,
    'excluir-forn': async () => {
      const f = F(S.gaveta.id);
      if (!(await U.confirmar('Excluir fornecedor?', `${f.nome} e todos os contatos, contratos, medições e documentos ligados a ele serão apagados. Para apenas retirá-lo da lista, desmarque “Fornecedor ativo”.`, 'Excluir', true))) return;
      try { await API.excluirFornecedor(f.id); await recarregar(true); fecharGaveta(); renderView(); U.toast('Fornecedor excluído'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Contratos
    'filtro-contr': (el) => { S.f.contrFiltro = el.dataset.v; renderView(); },
    'novo-contr': () => abrirContrato(null),
    'abrir-contr': (el) => abrirContrato(el.dataset.c),
    'salvar-contr': salvarContrato,
    'usar-total': (el) => { document.getElementById('fc-total').value = U.numBR(Number(el.dataset.v)); },
    'venc-avisar': async (el) => {
      const c = C(el.dataset.c);
      try {
        const r = await API.avisarVencimento(c.id, false, null);
        if (r.enviado) { await recarregar(true); renderView(); if (S.gaveta && S.gaveta.tipo === 'contr') abrirContrato(c.id); U.toast(`Aviso enviado para ${r.para.join(', ')}`); return; }
        if (!(await U.confirmar('Enviar o aviso pelo Outlook?', `O envio pelo app não está configurado. O e-mail "${r.assunto}" abre pronto no Outlook para ${r.para.join(', ')}; o aviso fica registrado.`, 'Abrir no Outlook'))) return;
        const a = document.createElement('a'); a.href = U.mailto(r.para, r.assunto, r.corpo); document.body.appendChild(a); a.click(); a.remove();
        await API.avisarVencimento(c.id, true, r.para);
        await recarregar(true); renderView(); if (S.gaveta && S.gaveta.tipo === 'contr') abrirContrato(c.id); U.toast('Aviso registrado');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'excluir-contr': async () => {
      const c = C(S.gaveta.id);
      if (!(await U.confirmar('Excluir contrato?', `O pedido ${c.pedido} e as medições dele serão apagados. Para encerrar sem apagar, mude a situação para Finalizado.${S.papel === 'admin' ? '' : ' Contrato com medição, F.S. ou nota fiscal só o administrador exclui.'}`, 'Excluir', true))) return;
      try { await API.excluirContrato(c.id); await recarregar(true); fecharGaveta(); renderView(); U.toast('Contrato excluído'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Histórico
    'aba-hist': (el) => { S.f.hist = el.dataset.v; renderView(); },
    'hist-limpos': (el) => { S.f.histLimpos = el.dataset.v === '1'; renderView(); },
    'seg-verificar': async (el) => {
      el.disabled = true;
      try { S.segVerif = await API.segurancaVerificar(); renderView(); const r = S.segVerif.resumo; U.toast(r.critico ? `${r.critico} item(ns) crítico(s) na verificação` : r.alerta ? `${r.alerta} alerta(s) na verificação` : 'Verificação concluída: nada crítico', r.critico ? 'erro' : undefined); }
      catch (e) { U.toast(e.message, 'erro'); el.disabled = false; }
    },
    'ir-pastas': () => irPara('pastas'),
    'copiar-webhook': () => U.copiar(document.getElementById('cw-url').value, 'Endereço do webhook copiado'),
    'salvar-webhook': async () => {
      const v = document.getElementById('cw-segredo').value.trim();
      if (!/^whsec_[A-Za-z0-9+/=]{16,200}$/.test(v)) { U.toast('Cole o Signing secret do webhook no Resend (começa com whsec_)', 'erro'); return; }
      try { await API.definirSegredoWebhook(v); document.getElementById('cw-segredo').value = ''; S.webhookSit = await API.webhookSituacao().catch(() => S.webhookSit); renderView(); U.toast('Segredo do webhook salvo'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'email-teste': async (el) => {
      el.disabled = true;
      try {
        const r = await API.emailTeste();
        U.toast(`E-mail de teste enviado para ${r.para}`);
        const ver = async () => { S.emailTeste = await API.emailTesteResultado().catch(() => S.emailTeste); S.webhookSit = await API.webhookSituacao().catch(() => S.webhookSit); if (S.view === 'conf') renderView(); };
        await ver(); setTimeout(ver, 3000); setTimeout(ver, 10000);
      } catch (e) { U.toast(e.message, 'erro'); el.disabled = false; }
    },
    'email-teste-ver': async () => { S.emailTeste = await API.emailTesteResultado().catch(() => S.emailTeste); S.webhookSit = await API.webhookSituacao().catch(() => S.webhookSit); renderView(); },
    'seg-vistos': async () => {
      try { const n = await API.marcarEventosVistos(null); S.segPend = []; await carregarHistorico(); renderView(); U.toast(`${n} registro${n !== 1 ? 's' : ''} marcado${n !== 1 ? 's' : ''} como visto${n !== 1 ? 's' : ''}`); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'ver-envio': (el) => verEnvio(el.dataset.s),
    'executar-rotina': async () => {
      try { const r = await API.executarRotina(); U.toast(r && r.ultima_execucao ? 'A rotina já rodou há menos de 30 minutos' : `Rotina executada · ${r.links_expirados || 0} link(s) expirado(s)`); await recarregar(); await carregarHistorico(); renderView(); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    // Configurações
    'salvar-modelo': async () => {
      try {
        await API.salvarConfig('modelo_assunto', document.getElementById('cf-assunto').value);
        await API.salvarConfig('modelo_corpo', document.getElementById('cf-corpo').value);
        await recarregar(true); renderView(); U.toast('Modelo salvo');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'ir-colab': async () => { await irPara('colab'); },
    'salvar-modelo-aval': async () => {
      const a = document.getElementById('ca-assunto').value, c = document.getElementById('ca-corpo').value;
      if (!a.trim() || !c.includes('{LINK}')) { U.toast('O modelo precisa de assunto e do campo {LINK} no corpo', 'erro'); return; }
      try { await API.salvarConfig('modelo_aval_assunto', a); await API.salvarConfig('modelo_aval_corpo', c); await recarregar(true); renderView(); U.toast('Modelo da avaliação salvo'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-padrao-aval': async () => {
      const notas = {};
      document.querySelectorAll('[data-padrao]').forEach((s) => { notas[s.dataset.padrao] = s.value ? Number(s.value) : null; });
      if (!U.notasCompletas(notas)) { U.toast('Escolha uma nota de 1 a 10 em todos os itens', 'erro'); return; }
      const p = Number(document.getElementById('ca-prazo').value);
      if (!(p >= 1 && p <= 30)) { U.toast('Use um prazo entre 1 e 30 dias úteis', 'erro'); return; }
      try {
        await API.salvarConfig('avaliacao_padrao', JSON.stringify(notas));
        await API.salvarConfig('avaliacao_prazo_dias_uteis', p);
        await recarregar(true); renderView(); U.toast(`Resposta padrão salva (nota geral ${U.nota(U.mediaNotas(notas))})`);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'limpar-padrao-aval': async () => {
      if (!(await U.confirmar('Remover a resposta padrão?', 'Sem resposta padrão, as avaliações sem resposta ficam pendentes até o supervisor responder ou um novo link ser enviado.', 'Remover', true))) return;
      try { await API.salvarConfig('avaliacao_padrao', ''); await recarregar(true); renderView(); U.toast('Resposta padrão removida'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Notas fiscais
    'filtro-nf': (el) => { S.f.nf = el.dataset.v; renderView(); },
    'abrir-nf': (el) => abrirNF(el.dataset.m),
    'ir-conf-nf': async () => { await irPara('conf'); const s = document.getElementById('conf-nf'); if (s) s.scrollIntoView({ block: 'start' }); },
    'nf-salvar-folha': (el) => salvarFolha(el.dataset.m),
    'nf-desfazer-folha': async (el) => {
      if (!(await U.confirmar('Desfazer o lançamento da folha?', 'Número, data, parcela e descrição da folha de serviço são apagados desta medição.', 'Desfazer', true))) return;
      try { await API.lancarFolha(el.dataset.m, null, null, null, null); await recarregar(true); renderView(); abrirNF(el.dataset.m, { manterScroll: true }); U.toast('Lançamento desfeito'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-gerar': async (el) => {
      try { await API.gerarSolicitacaoNF(el.dataset.m); await recarregar(); renderView(); abrirNF(el.dataset.m); U.toast('E-mail pronto. Confira os destinatários e os anexos e envie ao fornecedor.'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-copiar-link': (el) => { const n = S.nfSolic.find((x) => x.id === el.dataset.id); if (n) U.copiar(linkNF(n), 'Link da NF copiado'); },
    'nf-copiar-chave': (el) => U.copiar(el.dataset.v, 'Chave de acesso copiada'),
    'nf-previa': (el) => simularNF(el.dataset.id, true),
    'nf-simular': (el) => simularNF(el.dataset.id, false),
    'nf-copiar-email': async () => {
      try { const e = await emailNFFinal(); U.copiar(`Para: ${e.para.join(', ')}\nAssunto: ${e.assunto}\n\n${e.corpo}`, 'E-mail copiado'); } catch (err) { U.toast(err.message, 'erro'); }
    },
    'nf-outlook': async () => {
      try {
        const e = await emailNFFinal();
        const a = document.createElement('a'); a.href = U.mailto(e.para, e.assunto, e.corpo); document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => U.toast('Anexe a F.S. no Outlook (ou mantenha os links do e-mail) e depois clique em “Registrar envio”.'), 400);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'nf-registrar': async (el) => {
      const e0 = lerEmailForm();
      if (!conferirPara(e0)) return;
      try {
        const e = await emailNFFinal();
        const n = await API.registrarEnvioNF(el.dataset.id, e.para, e.assunto, e.corpo, e.anexos, e.manter);
        const mid = S.gaveta.id;
        await recarregar(); renderView(); abrirNF(mid);
        U.toast(`Envio registrado. Link válido até ${U.dataBR(U.dataLocal(n.expira_em))}.`);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'nf-enviar': async (el) => {
      const e0 = lerEmailForm();
      if (!conferirPara(e0)) return;
      const mid = S.gaveta.id;
      try {
        const links = await linksAnexosNF();
        const r = await API.enviarSolicitacaoNF(el.dataset.id, links, e0.para, e0.manter);
        await recarregar(); renderView(); abrirNF(mid);
        const ate = U.dataBR(U.dataLocal(r.expira_em));
        U.toast(r.tipo === 'lembrete' ? `Lembrete enviado. Prazo mantido até ${ate}.` : `F.S. enviada ao fornecedor${links.length ? ` com ${links.length} arquivo(s)` : ''}. Prazo da NF até ${ate}.`);
        if (!DEMO) setTimeout(async () => { await API.conferirEnvios().catch(() => {}); await recarregar(); if (S.view === 'nf') renderView(); if (S.gaveta && S.gaveta.id === mid) abrirNF(mid, { manterScroll: true }); }, 8000);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'nf-renovar': async (el) => {
      if (!(await U.confirmar('Gerar novo link da NF?', 'Um link novo é criado com o prazo recomeçado. Depois, envie de novo ao fornecedor.', 'Gerar novo link'))) return;
      try { await API.renovarSolicitacaoNF(el.dataset.id); const mid = S.gaveta.id; await recarregar(); renderView(); abrirNF(mid); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-cancelar': async (el) => {
      if (!(await U.confirmar('Cancelar o pedido de NF?', 'O link do fornecedor deixa de funcionar e a folha de serviço volta a poder ser alterada.', 'Cancelar pedido', true))) return;
      try { await API.cancelarSolicitacaoNF(el.dataset.id); const mid = S.gaveta.id; await recarregar(); renderView(); abrirNF(mid); U.toast('Pedido de NF cancelado'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-aprovar': async (el) => {
      const nota = S.nfNotas.find((x) => x.id === el.dataset.id);
      const txt = nota.alertas ? `A nota tem ${nota.alertas} alerta(s) na conferência automática. Confirme que você conferiu cada um.` : 'A nota passou na conferência automática.';
      if (!(await U.confirmar(`Aprovar a NF nº ${nota.numero}?`, `${txt} O número entra na medição para o pagamento${S.med.find((x) => x.id === nota.medicao_id).folha_status === 'aprovada' && autoServicos() ? ' e a NF é encaminhada a Serviços' : ''}.`, 'Aprovar nota'))) return;
      try {
        await API.conferirNF(nota.id, true); const mid = S.gaveta.id; await recarregar(); renderView(); abrirNF(mid);
        const m = S.med.find((x) => x.id === mid);
        U.toast(m && m.encaminhado_em ? 'Nota aprovada e encaminhada a Serviços. Processo finalizado.' : m && m.folha_status === 'aprovada' ? 'Nota aprovada. Encaminhe a NF a Serviços.' : 'Nota aprovada. Ela vai a Serviços depois da aprovação da F.S.');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-recusar': async (el) => {
      const nota = S.nfNotas.find((x) => x.id === el.dataset.id);
      const motivo = (document.getElementById('nf-motivo-' + nota.id) || {}).value || '';
      if (motivo.trim().length < 5) { U.toast('Escreva o motivo da recusa (o fornecedor verá este texto)', 'erro'); return; }
      if (!(await U.confirmar(`Recusar a NF nº ${nota.numero}?`, 'Em seguida, gere um novo link: o e-mail ao fornecedor informa o motivo.', 'Recusar nota', true))) return;
      try { await API.conferirNF(nota.id, false, motivo.trim()); const mid = S.gaveta.id; await recarregar(); renderView(); abrirNF(mid); U.toast('Nota recusada. Gere um novo link para o fornecedor.'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'nf-xml': (el) => baixarXmlNF(el.dataset.id, el.dataset.n),
    'estimar-pagas': estimarPagasAntes,
    'salvar-conf-nf': async () => {
      const linhas = document.getElementById('cn-cnpjs').value.split(/[\n,;]+/).map((x) => x.trim()).filter(Boolean);
      const ruim = linhas.find((x) => !U.cnpjValido(x));
      if (ruim) { U.toast(`CNPJ inválido: ${ruim}`, 'erro'); return; }
      if (linhas.length > 20) { U.toast('Até 20 CNPJs', 'erro'); return; }
      const p = Number(document.getElementById('cn-prazo').value);
      if (!(p >= 1 && p <= 30)) { U.toast('Use um prazo entre 1 e 30 dias úteis', 'erro'); return; }
      try {
        await API.salvarConfig('cnpj_klingele', [...new Set(linhas.map(U.cnpj))].join(','));
        await API.salvarConfig('nf_prazo_dias_uteis', p);
        await recarregar(true); renderView(); U.toast('Configuração da nota fiscal salva');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-modelo-nf': async () => {
      const a = document.getElementById('cn-assunto').value, c = document.getElementById('cn-corpo').value;
      if (!a.trim() || !c.includes('{LINK}')) { U.toast('O modelo precisa de assunto e do campo {LINK} no corpo', 'erro'); return; }
      try { await API.salvarConfig('modelo_nf_assunto', a); await API.salvarConfig('modelo_nf_corpo', c); await recarregar(true); renderView(); U.toast('Modelo do e-mail da NF salvo'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    // Colaboradores Klingele
    'novo-colab': () => abrirColaborador(null),
    'abrir-colab': (el) => abrirColaborador(el.dataset.id),
    'salvar-colab': salvarColaborador,
    'excluir-colab': async () => {
      const c = COL(S.gaveta.id);
      const n = S.base.contratos.filter((k) => k.supervisor_id === c.id).length;
      if (!(await U.confirmar('Excluir colaborador?', `${c.nome} sai da lista de contatos${n ? ` e deixa de ser supervisor de ${n} contrato(s)` : ''}. Para apenas ocultar, desmarque "Ativo".`, 'Excluir', true))) return;
      try { await API.excluirColaborador(c.id); await recarregar(true); fecharGaveta(); renderView(); U.toast('Colaborador excluído'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    // Documentos
    'doc-baixar': (el) => baixarDocumento(el.dataset.d),
    // Contratos
    'filtro-tipo-sem': () => { S.f.tipoServ = 'sem'; S.f.contrFiltro = 'ativos'; renderView(); },
    // Avaliações
    'filtro-aval': (el) => { S.f.aval = el.dataset.v; renderView(); },
    'ver-aval': (el) => abrirAvaliacao(el.dataset.a),
    'copiar-link-aval': (el) => { const a = S.aval.find((x) => x.id === el.dataset.a); if (a) U.copiar(linkAvaliacao(a), 'Link da avaliação copiado'); },
    'previa-aval': (el) => simularAvaliacao(el.dataset.a, true),
    'simular-aval': (el) => simularAvaliacao(el.dataset.a, false),
    'padrao-aval': (el) => aplicarPadraoUma(el.dataset.a),
    'padrao-vencidas': async () => {
      const p = padraoAval();
      const n = S.aval.filter(avalVencida).length;
      if (!p) { U.toast('Defina a resposta padrão em Configurações > Avaliação de satisfação', 'erro'); return; }
      if (!(await U.confirmar('Aplicar a resposta padrão nas vencidas?', `${n} avaliação(ões) de ${U.compLabel(S.comp)} sem resposta recebem as notas padrão (média ${U.nota(U.mediaNotas(p))}) e a observação "Resposta aprovada pelo supervisor (nome)". Confirme que os supervisores aprovaram.`, 'Aplicar'))) return;
      try { const r = await API.aplicarPadraoVencidas(S.comp); await recarregar(); renderView(); U.toast(`Resposta padrão aplicada em ${r.aplicadas} avaliação(ões)`); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'gerar-avals': async () => {
      try {
        const r = await API.gerarAvaliacoes(S.comp, null); await recarregar(); renderView();
        U.toast(r.geradas ? `${r.geradas} avaliaç${r.geradas > 1 ? 'ões geradas' : 'ão gerada'}. Prossiga com o envio aos supervisores.` : 'Nenhuma avaliação nova: confira se os contratos têm supervisor.');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'enviar-avals': async () => {
      if (!(await U.confirmar('Enviar as avaliações agora?', `As avaliações de ${U.compLabel(S.comp)} que faltam serão geradas e enviadas por e-mail aos supervisores que ainda não receberam.`, 'Enviar agora'))) return;
      try {
        const r = await API.enviarAvaliacoes(S.comp, null); await recarregar(); renderView();
        U.toast(`${r.enviados} avaliaç${r.enviados !== 1 ? 'ões enviadas' : 'ão enviada'}${r.sem_email && r.sem_email.length ? ` · sem e-mail: ${r.sem_email.join(', ')}` : ''}`);
        if (!DEMO) setTimeout(async () => { await API.conferirEnvios().catch(() => {}); await recarregar(); if (S.view === 'aval') renderView(); }, 8000);
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'enviar-aval': async (el) => {
      const e = lerEmailForm();
      if (!conferirPara(e)) return;
      const aid = el.dataset.a;
      try {
        const r = await API.reenviarAvaliacao(aid, e.para, e.manter);
        await recarregar(); renderView(); abrirAvaliacao(aid);
        const ate = U.dataBR(U.dataLocal(r.expira_em));
        U.toast(r.tipo === 'lembrete' ? `Lembrete enviado. Prazo mantido até ${ate}.` : r.tipo === 'reenvio' ? `Avaliação reenviada. Novo prazo até ${ate}.` : `Avaliação enviada. Prazo até ${ate}.`);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'registrar-envio-aval': async (el) => {
      const e = lerEmailForm();
      if (!conferirPara(e)) return;
      try {
        const a = await API.registrarEnvioAvaliacao(el.dataset.a, e.para, e.assunto, e.corpo, e.manter);
        await recarregar(); renderView(); abrirAvaliacao(a.id);
        U.toast(`Envio registrado. Link válido até ${U.dataBR(U.dataLocal(a.expira_em))}.`);
      } catch (err) { U.toast(err.message, 'erro'); }
    },
    'renovar-aval': async (el) => {
      if (!(await U.confirmar('Gerar novo link da avaliação?', 'O link atual deixa de funcionar e o prazo recomeça. Depois, envie de novo ao supervisor.', 'Gerar novo link'))) return;
      try { const a = await API.renovarAvaliacao(el.dataset.a); await recarregar(); renderView(); abrirAvaliacao(a.id); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'cancelar-aval': async (el) => {
      if (!(await U.confirmar('Cancelar avaliação?', 'O link do supervisor deixa de funcionar. Você pode reabrir depois.', 'Cancelar avaliação', true))) return;
      try { await API.cancelarAvaliacao(el.dataset.a); await recarregar(); fecharGaveta(); renderView(); U.toast('Avaliação cancelada'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'salvar-prazo': async () => {
      const p = Number(document.getElementById('cf-prazo').value);
      if (!(p >= 1 && p <= 30)) { U.toast('Use um prazo entre 1 e 30 dias úteis', 'erro'); return; }
      try {
        await API.salvarConfig('prazo_dias_uteis', p);
        await recarregar(true); renderView(); U.toast('Configuração salva');
      } catch (e) { U.toast(e.message, 'erro'); }
    },
    'add-feriado': async () => {
      const data = document.getElementById('cf-f-data').value, nome = document.getElementById('cf-f-nome').value.trim();
      if (!data || nome.length < 2) { U.toast('Informe a data e uma descrição', 'erro'); return; }
      if ([0, 6].includes(U.diaSemana(data))) { U.toast(`${U.dataBR(data)} é ${U.DIAS_SEMANA[U.diaSemana(data)]}: sábados e domingos não são considerados dias úteis.`, 'erro'); return; }
      try { await API.salvarFeriado({ data, nome }); await recarregar(true); renderView(); U.toast('Feriado incluído'); }
      catch (e) { U.toast(e.message, 'erro'); }
    },
    'rm-feriado': async (el) => { try { await API.excluirFeriado(el.dataset.d); await recarregar(true); renderView(); } catch (e) { U.toast(e.message, 'erro'); } },
    'add-membro': async () => {
      const email = document.getElementById('cf-m-email').value.trim().toLowerCase(), papel = document.getElementById('cf-m-papel').value;
      if (!U.emailValido(email)) { U.toast('E-mail inválido', 'erro'); return; }
      try { await API.salvarMembro({ email, papel }); await recarregar(true); renderView(); U.toast('Acesso liberado. Crie o login no Supabase com este e-mail.'); } catch (e) { U.toast(e.message, 'erro'); }
    },
    'rm-membro': async (el) => {
      if (!(await U.confirmar('Remover acesso?', `${el.dataset.e} deixa de ver os dados do app.`, 'Remover', true))) return;
      try { await API.excluirMembro(el.dataset.e); await recarregar(true); renderView(); } catch (e) { U.toast(e.message, 'erro'); }
    }
  };
  function syncContatosForn() {
    document.querySelectorAll('#ff-contatos [data-fc]').forEach((inp) => {
      const c = S.gaveta.contatos[Number(inp.dataset.fc)];
      if (!c) return;
      c[inp.dataset.k] = inp.type === 'checkbox' ? inp.checked : inp.value;
    });
  }
  async function mudarComp(c) {
    S.comp = c;
    await recarregar();
    render();
  }

  const ACOES_EDICAO = new Set(['gerar-pasta', 'gerar-um', 'registrar-envio', 'renovar', 'cancelar', 'enviar-um', 'renovar-reenviar', 'lembrete-todos', 'usar-informados',
    'salvar-conf', 'marcar-recebido', 'incluir-med', 'novo-forn', 'ff-add-contato', 'salvar-forn', 'novo-contr', 'salvar-contr', 'add-feriado', 'rm-feriado', 'usar-lido',
    'toggle-envio', 'med', 'doc-tipo', 'doc-contrato', 'anexar', 'novo-colab', 'salvar-colab', 'colab-flag', 'excluir-colab', 'excluir-contr',
    'gerar-avals', 'enviar-avals', 'enviar-aval', 'registrar-envio-aval', 'renovar-aval', 'padrao-aval', 'padrao-vencidas', 'cancelar-aval',
    'nf-salvar-folha', 'nf-desfazer-folha', 'nf-gerar', 'nf-registrar', 'nf-enviar', 'nf-renovar', 'nf-cancelar', 'nf-aprovar', 'nf-recusar', 'nf-anexar-pc', 'estimar-pagas',
    'fs-aprovar', 'fs-desfazer', 'fs-anexar', 'fs-reavisar', 'cobrar-agora', 'venc-avisar', 'venc-outlook', 'serv-encaminhar', 'nf-form',
    'nova-pasta', 'salvar-pasta', 'excluir-pasta', 'pasta-enviar', 'pasta-transferir', 'avulsos-mover', 'pasta-add-data',
    'docs-klg-gerar', 'pedir-docs', 'dispensar', 'reativar-envio', 'doc-klg-rm', 'anexar-klg']);
  const ACOES_ADMIN = new Set(['doc-rm', 'excluir-forn', 'salvar-modelo', 'salvar-prazo', 'add-membro', 'rm-membro', 'salvar-email', 'exigir-mfa',
    'salvar-modelo-aval', 'salvar-padrao-aval', 'limpar-padrao-aval', 'salvar-conf-nf', 'salvar-modelo-nf',
    'toggle-cobranca', 'salvar-fluxo', 'salvar-conf-fs', 'salvar-conf-venc', 'salvar-cadastro',
    'hist-limpar', 'receb-excluir', 'solic-excluir', 'envio-excluir', 'salvar-webhook', 'email-teste', 'email-teste-ver']);
  const ACOES_APROVAR = new Set(['salvar-usuario', 'usu-rapido', 'nova-equipe', 'salvar-equipe', 'excluir-equipe', 'equipe-convidar', 'equipe-tirar']);
  function bloqueado(acao) {
    if (ACOES_ADMIN.has(acao) && S.papel !== 'admin') { U.toast('Ação restrita a administradores', 'erro'); return true; }
    if (ACOES_APROVAR.has(acao) && !podeAprovar()) { U.toast('Ação restrita a administradores e supervisores', 'erro'); return true; }
    if (ACOES_EDICAO.has(acao) && S.papel === 'leitura') { U.toast('Seu perfil é somente leitura', 'erro'); return true; }
    return false;
  }

  document.addEventListener('click', (ev) => {
    const nav = ev.target.closest('[data-view]');
    if (nav && !ev.target.closest('.portal-overlay')) { ev.preventDefault(); const sh = root.querySelector('.shell'); if (sh) sh.classList.remove('nav-aberta'); fecharGaveta(); irPara(nav.dataset.view); return; }
    const el = ev.target.closest('[data-act]');
    if (!el || ev.target.closest('.portal-overlay')) return;
    if (ev.target.closest('.switch') && el.dataset.act !== 'tema') return;
    const fn = acoes[el.dataset.act];
    if (!fn) return;
    if (bloqueado(el.dataset.act)) { ev.preventDefault(); return; }
    if (el.tagName === 'BUTTON' && el.closest('summary')) ev.preventDefault(); // botão no título de um painel recolhível não abre/fecha o painel
    const r = fn(el, ev);
    if (r !== 'default' && el.tagName === 'A') ev.preventDefault();
  });
  document.addEventListener('change', async (ev) => {
    const t = ev.target;
    if (t.closest('.portal-overlay')) return;
    if (t.id === 'comp-sel') return mudarComp(t.value);
    if (t.id === 'f-gestor') { S.f.gestor = t.value; return renderView(); }
    if (t.id === 'f-pasta') { S.f.pasta = t.value; return renderView(); }
    if (t.dataset.pcontr !== undefined && S.gaveta && S.gaveta.tipo === 'pasta') {
      if (t.checked) S.gaveta.sel.add(t.dataset.pcontr); else S.gaveta.sel.delete(t.dataset.pcontr);
      const n = document.getElementById('pa-ncontr'); if (n) n.textContent = `(${S.gaveta.sel.size})`;
      t.closest('.pa-c').classList.toggle('marcado', t.checked); return;
    }
    if (t.id === 'pa-cver' && S.gaveta) { S.gaveta.cVer = t.value; atualizarListaPasta(); return; }
    if (t.id === 'pa-regra-on' && S.gaveta) { const r = rascunhoPasta(); S.gaveta.regraOn = t.checked; abrirPasta(S.gaveta.id, r); return; }
    if (t.id === 'av-todos') { document.querySelectorAll('[data-av]').forEach((b) => { b.checked = t.checked; }); return; }
    if (['pa-dia', 'pa-hora', 'pa-ativa', 'pa-pede'].includes(t.id) || t.dataset.pmes !== undefined) {
      const r = rascunhoPasta(), el = document.getElementById('pa-prox');
      if (el) el.textContent = r.ativa === false ? 'Desligado: o link só sai pelo botão' : proxTxt({ ...r, calendario: S.gaveta.cal }); return;
    }
    if (t.closest && t.closest('#pa-filtro')) { atualizarPreviaFiltro(); return; }
    if (t.dataset.chg === 'pasta-add-pessoa' && S.gaveta && S.gaveta.tipo === 'pasta') {
      const r = rascunhoPasta(), g = S.gaveta;
      if (t.value && !g.comp.some((c) => c.alvo_tipo === 'usuario' && c.alvo === t.value)) g.comp.push({ alvo_tipo: 'usuario', alvo: t.value, nivel: 'ver' });
      abrirPasta(g.id, r, 'pa-acessos'); return;
    }
    if (t.id === 'fk-sup') { document.querySelectorAll('#fk-aloc [data-aloc="sup"]').forEach((i) => { i.disabled = !t.checked; }); return; }
    if (t.id === 'fk-so-marcados' || t.dataset.aloc) {
      filtrarAloc();
      const r = document.getElementById('fk-resumo'); if (r) r.textContent = alocResumo(alocMarcados('ct').length, alocMarcados('sup').length);
      return;
    }
    if (t.dataset.chg === 'resp-add' && S.gaveta && S.gaveta.tipo === 'contr') {
      if (t.value) (t.dataset.papel === 'sup' ? S.gaveta.sups : S.gaveta.cts).push(t.value);
      atualizarResp(); return;
    }
    if (t.id === 'f-tipo-serv') { S.f.tipoServ = t.value; return renderView(); }
    if (t.id === 'f-contr-pasta') { S.f.contrPasta = t.value; return renderView(); }
    if (t.id === 'hist-forn') { S.f.histForn = t.value; return renderView(); }
    if (['pf-forn', 'pf-sup', 'pf-tipo', 'pf-etapa'].includes(t.id)) { S.f[{ 'pf-forn': 'pForn', 'pf-sup': 'pSup', 'pf-tipo': 'pTipo', 'pf-etapa': 'pEtapa' }[t.id]] = t.value; return renderView(); }
    if (t.dataset.fc !== undefined) { syncContatosForn(); return; }
    if (t.dataset.chg === 'ff-docs') { const b = document.querySelector('#gaveta .docs-klg-sel'); if (b) b.hidden = !t.checked; return; }
    if (t.dataset.padrao !== undefined) {
      const n = {}; document.querySelectorAll('[data-padrao]').forEach((s) => { if (s.value) n[s.dataset.padrao] = Number(s.value); });
      const b = document.getElementById('padrao-media'), m = U.mediaNotas(n);
      if (b) { b.textContent = U.nota(m); b.className = 'nota-badge sm ' + U.classeNota(m); }
      return;
    }
    if (t.dataset.cfg) {
      if (S.papel !== 'admin') { t.checked = !t.checked; U.toast('Ação restrita a administradores', 'erro'); return; }
      try { await API.salvarConfig(t.dataset.cfg, t.checked ? 'true' : 'false'); await recarregar(true); renderView(); U.toast(t.checked ? 'Opção ativada' : 'Opção desativada'); }
      catch (e) { t.checked = !t.checked; U.toast(e.message, 'erro'); }
      return;
    }
    const k = t.dataset.chg;
    if (!k) return;
    if (k === 'prazo-opcao' && S.gaveta) { const e = lerEmailForm(); abrirSolicitacao(S.gaveta.id, { manter: e.manter, marcados: e.marcados, extra: e.extra, manterScroll: true }); return; }
    if ((k === 'prazo-opcao-nf' || k === 'nf-anexos') && S.gaveta) {
      const e = lerEmailForm();
      const anexos = Array.from(document.querySelectorAll('#gaveta [data-anx]:checked')).map((i) => i.value);
      abrirNF(S.gaveta.id, { manter: e.manter, marcados: e.marcados, extra: e.extra, anexos, manterScroll: true, form: S.gaveta.form }); return;
    }
    if (k === 'nf-parcela') {
      const d = document.getElementById('nf-desc'), m = S.med.find((x) => x.id === S.gaveta.id);
      if (d && m && (d.dataset.auto === '1' || d.value === descricaoPadrao(m, Number(t.dataset.ant)))) { d.value = descricaoPadrao(m, Number(t.value)); d.dataset.auto = '1'; }
      t.dataset.ant = t.value;
      return;
    }
    if (k === 'nf-anexar-pc' || k === 'fs-anexar') {
      if (bloqueado(k)) { t.value = ''; return; }
      const files = Array.from(t.files); t.value = ''; await anexarPedidoCompra(files, k === 'fs-anexar' ? 'folha_servico' : 'pedido_compra'); return;
    }
    if (k === 'prazo-opcao-aval' && S.gaveta) { const e = lerEmailForm(); abrirAvaliacao(S.gaveta.id, { manter: e.manter, marcados: e.marcados, extra: e.extra, manterScroll: true }); return; }
    if (bloqueado(k)) { if (t.type === 'checkbox') t.checked = !t.checked; else if (['pag', 'envio'].includes(S.view)) renderView(); return; }
    try {
      if (k === 'toggle-auto') {
        const pad = pastaPadrao();
        if (!pad || !podeEditarPasta(pad)) { t.checked = !t.checked; U.toast('Administradores e supervisores alteram o Envio mensal', 'erro'); return; }
        try { await API.salvarPasta(pad.id, { nome: pad.nome, ativa: t.checked }); } catch (err) { t.checked = !t.checked; throw err; }
        await recarregar(true); renderView();
        U.toast(t.checked ? `Disparo automático do Envio mensal ligado: ${proxTxt(pastaPadrao()).toLowerCase()}` : 'Disparo automático do Envio mensal desligado');
        return;
      }
      if (k === 'exigir-mfa' || k === 'toggle-cobranca') {
        if (k === 'toggle-cobranca' && S.papel !== 'admin') { t.checked = !t.checked; U.toast('Ação restrita a administradores', 'erro'); return; }
        const chave = { 'exigir-mfa': 'exigir_mfa', 'toggle-cobranca': 'cobranca_automatica' }[k];
        try {
          await API.salvarConfig(chave, t.checked ? 'true' : 'false');
        } catch (err) { t.checked = !t.checked; throw err; }
        await recarregar(true); renderView();
        U.toast(k === 'toggle-cobranca' ? (t.checked ? 'Cobrança automática ativada' : 'Cobrança automática desativada')
          : (t.checked ? 'Verificação em duas etapas exigida para toda a equipe' : 'Verificação em duas etapas deixou de ser obrigatória'));
        return;
      }
      if (k === 'colab-flag') {
        const c = COL(t.dataset.id);
        if (t.dataset.k === 'supervisor' ? !podeMarcarSup(c) : !podeAlterarColab()) {
          t.checked = !t.checked;
          U.toast(t.dataset.k === 'supervisor' ? (S.papel === 'supervisor' ? 'O supervisor altera só a própria marca de supervisor' : 'Só o administrador altera a marca de supervisor de outra pessoa')
            : 'Só administradores e supervisores alteram os Contatos Klingele', 'erro');
          return;
        }
        if (t.dataset.k === 'contato_fornecedor' && t.checked && !c.email && !c.telefone) { t.checked = false; U.toast('Cadastre e-mail ou telefone antes de mostrar ao fornecedor', 'erro'); return; }
        if (t.dataset.k === 'contato_fornecedor' && t.checked && contatosFornecedor().length >= 5) U.toast('Apenas os 5 primeiros contatos (pela ordem) são exibidos ao fornecedor');
        try { await API.salvarColaborador({ id: c.id, [t.dataset.k]: t.checked }); }
        catch (err) { t.checked = !t.checked; throw err; }
        await recarregar(true); renderView();
        U.toast(t.dataset.k === 'supervisor' ? (t.checked ? `${c.nome} pode ser supervisor de contrato` : `${c.nome} deixou de ser supervisor`)
          : (t.checked ? `${c.nome} aparece para o fornecedor` : `${c.nome} não aparece mais para o fornecedor`));
        return;
      }
      if (k === 'toggle-envio') {
        const f = F(t.dataset.f);
        await API.salvarFornecedor({ id: f.id, deseja_enviar: t.checked });
        f.deseja_enviar = t.checked;
        U.toast(t.checked ? `${f.nome} entrou na lista de envio` : `${f.nome} saiu da lista de envio`);
        if (S.view === 'envio') renderView(); else root.querySelector('#nav').innerHTML = navHTML();
      }
      if (k === 'med') {
        const tr = t.closest('tr'), m = S.med.find((x) => x.id === tr.dataset.m);
        let v = t.value;
        if (t.dataset.k === 'valor_aprovado') {
          v = t.value.trim() === '' ? null : U.parseValor(t.value);
          if (t.value.trim() !== '' && v === null) { U.toast('Valor inválido', 'erro'); return; }
          t.value = U.numBR(v);
        }
        const patch = { id: m.id, [t.dataset.k]: v === '' ? null : v };
        if (t.dataset.k === 'nota_fiscal' && String(v || '').length > 60) { U.toast('Número da NF muito longo', 'erro'); renderView(); return; }
        if (t.dataset.k === 'data_pagamento' && v && m.status !== 'pago') { patch.status = 'pago'; tr.querySelector('[data-k="status"]').value = 'pago'; }
        if (t.dataset.k === 'valor_aprovado' && v !== null && ['aguardando', 'recebido', 'em_conferencia'].includes(m.status)) { patch.status = 'aprovado'; tr.querySelector('[data-k="status"]').value = 'aprovado'; }
        if (t.dataset.k === 'status' && v === 'pago' && !m.data_pagamento) {
          patch.data_pagamento = U.hojeISO();
          const di = tr.querySelector('[data-k="data_pagamento"]'); if (di) di.value = patch.data_pagamento;
        }
        const futuro = { ...m, ...patch };
        if (['aprovado', 'pago'].includes(futuro.status) && (futuro.valor_aprovado === null || futuro.valor_aprovado === undefined)) {
          U.toast('Informe o valor aprovado antes de aprovar ou pagar', 'erro'); renderView(); return;
        }
        if (futuro.status === 'pago' && m.status !== 'pago' && etapaNF(m).k !== 'aprovada'
          && !(await U.confirmar('Marcar como pago sem NF aprovada?', `O pedido ${C(m.contrato_id).pedido} de ${F(m.fornecedor_id).nome} ainda não tem nota fiscal aprovada na tela Notas fiscais${m.parcela ? '' : ' nem folha de serviço com a parcela'}. Pagar mesmo assim?`, 'Marcar como pago'))) {
          renderView(); return;
        }
        const novo = await API.salvarMedicao(patch);
        Object.assign(m, novo || patch);
        const tf = document.getElementById('pag-total');
        if (tf) {
          const filtro = S.f.pag === 'todos' ? S.med : S.med.filter((x) => GRUPO_PAG[S.f.pag].includes(x.status));
          tf.innerHTML = totaisPag(filtro);
          rotularTabelas(document.getElementById('main'));
        }
        U.toast('Salvo');
      }
      if (k === 'doc-tipo' || k === 'doc-contrato') {
        await API.atualizarDocumento(t.dataset.d, k === 'doc-tipo' ? { tipo: t.value } : { contrato_id: t.value || null });
        await recarregar();
        U.toast('Documento atualizado');
      }
      if (k === 'anexar') { const files = Array.from(t.files); t.value = ''; await anexar(files); }
      if (k === 'anexar-klg') { const files = Array.from(t.files); t.value = ''; await anexarKlg(files); }
    } catch (e) { U.toast(e.message, 'erro'); if (k === 'med' && S.view === 'pag') renderView(); }
  });
  document.addEventListener('input', (ev) => {
    const t = ev.target;
    if (t.id === 'pa-ftexto') { atualizarPreviaFiltro(); return; }
    if (t.id === 'pa-cbusca' && S.gaveta) { S.gaveta.cBusca = t.value; atualizarListaPasta(); return; }
    if (t.id === 'colab-busca') {
      const q = t.value.trim().toLowerCase(); let n = 0;
      document.querySelectorAll('#colab-lista .colab-row').forEach((r) => { r.hidden = !!q && !r.dataset.busca.includes(q); if (!r.hidden) n++; });
      const v = document.querySelector('#colab-lista .colab-nada'); if (v) v.hidden = n > 0;
      return;
    }
    if (t.id === 'hist-busca') {
      S.f.histBusca = t.value; const pos = t.selectionStart; renderView();
      const n = document.getElementById('hist-busca'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* sem seleção */ } }
      return;
    }
    if (t.id === 'usu-busca') {
      S.f.usuBusca = t.value; const pos = t.selectionStart; renderView();
      const n = document.getElementById('usu-busca'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* sem seleção */ } }
      return;
    }
    if (t.id === 'busca-forn' || t.id === 'busca-contr') {
      S.f[t.id === 'busca-forn' ? 'forn' : 'contr'] = t.value;
      const pos = t.selectionStart;
      renderView();
      const n = document.getElementById(t.id);
      if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* campo sem seleção */ } }
    }
    if (t.id === 'fc-mensal' || t.id === 'fc-meses') sugerirTotal();
    if (t.id === 'fk-busca') filtrarAloc();
    if (t.id === 'nf-desc') t.dataset.auto = '0';
    if (t.closest('#tbl-conf') && t.dataset.k === 'valor_aprovado') {
      const sel = t.closest('tr').querySelector('[data-k="status"]');
      if (t.value.trim() && ['aguardando', 'recebido', 'em_conferencia'].includes(sel.value)) sel.value = 'aprovado';
    }
  });
  document.addEventListener('toggle', (ev) => {
    const d = ev.target;
    if (d && d.matches && d.matches('details.retratil')) S.ret[d.dataset.ret] = d.open;
    if (d && d.dataset && d.dataset.lembrar) { try { localStorage.setItem(d.dataset.lembrar, d.open ? '1' : '0'); } catch (e) { /* sem armazenamento */ } }
  }, true);
  document.addEventListener('keydown', (ev) => {
    if (ev.key !== 'Escape') return;
    const sh = root.querySelector('.shell.nav-aberta');
    if (sh) { sh.classList.remove('nav-aberta'); return; }
    if (document.getElementById('gaveta')) fecharGaveta();
  });
  window.addEventListener('hashchange', () => {
    const h = (location.hash || '').slice(1);
    if (TITULOS[h] && h !== S.view && S.base && root.querySelector('.shell')) { fecharGaveta(); irPara(h); }
  });

  // =====================================================================
  //  LOGIN E INÍCIO
  // =====================================================================
  // ---------- Captcha opcional (Cloudflare Turnstile) ----------
  let captchaToken = null, captchaId = null;
  let loginAnimado = false; // a entrada animada roda só na primeira exibição (trocar de aba ou de tema não repete)
  async function montarCaptcha(alvo) {
    if (!cfg.turnstileSiteKey || !alvo) return;
    try {
      await U.carregarScript('https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit');
      captchaId = window.turnstile.render(alvo, { sitekey: cfg.turnstileSiteKey, language: 'pt-br', callback: (t) => { captchaToken = t; }, 'expired-callback': () => { captchaToken = null; } });
    } catch (e) { U.toast('Não foi possível carregar a verificação anti-robô', 'erro'); }
  }
  const resetCaptcha = () => { captchaToken = null; try { if (window.turnstile && captchaId !== null) window.turnstile.reset(captchaId); } catch (e) { /* ignore */ } };

  // ---------- Fluxo do mês na tela de entrada: roda deitada vista de frente ----------
  // As 4 etapas ficam numa roda deitada (elipse em perspectiva). A esfera fica sempre na frente de quem olha;
  // a roda gira e traz a próxima etapa até ela, deixando um rastro de luz no trecho percorrido. A legenda embaixo
  // mostra a etapa da frente. Sem animação quando o aparelho pede "Reduzir movimento".
  const ETAPAS_LOGIN = [['Boletim', 'O fornecedor envia o boletim pelo link'], ['F.S.', 'A equipe confere os valores e lança a folha de serviço'],
    ['NF', 'O fornecedor envia a nota fiscal pelo link'], ['Serviços', 'A NF segue para Serviços e o mês se encerra']];
  function rodaFluxo(caixa) {
    if (!caixa) return;
    const svg = caixa.querySelector('.lf-roda'), leg = caixa.querySelector('.lf-legenda');
    if (!svg || !leg) return;
    const NS = 'http://www.w3.org/2000/svg', el = (tag, at) => { const e = document.createElementNS(NS, tag); Object.entries(at || {}).forEach(([k, v]) => e.setAttribute(k, v)); return e; };
    // Roda deitada: elipse (perspectiva), aro com espessura na parte da frente, raios até as etapas
    const cx = 220, cy = 64, RX = 172, RY = 58, ARO = 8, N = ETAPAS_LOGIN.length, PASSO = 360 / N;
    const pt = (a, dy) => [cx + RX * Math.sin(a * Math.PI / 180), cy + RY * Math.cos(a * Math.PI / 180) + (dy || 0)];
    const arco = (a0, a1, dy, cont) => { const n = Math.max(2, Math.ceil(Math.abs(a1 - a0) / 3)); let d = ''; for (let i = 0; i <= n; i++) { const [x, y] = pt(a0 + (a1 - a0) * i / n, dy); d += (i || cont ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); } return d; };
    svg.setAttribute('viewBox', '0 0 440 176');
    svg.innerHTML = `<defs>
        <radialGradient id="lf-disco" cx=".5" cy=".62" r=".6"><stop offset="0" stop-color="#ffffff" stop-opacity=".09"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient>
        <linearGradient id="lf-borda" gradientUnits="userSpaceOnUse" x1="${cx - RX}" y1="0" x2="${cx + RX}" y2="0">
          <stop offset="0" stop-color="#7fd6b8" stop-opacity=".1"/><stop offset=".5" stop-color="#7fd6b8" stop-opacity=".85"/><stop offset="1" stop-color="#7fd6b8" stop-opacity=".1"/></linearGradient>
        <linearGradient id="lf-aro" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fd6b8" stop-opacity=".28"/><stop offset="1" stop-color="#7fd6b8" stop-opacity=".03"/></linearGradient>
        <radialGradient id="lf-halo"><stop offset="0" stop-color="#7fd6b8" stop-opacity=".6"/><stop offset=".4" stop-color="#7fd6b8" stop-opacity=".2"/><stop offset="1" stop-color="#7fd6b8" stop-opacity="0"/></radialGradient>
        <radialGradient id="lf-bola" cx=".36" cy=".32" r=".72"><stop offset="0" stop-color="#f2fffa"/><stop offset=".42" stop-color="#8fe3c6"/><stop offset="1" stop-color="#2f8f72"/></radialGradient></defs>`;
    const gFundo = el('g'), gAtras = el('g'), gFrente = el('g'), gTopo = el('g');
    gFundo.append(el('ellipse', { cx, cy, rx: RX, ry: RY, fill: 'url(#lf-disco)' }),
      el('path', { d: arco(90, 270), fill: 'none', stroke: 'rgba(255,255,255,.18)', 'stroke-width': 1.4 }),
      el('ellipse', { cx, cy, rx: 15, ry: 5, fill: 'rgba(255,255,255,.08)', stroke: 'rgba(255,255,255,.22)', 'stroke-width': 1 }));
    const raios = ETAPAS_LOGIN.map(() => { const l = el('line', { x1: cx, y1: cy, stroke: 'rgba(255,255,255,1)', 'stroke-width': 1.2 }); gFundo.append(l); return l; });
    // Parte da frente do aro (a espessura da roda, vista de frente) e a borda de cima iluminada no centro
    const aro = el('path', { d: arco(-90, 90) + arco(90, -90, ARO, true) + 'Z', fill: 'url(#lf-aro)' });
    const borda = el('path', { d: arco(-90, 90), fill: 'none', stroke: 'url(#lf-borda)', 'stroke-width': 2.4, 'stroke-linecap': 'round' });
    const base = el('path', { d: arco(-90, 90, ARO), fill: 'none', stroke: 'rgba(127,214,184,.22)', 'stroke-width': 1.2 });
    const rastro = el('path', { fill: 'none', stroke: '#9ff0d3', 'stroke-width': 3.4, 'stroke-linecap': 'round', opacity: 0 });
    const nos = ETAPAS_LOGIN.map(([nome]) => {
      const g = el('g'), c = el('circle', { r: 6 }), tx = el('text', { 'text-anchor': 'middle', 'font-weight': 600 }); tx.textContent = nome;
      g.append(c, tx); return { g, c, tx };
    });
    const [fx, fy] = pt(0);
    const halo = el('circle', { cx: fx, cy: fy, r: 26, fill: 'url(#lf-halo)' }), bola = el('circle', { cx: fx, cy: fy - 1, r: 9, fill: 'url(#lf-bola)' });
    gTopo.append(halo, bola);
    svg.append(gFundo, gAtras, aro, base, borda, rastro, gFrente, gTopo);
    svg.style.overflow = 'visible';
    // Altura (no desenho) do nome na legenda: o rótulo da etapa que chega à frente desce até lá
    let yLeg = null;
    const medirLeg = () => {
      const rs = svg.getBoundingClientRect(), rn = leg.querySelector('.lf-nome').getBoundingClientRect();
      if (!rs.height) return; const esc = 176 / rs.height;
      yLeg = (rn.top + rn.height * 0.78 - rs.top) * esc;
    };
    window.addEventListener('resize', () => { yLeg = null; });
    const reduzir = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let atual = -1;
    const legenda = (i) => {
      if (i === atual) return; atual = i;
      leg.querySelector('.lf-passo').textContent = `Etapa ${i + 1} de ${N}`;
      leg.querySelector('.lf-nome').textContent = ETAPAS_LOGIN[i][0];
      leg.querySelector('.lf-desc').textContent = ETAPAS_LOGIN[i][1];
    };
    const desenhar = (fi, brilho) => {
      let kChega = 0;
      nos.forEach((n, i) => {
        let a = ((i - fi) * PASSO) % 360; if (a > 180) a -= 360; if (a < -180) a += 360;
        const [x, y] = pt(a), d = (1 + Math.cos(a * Math.PI / 180)) / 2, naFrente = Math.abs(a) < PASSO * 0.2;
        const k = Math.max(0, 1 - Math.abs(a) / PASSO), kk = k * k * (3 - 2 * k); // 1 = na frente, 0 = posição vizinha
        n.c.setAttribute('cx', x.toFixed(1)); n.c.setAttribute('cy', y.toFixed(1)); n.c.setAttribute('r', (2.6 + 5.4 * d).toFixed(2));
        n.c.style.fill = naFrente ? '#7fd6b8' : 'var(--rail)';
        n.c.style.stroke = `rgba(255,255,255,${(0.25 + 0.55 * d).toFixed(2)})`; n.c.setAttribute('stroke-width', (1 + 1.2 * d).toFixed(2));
        n.c.style.opacity = '1'; // o ponto não some: a esfera passa por cima dele
        if (yLeg === null) medirLeg();
        // Só a etapa que está chegando desce até o nome da legenda; a que sai some sob a esfera e reaparece no aro
        const chega = a > 0.01, yBase = y + 13 + 9 * d, yAlvo = yLeg === null ? yBase : yLeg, m = chega ? kk : 0;
        if (chega) kChega = Math.max(kChega, k);
        n.tx.setAttribute('x', (x + (cx - x) * m).toFixed(1)); n.tx.setAttribute('y', (yBase + (yAlvo - yBase) * m).toFixed(1));
        n.tx.setAttribute('font-size', (8 + 5 * d + (chega ? 3 * kk : 0)).toFixed(1));
        const somir = chega ? 1 : Math.min(1, (1 - k) / 0.6); // o que chega fica visível até virar o nome da legenda
        n.tx.style.fill = `rgba(255,255,255,${((0.25 + 0.65 * d) * somir).toFixed(2)})`;
        (d < 0.5 ? gAtras : gFrente).append(n.g);
        raios[i].setAttribute('x2', x.toFixed(1)); raios[i].setAttribute('y2', y.toFixed(1)); raios[i].setAttribute('stroke-opacity', (0.06 + 0.3 * d).toFixed(2));
      });
      // A legenda atual se apaga enquanto o nome da próxima etapa desce até ela
      const op = (1 - Math.min(1, kChega / 0.85) ** 2).toFixed(2);
      leg.querySelector('.lf-nome').style.opacity = op; leg.querySelector('.lf-desc').style.opacity = op;
      leg.querySelector('.lf-passo').style.opacity = (1 - Math.min(1, kChega / 0.5)).toFixed(2); // "Etapa N de 4" sai do caminho do nome que desce
      // Rastro de luz: o trecho da roda que acabou de passar pela esfera
      const frac = fi - Math.floor(fi);
      rastro.setAttribute('d', arco(-Math.max(frac, 0.02) * PASSO, 0)); rastro.setAttribute('opacity', (brilho * 0.95).toFixed(2));
      halo.setAttribute('r', (26 * (1 + 0.22 * brilho)).toFixed(1));
    };
    if (reduzir) { desenhar(0, 0); legenda(0); return; }
    const SEG = 1900, MOVE = 1300, CICLO = (SEG + MOVE) * N, t0 = performance.now();
    const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
    const quadro = (agora) => {
      if (!svg.isConnected) return;
      if (!document.hidden && caixa.offsetParent !== null) {
        const tc = (agora - t0) % CICLO, k = Math.floor(tc / (SEG + MOVE)), tl = tc - k * (SEG + MOVE);
        const mov = tl < SEG ? 0 : ease((tl - SEG) / MOVE), fi = k + mov;
        desenhar(fi, tl < SEG ? Math.max(0, 1 - tl / 500) : Math.sin(mov * Math.PI) * 0.9 + mov * 0.1);
        legenda(Math.floor(fi + 0.03) % N); // a legenda troca quando o rótulo chega a ela
      }
      requestAnimationFrame(quadro);
    };
    requestAnimationFrame(quadro);
  }

  // Celular: trilho do mês no topo verde. A esfera percorre Boletim > F.S. > NF > Serviços, acende o trecho já
  // percorrido e cada etapa pulsa quando a esfera chega; a legenda curta mostra a etapa. Só desenha quando está
  // visível (no computador fica escondido e quem anima é a roda). "Reduzir movimento": parado na 1ª etapa.
  function trilhoFluxo(caixa) {
    if (!caixa) return;
    const svg = caixa.querySelector('.lt-svg'), leg = caixa.querySelector('.lt-leg');
    if (!svg || !leg) return;
    const NS = 'http://www.w3.org/2000/svg', el = (tag, at) => { const e = document.createElementNS(NS, tag); Object.entries(at || {}).forEach(([k, v]) => e.setAttribute(k, v)); return e; };
    const N = ETAPAS_LOGIN.length, X0 = 24, X1 = 316, Y = 20, xs = ETAPAS_LOGIN.map((_, i) => X0 + (X1 - X0) * i / (N - 1));
    svg.setAttribute('viewBox', '0 0 340 58');
    svg.innerHTML = `<defs>
        <radialGradient id="lt-halo"><stop offset="0" stop-color="#7fd6b8" stop-opacity=".65"/><stop offset=".45" stop-color="#7fd6b8" stop-opacity=".18"/><stop offset="1" stop-color="#7fd6b8" stop-opacity="0"/></radialGradient>
        <radialGradient id="lt-bola" cx=".36" cy=".32" r=".72"><stop offset="0" stop-color="#f2fffa"/><stop offset=".42" stop-color="#8fe3c6"/><stop offset="1" stop-color="#2f8f72"/></radialGradient>
        <linearGradient id="lt-luz" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#9ff0d3" stop-opacity="0"/><stop offset="1" stop-color="#9ff0d3" stop-opacity=".95"/></linearGradient></defs>`;
    const base = el('line', { x1: X0, y1: Y, x2: X1, y2: Y, stroke: 'rgba(255,255,255,.2)', 'stroke-width': 2, 'stroke-linecap': 'round' });
    const feito = el('line', { x1: X0, y1: Y, x2: X0, y2: Y, stroke: 'rgba(159,240,211,.5)', 'stroke-width': 2.4, 'stroke-linecap': 'round' });
    const rastro = el('line', { x1: X0, y1: Y, x2: X0, y2: Y, stroke: 'url(#lt-luz)', 'stroke-width': 3.4, 'stroke-linecap': 'round' });
    const nos = ETAPAS_LOGIN.map(([nome], i) => {
      const g = el('g'), onda = el('circle', { cx: xs[i], cy: Y, r: 5, fill: 'none', stroke: '#9ff0d3', 'stroke-width': 1.4, opacity: 0 });
      const c = el('circle', { cx: xs[i], cy: Y, r: 5, 'stroke-width': 1.4 });
      const tx = el('text', { x: xs[i], y: 45, 'text-anchor': i === 0 ? 'start' : i === N - 1 ? 'end' : 'middle' }); tx.textContent = nome;
      if (i === 0) tx.setAttribute('x', X0 - 6); if (i === N - 1) tx.setAttribute('x', X1 + 6);
      g.append(onda, c, tx); return { onda, c, tx };
    });
    const halo = el('circle', { cx: X0, cy: Y, r: 15, fill: 'url(#lt-halo)' }), bola = el('circle', { cx: X0, cy: Y - 0.5, r: 7, fill: 'url(#lt-bola)' });
    svg.append(base, feito, rastro, ...nos.flatMap((n) => [n.onda.parentNode]).filter((v, i, l) => l.indexOf(v) === i), halo, bola);
    const tPasso = leg.querySelector('b'), tDesc = leg.querySelector('span');
    let atual = -1;
    const legenda = (i) => { if (i === atual) return; atual = i; tPasso.textContent = `Etapa ${i + 1} de ${N}`; tDesc.textContent = ETAPAS_LOGIN[i][1]; };
    // pos: 0..N-1 (posição da esfera); chegada: tempo (ms) desde a chegada à etapa atual; vis: opacidade da esfera
    const desenhar = (pos, chegada, vis) => {
      const x = X0 + (X1 - X0) * pos / (N - 1), i0 = Math.floor(pos + 0.001);
      feito.setAttribute('x2', x.toFixed(1));
      rastro.setAttribute('x1', Math.max(X0, x - 46).toFixed(1)); rastro.setAttribute('x2', x.toFixed(1));
      rastro.setAttribute('opacity', (pos % 1 > 0.001 ? 0.95 : Math.max(0, 1 - chegada / 700) * 0.95).toFixed(2));
      halo.setAttribute('cx', x.toFixed(1)); bola.setAttribute('cx', x.toFixed(1));
      halo.setAttribute('opacity', vis.toFixed(2)); bola.setAttribute('opacity', vis.toFixed(2));
      halo.setAttribute('r', (15 * (1 + 0.25 * Math.max(0, 1 - chegada / 600))).toFixed(1));
      nos.forEach((n, i) => {
        const ativo = i === i0 && pos % 1 < 0.001, passou = i <= pos + 0.001;
        n.c.style.fill = passou ? '#7fd6b8' : 'var(--rail)';
        n.c.style.stroke = passou ? '#c9f5e5' : 'rgba(255,255,255,.5)';
        n.c.setAttribute('r', ativo ? 6 : 5);
        n.tx.style.fill = ativo ? '#ffffff' : passou ? 'rgba(201,245,229,.85)' : 'rgba(255,255,255,.5)';
        n.tx.setAttribute('font-size', ativo ? 12 : 10.5);
        n.tx.setAttribute('font-weight', ativo ? 700 : 600);
        const k = ativo ? Math.min(1, chegada / 650) : 1; // onda que se abre quando a esfera chega
        n.onda.setAttribute('r', (5 + 11 * k).toFixed(1)); n.onda.setAttribute('opacity', ativo ? ((1 - k) * 0.9).toFixed(2) : 0);
      });
    };
    const reduzir = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduzir) { desenhar(0, 9999, 1); legenda(0); return; }
    const PARA = 1700, MOVE = 950, VOLTA = 650, CICLO = N * PARA + (N - 1) * MOVE + VOLTA, t0 = performance.now();
    const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
    const quadro = (agora) => {
      if (!svg.isConnected) return;
      if (!document.hidden && caixa.offsetParent !== null) {
        let t = (agora - t0) % CICLO, pos = 0, chegada = 0, vis = 1;
        for (let i = 0; i < N; i++) {
          if (t < PARA) { pos = i; chegada = t; break; }
          t -= PARA;
          if (i === N - 1) { pos = N - 1; chegada = PARA + t; vis = Math.max(0, 1 - t / (VOLTA * 0.6)); break; } // fim do mês: a esfera some e volta ao início
          if (t < MOVE) { pos = i + ease(t / MOVE); chegada = 0; break; }
          t -= MOVE;
        }
        desenhar(pos, chegada, vis);
        legenda(Math.min(N - 1, Math.round(pos)));
      }
      requestAnimationFrame(quadro);
    };
    requestAnimationFrame(quadro);
  }

  // Entrar (e-mail ou usuário) e Criar conta (colaborador Klingele; fica aguardando a aprovação do administrador)
  function telaLogin(msg, opc) {
    opc = opc || {};
    const aba = opc.aba || 'entrar';
    const entrada = !loginAnimado; loginAnimado = true;
    // Lado esquerdo com animações leves (fundo, seta do logo e fluxo do mês); o formulário não é animado
    root.innerHTML = `<div class="login${entrada ? ' entrada' : ''}">
      <section class="login-side">
        <div class="login-fx" aria-hidden="true"><i class="fx-grade"></i><i class="fx-luz a"></i><i class="fx-luz b"></i><i class="fx-luz c"></i></div>
        ${U.marca('Boletim Mensal Klingele')}
        <div class="stack login-txt" style="gap:16px"><h1>Boletins de medição do fim do mês</h1>
          <div class="login-trilho" aria-hidden="true"><svg class="lt-svg" viewBox="0 0 340 58"></svg><div class="lt-leg"><b></b><span></span></div></div>
          <p>Do link ao fornecedor até a nota fiscal em Serviços: envio e cobrança automáticos, conferência dos valores, F.S. e nota fiscal no mesmo lugar.</p>
          <ol><li>Link do boletim ao fornecedor, com cobrança automática e avaliação ao supervisor</li><li>Conferência dos valores e lançamento da F.S. com os anexos</li><li>NF do fornecedor pelo link, aprovação da F.S. e encaminhamento a Serviços</li></ol>
          <div class="login-fluxo" aria-hidden="true"><svg class="lf-roda" viewBox="0 0 440 168"></svg>
            <div class="lf-legenda"><span class="lf-passo"></span><b class="lf-nome"></b><span class="lf-desc"></span></div></div></div>
        <span class="small" style="color:var(--rail-ink-2)">Acesso restrito aos colaboradores Klingele. Novas contas dependem da aprovação de um administrador ou supervisor.</span>
      </section>
      <section class="login-form">
        <div class="login-box">
          ${opc.previa ? `<div class="demo-banner"><span><b>Prévia</b> · telas exibidas ao colaborador no site publicado</span><span class="spacer"></span><button class="btn sm" type="button" id="lg-voltar">${ic.esq} Voltar ao app</button></div>` : ''}
          <div class="seg login-abas" role="tablist" aria-label="Entrar ou criar conta">
            <button type="button" role="tab" data-aba="entrar" aria-pressed="${aba === 'entrar'}">Entrar</button>
            <button type="button" role="tab" data-aba="criar" aria-pressed="${aba === 'criar'}">Criar conta</button></div>
          ${msg ? `<div class="demo-banner"><span>${esc(msg)}</span></div>` : ''}
          <div id="lg-corpo"></div>
          <button class="btn ghost" type="button" id="lg-tema">${U.tema.atual() === 'dark' ? 'Tema claro' : 'Tema escuro'}</button>
        </div>
      </section></div>`;
    const corpo = root.querySelector('#lg-corpo');
    root.querySelectorAll('[data-aba]').forEach((b) => b.addEventListener('click', () => telaLogin(null, { ...opc, aba: b.dataset.aba })));
    root.querySelector('#lg-tema').addEventListener('click', (ev) => { U.tema.alternar(); ev.currentTarget.textContent = U.tema.atual() === 'dark' ? 'Tema claro' : 'Tema escuro'; });
    rodaFluxo(root.querySelector('.login-fluxo'));
    trilhoFluxo(root.querySelector('.login-trilho'));
    if (opc.previa) root.querySelector('#lg-voltar').addEventListener('click', () => { root.innerHTML = ''; render(); });
    if (aba === 'criar') return formCadastro(corpo, opc);
    corpo.innerHTML = `<form id="f-login" class="stack" novalidate>
      <h2>Entrar</h2>
      <label class="field"><span>E-mail ou usuário</span><input type="text" id="lg-email" autocomplete="username" maxlength="254" required autocapitalize="off" spellcheck="false"></label>
      <label class="field"><span>Senha</span><input type="password" id="lg-senha" autocomplete="current-password" maxlength="200" required></label>
      <div id="lg-captcha"></div>
      <button class="btn primary" type="submit">Entrar</button>
      <button class="btn ghost" type="button" id="lg-esqueci">Esqueci a senha</button>
    </form>`;
    montarCaptcha(corpo.querySelector('#lg-captcha'));
    corpo.querySelector('#f-login').addEventListener('submit', async (e) => {
      e.preventDefault();
      if (opc.previa) { root.innerHTML = ''; render(); U.toast('Na demonstração não há login: este é o formulário do site publicado.'); return; }
      if (cfg.turnstileSiteKey && !captchaToken) { U.toast('Conclua a verificação anti-robô', 'erro'); return; }
      const login = document.getElementById('lg-email').value.trim(), senha = document.getElementById('lg-senha').value;
      if (!login || !senha) { U.toast('Informe o e-mail (ou usuário) e a senha', 'erro'); return; }
      const btn = e.target.querySelector('[type="submit"]');
      btn.disabled = true; btn.textContent = 'Entrando…';
      try { await API.entrar(login, senha, captchaToken); await aposLogin(true); }
      catch (err) { btn.disabled = false; btn.textContent = 'Entrar'; resetCaptcha(); U.toast(/Invalid login|incorretos/i.test(err.message) ? 'Usuário, e-mail ou senha incorretos.' : err.message, 'erro'); }
    });
    corpo.querySelector('#lg-esqueci').addEventListener('click', async () => {
      const email = document.getElementById('lg-email').value.trim();
      if (!U.emailValido(email)) { U.toast('Digite o seu e-mail (não o usuário) para receber o link', 'erro'); return; }
      if (opc.previa) { U.toast('Na demonstração nenhum e-mail é enviado.'); return; }
      if (cfg.turnstileSiteKey && !captchaToken) { U.toast('Conclua a verificação anti-robô', 'erro'); return; }
      try { await API.recuperarSenha(email, captchaToken); resetCaptcha(); U.toast('Se o e-mail estiver cadastrado, enviamos um link para redefinir a senha.'); }
      catch (err) { resetCaptcha(); U.toast(err.message, 'erro'); }
    });
  }
  async function formCadastro(corpo, opc) {
    corpo.innerHTML = '<p class="muted">Carregando…</p>';
    const op = await API.cadastroOpcoes();
    if (!op.aberto) {
      corpo.innerHTML = `<div class="stack"><h2>Criar conta</h2><p>${op.indisponivel ? 'O cadastro pelo site ainda não foi instalado (rode o 04_usuarios.sql no Supabase).' : 'O cadastro de novas contas está fechado.'} Fale com o administrador do sistema.</p></div>`;
      return;
    }
    const dom = (op.dominios || []).map((d) => String(d).replace(/^@/, ''));
    const resps = op.responsaveis || (op.admins || []).map((x) => ({ ...x, papel: 'admin' }));
    corpo.innerHTML = `<form id="f-cad" class="stack" novalidate>
      <h2>Criar conta</h2>
      <p class="small muted">Exclusivo para colaboradores Klingele. Após a criação, a conta aguarda a aprovação do responsável escolhido.</p>
      <label class="field"><span>Nome completo</span><input type="text" id="cd-nome" maxlength="120" autocomplete="name" required></label>
      <div class="form-grid">
        <label class="field"><span>Usuário <span class="hint">(para entrar)</span></span><input type="text" id="cd-usuario" maxlength="30" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="ex.: maria.souza" required>
          <span class="hint" id="cd-usuario-ok">3 a 30 letras, números, ponto, hífen ou _</span></label>
        <label class="field"><span>E-mail${dom.length ? ' Klingele' : ''}</span><input type="email" id="cd-email" maxlength="254" autocomplete="email" placeholder="${dom.length ? 'nome@' + esc(dom[0]) : 'nome@klingele.com.br'}" required>
          ${dom.length ? `<span class="hint">Aceito: ${esc(dom.map((d) => '@' + d).join(', '))}</span>` : ''}</label>
        <label class="field"><span>Cargo</span><input type="text" id="cd-cargo" maxlength="80" placeholder="ex.: Analista de contratos"></label>
        <label class="field"><span>Telefone</span><input type="tel" id="cd-tel" maxlength="60" autocomplete="tel"></label>
      </div>
      <label class="field"><span>Responsável pela aprovação <span class="hint">(administrador ou supervisor; recebe o pedido)</span></span><select id="cd-aprov"><option value="">Qualquer perfil de administração</option>
        ${resps.some((x) => x.papel === 'admin') ? `<optgroup label="Administradores">${resps.filter((x) => x.papel === 'admin').map((x) => `<option value="${esc(x.id)}">${esc(x.nome)}</option>`).join('')}</optgroup>` : ''}
        ${resps.some((x) => x.papel === 'supervisor') ? `<optgroup label="Supervisores">${resps.filter((x) => x.papel === 'supervisor').map((x) => `<option value="${esc(x.id)}">${esc(x.nome)}${x.admin ? ' · ligado a ' + esc(x.admin) : ''}</option>`).join('')}</optgroup>` : ''}</select></label>
      <div class="form-grid">
        <label class="field"><span>Senha <span class="hint">(mínimo de 10 caracteres, com letras e números)</span></span><input type="password" id="cd-senha" maxlength="200" autocomplete="new-password" required></label>
        <label class="field"><span>Repita a senha</span><input type="password" id="cd-senha2" maxlength="200" autocomplete="new-password" required></label>
      </div>
      <label class="check"><input type="checkbox" id="cd-klingele"> Sou colaborador da Klingele Paper &amp; Packing</label>
      <div id="cd-captcha"></div>
      <button class="btn primary" type="submit">Criar conta</button>
    </form>`;
    montarCaptcha(corpo.querySelector('#cd-captcha'));
    const uInp = corpo.querySelector('#cd-usuario'), uOk = corpo.querySelector('#cd-usuario-ok');
    uInp.addEventListener('blur', async () => {
      const v = uInp.value.trim();
      if (!v) return;
      if (!U.usuarioValido(v)) { uOk.textContent = 'Use 3 a 30 letras, números, ponto, hífen ou _'; uOk.style.color = 'var(--crit)'; return; }
      try { const livre = await API.usuarioLivre(v); uOk.textContent = livre === null ? 'Não foi possível conferir agora' : livre ? 'Disponível' : 'Já existe: escolha outro'; uOk.style.color = livre === null ? 'var(--ink-3)' : livre ? 'var(--ok)' : 'var(--crit)'; } catch (e) { /* confere no envio */ }
    });
    corpo.querySelector('#f-cad').addEventListener('submit', async (e) => {
      e.preventDefault();
      const g = (k) => corpo.querySelector('#cd-' + k).value.trim();
      const d = { nome: g('nome'), usuario: g('usuario'), email: g('email').toLowerCase(), cargo: g('cargo') || null, telefone: g('tel') || null,
        aprovador_id: g('aprov') || null, senha: corpo.querySelector('#cd-senha').value };
      if (d.nome.length < 3 || d.nome.length > 120) { U.toast('Informe o nome completo', 'erro'); return; }
      if (!U.usuarioValido(d.usuario)) { U.toast('Usuário: 3 a 30 letras, números, ponto, hífen ou _', 'erro'); return; }
      if (!U.emailValido(d.email)) { U.toast('E-mail inválido', 'erro'); return; }
      if (dom.length && !dom.includes(d.email.split('@')[1])) { U.toast(`Use o e-mail da Klingele (${dom.map((x) => '@' + x).join(', ')})`, 'erro'); return; }
      if (!U.telefoneValido(d.telefone)) { U.toast('Telefone inválido', 'erro'); return; }
      if (!senhaForte(d.senha)) { U.toast('Senha: pelo menos 10 caracteres, com letras e números', 'erro'); return; }
      if (d.senha !== corpo.querySelector('#cd-senha2').value) { U.toast('As senhas não conferem', 'erro'); return; }
      if (!corpo.querySelector('#cd-klingele').checked) { U.toast('Confirme que você é colaborador da Klingele', 'erro'); return; }
      if (cfg.turnstileSiteKey && !captchaToken && !opc.previa) { U.toast('Conclua a verificação anti-robô', 'erro'); return; }
      const btn = e.target.querySelector('[type="submit"]');
      btn.disabled = true; btn.textContent = 'Criando…';
      try {
        if ((await API.usuarioLivre(d.usuario)) === false) throw new Error('Este usuário já existe. Escolha outro.');
        const r = await API.cadastrar(d, captchaToken);
        const resp = resps.find((x) => x.id === d.aprovador_id);
        if (r.sessao) { await aposLogin(true); return; }
        telaPendente({ status: 'pendente', nome: d.nome, usuario: d.usuario, aprovador: resp ? resp.nome : null }, { novo: true, email: d.email, previa: opc.previa, confirmar: !r.demo });
      } catch (err) { btn.disabled = false; btn.textContent = 'Criar conta'; resetCaptcha(); U.toast(err.message, 'erro'); }
    });
  }
  // Conta criada aguardando aprovação, recusada ou bloqueada
  function telaPendente(cad, opc) {
    opc = opc || {};
    const st = cad.status;
    const titulo = st === 'pendente' ? (opc.novo ? 'Conta criada' : 'Cadastro aguardando aprovação') : st === 'recusado' ? 'Cadastro recusado' : 'Acesso bloqueado';
    telaSimples(`<h2>${titulo}</h2>
      ${st === 'pendente' ? `<p>${esc(cad.nome || '')}${cad.usuario ? ` (usuário <b class="mono">${esc(cad.usuario)}</b>)` : ''}, seu cadastro foi encaminhado para <b>${esc(cad.aprovador || 'os administradores e supervisores')}</b>.
        Você recebe um e-mail quando o acesso for liberado, com o perfil definido na aprovação.</p>
        ${opc.confirmar ? `<p class="small muted">Se o Supabase pedir confirmação, abra o link enviado para ${esc(opc.email || 'o seu e-mail')} antes de entrar.</p>` : ''}`
        : `<p>${esc(cad.nome || '')}, seu acesso ao BMK · Boletim Mensal Klingele foi ${st}.</p>${cad.motivo ? `<p><b>Motivo:</b> ${esc(cad.motivo)}</p>` : ''}<p class="small muted">Fale com o administrador do sistema.</p>`}
      <div class="row">${!opc.novo && !opc.previa ? '<button class="btn primary" id="pd-atualizar">Verificar de novo</button>' : ''}
        <button class="btn" id="pd-sair">${opc.previa ? 'Voltar ao app' : opc.novo ? 'Ir para entrar' : 'Sair'}</button></div>`);
    const at = document.getElementById('pd-atualizar');
    if (at) at.addEventListener('click', () => aposLogin(false));
    document.getElementById('pd-sair').addEventListener('click', async () => {
      if (opc.previa) { root.innerHTML = ''; await recarregar(true); render(); return; }
      if (!opc.novo) await API.sair();
      telaLogin(opc.novo ? 'Assim que o administrador aprovar, entre com o usuário ou o e-mail.' : null);
    });
  }
  const senhaForte = (s) => s.length >= 10 && /[A-Za-z]/.test(s) && /\d/.test(s);
  // Nova senha. Obrigatória quando a conta ainda usa a senha padrão da instalação (não dá para fechar).
  function telaNovaSenha(obrigatoria) {
    if (document.getElementById('f-senha')) return;
    const w = document.createElement('div');
    w.className = 'modal-wrap';
    w.innerHTML = `<div class="backdrop"></div><form class="modal" id="f-senha"><h2>${obrigatoria ? 'Troque a senha para continuar' : 'Nova senha'}</h2>
      ${obrigatoria ? '<p class="small">Esta conta ainda usa a senha padrão da instalação, que está escrita nas instruções do sistema. Defina uma senha só sua.</p>' : ''}
      <label class="field"><span>Senha <span class="hint">(mínimo 10 caracteres, com letras e números)</span></span><input type="password" id="ns-senha" autocomplete="new-password" maxlength="200"></label>
      <label class="field"><span>Repita a senha</span><input type="password" id="ns-senha2" autocomplete="new-password" maxlength="200"></label>
      <div class="row" style="justify-content:flex-end">${obrigatoria ? '' : '<button class="btn" type="button" data-cancelar>Cancelar</button>'}<button class="btn primary" type="submit">Salvar senha</button></div></form>`;
    document.body.appendChild(w);
    const cancelar = w.querySelector('[data-cancelar]'); if (cancelar) cancelar.addEventListener('click', () => w.remove());
    setTimeout(() => { const i = document.getElementById('ns-senha'); if (i) i.focus(); }, 50);
    w.querySelector('#f-senha').addEventListener('submit', async (e) => {
      e.preventDefault();
      const s = document.getElementById('ns-senha').value;
      if (!senhaForte(s)) { U.toast('Use pelo menos 10 caracteres, com letras e números', 'erro'); return; }
      if (s !== document.getElementById('ns-senha2').value) { U.toast('As duas senhas não são iguais', 'erro'); return; }
      try { await API.definirSenha(s); w.remove(); if (S.cad) S.cad.trocar_senha = false; U.toast('Senha atualizada'); } catch (err) { U.toast(err.message, 'erro'); }
    });
  }

  // ---------- Verificação em duas etapas ----------
  function telaSimples(html) {
    root.innerHTML = `<div class="login-form" style="min-height:100%"><div class="panel" style="max-width:480px;width:100%;padding:24px;display:grid;gap:14px">${html}</div></div>`;
  }
  function telaCodigoMfa() {
    telaSimples(`<h2>Verificação em duas etapas</h2><p>Digite o código de 6 dígitos do aplicativo autenticador (Google Authenticator, Microsoft Authenticator ou similar).</p>
      <form id="f-mfa" class="stack"><input type="text" id="mfa-cod" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" aria-label="Código de 6 dígitos" style="font-size:1.4rem;letter-spacing:.3em;text-align:center">
      <button class="btn primary" type="submit">Confirmar</button><button class="btn ghost" type="button" id="mfa-sair">Sair</button></form>`);
    document.getElementById('mfa-cod').focus();
    document.getElementById('mfa-sair').addEventListener('click', async () => { await API.sair(); telaLogin(); });
    document.getElementById('f-mfa').addEventListener('submit', async (e) => {
      e.preventDefault();
      const c = document.getElementById('mfa-cod').value.trim();
      if (!/^\d{6}$/.test(c)) { U.toast('O código tem 6 dígitos', 'erro'); return; }
      try { await API.mfaEntrar(c); await aposLogin(true); } catch (err) { U.toast('Código incorreto ou expirado. Tente o código atual do aplicativo.', 'erro'); }
    });
  }
  async function fluxoAtivarMfa(dentroDoApp) {
    let f;
    try { f = await API.mfaIniciar(); } catch (e) { U.toast(e.message, 'erro'); return; }
    const html = `<h2>Ativar verificação em duas etapas</h2>
      <ol style="margin:0;padding-left:18px;display:grid;gap:6px"><li>Abra um aplicativo autenticador no celular.</li><li>Leia o QR code abaixo (ou digite a chave).</li><li>Digite o código de 6 dígitos que aparecer.</li></ol>
      <div style="display:grid;place-items:center;background:#fff;border-radius:10px;padding:10px"><img src="${esc(f.qr)}" alt="QR code para o aplicativo autenticador" width="180" height="180"></div>
      <div class="link-box"><code>${esc(f.segredo)}</code></div>
      <form id="f-mfa-novo" class="stack"><input type="text" id="mfa-novo-cod" inputmode="numeric" autocomplete="one-time-code" maxlength="6" aria-label="Código de 6 dígitos" style="font-size:1.3rem;letter-spacing:.3em;text-align:center">
        <button class="btn primary" type="submit">Ativar</button><button class="btn ghost" type="button" id="mfa-cancelar">${dentroDoApp ? 'Cancelar' : 'Sair'}</button></form>`;
    let w = null;
    if (dentroDoApp) {
      w = document.createElement('div'); w.className = 'modal-wrap';
      w.innerHTML = `<div class="backdrop"></div><div class="modal">${html}</div>`;
      document.body.appendChild(w);
    } else telaSimples(`<p class="demo-banner"><span>A equipe exige verificação em duas etapas. Ative para continuar.</span></p>${html}`);
    const raiz = w || root;
    raiz.querySelector('#mfa-cancelar').addEventListener('click', async () => { if (w) w.remove(); else { await API.sair(); telaLogin(); } });
    raiz.querySelector('#f-mfa-novo').addEventListener('submit', async (e) => {
      e.preventDefault();
      const c = raiz.querySelector('#mfa-novo-cod').value.trim();
      if (!/^\d{6}$/.test(c)) { U.toast('O código tem 6 dígitos', 'erro'); return; }
      try {
        await API.mfaConfirmar(f.id, c);
        U.toast('Verificação em duas etapas ativada');
        if (w) { w.remove(); carregarMfa(); } else await aposLogin(true);
      } catch (err) { U.toast('Código incorreto. Confira o horário do celular e tente o código atual.', 'erro'); }
    });
  }
  async function carregarMfa() {
    const el = document.getElementById('mfa-status');
    if (!el || DEMO) return;
    try {
      const fs = await API.mfaFatores();
      el.innerHTML = fs.length
        ? `${chip('ok', 'Ativa')} <button class="btn sm" data-act="mfa-desativar" data-id="${esc(fs[0].id)}">Desativar</button>`
        : `${chip('warn', 'Desativada')} <button class="btn sm primary" data-act="mfa-ativar">Ativar</button>`;
    } catch (e) { el.innerHTML = `<span class="muted small">${esc(e.message)}</span>`; }
  }

  // ---------- Sessão: encerra após 30 minutos sem uso ----------
  const INATIVIDADE_MIN = 30;
  let ultimaAtividade = Date.now(), timerInatividade = null;
  function vigiarInatividade() {
    if (DEMO || timerInatividade) return;
    ['click', 'keydown', 'mousemove', 'touchstart', 'scroll'].forEach((t) => document.addEventListener(t, () => { ultimaAtividade = Date.now(); }, { passive: true }));
    timerInatividade = setInterval(async () => {
      if (Date.now() - ultimaAtividade < INATIVIDADE_MIN * 60000) return;
      clearInterval(timerInatividade); timerInatividade = null;
      fecharGaveta();
      try { await API.sair(); } catch (e) { /* sessão já encerrada */ }
      S.base = null; S.solic = []; S.med = []; S.docs = []; S.cache = { envios: null, hist: null, rotina: null };
      telaLogin(`Sessão encerrada após ${INATIVIDADE_MIN} minutos sem uso. Entre de novo.`);
    }, 30000);
  }

  async function aposLogin(acabouDeEntrar) {
    S.user = await API.sessao();
    if (!S.user) return telaLogin();
    const acesso = await API.situacaoAcesso();
    if (!DEMO) {
      const nivel = await API.mfaNivel().catch(() => null);
      if (nivel && nivel.proximo === 'aal2' && nivel.atual !== 'aal2') return telaCodigoMfa();
      if (!acesso.liberado && acesso.papel && acesso.exige_mfa) return fluxoAtivarMfa(false);
    }
    S.cad = acesso.cadastro && acesso.cadastro.status !== 'sem_cadastro' ? acesso.cadastro : null;
    if (!acesso.liberado) {
      if (S.cad && ['pendente', 'recusado', 'bloqueado'].includes(S.cad.status)) return telaPendente(S.cad);
      telaSimples(`<h2>Acesso não liberado</h2><p>O login <b>${esc(S.user.email)}</b> existe, mas ainda não foi aprovado. A aprovação é feita por um administrador ou supervisor, na tela Usuários.</p>
        <button class="btn" id="sx">Sair</button>`);
      document.getElementById('sx').addEventListener('click', async () => { await API.sair(); location.reload(); });
      return;
    }
    S.papel = acesso.papel;
    if (acabouDeEntrar) API.registrarEvento('login', 'acesso', null, null, {});
    await carregarBase();
    await carregarComp();
    const h = (location.hash || '').slice(1);
    if (TITULOS[h] && !(h === 'hist' && S.papel === 'leitura') && !(h === 'usuarios' && !podeAprovar())) S.view = h;
    root.innerHTML = '';
    render();
    if (S.view === 'hist') carregarHistorico();
    vigiarInatividade();
    if (!DEMO && S.cad && S.cad.trocar_senha) telaNovaSenha(true);
  }

  async function iniciar() {
    U.tema.iniciar();
    root.innerHTML = '<div class="login-form" style="min-height:100%"><p class="muted">Carregando…</p></div>';
    try {
      await API.init();
      if (!DEMO) {
        API.onAuth((evt) => { if (evt === 'PASSWORD_RECOVERY') telaNovaSenha(); });
        const s = await API.sessao();
        if (!s) return telaLogin();
      }
      await aposLogin(false);
    } catch (e) {
      telaSimples(`<h2>Não foi possível iniciar</h2><p>${esc(e.message)}</p>
        <p class="muted small">Projeto: <span class="mono">${esc(cfg.supabaseUrl || '—')}</span>. Confira o arquivo assets/config.js, o _headers publicado junto e se os scripts SQL (01 a 04) foram executados neste projeto.</p>
        <div class="row"><button class="btn primary" id="ini-de-novo">Tentar de novo</button><button class="btn" id="ini-sair">Sair</button></div>`);
      document.getElementById('ini-de-novo').addEventListener('click', () => location.reload());
      document.getElementById('ini-sair').addEventListener('click', async () => { try { await API.sair(); } catch (x) { /* sem sessão */ } location.reload(); });
    }
  }
  iniciar();
})();

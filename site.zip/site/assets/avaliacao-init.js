/* Abre a avaliação do supervisor. O link chega como avaliacao.html#CODIGO:
   o trecho depois do # não vai para o servidor nem aparece em logs. */
(async function () {
  var el = document.getElementById('avaliacao');
  var token = (location.hash || '').slice(1) || '';
  try {
    if (token) sessionStorage.setItem('klg-avaliacao', token);
    else token = sessionStorage.getItem('klg-avaliacao') || '';
    history.replaceState(null, '', location.pathname);
  } catch (e) { /* sem armazenamento */ }
  try { await API.init({ portal: true }); }
  catch (e) { el.textContent = 'Não foi possível carregar a página. Verifique sua conexão e recarregue.'; return; }
  Avaliacao.montar(el, token.trim(), {
    api: API,
    aoConcluir: function () { try { sessionStorage.removeItem('klg-avaliacao'); } catch (e) { /* sem armazenamento */ } }
  });
})();

/* BMK · Boletim Mensal Klingele · utilidades compartilhadas (app interno e portal do fornecedor) */
(function () {
  'use strict';
  const U = {};

  U.MESES = ['JANEIRO', 'FEVEREIRO', 'MARÇO', 'ABRIL', 'MAIO', 'JUNHO', 'JULHO', 'AGOSTO', 'SETEMBRO', 'OUTUBRO', 'NOVEMBRO', 'DEZEMBRO'];
  U.MESES_CURTOS = ['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN', 'JUL', 'AGO', 'SET', 'OUT', 'NOV', 'DEZ'];
  U.TZ = 'America/Sao_Paulo';

  U.esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  U.cap = (s) => String(s || '').toLowerCase().replace(/(^|\s)\S/g, (m) => m.toUpperCase());

  // ---------- Marca: BMK · Boletim Mensal Klingele ----------
  U.NOME = 'BMK';
  U.NOME_LONGO = 'Boletim Mensal Klingele';
  // Letras BMK (Inter ExtraBold em contorno) na cor do texto + seta verde-clara no alto (envio)
  const LOGO = '<svg viewBox="0 -88.00 319.98 188.00" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path class="logo-seta" d="M259.98 -88.00h60.00v60.00z" fill="#7fd6b8"/><path d="M0 100H44.56C66.71 100 79.26 88.19 79.26 72.08C79.26 57.58 68.79 48.52 56.78 48.05V46.98C67.65 44.77 75.37 36.85 75.37 25.37C75.37 10.27 63.83 0 41.48 0H0ZM23.69 80.87V56.58H39.46C48.79 56.58 54.56 61.61 54.56 69.4C54.56 76.51 49.6 80.87 38.99 80.87ZM23.69 41.21V18.93H37.85C46.04 18.93 51.21 23.15 51.21 29.87C51.21 37.05 45.44 41.21 37.45 41.21ZM95.63 100H119.39V56.91C119.39 49.46 118.78 33.76 118.51 20.6C121.94 34.7 126.03 49.53 128.38 56.91L142.81 100H162.61L176.84 56.91C179.25 49.26 183.48 33.76 186.77 19.46C186.5 32.95 185.9 49.33 185.9 56.91V100H209.72V0H172.74L160.19 38.93C158.18 45.77 155.09 60.13 152.81 72.08C150.46 60.13 147.37 45.77 145.29 38.93L132.54 0H95.63ZM229.58 100H253.27V73.15L266.02 58.72L292.13 100H319.98L282.33 43.15L318.57 0H290.12L267.83 27.32C261.12 35.7 256.76 41.88 252.87 48.72L253.27 24.56V0H229.58Z" fill="currentColor"/></svg>';
  U.marca = (sub) => `<div class="brand"><span class="brand-logo" role="img" aria-label="BMK · Boletim Mensal Klingele">${LOGO}</span>${sub ? `<span class="brand-sub">${U.esc(sub)}</span>` : ''}</div>`;

  // ---------- Números ----------
  const fBRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });
  const fBRL0 = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL', maximumFractionDigits: 0 });
  const fNum = new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  U.vazio = (v) => v === null || v === undefined || v === '' || Number.isNaN(Number(v));
  U.brl = (v) => (U.vazio(v) ? '—' : fBRL.format(Number(v)));
  U.brl0 = (v) => (U.vazio(v) ? '—' : fBRL0.format(Number(v)));
  U.numBR = (v) => (U.vazio(v) ? '' : fNum.format(Number(v)));
  U.compacto = (v) => {
    const n = Math.abs(Number(v) || 0);
    if (n >= 1e6) return 'R$ ' + (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi';
    if (n >= 1e3) return 'R$ ' + (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 0 }) + ' mil';
    return fBRL0.format(v || 0);
  };
  U.compactoCurto = (v) => {
    const n = Math.abs(Number(v) || 0);
    if (n >= 1e6) return (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi';
    if (n >= 1e3) return (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 0 }) + ' mil';
    return String(Math.round(v || 0));
  };
  U.pct = (v) => (U.vazio(v) || !isFinite(v) ? '—' : (v > 0 ? '+' : '') + (v * 100).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%');

  // Converte texto em número aceitando "R$ 1.234,56", "1234,56", "1,234.56", "1234.56"
  U.parseValor = (s) => {
    if (typeof s === 'number') return isFinite(s) ? s : null;
    if (s === null || s === undefined) return null;
    let t = String(s).trim().replace(/R\$|\s/g, '');
    if (!t) return null;
    const neg = /^\(.*\)$/.test(t) || t.startsWith('-');
    t = t.replace(/[()\-]/g, '');
    const lc = t.lastIndexOf(','), ld = t.lastIndexOf('.');
    if (lc > -1 && ld > -1) {
      t = lc > ld ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
    } else if (lc > -1) {
      t = /,\d{1,2}$/.test(t) ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
    } else if (ld > -1 && /^\d{1,3}(\.\d{3})+$/.test(t)) {
      t = t.replace(/\./g, '');
    }
    const n = Number(t);
    return isFinite(n) ? (neg ? -n : n) : null;
  };

  // CNPJ numérico ou alfanumérico (formato novo da Receita, desde julho de 2026): 12 posições com letras
  // ou números + 2 dígitos verificadores; cada caractere vale (código ASCII - 48). Igual ao banco.
  U.cnpjNorm = (s) => String(s || '').toUpperCase().replace(/[^0-9A-Z]/g, '');
  // Nome comparável (igual ao banco): sem acento, pontuação, espaços extras e sufixos de empresa (LTDA, ME, EPP, EIRELI, S/A...)
  U.normNome = (s) => {
    const t = ' ' + String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toUpperCase().replace(/[^A-Z0-9]+/g, ' ') + ' ';
    return t.replace(/ (LTDA|LIMITADA|ME|EPP|EIRELI|MEI|SA|S A|CIA|COMPANHIA|SS)(?= )/g, ' ').replace(/ +/g, ' ').trim() || null;
  };
  U.cnpj = (s) => {
    const d = U.cnpjNorm(s);
    if (d.length !== 14) return s || '';
    return `${d.slice(0, 2)}.${d.slice(2, 5)}.${d.slice(5, 8)}/${d.slice(8, 12)}-${d.slice(12)}`;
  };

  U.cnpjValido = (s) => {
    if (/[^0-9A-Za-z./ -]/.test(String(s || ''))) return false;
    const d = U.cnpjNorm(s);
    if (!/^[0-9A-Z]{12}[0-9]{2}$/.test(d) || /^(.)\1{13}$/.test(d)) return false;
    const v = (c) => c.charCodeAt(0) - 48;
    const dv = (n) => {
      const w = n === 12 ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2] : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
      const r = w.reduce((t, x, i) => t + x * v(d[i]), 0) % 11;
      return r < 2 ? 0 : 11 - r;
    };
    return dv(12) === Number(d[12]) && dv(13) === Number(d[13]);
  };
  U.telefoneValido = (t) => !t || (String(t).length <= 60 && /^[0-9 ()+./-]*$/.test(String(t)));
  // Mesmos limites conferidos pelo servidor
  U.LIMITES = { arquivos: 20, mb: 25, contatos: 15, observacao: 2000, valorMax: 100000000 };
  U.valorOk = (v) => typeof v === 'number' && isFinite(v) && v > 0 && v <= U.LIMITES.valorMax && Math.abs(v * 100 - Math.round(v * 100)) < 1e-6;
  U.arred = (v) => (v === null || v === undefined || !isFinite(v) ? null : Math.round(v * 100) / 100);

  // ---------- Datas ----------
  const pad = (n) => String(n).padStart(2, '0');
  U.hojeISO = () => {
    const p = new Intl.DateTimeFormat('en-CA', { timeZone: U.TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
    return p; // AAAA-MM-DD
  };
  U.dataBR = (iso) => {
    if (!iso) return '—';
    const s = String(iso);
    if (/^\d{4}-\d{2}-\d{2}$/.test(s)) { const [a, m, d] = s.split('-'); return `${d}/${m}/${a}`; }
    return new Date(s).toLocaleDateString('pt-BR', { timeZone: U.TZ });
  };
  U.dataHoraBR = (iso) => {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('pt-BR', { timeZone: U.TZ, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };
  U.dataLocal = (iso) => {
    // AAAA-MM-DD do instante em Brasília
    if (!iso) return null;
    if (/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
    return new Intl.DateTimeFormat('en-CA', { timeZone: U.TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));
  };
  U.addDias = (iso, n) => {
    const [a, m, d] = iso.split('-').map(Number);
    const dt = new Date(Date.UTC(a, m - 1, d + n));
    return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
  };
  U.diaSemana = (iso) => { const [a, m, d] = iso.split('-').map(Number); return new Date(Date.UTC(a, m - 1, d)).getUTCDay(); };
  U.diffDias = (de, ate) => {
    const t = (s) => { const [a, m, d] = s.split('-').map(Number); return Date.UTC(a, m - 1, d); };
    return Math.round((t(ate) - t(de)) / 86400000);
  };
  // Calendário: { feriados: Set } (também aceita só um Set). Sábado e domingo nunca contam como dia útil.
  const cal = (c) => (c instanceof Set ? c : (c && c.feriados) || null);
  U.calendario = (lista) => ({ feriados: new Set((lista || []).map((x) => x.data)) });
  U.DIAS_SEMANA = ['domingo', 'segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado'];
  U.ehDiaUtil = (iso, c) => {
    const f = cal(c);
    const w = U.diaSemana(iso);
    return w !== 0 && w !== 6 && !(f && f.has(iso));
  };
  // N-ésimo dia útil do mês da competência (1º, 2º, ...)
  U.diaUtilDoMes = (comp, n, c) => {
    let d = U.compDe(comp), k = 0;
    for (;;) { if (U.ehDiaUtil(d, c) && ++k >= Math.max(1, n || 1)) return d; d = U.addDias(d, 1); }
  };
  // Último dia útil do mês da competência (opção "fim do mês" do envio automático)
  U.ultimoDiaUtil = (comp, c) => { let d = U.fimMes(U.compDe(comp)); while (!U.ehDiaUtil(d, c)) d = U.addDias(d, -1); return d; };
  // Competência que já pode ser pedida: meses encerrados, ou o mês atual a partir do último dia útil (igual ao banco)
  U.compLiberada = (comp, c) => { const h = U.hojeISO(), atual = U.compDe(h); return comp < atual || (comp === atual && h >= U.ultimoDiaUtil(atual, c)); };
  U.addDiasUteis = (iso, n, feriados) => {
    let d = iso, c = 0;
    while (c < n) { d = U.addDias(d, 1); if (U.ehDiaUtil(d, feriados)) c++; }
    return d;
  };
  U.diasUteisAte = (iso, feriados) => {
    // dias úteis restantes de hoje até a data (inclusive), 0 se já passou
    let d = U.hojeISO(), c = 0;
    if (iso < d) return 0;
    while (d < iso) { d = U.addDias(d, 1); if (U.ehDiaUtil(d, feriados)) c++; }
    return c;
  };
  U.fimPrazoISO = (inicioISO, n, feriados) => U.addDiasUteis(U.dataLocal(inicioISO), n, feriados) + 'T23:59:59-03:00';

  // Competência = primeiro dia do mês (AAAA-MM-01)
  U.compDe = (iso) => String(iso).slice(0, 7) + '-01';
  U.compAnterior = () => { const h = U.hojeISO(); return U.addMes(U.compDe(h), -1); };
  U.addMes = (comp, n) => {
    const [a, m] = comp.split('-').map(Number);
    const t = a * 12 + (m - 1) + n;
    return `${Math.floor(t / 12)}-${pad((t % 12) + 1)}-01`;
  };
  U.fimMes = (comp) => U.addDias(U.addMes(comp, 1), -1);
  U.mesNome = (comp) => U.MESES[Number(comp.slice(5, 7)) - 1];
  U.compLabel = (comp) => U.cap(U.mesNome(comp)) + '/' + comp.slice(0, 4);
  U.compCurta = (comp) => U.MESES_CURTOS[Number(comp.slice(5, 7)) - 1] + '/' + comp.slice(2, 4);

  // ---------- Arquivos ----------
  // Só letras e números: o nome do arquivo vem de fora e a extensão aparece em classes e caminhos
  U.extensao = (nome) => (String(nome).split('.').pop() || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8);
  U.MIME = {
    pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', csv: 'text/csv',
    xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  };
  U.ACEITOS = '.pdf,.xlsx,.xls,.csv,.jpg,.jpeg,.png';
  U.mimeArquivo = (nome) => U.MIME[U.extensao(nome)] || null;
  U.tamanho = (b) => {
    if (!b && b !== 0) return '';
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toLocaleString('pt-BR', { maximumFractionDigits: 0 }) + ' KB';
    return (b / 1048576).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' MB';
  };
  U.nomeSeguro = (nome) => {
    const ext = U.extensao(nome);
    const base = String(nome).replace(/\.[^.]+$/, '').normalize('NFD').replace(/[̀-ͯ]/g, '')
      .replace(/[^A-Za-z0-9_-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 70) || 'arquivo';
    return base + (ext ? '.' + ext : '');
  };
  // Impressão digital do arquivo (detecta o mesmo arquivo enviado de novo)
  U.sha256 = async (file) => {
    try {
      if (!window.crypto || !crypto.subtle) return null;
      const h = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
      return Array.from(new Uint8Array(h)).map((b) => b.toString(16).padStart(2, '0')).join('');
    } catch (e) { return null; }
  };
  // Confere se o conteúdo bate com a extensão (ex.: um .exe renomeado para .pdf é recusado)
  U.conferirAssinatura = async (file) => {
    const ext = U.extensao(file.name);
    const b = new Uint8Array(await file.slice(0, 8).arrayBuffer());
    const inicia = (...bytes) => bytes.every((x, i) => b[i] === x);
    if (ext === 'pdf') return inicia(0x25, 0x50, 0x44, 0x46);
    if (ext === 'png') return inicia(0x89, 0x50, 0x4e, 0x47);
    if (ext === 'jpg' || ext === 'jpeg') return inicia(0xff, 0xd8, 0xff);
    if (ext === 'xlsx') return inicia(0x50, 0x4b, 0x03, 0x04);
    if (ext === 'xls') return inicia(0xd0, 0xcf, 0x11, 0xe0) || inicia(0x50, 0x4b, 0x03, 0x04);
    if (ext === 'csv') { const t = new Uint8Array(await file.slice(0, 4096).arrayBuffer()); return !t.includes(0); }
    return false;
  };
  // Tipos de documento (o mesmo vale no banco) e sigla usada no nome organizado do arquivo
  U.TIPOS_DOC = { boletim: 'Boletim de medição', rdo: 'RDO (relatório diário)', pre_nf: 'Pré-NF', ponto: 'Folha de ponto', nota_fiscal: 'Nota fiscal',
    pedido_compra: 'Pedido de compra', folha_servico: 'Folha de serviço (F.S.)', outro: 'Outros', klingele: 'Documento da Klingele para a medição' };
  U.SIGLA_DOC = { boletim: 'BOLETIM', rdo: 'RDO', pre_nf: 'PRE-NF', ponto: 'PONTO', nota_fiscal: 'NF', pedido_compra: 'PEDIDO', folha_servico: 'FS', outro: 'OUTROS', klingele: 'DOCS-KLINGELE' };
  // O fornecedor não envia pedido de compra nem F.S. (são documentos da Klingele)
  U.TIPOS_DOC_FORNECEDOR = Object.fromEntries(Object.entries(U.TIPOS_DOC).filter(([k]) => !['pedido_compra', 'folha_servico', 'klingele'].includes(k)));
  // Troca de tipo pela equipe: documento da Klingele para a medição não entra nem sai deste tipo (anexa de novo)
  U.TIPOS_DOC_TROCA = Object.fromEntries(Object.entries(U.TIPOS_DOC).filter(([k]) => k !== 'klingele'));
  U.DISPENSA_TXT = { sem_medicao: 'Não houve medição no mês', sem_contrato: 'Não há contrato no mês' };
  // Sufixo aleatório no nome dos documentos da Klingele (o fornecedor baixa pelo link; ninguém adivinha o caminho)
  U.sufixoAleatorio = (bytes = 12) => {
    const a = new Uint8Array(bytes);
    (window.crypto || window.msCrypto).getRandomValues(a);
    return Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
  };
  // Sugere o tipo pelo nome do arquivo enviado
  U.tipoPeloNome = (nome) => {
    const n = String(nome || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    if (/\brdo\b|relatorio[\s_-]*diario/.test(n)) return 'rdo';
    if (/pre[\s_.-]*(nf|nota)|prenf|previa[\s_-]*(da[\s_-]*)?nota/.test(n)) return 'pre_nf';
    if (/ponto|frequencia/.test(n)) return 'ponto';
    if (/pedido[\s_-]*(de[\s_-]*)?compra|ordem[\s_-]*de[\s_-]*compra|\bpc[\s_-]*\d/.test(n)) return 'pedido_compra';
    if (/folha[\s_-]*(de[\s_-]*)?servico|\bf\.?s\b|\bfrs\b/.test(n)) return 'folha_servico';
    if (/\bnf\b|\bnfs?e\b|nota[\s_-]*fiscal|danfe/.test(n)) return 'nota_fiscal';
    if (/\bbm\b|boletim|medicao/.test(n)) return 'boletim';
    return null;
  };
  U.slug = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  // Nome organizado: 2026-09_SETEMBRO_FORNECEDOR_TIPO.pdf (o 2º do mesmo tipo ganha _2). Igual ao calculado no banco.
  U.nomePadrao = ({ competencia, fornecedor, tipo, ext, seq }) => {
    const forn = U.slug(fornecedor).slice(0, 40).replace(/^-+|-+$/g, '').toUpperCase() || 'FORNECEDOR';
    return `${competencia.slice(0, 7)}_${U.slug(U.mesNome(competencia)).toUpperCase()}_${forn}_${U.SIGLA_DOC[tipo] || 'OUTROS'}`
      + (seq > 1 ? '_' + seq : '') + '.' + (String(ext || 'pdf').toLowerCase());
  };

  // Tipo de serviço do contrato
  U.TIPOS_SERVICO = {
    locacao: ['Fixo', 'Locação'], suporte_tecnico: ['Fixo', 'Suporte técnico'],
    servico_especifico: ['Não fixo', 'Serviço específico'], servico_unico: ['Não fixo', 'Serviço único']
  };
  U.FIXOS = ['locacao', 'suporte_tecnico'];
  // Pasta por filtro: o contrato entra se cumprir todas as regras escolhidas (igual a _contrato_no_filtro no banco).
  // x = { forn(id), naLista(fornecedorId), colabNaEquipe(colabId, equipeIds) }
  U.FILTRO_TIPOS = [['locacao', 'Locação'], ['suporte_tecnico', 'Suporte técnico'], ['servico_especifico', 'Spot · serviço específico'],
    ['servico_unico', 'Spot · serviço único'], ['sem_tipo', 'Sem tipo definido']];
  U.contratoNoFiltro = (c, f, x) => {
    if (!c || c.situacao !== 'ativo' || !f) return false;
    const tem = (k) => Array.isArray(f[k]) && f[k].length > 0;
    const sups = c.supervisores || (c.supervisor_id ? [c.supervisor_id] : []), cts = c.contatos || [];
    if (tem('tipos') && !f.tipos.includes(c.tipo_servico || 'sem_tipo')) return false;
    if (tem('supervisores') && !f.supervisores.some((id) => sups.includes(id))) return false;
    if (tem('contatos') && !f.contatos.some((id) => cts.includes(id))) return false;
    if (tem('equipes') && ![...sups, ...cts].some((id) => x.colabNaEquipe(id, f.equipes))) return false;
    const t = String(f.texto || '').trim().toLowerCase();
    if (t) { const fo = x.forn(c.fornecedor_id) || {}; if (![fo.nome, fo.codigo, c.pedido, c.titulo].filter((v) => v !== null && v !== undefined).join(' ').toLowerCase().includes(t)) return false; }
    if (f.somente_lista !== false && !x.naLista(c.fornecedor_id)) return false;
    return true;
  };
  U.filtroTemRegra = (f) => !!f && (['tipos', 'supervisores', 'contatos', 'equipes'].some((k) => Array.isArray(f[k]) && f[k].length) || !!String(f.texto || '').trim());
  U.SPOT = ['servico_especifico', 'servico_unico'];
  // Por que o fornecedor recebe o link no fim do mês (igual a modalidade_envio no banco)
  U.MODALIDADE = { boletim: ['Boletim', 'accent'], fixo: ['Valor fixo', 'info'], spot: ['Spot', 'warn'] };
  U.modalidade = (f, contratos, comp, config) => {
    if (!f || !f.ativo) return null;
    if (f.deseja_enviar) return 'boletim';
    const fim = U.fimMes(comp);
    const vig = contratos.filter((c) => c.fornecedor_id === f.id && c.situacao === 'ativo' && (!c.data_inicio || c.data_inicio <= fim) && (!c.data_fim || c.data_fim >= comp));
    const cfg = (k) => (config && config[k] !== undefined ? config[k] : 'true') === 'true';
    if (cfg('envio_incluir_fixos') && vig.some((c) => U.FIXOS.includes(c.tipo_servico) || (!c.tipo_servico && f.tipo_contrato === 'FIXO'))) return 'fixo';
    if (cfg('envio_incluir_spot') && vig.some((c) => U.SPOT.includes(c.tipo_servico))) return 'spot';
    return null;
  };
  // ---------- Pastas de fechamento (mesmas regras do banco) ----------
  U.vigenteNoMes = (c, comp) => !!c && c.situacao === 'ativo' && (!c.data_inicio || c.data_inicio <= U.fimMes(comp)) && (!c.data_fim || c.data_fim >= comp);
  U.contratoCumpreRegra = (c, regra, x) => !!regra && U.filtroTemRegra(regra) && U.contratoNoFiltro({ ...c, situacao: 'ativo' }, { ...regra, somente_lista: false }, x);
  // Contrato novo: 1ª pasta (ordem de criação) cuja regra ele cumpre; senão contínuo vai ao Envio mensal; senão avulso
  U.pastaParaContrato = (c, pastas, f, x) => {
    const regra = (pastas || []).filter((p) => !p.padrao && p.filtro).sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)) || a.nome.localeCompare(b.nome))
      .find((p) => U.contratoCumpreRegra(c, p.filtro, x));
    if (regra) return regra.id;
    const pad = (pastas || []).find((p) => p.padrao);
    return pad && f && (f.deseja_enviar || U.FIXOS.includes(c.tipo_servico) || (!c.tipo_servico && f.tipo_contrato === 'FIXO')) ? pad.id : null;
  };
  // Competência que a pasta pede no dia (null = não dispara nesse dia)
  U.pastaCompDoDia = (p, iso, cal) => {
    if (!p) return null;
    const comp = U.compDe(iso);
    if (p.calendario === 'mensal' || p.calendario === 'meses' || !p.calendario) {
      if (p.calendario === 'meses' && !(p.meses || []).includes(Number(iso.slice(5, 7)))) return null;
      if (Number(p.dia_util) === 0) return iso === U.ultimoDiaUtil(comp, cal) ? comp : null;
      return iso === U.diaUtilDoMes(comp, Number(p.dia_util) || 1, cal) ? U.addMes(comp, -1) : null;
    }
    if (p.calendario === 'datas') {
      if (!(p.datas || []).includes(iso)) return null;
      return p.pede === 'mes_atual' ? comp : U.addMes(comp, -1);
    }
    return null;
  };
  // A pasta pede esta competência? (mensal e manual: todo mês; meses: só os meses marcados; datas: os meses que as datas pedem)
  U.pastaPedeComp = (p, comp) => {
    if (!p || p.calendario === 'mensal' || p.calendario === 'manual' || !p.calendario) return true;
    if (p.calendario === 'meses') return (p.meses || []).includes(Number((Number(p.dia_util) === 0 ? comp : U.addMes(comp, 1)).slice(5, 7)));
    return (p.datas || []).some((d) => (p.pede === 'mes_atual' ? U.compDe(d) : U.addMes(U.compDe(d), -1)) === comp);
  };
  // Próximo disparo automático (a partir de hoje; hoje só se ainda não passou do horário): {data, competencia} ou null
  U.proximoDisparo = (p, cal, agoraHHMM) => {
    if (!p || p.ativa === false || p.calendario === 'manual') return null;
    const hoje = U.hojeISO(), hora = agoraHHMM || '00:00';
    if (p.calendario === 'datas') {
      const d = (p.datas || []).filter((x) => x > hoje || (x === hoje && hora < p.horario)).sort()[0];
      return d ? { data: d, competencia: U.pastaCompDoDia(p, d, cal) } : null;
    }
    let d = hoje;
    for (let i = 0; i < 400; i++, d = U.addDias(d, 1)) {
      const c = U.pastaCompDoDia(p, d, cal);
      if (c && (d > hoje || hora < p.horario)) return { data: d, competencia: c };
    }
    return null;
  };
  U.MESES_CURTOS_TXT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  U.diaPastaTxt = (n) => (Number(n) === 0 ? 'último dia útil do mês' : `${Number(n) || 1}º dia útil do mês seguinte`);
  U.calendarioTxt = (p) => {
    if (!p) return '';
    if (p.calendario === 'manual') return 'Só manual (botão Enviar agora)';
    if (p.calendario === 'datas') {
      const ds = (p.datas || []).slice().sort();
      return `Datas marcadas: ${ds.slice(0, 4).map((d) => U.dataBR(d).slice(0, 5)).join(', ')}${ds.length > 4 ? ` e mais ${ds.length - 4}` : ''} · ${p.horario} · pede ${p.pede === 'mes_atual' ? 'o mês da data' : 'o mês anterior'}`;
    }
    const meses = p.calendario === 'meses' ? (p.meses || []).slice().sort((a, b) => a - b).map((m) => U.MESES_CURTOS_TXT[m - 1]).join(', ') : '';
    return `${meses ? 'Em ' + meses : 'Todo mês'} · ${U.diaPastaTxt(p.dia_util)} · ${p.horario}`;
  };

  // Aviso de vencimento: dias de antecedência do contrato (igual a alerta_dias_contrato no banco)
  U.alertaDias = (c, config) => {
    if (c.alerta_dias) return Number(c.alerta_dias);
    const n = (k, p) => Number((config || {})[k]) || p;
    const longo = !c.data_inicio || !c.data_fim || U.diffDias(c.data_inicio, c.data_fim) > n('alerta_venc_limite_curto', 42);
    return longo ? n('alerta_venc_longo_dias', 42) : n('alerta_venc_curto_dias', 14);
  };
  U.tipoServicoTxt = (k) => (U.TIPOS_SERVICO[k] ? U.TIPOS_SERVICO[k].join(' · ') : '');
  U.opcoesTipoServico = (atual, vazio) => `<option value="">${U.esc(vazio || 'Sem tipo definido')}</option>`
    + ['Fixo', 'Não fixo'].map((g) => `<optgroup label="${g}">${Object.entries(U.TIPOS_SERVICO).filter(([, v]) => v[0] === g)
      .map(([k, v]) => `<option value="${k}" ${atual === k ? 'selected' : ''}>${v[1]}</option>`).join('')}</optgroup>`).join('');

  // ---------- Avaliação de satisfação ----------
  U.CATEGORIAS = [
    ['know_how', 'Know how', 'Conhecimento técnico da equipe'],
    ['org_limpeza', 'Organização e limpeza', 'Local de trabalho arrumado e limpo'],
    ['saude_seguranca', 'Saúde e segurança', 'EPI, normas e cuidados no serviço'],
    ['iniciativa', 'Iniciativa', 'Proatividade para resolver problemas'],
    ['cumprimento_prazos', 'Cumprimento de prazos', 'Entregas no tempo combinado'],
    ['planejamento', 'Planejamento', 'Programação e preparação dos serviços'],
    ['supervisao', 'Supervisão', 'Acompanhamento da equipe pelo fornecedor'],
    ['cond_equipamento', 'Condição dos equipamentos', 'Ferramentas e equipamentos em bom estado'],
    ['qualidade_final', 'Qualidade final', 'Resultado do serviço entregue']
  ];
  U.notasCompletas = (n) => !!n && U.CATEGORIAS.every(([k]) => Number.isInteger(n[k]) && n[k] >= 1 && n[k] <= 10);
  U.mediaNotas = (n) => {
    const v = U.CATEGORIAS.map(([k]) => n && n[k]).filter((x) => Number.isInteger(x));
    return v.length ? Math.round((v.reduce((t, x) => t + x, 0) / v.length) * 100) / 100 : null;
  };
  U.nota = (v) => (U.vazio(v) ? '—' : Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }));
  U.classeNota = (v) => (U.vazio(v) ? '' : v >= 8 ? 'ok' : v >= 6 ? 'warn' : 'crit');

  // Horários do envio automático (o agendamento roda a cada 15 minutos, das 06:00 às 20:45)
  U.HORARIOS = [];
  for (let h = 6; h <= 20; h++) for (const m of ['00', '15', '30', '45']) U.HORARIOS.push(String(h).padStart(2, '0') + ':' + m);

  // ---------- E-mail ----------
  // Contatos Klingele no lugar de {SUPORTE}: uma linha (1 contato) ou lista (2 ou mais). Igual ao banco.
  U.contatosTexto = (lista) => {
    const ls = (lista || []).map((c) => (typeof c === 'string' ? { email: c } : c)).filter((c) => c && (c.email || c.telefone)).slice(0, 5)
      .map((c) => [c.nome, (c.cargo || '').trim() || null, c.email, c.telefone].filter(Boolean).join(' · '));
    if (!ls.length) return null;
    return ls.length === 1 ? ls[0] : '\n' + ls.map((l) => '- ' + l).join('\n');
  };
  // Contatos por serviço (igual ao banco): serviço sem contato próprio usa os contatos gerais; se todos os serviços
  // ficam com os mesmos contatos, sai uma linha (ou lista) como antes; senão, uma linha por serviço com os contatos dele.
  U.contatoLinha = (c) => [c.nome, (c.cargo || '').trim() || null, c.email, c.telefone].filter(Boolean).join(' · ');
  U.suporteServicos = (servicos, geral) => {
    const g = (geral || []).filter((c) => c && (c.email || c.telefone)).slice(0, 5);
    const itens = (servicos || []).map((s) => ({ s, cts: ((s.contatos && s.contatos.length ? s.contatos : g) || []).filter((c) => c && (c.email || c.telefone)).slice(0, 5) }))
      .filter((x) => x.cts.length);
    if (!itens.length) return null;
    const chave = (cts) => cts.map(U.contatoLinha).join('|');
    if (new Set(itens.map((x) => chave(x.cts))).size === 1) return U.contatosTexto(itens[0].cts);
    return '\n' + itens.map((x) => `- ${x.s.titulo}${x.s.pedido ? ` (Pedido ${x.s.pedido})` : ''}: ${x.cts.map(U.contatoLinha).join('; ')}`).join('\n');
  };
  U.montarEmail = ({ modeloAssunto, modeloCorpo, fornecedor, competencia, servicos, link, prazoISO, prazoDias, suporte, suporteServicos, documentos }) => {
    const sup = suporteServicos ? U.suporteServicos(suporteServicos, suporte) : U.contatosTexto(suporte);
    if (!sup) modeloCorpo = String(modeloCorpo || '').replace(/\n*[^\n]*\{SUPORTE\}[^\n]*/g, '');
    const lista = (servicos || []).map((s) => `- ${s.titulo}${s.pedido ? ` (Pedido ${s.pedido})` : ''}`).join('\n') || '- (sem serviço cadastrado)';
    const mapa = {
      FORNECEDOR: fornecedor, MES: U.mesNome(competencia), ANO: competencia.slice(0, 4), SERVICOS: lista, LINK: link,
      PRAZO_DIAS: String(prazoDias), PRAZO_DATA: U.dataBR(U.dataLocal(prazoISO)), SUPORTE: sup || ''
    };
    const troca = (t) => String(t || '').replace(/\{(FORNECEDOR|MES|ANO|SERVICOS|LINK|PRAZO_DIAS|PRAZO_DATA|SUPORTE)\}/g, (_, k) => mapa[k]);
    let corpo = sup ? troca(modeloCorpo).replace(/[ \t]+\n/g, '\n') : troca(modeloCorpo);
    // Documentos da Klingele no link (mesma regra do banco): parágrafo logo depois da linha do link
    const docs = (documentos || []).filter(Boolean);
    if (docs.length) {
      const txt = `A Klingele deixou ${docs.length === 1 ? '1 documento' : docs.length + ' documentos'} no link para você fazer a medição (${docs.join(', ').slice(0, 600)}). Baixe pelo link, prepare o boletim e envie pelo mesmo link.`;
      if (corpo.includes('{DOCUMENTOS}')) corpo = corpo.split('{DOCUMENTOS}').join(txt);
      else if (link && corpo.includes(link)) { const i = corpo.indexOf(link) + link.length, j = corpo.indexOf('\n', i); const p = j < 0 ? corpo.length : j; corpo = corpo.slice(0, p) + '\n\n' + txt + corpo.slice(p); }
      else corpo += '\n\n' + txt;
    } else corpo = corpo.replace(/\n*[^\n]*\{DOCUMENTOS\}[^\n]*/g, '');
    return { assunto: troca(modeloAssunto), corpo };
  };
  U.montarEmailAvaliacao = ({ modeloAssunto, modeloCorpo, supervisor, fornecedor, competencia, servicos, link, prazoISO, prazoDias }) => {
    const lista = (servicos || []).map((s) => `- ${s.titulo}${s.pedido ? ` (Pedido ${s.pedido})` : ''}`).join('\n') || '- (sem pedido vinculado)';
    const mapa = {
      SUPERVISOR: supervisor, FORNECEDOR: fornecedor, MES: U.mesNome(competencia), ANO: competencia.slice(0, 4), SERVICOS: lista, LINK: link,
      PRAZO_DIAS: String(prazoDias), PRAZO_DATA: U.dataBR(U.dataLocal(prazoISO))
    };
    const troca = (t) => String(t || '').replace(/\{(SUPERVISOR|FORNECEDOR|MES|ANO|SERVICOS|LINK|PRAZO_DIAS|PRAZO_DATA)\}/g, (_, k) => mapa[k]);
    return { assunto: troca(modeloAssunto), corpo: troca(modeloCorpo) };
  };
  // Pedido de nota fiscal ao fornecedor (mesma regra do banco: dados do sistema primeiro, textos cadastrados por último)
  U.montarEmailNF = ({ modeloAssunto, modeloCorpo, fornecedor, competencia, pedido, servico, parcela, parcelasTotal, valor, folhaNumero, folhaData,
    descricao, link, prazoISO, prazoDias, suporte, suporteServicos, cnpjs, anexos, recusa }) => {
    const parc = parcela ? String(parcela) + (parcelasTotal ? ' de ' + parcelasTotal : '') : '-';
    const folha = folhaNumero ? folhaNumero + (folhaData ? ' de ' + U.dataBR(folhaData) : '') : '-';
    const sup = suporteServicos ? U.suporteServicos(suporteServicos, suporte) : U.contatosTexto(suporte);
    const cnpjTxt = (cnpjs || []).filter(Boolean).map(U.cnpj).join(', ');
    const anx = (anexos || []).length ? '\n' + anexos.map((a) => `- ${a.nome}: ${a.url}`).join('\n') : '';
    const tiraLinha = (t, k) => t.replace(new RegExp('\\n*[^\\n]*\\{' + k + '\\}[^\\n]*', 'g'), '');
    let c = String(modeloCorpo || '');
    c = c.split('{LINK}').join(link).split('{PRAZO_DIAS}').join(String(prazoDias)).split('{PRAZO_DATA}').join(U.dataBR(U.dataLocal(prazoISO)))
      .split('{PEDIDO}').join(pedido ? String(pedido) : '-').split('{PARCELA}').join(parc).split('{PARCELAS}').join(parcelasTotal ? String(parcelasTotal) : '-')
      .split('{VALOR}').join(U.brl(valor)).split('{FOLHA}').join(folha).split('{MES}').join(U.mesNome(competencia)).split('{ANO}').join(competencia.slice(0, 4));
    c = cnpjTxt ? c.split('{CNPJ_KLINGELE}').join(cnpjTxt) : tiraLinha(c, 'CNPJ_KLINGELE');
    c = anx ? c.split('{ANEXOS}').join(anx) : tiraLinha(c, 'ANEXOS');
    c = sup ? c.split('{SUPORTE}').join(sup).replace(/[ \t]+\n/g, '\n') : tiraLinha(c, 'SUPORTE');
    c = c.split('{FORNECEDOR}').join(fornecedor).split('{SERVICO}').join(servico || '').split('{DESCRICAO}').join(descricao || '-');
    if (recusa) c = `ATENÇÃO: a nota fiscal nº ${recusa.numero} enviada anteriormente foi recusada.\nMotivo: ${recusa.motivo || '-'}\nEnvie uma nova nota pelo link abaixo.\n\n` + c;
    const a = String(modeloAssunto || '').split('{PEDIDO}').join(pedido ? String(pedido) : '-').split('{MES}').join(U.mesNome(competencia))
      .split('{ANO}').join(competencia.slice(0, 4)).split('{PARCELA}').join(parc).split('{FORNECEDOR}').join(fornecedor);
    return { assunto: a.replace(/[\r\n]+/g, ' ').trim(), corpo: c };
  };
  // Encaminhamento da NF a Serviços: NF recebida + F.S. aprovada (mesma regra do banco)
  U.montarEmailFS = ({ modeloAssunto, modeloCorpo, fornecedor, competencia, pedido, servico, folha, folhaData, parcela, parcelasTotal, valor, aprovadoPor, anexos, descricao,
    nfModelo, nfNumero, nfSerie, nfValor, nfEmissao }) => {
    let c = String(modeloCorpo || '') || 'Segue a nota fiscal do serviço abaixo. A folha de serviço foi aprovada.\n\nFornecedor: {FORNECEDOR}\nPedido: {PEDIDO}\nCompetência: {MES}/{ANO}\nF.S.: {FOLHA}\nNota fiscal: {NF_TIPO} nº {NF_NUMERO} · {NF_VALOR}\n\nArquivos: {ANEXOS}';
    const anx = (anexos || []).length ? '\n' + anexos.map((a) => `- ${a.nome}`).join('\n') : '';
    const tipo = { nfe: 'NF-e', nfse: 'NFS-e' }[nfModelo] || 'Fatura/recibo';
    c = c.split('{PEDIDO}').join(pedido ? String(pedido) : '-').split('{MES}').join(U.mesNome(competencia)).split('{ANO}').join(competencia.slice(0, 4))
      .split('{FOLHA}').join((folha || '-') + (folhaData ? ' de ' + U.dataBR(folhaData) : '')).split('{PARCELA}').join(parcela ? parcela + (parcelasTotal ? ' de ' + parcelasTotal : '') : '-')
      .split('{VALOR}').join(U.brl(valor)).split('{APROVADO_POR}').join(aprovadoPor || '-')
      .split('{NF_TIPO}').join(tipo).split('{NF_NUMERO}').join((nfNumero || '-') + (nfSerie ? ' série ' + nfSerie : ''))
      .split('{NF_VALOR}').join(U.brl(nfValor)).split('{NF_EMISSAO}').join(nfEmissao ? U.dataBR(nfEmissao) : '-');
    c = anx ? c.split('{ANEXOS}').join(anx) : c.replace(/\n*[^\n]*\{ANEXOS\}[^\n]*/g, '');
    c = c.split('{DESCRICAO}').join(descricao || '-').split('{SERVICO}').join(servico || '').split('{FORNECEDOR}').join(fornecedor || '');
    const a = String(modeloAssunto || 'NOTA FISCAL {NF_NUMERO} - {FORNECEDOR} - PEDIDO {PEDIDO} - {MES}/{ANO}').split('{PEDIDO}').join(pedido ? String(pedido) : '-')
      .split('{MES}').join(U.mesNome(competencia)).split('{ANO}').join(competencia.slice(0, 4)).split('{NF_NUMERO}').join(nfNumero || '-').split('{FORNECEDOR}').join(fornecedor || '');
    return { assunto: a.replace(/[\r\n]+/g, ' ').trim(), corpo: c };
  };
  // Aviso de vencimento do contrato (mesma regra do banco)
  U.montarEmailVenc = ({ modeloAssunto, modeloCorpo, fornecedor, pedido, servico, supervisor, dataInicio, dataFim }) => {
    const dias = U.diffDias(U.hojeISO(), dataFim);
    let c = String(modeloCorpo || '') || 'Olá, {SUPERVISOR}!\n\nO contrato abaixo vence em {DIAS} dias ({DATA_FIM}).\n\nFornecedor: {FORNECEDOR}\nPedido: {PEDIDO}\nServiço: {SERVICO}\nVigência: {DATA_INICIO} a {DATA_FIM}\n\nVerifique a renovação, um novo pedido ou o encerramento.\n\nBMK · Boletim Mensal · Klingele Paper & Packing';
    c = c.split('{PEDIDO}').join(pedido ? String(pedido) : '-').split('{DATA_FIM}').join(U.dataBR(dataFim)).split('{DATA_INICIO}').join(dataInicio ? U.dataBR(dataInicio) : '-')
      .split('{DIAS}').join(String(dias)).split('{SERVICO}').join(servico || '').split('{SUPERVISOR}').join(supervisor || 'equipe').split('{FORNECEDOR}').join(fornecedor || '');
    const a = String(modeloAssunto || 'AVISO DE VENCIMENTO - CONTRATO {PEDIDO} {FORNECEDOR} - {DATA_FIM}').split('{PEDIDO}').join(pedido ? String(pedido) : '-')
      .split('{DATA_FIM}').join(U.dataBR(dataFim)).split('{FORNECEDOR}').join(fornecedor || '');
    return { assunto: a.replace(/[\r\n]+/g, ' ').trim(), corpo: c };
  };
  U.usuarioValido = (u) => /^[A-Za-z0-9][A-Za-z0-9._-]{2,29}$/.test(String(u || ''));
  U.mailto = (para, assunto, corpo) =>
    'mailto:' + (para || []).map(encodeURIComponent).join(',') +
    '?subject=' + encodeURIComponent(assunto || '') + '&body=' + encodeURIComponent(String(corpo || '').replace(/\r?\n/g, '\r\n'));
  U.emailValido = (e) => { const t = String(e || '').trim(); return t.length <= 254 && /^[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$/.test(t); };

  // ---------- Leitura automática do valor (PDF e Excel/CSV) ----------
  const LIBS = {
    pdf: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
    pdfWorker: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
    xlsx: 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js'
  };
  const carregados = {};
  U.carregarScript = (url) => {
    if (!carregados[url]) {
      carregados[url] = new Promise((ok, erro) => {
        const s = document.createElement('script');
        const sri = ((window.APP_CONFIG || {}).sri || {})[url];
        if (sri) { s.integrity = sri; s.crossOrigin = 'anonymous'; }
        s.referrerPolicy = 'no-referrer';
        s.src = url; s.async = true;
        s.onload = () => ok(); s.onerror = () => { delete carregados[url]; erro(new Error('Não foi possível carregar ' + url)); };
        document.head.appendChild(s);
      });
    }
    return carregados[url];
  };
  U.carregarXLSX = async () => { await U.carregarScript(LIBS.xlsx); return window.XLSX; };

  const RE_TOTAL = /(valor\s+total|total\s+geral|total\s+(do|da)\s+(boletim|medi[cç][aã]o|m[eê]s|servi[cç]o|nota)|total\s+a\s+(pagar|faturar)|valor\s+a\s+(pagar|faturar)|valor\s+l[ií]quido|total\s+l[ií]quido|total\s+bruto|valor\s+da\s+medi[cç][aã]o|total)/i;
  const RE_SUB = /sub\s*-?\s*total/i;
  const RE_MOEDA = /(?:R\$\s*)?-?\d{1,3}(?:\.\d{3})+,\d{2}(?!\d)|(?:R\$\s*)-?\d+,\d{2}(?!\d)|(?<![\d.,])\d{1,6},\d{2}(?!\d)/g;

  function pontuar(rotulo) {
    const r = rotulo.toLowerCase();
    if (RE_SUB.test(r)) return 2;
    if (/total\s+geral|valor\s+total|total\s+(do|da)\s+(boletim|medi)|total\s+a\s+(pagar|faturar)|valor\s+a\s+(pagar|faturar)|valor\s+da\s+medi/.test(r)) return 6;
    if (/l[ií]quido/.test(r)) return 5;
    if (/bruto/.test(r)) return 4;
    if (/total/.test(r)) return 3;
    return 1;
  }
  function escolher(cands) {
    const uniq = [];
    cands.forEach((c) => {
      if (c.valor === null || !isFinite(c.valor) || c.valor <= 0) return;
      const ja = uniq.find((u) => Math.abs(u.valor - c.valor) < 0.005);
      if (ja) { if (c.peso > ja.peso) Object.assign(ja, c); } else uniq.push({ ...c });
    });
    uniq.sort((a, b) => b.peso - a.peso || b.ordem - a.ordem || b.valor - a.valor);
    const melhor = uniq[0] || null;
    return {
      suportado: true,
      valor: melhor ? Math.round(melhor.valor * 100) / 100 : null,
      rotulo: melhor ? melhor.rotulo : null,
      confianca: !melhor ? 'nenhuma' : melhor.peso >= 5 ? 'alta' : melhor.peso >= 3 ? 'media' : 'baixa',
      candidatos: uniq.slice(0, 6).map((c) => ({ valor: Math.round(c.valor * 100) / 100, rotulo: c.rotulo }))
    };
  }

  async function lerPDF(buf) {
    await U.carregarScript(LIBS.pdf);
    const pdfjs = window.pdfjsLib;
    pdfjs.GlobalWorkerOptions.workerSrc = LIBS.pdfWorker;
    const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), isEvalSupported: false }).promise;
    const linhas = [];
    try {
    for (let p = 1; p <= Math.min(doc.numPages, 15); p++) {
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const grupos = [];
      tc.items.forEach((it) => {
        if (!it.str || !it.str.trim()) return;
        const y = it.transform[5], x = it.transform[4];
        let g = grupos.find((gg) => Math.abs(gg.y - y) < 3);
        if (!g) { g = { y, itens: [] }; grupos.push(g); }
        g.itens.push({ x, s: it.str });
      });
      grupos.sort((a, b) => b.y - a.y).forEach((g) => {
        linhas.push(g.itens.sort((a, b) => a.x - b.x).map((i) => i.s).join(' ').replace(/\s+/g, ' ').trim());
      });
    }
    } finally {
      try { await doc.destroy(); } catch (e) { /* já liberado */ }
    }
    const cands = [];
    let ordem = 0;
    linhas.forEach((ln, i) => {
      const valores = (ln.match(RE_MOEDA) || []).map(U.parseValor);
      if (RE_TOTAL.test(ln)) {
        const alvo = valores.length ? valores : (linhas[i + 1] || '').match(RE_MOEDA)?.map(U.parseValor) || [];
        if (alvo.length) cands.push({ valor: alvo[alvo.length - 1], rotulo: ln.slice(0, 90), peso: pontuar(ln), ordem: ordem++ });
      } else {
        valores.forEach((v) => cands.push({ valor: v, rotulo: ln.slice(0, 90), peso: 0, ordem: ordem++ }));
      }
    });
    if (!cands.some((c) => c.peso > 0)) {
      const maior = cands.reduce((m, c) => (c.valor > (m?.valor || 0) ? c : m), null);
      if (maior) { maior.peso = 1; maior.rotulo = 'Maior valor do documento: ' + maior.rotulo; }
    }
    return escolher(cands.filter((c) => c.peso > 0));
  }

  async function lerPlanilha(buf, nome) {
    const XLSX = await U.carregarXLSX();
    const wb = U.extensao(nome) === 'csv'
      ? XLSX.read(new TextDecoder('utf-8').decode(buf), { type: 'string' })
      : XLSX.read(buf, { type: 'array' });
    const cands = [];
    let ordem = 0, maior = null;
    wb.SheetNames.slice(0, 8).forEach((sn) => {
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sn], { header: 1, raw: true, blankrows: false, defval: null });
      rows.forEach((row, ri) => {
        (row || []).forEach((cel, ci) => {
          const num = typeof cel === 'number' ? cel : (typeof cel === 'string' && /\d,\d{2}\s*$/.test(cel) ? U.parseValor(cel) : null);
          if (num && num > 0 && (!maior || num > maior.valor)) maior = { valor: num, rotulo: `Maior valor (${sn})`, peso: 1, ordem: ordem++ };
          if (typeof cel !== 'string' || !RE_TOTAL.test(cel) || cel.length > 80) return;
          let v = null;
          for (let k = ci + 1; k < row.length && v === null; k++) v = typeof row[k] === 'number' ? row[k] : (row[k] ? U.parseValor(row[k]) : null);
          for (let k = 1; k <= 2 && v === null; k++) { const below = rows[ri + k] && rows[ri + k][ci]; v = typeof below === 'number' ? below : null; }
          if (v !== null) cands.push({ valor: v, rotulo: `${String(cel).trim()} (${sn})`, peso: pontuar(cel), ordem: ordem++ });
        });
      });
    });
    if (!cands.length && maior) cands.push(maior);
    return escolher(cands);
  }

  // file: File ou Blob; nome: nome do arquivo
  U.lerValor = async (file, nome) => {
    const ext = U.extensao(nome || file.name || '');
    try {
      const buf = await file.arrayBuffer();
      if (ext === 'pdf') return await lerPDF(buf);
      if (['xlsx', 'xls', 'csv'].includes(ext)) return await lerPlanilha(buf, nome || file.name);
      return { suportado: false, valor: null, candidatos: [], motivo: 'Leitura automática disponível para PDF e Excel. Informe o valor manualmente.' };
    } catch (e) {
      console.warn('Leitura do valor falhou', e);
      return { suportado: true, valor: null, candidatos: [], erro: true, motivo: 'Não foi possível ler o arquivo automaticamente.' };
    }
  };

  // ---------- Interface ----------
  U.toast = (msg, tipo) => {
    let box = document.querySelector('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast' + (tipo === 'erro' ? ' err' : '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), tipo === 'erro' ? 6500 : 3200);
  };
  U.copiar = async (texto, ok) => {
    try { await navigator.clipboard.writeText(texto); U.toast(ok || 'Copiado'); }
    catch (e) {
      const ta = document.createElement('textarea');
      ta.value = texto; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      let feito = false;
      try { feito = document.execCommand('copy'); } catch (_) { /* sem suporte */ }
      ta.remove();
      U.toast(feito ? (ok || 'Copiado') : 'Selecione o texto e copie com Ctrl+C', feito ? null : 'erro');
    }
  };
  U.confirmar = (titulo, texto, rotuloOk, perigo) => new Promise((ok) => {
    const w = document.createElement('div');
    w.className = 'modal-wrap';
    w.innerHTML = `<div class="backdrop" data-x></div><div class="modal" role="dialog" aria-modal="true" aria-labelledby="mdl-t">
      <h2 id="mdl-t">${U.esc(titulo)}</h2><p class="muted">${U.esc(texto)}</p>
      <div class="row" style="justify-content:flex-end"><button class="btn ghost" data-x>Voltar</button>
      <button class="btn ${perigo ? 'danger' : 'primary'}" data-ok>${U.esc(rotuloOk || 'Confirmar')}</button></div></div>`;
    const fim = (v) => { w.remove(); ok(v); };
    w.addEventListener('click', (e) => { if (e.target.closest('[data-ok]')) fim(true); else if (e.target.closest('[data-x]')) fim(false); });
    document.body.appendChild(w);
    w.querySelector('[data-ok]').focus();
  });
  U.storage = {
    get(k, padrao) { try { const v = localStorage.getItem(k); return v === null ? padrao : JSON.parse(v); } catch (e) { return padrao; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* armazenamento indisponível */ } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { /* armazenamento indisponível */ } }
  };
  U.tema = {
    aplicar(t) { if (t) document.documentElement.setAttribute('data-theme', t); else document.documentElement.removeAttribute('data-theme'); },
    atual() {
      const t = document.documentElement.getAttribute('data-theme');
      if (t) return t;
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    },
    alternar() { const n = U.tema.atual() === 'dark' ? 'light' : 'dark'; U.tema.aplicar(n); U.storage.set('klg-tema', n); return n; },
    iniciar() { const t = U.storage.get('klg-tema', null); if (t) U.tema.aplicar(t); }
  };

  // Ícones (traço simples, herdam a cor do texto)
  const I = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${p}</svg>`;
  U.ic = {
    painel: I('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    envio: I('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7z"/>'),
    receb: I('<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.8 4H7.2a2 2 0 0 0-1.7 1.1z"/>'),
    pag: I('<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20M6 15h4"/>'),
    forn: I('<path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-6h6v6"/>'),
    contr: I('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>'),
    hist: I('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>'),
    conf: I('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
    esq: I('<path d="m15 18-6-6 6-6"/>'),
    dir: I('<path d="m9 18 6-6-6-6"/>'),
    x: I('<path d="M18 6 6 18M6 6l12 12"/>'),
    mais: I('<path d="M12 5v14M5 12h14"/>'),
    busca: I('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>'),
    copiar: I('<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'),
    mail: I('<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 6-10 7L2 6"/>'),
    link: I('<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/>'),
    abrir: I('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3"/>'),
    ler: I('<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10M7 8h6M7 16h8"/>'),
    upload: I('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>'),
    lixo: I('<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'),
    ok: I('<path d="M20 6 9 17l-5-5"/>'),
    refazer: I('<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>'),
    baixar: I('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>'),
    olho: I('<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    estrela: I('<path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/>'),
    pessoas: I('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.6a3.5 3.5 0 0 1 0 6.8M18 14.2a6.5 6.5 0 0 1 3.5 5.8"/>'),
    tel: I('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>'),
    lapis: I('<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    nf: I('<path d="M5 2h14v20l-3.5-2-3.5 2-3.5-2L5 22z"/><path d="M9 7h6M9 11h6M9 15h3"/>'),
    alerta: I('<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>'),
    menu: I('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'),
    sair: I('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
    lua: I('<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>'),
    usuarios: I('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/><path d="m17 3 1.5 1.5L21 2"/>'),
    filtro: I('<path d="M3 5h18l-7 8v6l-4 2v-8z"/>'),
    pasta: I('<path d="M3 6.5A2.5 2.5 0 0 1 5.5 4H9l2 2.5h7.5A2.5 2.5 0 0 1 21 9v8.5a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/>'),
    relogio: I('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    pausa: I('<circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/>'),
    docs: I('<path d="M15 2H8a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7z"/><path d="M15 2v5h5M3 7v13a2 2 0 0 0 2 2h10"/>'),
    sino: I('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>'),
    sol: I('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>')
  };

  window.U = U;
})();

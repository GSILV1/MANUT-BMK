/* Aplica o tema salvo antes de desenhar a página (evita piscar claro/escuro) */
try { var t = localStorage.getItem('klg-tema'); if (t) document.documentElement.setAttribute('data-theme', JSON.parse(t)); } catch (e) { /* sem armazenamento */ }

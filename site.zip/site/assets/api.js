/* BMK · Boletim Mensal Klingele · acesso a dados
   - Modo "supabase": banco real (RLS protege os dados; só a equipe logada lê)
   - Modo "demo": dados da planilha + exemplos, guardados só neste navegador */
(function () {
  'use strict';
  const cfg = window.APP_CONFIG || { modo: 'demo' };
  const SB_JS = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.49.4/dist/umd/supabase.min.js';
  const SB_JS_RESERVA = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js';
  const BUCKET = 'boletins';

  const uuid = () => (window.crypto && crypto.randomUUID ? crypto.randomUUID()
    : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }));
  const token64 = () => (uuid() + uuid()).replace(/-/g, '');
  const slug = (t) => String(t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  // Início do dia em Brasília (filtros de período do histórico)
  const inicioDia = (iso) => iso + 'T00:00:00-03:00';
  const pastaDe = (f, comp) => `${comp.slice(0, 7)}/${f.codigo || 'sem-codigo'}-${slug(f.nome).slice(0, 48).replace(/-$/, '')}`;

  // Diagnóstico de conexão: a política de segurança do site (_headers) bloqueia endereços não liberados.
  // Quando o projeto do Supabase muda e o _headers não acompanha, o navegador recusa a conexão.
  let bloqueioCSP = null;
  document.addEventListener('securitypolicyviolation', (e) => {
    if (/supabase\.co/i.test(e.blockedURI || '')) bloqueioCSP = { host: (e.blockedURI.match(/^https?:\/\/[^/]+/) || [e.blockedURI])[0], diretiva: e.violatedDirective || e.effectiveDirective };
  });
  function semConexao() {
    if (bloqueioCSP) return new Error(`O site bloqueou a conexão com ${bloqueioCSP.host}: este endereço não está liberado no arquivo _headers (${bloqueioCSP.diretiva}). Publique a pasta site/ inteira, com o _headers que acompanha o config.js.`);
    if (!/^https:\/\/[a-z0-9]{20}\.supabase\.co$/.test(String(cfg.supabaseUrl || ''))) return new Error('Endereço do Supabase inválido em assets/config.js (esperado https://<projeto>.supabase.co, sem barra no fim).');
    return new Error('Sem conexão com o Supabase. Confira a internet, se o projeto está ativo (não pausado) no painel do Supabase e o endereço em assets/config.js.');
  }
  function traduzir(err) {
    const m = (err && (err.message || err.error_description || err.msg)) || String(err);
    if (/Invalid login credentials/i.test(m)) return new Error('E-mail ou senha incorretos.');
    if (/Email not confirmed/i.test(m)) return new Error('Confirme o e-mail antes de entrar (veja a mensagem que enviamos).');
    if (/Database error saving new user/i.test(m)) return new Error('Não foi possível criar a conta: o usuário pode já existir, o e-mail pode não ser da Klingele ou o cadastro está fechado.');
    if (/User already registered/i.test(m)) return new Error('Este e-mail já tem cadastro. Use "Entrar" ou "Esqueci a senha".');
    if (/Signups? not allowed|signup is disabled/i.test(m)) return new Error('A criação de contas está desligada no Supabase (Authentication > Sign In / Providers > Allow new users to sign up).');
    if (/Password should|weak password|password is too weak/i.test(m)) return new Error('Senha fraca: use pelo menos 10 caracteres, com letras e números.');
    if (/email rate limit|over_email_send_rate_limit/i.test(m)) return new Error('Limite de e-mails do Supabase atingido. Tente de novo em alguns minutos.');
    if (/row-level security|permission denied|42501/i.test(m)) return new Error('Sem permissão para esta ação. Verifique se seu e-mail está na equipe.');
    if (/Failed to fetch|NetworkError|Load failed|fetch failed/i.test(m)) return semConexao();
    if (/Invalid API key|No API key found|invalid.*apikey/i.test(m)) return new Error('Chave do Supabase recusada: confira a chave publicável (sb_publishable_…) em assets/config.js. Ela precisa ser do mesmo projeto do endereço.');
    if (/Could not find the function|PGRST202|schema cache/i.test(m)) return new Error('O banco deste projeto ainda não tem as funções do app: rode 01, 02, 03 e 04 no SQL Editor do Supabase.');
    if (/relation .* does not exist|PGRST205|Could not find the table/i.test(m)) return new Error('O banco deste projeto ainda não tem as tabelas do app: rode 01, 02, 03 e 04 no SQL Editor do Supabase.');
    if ((err && (err.code === 'PT429' || err.status === 429)) && !/Muitas|limite|Limite|acessos/.test(m)) return new Error('Muitas requisições em pouco tempo. Aguarde um minuto e tente de novo.');
    if (/mime type|invalid_mime/i.test(m)) return new Error('Tipo de arquivo não aceito. Envie PDF, Excel, CSV, JPG ou PNG.');
    if (/exceeded the maximum allowed size|Payload too large/i.test(m)) return new Error('Arquivo maior que 25 MB.');
    if (/solicitacoes_uma_ativa/.test(m)) return new Error('Já existe uma solicitação ativa deste fornecedor nesta competência.');
    if (/medicoes_parcela_uq/.test(m)) return new Error('Esta parcela já foi lançada em outra medição do contrato.');
    if (/notas_fiscais_(chave|numero)_uq/.test(m)) return new Error('Esta nota fiscal já foi registrada.');
    if (/contratos_pagas_ck|contratos_parcelas_ck/.test(m)) return new Error('Parcelas do contrato inválidas: as pagas antes do sistema não podem passar do total (até 600).');
    return new Error(m);
  }

  // =====================================================================
  //  SUPABASE
  // =====================================================================
  function criarSupabase() {
    let sb = null;
    const q = async (p) => {
      const { data, error } = await p;
      if (error) {
        // O aviso de bloqueio do navegador chega logo depois da falha: espera um instante para explicar o motivo certo
        if (/fetch|NetworkError|Load failed/i.test(String(error.message || error))) await new Promise((r) => setTimeout(r, 200));
        throw traduzir(error);
      }
      return data;
    };

    const api = {
      modo: 'supabase',
      async init(opts) {
        if (!window.supabase) {
          try { await U.carregarScript(SB_JS); } catch (e) { await U.carregarScript(SB_JS_RESERVA); }
        }
        const portal = opts && opts.portal;
        // Sessão da equipe fica só nesta aba (sessionStorage): fechou o navegador, precisa entrar de novo.
        // No portal do fornecedor não existe sessão: ele usa apenas o link.
        sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseKey, {
          auth: portal
            ? { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
            : { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: 'klg-boletins-auth', storage: window.sessionStorage }
        });
      },
      // ---------- Login ----------
      async sessao() { const { data } = await sb.auth.getSession(); return data.session ? { email: data.session.user.email } : null; },
      // Entra com o e-mail ou com o usuário (ex.: Gsilv1)
      async entrar(login, senha, captcha) {
        let email = String(login || '').trim();
        if (!email.includes('@')) {
          // O banco só devolve o e-mail quando a senha confere (não revela contas). Falha de conexão ou banco
          // sem o 04 aparecem como tal (não como "senha incorreta").
          email = await q(sb.rpc('login_email', { p_login: email, p_senha: senha }));
          if (email === '!limite') throw new Error('Muitas tentativas em pouco tempo. Aguarde alguns minutos e tente de novo.');
          if (email === '!bloqueado') throw new Error('Senha incorreta várias vezes: a entrada por este usuário ficou bloqueada por 15 minutos. Entre com o e-mail ou use "Esqueci a senha".');
          if (!email) throw new Error('Usuário ou senha incorretos.');
        }
        await q(sb.auth.signInWithPassword({ email, password: senha, options: captcha ? { captchaToken: captcha } : undefined }));
        return api.sessao();
      },
      // ---------- Cadastro de colaboradores (fica pendente até o administrador aprovar) ----------
      cadastroOpcoes: () => q(sb.rpc('cadastro_opcoes')).catch(() => ({ aberto: false, dominios: [], admins: [], indisponivel: true })),
      usuarioLivre: (u) => q(sb.rpc('cadastro_usuario_livre', { p_usuario: u })),
      async cadastrar(d, captcha) {
        const r = await q(sb.auth.signUp({ email: d.email, password: d.senha, options: {
          emailRedirectTo: location.origin + location.pathname, captchaToken: captcha || undefined,
          data: { usuario: d.usuario, nome: d.nome, cargo: d.cargo || null, telefone: d.telefone || null, aprovador_id: d.aprovador_id || null } } }));
        // E-mail já cadastrado: o Supabase devolve um usuário sem identidades (não revela se existe)
        if (r && r.user && Array.isArray(r.user.identities) && !r.user.identities.length) throw new Error('Este e-mail já tem cadastro. Use "Entrar" ou "Esqueci a senha".');
        return { sessao: !!(r && r.session) };
      },
      usuarios: () => q(sb.from('usuarios').select('*').order('created_at', { ascending: false })).catch(() => []),
      salvarUsuario: (id, dados) => q(sb.rpc('usuario_salvar', { p_id: id, p_dados: dados })),
      salvarMeuPerfil: (dados) => q(sb.rpc('meu_perfil_salvar', { p_dados: dados })),
      async sair() { await sb.auth.signOut(); },
      async recuperarSenha(email, captcha) {
        await q(sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname, captchaToken: captcha || undefined }));
      },
      async definirSenha(senha) { await q(sb.auth.updateUser({ password: senha })); },
      onAuth(cb) { sb.auth.onAuthStateChange((evt, s) => cb(evt, s)); },
      situacaoAcesso: () => q(sb.rpc('situacao_acesso')),
      async souEquipe() { return !!(await api.situacaoAcesso()).liberado; },
      // ---------- Verificação em duas etapas (aplicativo autenticador) ----------
      async mfaNivel() { const d = await q(sb.auth.mfa.getAuthenticatorAssuranceLevel()); return { atual: d.currentLevel, proximo: d.nextLevel }; },
      async mfaFatores() { const d = await q(sb.auth.mfa.listFactors()); return (d.totp || []).filter((f) => f.status === 'verified'); },
      async mfaIniciar() {
        const d = await q(sb.auth.mfa.listFactors());
        for (const f of (d.all || []).filter((x) => x.status !== 'verified')) await sb.auth.mfa.unenroll({ factorId: f.id });
        const r = await q(sb.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'BMK Klingele ' + new Date().toISOString().slice(0, 16) }));
        return { id: r.id, qr: r.totp.qr_code, segredo: r.totp.secret };
      },
      async mfaConfirmar(factorId, codigo) { await q(sb.auth.mfa.challengeAndVerify({ factorId, code: codigo })); },
      async mfaEntrar(codigo) {
        const f = (await api.mfaFatores())[0];
        if (!f) throw new Error('Nenhum aplicativo autenticador cadastrado nesta conta.');
        await q(sb.auth.mfa.challengeAndVerify({ factorId: f.id, code: codigo }));
      },
      async mfaRemover(factorId) { await q(sb.auth.mfa.unenroll({ factorId })); },
      async registrarEvento(acao, entidade, id, fornecedorId, detalhes) {
        try { await sb.rpc('registrar_evento', { p_acao: acao, p_entidade: entidade || null, p_entidade_id: id || null, p_fornecedor_id: fornecedorId || null, p_detalhes: detalhes || {} }); }
        catch (e) { /* registro de acesso não bloqueia a tela */ }
      },

      // ---------- Leitura ----------
      async carregarBase() {
        const [fornecedores, contratos, conf, feriados, equipe, colaboradores, parcelas, alertas, pastas, pastaItens, pastaExec, equipes, membros, compart] = await Promise.all([
          q(sb.from('fornecedores').select('*, contatos(*)').order('nome')),
          q(sb.from('contratos').select('*').order('pedido')),
          q(sb.from('configuracoes').select('*')),
          q(sb.from('feriados').select('*').order('data')),
          q(sb.from('equipe').select('*').order('email')),
          q(sb.from('colaboradores').select('*').order('ordem').order('nome')),
          q(sb.from('vw_contratos_parcelas').select('*')).catch(() => []),
          q(sb.from('alertas_contrato').select('*')).catch(() => []),
          q(sb.from('pastas_envio').select('*').order('nome')).catch(() => []),
          Promise.resolve([]),
          q(sb.from('rotina_log').select('*').in('origem', ['pasta programada', 'envio automático']).order('executado_em', { ascending: false }).limit(300)).catch(() => []),
          q(sb.from('equipes_trabalho').select('*').order('nome')).catch(() => []),
          q(sb.from('equipe_membros').select('*')).catch(() => []),
          q(sb.from('pasta_compartilhamentos').select('*')).catch(() => [])
        ]);
        const config = {};
        conf.forEach((c) => { config[c.chave] = c.valor; });
        return { fornecedores, contratos, config, feriados, equipe, colaboradores, parcelas, alertas, pastas, pastaItens, pastaExec, equipes, membros, compart };
      },
      solicitacoes: (comp) => q(sb.from('solicitacoes').select('*').eq('competencia', comp)),
      medicoes: (comp) => q(sb.from('medicoes').select('*').eq('competencia', comp)),
      medicoesPeriodo: (ini, fim) => q(sb.from('medicoes')
        .select('id, competencia, fornecedor_id, contrato_id, valor_contratado, valor_informado, valor_lido, valor_aprovado, status')
        .gte('competencia', ini).lte('competencia', fim)),
      medicoesFornecedor: (id) => q(sb.from('medicoes').select('*').eq('fornecedor_id', id).order('competencia', { ascending: false }).limit(60)),
      documentos: (comp) => q(sb.from('documentos').select('*').eq('competencia', comp).order('created_at')),
      envios: (f) => {
        let r = sb.from('envios_email')
          .select('id, solicitacao_id, avaliacao_id, solicitacao_nf_id, medicao_id, contrato_id, fornecedor_id, competencia, tipo, via, para, assunto, corpo, prazo_ate, status, erro, autor, created_at, arquivado_em, arquivado_por')
          .order('created_at', { ascending: false }).limit((f && f.limite) || 2000);
        if (f && f.de) r = r.gte('created_at', inicioDia(f.de));
        if (f && f.ate) r = r.lt('created_at', inicioDia(U.addDias(f.ate, 1)));
        return q(r);
      },
      enviosDe: (solicitacaoId) => q(sb.from('envios_email').select('*').eq('solicitacao_id', solicitacaoId).order('created_at', { ascending: false })),
      enviosAvaliacao: (avaliacaoId) => q(sb.from('envios_email').select('*').eq('avaliacao_id', avaliacaoId).order('created_at', { ascending: false })),
      enviosCompetencia: (comp) => q(sb.from('envios_email').select('id, solicitacao_id, avaliacao_id, solicitacao_nf_id, medicao_id, contrato_id, tipo, via, para, status, erro, autor, prazo_ate, created_at, entrega_em, entrega_detalhe').eq('competencia', comp)),
      enviosContrato: (id) => q(sb.from('envios_email').select('*').eq('contrato_id', id).order('created_at', { ascending: false }).limit(20)),
      enviosMedicao: (id) => q(sb.from('envios_email').select('*').eq('medicao_id', id).order('created_at', { ascending: false }).limit(20)),
      enviosNF: (id) => q(sb.from('envios_email').select('*').eq('solicitacao_nf_id', id).order('created_at', { ascending: false })),
      solicitacoesNF: (comp) => q(sb.from('solicitacoes_nf').select('*').eq('competencia', comp).order('created_at')),
      // Sem o XML (texto grande): baixado só quando a equipe pede
      notasFiscais: (comp) => q(sb.from('notas_fiscais').select('id, solicitacao_nf_id, medicao_id, contrato_id, fornecedor_id, competencia, modelo, numero, serie, chave, '
        + 'codigo_verificacao, data_emissao, valor, cnpj_emitente, cnpj_destinatario, pedidos_xml, info, documento_id, status, validacoes, alertas, responsavel, '
        + 'observacao, conferido_por, conferido_em, motivo_recusa, created_at').eq('competencia', comp).order('created_at', { ascending: false })),
      async xmlNotaFiscal(id) { return (await q(sb.from('notas_fiscais').select('xml').eq('id', id).single())).xml; },
      avaliacoes: (comp) => q(sb.from('avaliacoes').select('*').eq('competencia', comp)),
      avaliacoesPeriodo: (ini, fim) => q(sb.from('avaliacoes')
        .select('id, fornecedor_id, competencia, supervisor_id, supervisor_nome, status, nota_geral, notas')
        .gte('competencia', ini).lte('competencia', fim).in('status', ['respondida', 'padrao'])),
      avaliacoesFornecedor: (id) => q(sb.from('avaliacoes').select('id, competencia, supervisor_nome, status, nota_geral, observacao, respondido_em')
        .eq('fornecedor_id', id).in('status', ['respondida', 'padrao']).order('competencia', { ascending: false }).limit(24)),
      historico: (f) => {
        let r = sb.from('historico').select('*').order('created_at', { ascending: false }).limit((f && f.limite) || 300);
        if (f && f.fornecedor_id) r = r.eq('fornecedor_id', f.fornecedor_id);
        if (f && f.de) r = r.gte('created_at', inicioDia(f.de));
        if (f && f.ate) r = r.lt('created_at', inicioDia(U.addDias(f.ate, 1)));
        return q(r);
      },
      rotinaLog: (f) => {
        let r = sb.from('rotina_log').select('*').order('executado_em', { ascending: false }).limit((f && f.limite) || 40);
        if (f && f.de) r = r.gte('executado_em', inicioDia(f.de));
        if (f && f.ate) r = r.lt('executado_em', inicioDia(U.addDias(f.ate, 1)));
        return q(r);
      },
      // ---------- Segurança (só administradores; o banco confere) ----------
      eventosSeguranca: (f) => {
        let r = sb.from('eventos_seguranca').select('*').order('created_at', { ascending: false }).limit((f && f.limite) || 500);
        if (f && f.de) r = r.gte('created_at', inicioDia(f.de));
        if (f && f.ate) r = r.lt('created_at', inicioDia(U.addDias(f.ate, 1)));
        if (f && f.naoVistos) r = r.is('visto_em', null).in('gravidade', ['alerta', 'critico']);
        return q(r).catch(() => []);
      },
      segurancaVerificar: () => q(sb.rpc('seguranca_verificar')),
      // Confirmação de entrega (webhook do Resend) e e-mail de teste
      webhookSituacao: () => q(sb.rpc('email_webhook_situacao')),
      definirSegredoWebhook: (s) => q(sb.rpc('definir_segredo_webhook', { p_segredo: s })),
      emailTeste: () => q(sb.rpc('email_teste')),
      emailTesteResultado: () => q(sb.rpc('email_teste_resultado')),
      marcarEventosVistos: (ids) => q(sb.rpc('seguranca_marcar_vistos', { p_ids: ids && ids.length ? ids : null })),
      // ---------- Correções e limpeza (só administrador, com motivo) ----------
      limparHistorico: (de, ate, partes, motivo) => q(sb.rpc('limpar_historico', { p_de: de, p_ate: ate, p_partes: partes, p_motivo: motivo })),
      excluirRecebimento: (id, motivo, modo) => q(sb.rpc('excluir_recebimento', { p_id: id, p_motivo: motivo, p_modo: modo })),
      excluirSolicitacao: (id, motivo) => q(sb.rpc('excluir_solicitacao', { p_id: id, p_motivo: motivo })),
      excluirEnvioEmail: (id, motivo) => q(sb.rpc('excluir_envio_email', { p_id: id, p_motivo: motivo })),
      // Arquivos dos recebimentos excluídos: o banco devolve os caminhos e o app apaga do armazenamento
      async removerArquivos(caminhos) {
        const l = (caminhos || []).filter(Boolean);
        for (let i = 0; i < l.length; i += 20) { const { error } = await sb.storage.from(BUCKET).remove(l.slice(i, i + 20)); if (error) return { ok: false, erro: traduzir(error).message }; }
        return { ok: true, removidos: l.length };
      },

      // ---------- Envio ----------
      gerarSolicitacoes: (comp, ids, pasta) => q(sb.rpc('gerar_solicitacoes', { p_competencia: comp, p_fornecedores: ids || null, p_pasta: pasta || null })),
      registrarEnvio: (id, emails, assunto, corpo, manterPrazo) => q(sb.rpc('registrar_envio', { p_id: id, p_emails: emails, p_assunto: assunto, p_corpo: corpo, p_manter_prazo: !!manterPrazo })),
      reenviar: (id, para, manterPrazo) => q(sb.rpc('reenviar_solicitacao', { p_id: id, p_para: para && para.length ? para : null, p_manter_prazo: !!manterPrazo })),
      lembretePendentes: (comp) => q(sb.rpc('lembrete_pendentes', { p_competencia: comp })),
      portalPrevia: (id) => q(sb.rpc('portal_previa', { p_id: id })),
      enviarSolicitacoes: (comp, ids) => q(sb.rpc('enviar_solicitacoes', { p_competencia: comp, p_ids: ids || null })),
      conferirEnvios: () => q(sb.rpc('conferir_envios')),
      cobrancaExecutar: () => q(sb.rpc('cobranca_executar')),
      emailConfigurado: () => q(sb.rpc('email_configurado')),
      definirChaveEmail: (chave) => q(sb.rpc('definir_chave_email', { p_chave: chave })),
      renovarLink: (id) => q(sb.rpc('renovar_link', { p_id: id })),
      cancelarSolicitacao: (id) => q(sb.rpc('cancelar_solicitacao', { p_id: id })),
      atualizarSolicitacao: async (id, patch) => (await q(sb.from('solicitacoes').update(patch).eq('id', id).select()))[0],

      // ---------- Avaliação de satisfação ----------
      gerarAvaliacoes: (comp, ids) => q(sb.rpc('gerar_avaliacoes', { p_competencia: comp, p_fornecedores: ids || null })),
      enviarAvaliacoes: (comp, ids) => q(sb.rpc('enviar_avaliacoes', { p_competencia: comp, p_ids: ids || null })),
      reenviarAvaliacao: (id, para, manterPrazo) => q(sb.rpc('reenviar_avaliacao', { p_id: id, p_para: para && para.length ? para : null, p_manter_prazo: !!manterPrazo })),
      registrarEnvioAvaliacao: (id, emails, assunto, corpo, manterPrazo) => q(sb.rpc('registrar_envio_avaliacao', { p_id: id, p_emails: emails, p_assunto: assunto, p_corpo: corpo, p_manter_prazo: !!manterPrazo })),
      renovarAvaliacao: (id) => q(sb.rpc('renovar_avaliacao', { p_id: id })),
      cancelarAvaliacao: (id) => q(sb.rpc('cancelar_avaliacao', { p_id: id })),
      aplicarRespostaPadrao: (id) => q(sb.rpc('aplicar_resposta_padrao', { p_id: id })),
      aplicarPadraoVencidas: (comp) => q(sb.rpc('aplicar_padrao_vencidas', { p_competencia: comp })),
      avaliacaoPrevia: (id) => q(sb.rpc('avaliacao_previa', { p_id: id })),
      avaliacaoAbrir: (token) => q(sb.rpc('avaliacao_abrir', { p_token: token })),
      avaliacaoResponder: (token, dados) => q(sb.rpc('avaliacao_responder', { p_token: token, p_dados: dados })),

      // ---------- Nota fiscal: folha de serviço, pedido de compra, link da NF e conferência ----------
      lancarFolha: (id, numero, data, parcela, descricao, valor) => q(sb.rpc('lancar_folha_servico', { p_medicao: id, p_numero: numero || null, p_data: data || null,
        p_parcela: parcela === null || parcela === undefined || parcela === '' ? null : Number(parcela), p_descricao: descricao || null,
        p_valor: valor === null || valor === undefined || valor === '' ? null : Number(valor) })),
      aprovarFolha: (id, anexos) => q(sb.rpc('aprovar_folha_servico', { p_medicao: id, p_anexos: anexos && anexos.length ? anexos : null })),
      desfazerAprovacaoFolha: (id) => q(sb.rpc('desfazer_aprovacao_folha', { p_medicao: id })),
      encaminharServicos: (id, anexos) => q(sb.rpc('encaminhar_servicos', { p_medicao: id, p_anexos: anexos && anexos.length ? anexos : null })),
      registrarEncaminhamentoServicos: (id, emails, assunto, corpo) => q(sb.rpc('registrar_encaminhamento_servicos', { p_medicao: id, p_emails: emails, p_assunto: assunto, p_corpo: corpo })),
      registrarEnvioFS: (id, emails, assunto, corpo) => q(sb.rpc('registrar_envio_fs', { p_medicao: id, p_emails: emails, p_assunto: assunto, p_corpo: corpo })),
      avisarVencimento: (id, somenteRegistrar, para) => q(sb.rpc('avisar_vencimento', { p_contrato: id, p_somente_registrar: !!somenteRegistrar, p_para: para && para.length ? para : null })),
      gerarSolicitacaoNF: (medicaoId) => q(sb.rpc('gerar_solicitacao_nf', { p_medicao: medicaoId })),
      enviarSolicitacaoNF: (id, anexos, para, manterPrazo) => q(sb.rpc('enviar_solicitacao_nf', { p_id: id, p_anexos: anexos && anexos.length ? anexos : null,
        p_para: para && para.length ? para : null, p_manter_prazo: !!manterPrazo })),
      registrarEnvioNF: (id, emails, assunto, corpo, anexos, manterPrazo) => q(sb.rpc('registrar_envio_nf', { p_id: id, p_emails: emails, p_assunto: assunto, p_corpo: corpo,
        p_anexos: anexos && anexos.length ? anexos : null, p_manter_prazo: !!manterPrazo })),
      renovarSolicitacaoNF: (id) => q(sb.rpc('renovar_solicitacao_nf', { p_id: id })),
      cancelarSolicitacaoNF: (id) => q(sb.rpc('cancelar_solicitacao_nf', { p_id: id })),
      conferirNF: (id, aprovar, motivo) => q(sb.rpc('conferir_nf', { p_id: id, p_aprovar: !!aprovar, p_motivo: motivo || null })),
      nfPrevia: (id) => q(sb.rpc('nf_previa', { p_id: id })),
      nfAbrir: (token) => q(sb.rpc('nf_abrir', { p_token: token })),
      nfFinalizar: (token, dados) => q(sb.rpc('nf_finalizar', { p_token: token, p_dados: dados })),
      // Página da NF: links temporários (60 dias) dos arquivos enviados, para o encaminhamento a Serviços
      async nfLinksArquivos(caminhos) {
        const out = [];
        for (const c of (caminhos || []).filter(Boolean)) {
          try { const r = await sb.storage.from(BUCKET).createSignedUrl(c, 60 * 86400); if (r && r.data && r.data.signedUrl) out.push({ caminho: c, url: r.data.signedUrl }); } catch (e) { /* segue sem o link */ }
        }
        return out;
      },
      // Links temporários do pedido de compra (vão no e-mail e na página da NF); validade = prazo do link + folga
      async linksPedidoCompra(docs, dias) {
        const seg = Math.max(1, Math.min(60, Number(dias) || 15)) * 86400;
        const out = [];
        for (const d of docs) {
          const r = await q(sb.storage.from(BUCKET).createSignedUrl(d.caminho, seg));
          out.push({ nome: d.nome_padrao || d.nome_arquivo, url: r.signedUrl });
        }
        return out;
      },

      // ---------- Colaboradores Klingele (contatos e supervisores) ----------
      async salvarColaborador(c) {
        const { id, created_at, updated_at, ...dados } = c;
        if (id) return (await q(sb.from('colaboradores').update(dados).eq('id', id).select()))[0];
        return (await q(sb.from('colaboradores').insert(dados).select()))[0];
      },
      excluirColaborador: (id) => q(sb.from('colaboradores').delete().eq('id', id)),
      definirResponsavel: (colab, papel, contratos) => q(sb.rpc('definir_responsavel', { p_colaborador: colab, p_papel: papel, p_contratos: contratos || [] })),
      // ---------- Pastas de fechamento (cada contrato em uma pasta; Envio mensal = pasta padrão) ----------
      salvarPasta: (id, dados) => q(sb.rpc('salvar_pasta', { p_id: id || null, p_dados: dados })),
      excluirPasta: (id) => q(sb.rpc('excluir_pasta', { p_id: id })),
      transferirPasta: (id, email) => q(sb.rpc('transferir_pasta', { p_id: id, p_email: email })),
      moverContratos: (ids, pasta) => q(sb.rpc('mover_contratos', { p_contratos: ids, p_pasta: pasta || null })),
      executarPasta: (id, comp) => q(sb.rpc('executar_pasta', { p_id: id, p_competencia: comp })),
      // ---------- Equipes de trabalho ----------
      salvarEquipe: (id, d) => q(sb.rpc('salvar_equipe', { p_id: id || null, p_dados: d })),
      excluirEquipe: (id) => q(sb.rpc('excluir_equipe', { p_id: id })),
      convidarEquipe: (id, emails) => q(sb.rpc('convidar_equipe', { p_equipe: id, p_emails: emails })),
      responderConvite: (id, aceitar) => q(sb.rpc('responder_convite_equipe', { p_equipe: id, p_aceitar: !!aceitar })),
      removerMembroEquipe: (id, email) => q(sb.rpc('remover_membro_equipe', { p_equipe: id, p_email: email })),

      // ---------- Cadastros ----------
      async salvarFornecedor(f) {
        const { contatos, id, created_at, updated_at, ...dados } = f;
        if (id) return (await q(sb.from('fornecedores').update(dados).eq('id', id).select()))[0];
        return (await q(sb.from('fornecedores').insert(dados).select()))[0];
      },
      excluirFornecedor: (id) => q(sb.from('fornecedores').delete().eq('id', id)),
      async salvarContato(c) {
        const { id, created_at, updated_at, ...dados } = c;
        if (id) return (await q(sb.from('contatos').update(dados).eq('id', id).select()))[0];
        return (await q(sb.from('contatos').insert(dados).select()))[0];
      },
      excluirContato: (id) => q(sb.from('contatos').delete().eq('id', id)),
      async salvarContrato(c) {
        const { id, created_at, updated_at, ...dados } = c;
        if (id) return (await q(sb.from('contratos').update(dados).eq('id', id).select()))[0];
        return (await q(sb.from('contratos').insert(dados).select()))[0];
      },
      excluirContrato: (id) => q(sb.from('contratos').delete().eq('id', id)),
      async salvarMedicao(m) {
        const campos = ['valor_aprovado', 'valor_lido', 'valor_informado', 'status', 'nota_fiscal', 'data_pagamento', 'observacao'];
        const dados = {};
        campos.forEach((k) => { if (k in m) dados[k] = m[k] === '' ? null : m[k]; });
        return (await q(sb.from('medicoes').update(dados).eq('id', m.id).select()))[0];
      },
      async incluirMedicao(contrato, comp) {
        return (await q(sb.from('medicoes').insert({
          contrato_id: contrato.id, fornecedor_id: contrato.fornecedor_id, competencia: comp, valor_contratado: contrato.valor_mensal
        }).select()))[0];
      },
      salvarConfig: (chave, valor) => q(sb.from('configuracoes').upsert({ chave, valor: String(valor), updated_at: new Date().toISOString() })),
      salvarFeriado: (f) => q(sb.from('feriados').upsert({ data: f.data, nome: f.nome })),
      excluirFeriado: (data) => q(sb.from('feriados').delete().eq('data', data)),
      salvarMembro: (m) => q(sb.from('equipe').upsert(m)),
      excluirMembro: (email) => q(sb.from('equipe').delete().eq('email', email)),
      executarRotina: () => q(sb.rpc('ping')),

      // ---------- Documentos ----------
      async urlDocumento(doc, baixar) {
        // link temporário de 1 minuto; ao baixar, o arquivo sai com o nome organizado
        const r = await q(sb.storage.from(BUCKET).createSignedUrl(doc.caminho, 60, baixar ? { download: doc.nome_padrao || doc.nome_arquivo } : undefined));
        return r.signedUrl;
      },
      async baixarDocumento(doc) { return q(sb.storage.from(BUCKET).download(doc.caminho)); },
      async anexarDocumento({ solicitacao, fornecedor, competencia, file, tipo, contrato_id, valor_lido }) {
        const pasta = solicitacao ? solicitacao.pasta : pastaDe(fornecedor, competencia);
        const ext = U.extensao(file.name);
        const base = U.nomePadrao({ competencia, fornecedor: fornecedor.nome, tipo, ext }).replace(/\.[^.]+$/, '');
        // documento da Klingele: sufixo aleatório (o fornecedor baixa pelo link e ninguém adivinha o caminho)
        const caminho = `${pasta}/equipe/${base}--${Date.now().toString(36)}${tipo === 'klingele' ? '-' + U.sufixoAleatorio() : ''}.${ext}`;
        await q(sb.storage.from(BUCKET).upload(caminho, file, { contentType: U.mimeArquivo(file.name) || file.type, upsert: false }));
        const row = (await q(sb.from('documentos').insert({
          solicitacao_id: solicitacao ? solicitacao.id : null, fornecedor_id: fornecedor.id, contrato_id: contrato_id || null,
          competencia, tipo, nome_arquivo: file.name, caminho, mime: U.mimeArquivo(file.name), tamanho: file.size,
          valor_lido: valor_lido ?? null, enviado_por: 'equipe'
        }).select()))[0];
        return row;
      },
      atualizarDocumento: async (id, patch) => (await q(sb.from('documentos').update(patch).eq('id', id).select()))[0],
      async excluirDocumento(doc) {
        await q(sb.storage.from(BUCKET).remove([doc.caminho]));
        await q(sb.from('documentos').delete().eq('id', doc.id));
      },

      // ---------- Portal do fornecedor ----------
      portalAbrir: (token) => q(sb.rpc('portal_abrir', { p_token: token })),
      // nomeBase: nome organizado sem extensão (ex.: 2026-09_SETEMBRO_FORNECEDOR_BOLETIM)
      async portalEnviarArquivo(pastaUpload, file, i, nomeBase) {
        const ext = U.extensao(file.name);
        const caminho = `${pastaUpload}/${nomeBase || 'arquivo'}--${Date.now().toString(36)}${i}.${ext}`;
        const { error } = await sb.storage.from(BUCKET).upload(caminho, file, { contentType: U.mimeArquivo(file.name) || file.type, upsert: false });
        if (error) {
          // Recusa da regra do Storage: link vencido, limite de arquivos do link ou de envios por hora
          if (/row-level security|unauthorized|403/i.test(error.message || '')) throw new Error('O servidor recusou o arquivo: o link pode ter vencido ou atingido o limite de arquivos ou de envios por hora. Aguarde alguns minutos e recarregue a página.');
          throw traduzir(error);
        }
        return caminho;
      },
      portalFinalizar: (token, dados) => q(sb.rpc('portal_finalizar', { p_token: token, p_dados: dados })),
      // Documento da Klingele no link (fornecedor ou colaborador, sem login): link temporário de 5 minutos para baixar
      async urlDocPortal(doc) {
        const r = await q(sb.storage.from(BUCKET).createSignedUrl(doc.caminho, 300, { download: doc.nome || doc.nome_arquivo || true }));
        return r.signedUrl;
      },

      // ---------- Documentos da Klingele: página do colaborador e envio dispensado no mês ----------
      docsPrevia: (id) => q(sb.rpc('docs_previa', { p_id: id })),
      docsAbrir: (token) => q(sb.rpc('docs_abrir', { p_token: token })),
      docsFinalizar: (token, dados) => q(sb.rpc('docs_finalizar', { p_token: token, p_dados: dados })),
      async docsEnviarArquivo(pastaUpload, file, i) {
        const ext = U.extensao(file.name);
        const base = (U.slug ? U.slug(file.name.replace(/\.[^.]+$/, '')) : 'documento').slice(0, 60) || 'documento';
        const caminho = `${pastaUpload}/${base}--${Date.now().toString(36)}${i}.${ext}`;
        const { error } = await sb.storage.from(BUCKET).upload(caminho, file, { contentType: U.mimeArquivo(file.name) || file.type, upsert: false });
        if (error) {
          if (/row-level security|unauthorized|403/i.test(error.message || '')) throw new Error('O servidor recusou o arquivo: o link pode ter vencido ou atingido o limite de 15 arquivos. Recarregue a página.');
          throw traduzir(error);
        }
        return caminho;
      },
      dispensarEnvio: (id, motivo, obs, forn, comp, pasta) => q(sb.rpc('dispensar_envio', { p_id: id || null, p_motivo: motivo, p_obs: obs || null,
        p_fornecedor: forn || null, p_competencia: comp || null, p_pasta: pasta || null })),
      reativarEnvio: (id) => q(sb.rpc('reativar_envio', { p_id: id })),
      pedirDocsKlingele: (id) => q(sb.rpc('pedir_docs_klingele', { p_id: id }))
    };
    return api;
  }

  // =====================================================================
  //  DEMONSTRAÇÃO (sem servidor)
  // =====================================================================
  function criarDemo() {
    const CHAVE = 'klg-boletins-demo-v17';
    const arquivos = {}; // caminho -> File (somente nesta aba)
    let db = null;

    const agora = () => new Date().toISOString();
    const feriadosSet = () => U.calendario(db.feriados);
    const colab = (id) => db.colaboradores.find((c) => c.id === id);
    // Contato Klingele do usuário (admin, supervisor ou analista): liga ao contato com o mesmo e-mail ou cria; bloqueado = inativo
    function ligarColaboradorDemo(u, sincronizar, semLog) {
      if (u.status === 'aprovado' && ['admin', 'supervisor', 'analista'].includes(u.papel)) {
        let c = u.colaborador_id && colab(u.colaborador_id);
        if (!c) { c = db.colaboradores.find((x) => (x.email || '').toLowerCase() === u.email.toLowerCase()); sincronizar = false; }
        if (!c) {
          c = { id: uuid(), nome: u.nome, cargo: u.cargo || null, email: u.email.toLowerCase(), telefone: u.telefone || null, contato_fornecedor: false,
            supervisor: u.papel === 'supervisor', ativo: true, ordem: 100, created_at: agora(), updated_at: agora() };
          db.colaboradores.push(c);
          if (!semLog) log('colaboradores', c.id, null, 'cadastro', { nome: c.nome, email: c.email, supervisor: c.supervisor });
        } else {
          if (sincronizar) { c.nome = u.nome; if (u.cargo) c.cargo = u.cargo; if (u.telefone) c.telefone = u.telefone; }
          else { c.cargo = c.cargo || u.cargo || null; c.telefone = c.telefone || u.telefone || null; }
          c.email = c.email || u.email.toLowerCase(); c.supervisor = c.supervisor || u.papel === 'supervisor'; c.ativo = true;
          db.contratos.forEach((k) => { if (k.supervisor_id === c.id) k.gestor = c.nome; });
        }
        u.colaborador_id = c.id;
      } else if (u.status === 'bloqueado' && u.colaborador_id && colab(u.colaborador_id)) colab(u.colaborador_id).ativo = false;
    }
    // Contatos Klingele mostrados ao fornecedor (até 5, na ordem cadastrada)
    const contatosDemo = () => db.colaboradores.filter((c) => c.ativo && c.contato_fornecedor && (c.email || c.telefone))
      .sort((a, b) => (a.ordem || 0) - (b.ordem || 0) || a.nome.localeCompare(b.nome)).slice(0, 5)
      .map((c) => ({ nome: c.nome, cargo: c.cargo || null, email: c.email || null, telefone: c.telefone || null }));
    const suporteDemo = () => contatosDemo().filter((c) => c.email).map((c) => c.email);
    // Contatos Klingele de cada contrato (suporte ao fornecedor); contrato sem contato usa os gerais (igual ao banco)
    const pubContato = (x) => ({ nome: x.nome, cargo: x.cargo || null, email: x.email || null, telefone: x.telefone || null });
    const contatosProprios = (c) => ((c && c.contatos) || []).map(colab).filter((x) => x && x.ativo && (x.email || x.telefone)).slice(0, 5).map(pubContato);
    const contatosContrato = (c) => { const p = contatosProprios(c); return p.length ? p : contatosDemo(); };
    // Pedidos de um link: as medições ligadas a ele (um fornecedor pode ter um link por pasta no mesmo mês)
    const contratosDoLink = (s) => db.medicoes.filter((m) => m.solicitacao_id === s.id)
      .map((m) => db.contratos.find((c) => c.id === m.contrato_id)).filter(Boolean).sort((a, b) => (a.pedido || 0) - (b.pedido || 0));
    const servicosSuporte = (cs) => cs.filter(Boolean).map((c) => ({ titulo: c.titulo, pedido: c.pedido, contatos: contatosProprios(c) }));
    const contatosDe = (cs) => {
      if (!cs.length) return contatosDemo();
      const v = [];
      cs.forEach((c) => contatosContrato(c).forEach((x) => { if (!v.some((y) => JSON.stringify(y) === JSON.stringify(x))) v.push(x); }));
      return v.slice(0, 8);
    };
    const emailsDe = (cs) => { const e = [...new Set(contatosDe(cs).filter((x) => x.email).map((x) => x.email.toLowerCase()))]; return e.length ? e : suporteDemo(); };
    const contatosServicos = (cs) => cs.map((c) => ({ pedido: c.pedido, titulo: c.titulo, tipo: c.tipo_servico || null, contatos: contatosContrato(c) }));
    // Pastas de fechamento (mesmas regras do banco): cada contrato em uma pasta (pasta_id; sem pasta = avulso)
    const colabNaEquipeDemo = (colabId, eqs) => { const co = db.colaboradores.find((c) => c.id === colabId); const e = co && (co.email || '').toLowerCase();
      return !!e && (db.equipe_membros || []).some((m) => m.email === e && m.status === 'ativo' && eqs.includes(m.equipe_id)); };
    const ctxRegra = () => ({ forn: (id) => db.fornecedores.find((f) => f.id === id), colabNaEquipe: colabNaEquipeDemo, naLista: () => true });
    const padraoDemo = () => (db.pastas_envio || []).find((p) => p.padrao) || null;
    const pastaD = (id) => (db.pastas_envio || []).find((p) => p.id === id) || null;
    const pastaParaContratoDemo = (c) => U.pastaParaContrato(c, db.pastas_envio, db.fornecedores.find((f) => f.id === c.fornecedor_id), ctxRegra());
    const prazoLinkDemo = (pid) => { const p = pastaD(pid); return Number((p && p.prazo_dias) || conf('prazo_dias_uteis', 7)) || 7; };
    const linkAtivo = (id) => { const s = db.solicitacoes.find((x) => x.id === id); return !!s && !['expirado', 'cancelado'].includes(s.status); };
    // contrato já está em outro link ativo (de outra pasta) no mês
    const emOutroLink = (cid, comp, pid) => db.medicoes.some((m) => m.contrato_id === cid && m.competencia === comp && m.solicitacao_id && linkAtivo(m.solicitacao_id)
      && ((db.solicitacoes.find((s) => s.id === m.solicitacao_id) || {}).pasta_envio_id || null) !== (pid || null));
    const contratosPastaComp = (pid, comp, fid) => db.contratos.filter((c) => (c.pasta_id || null) === (pid || null) && (!fid || c.fornecedor_id === fid)
      && ((db.fornecedores.find((f) => f.id === c.fornecedor_id) || {}).ativo) && U.vigenteNoMes(c, comp));
    const idsEnvioPastaDemo = (pid, comp) => (!pid ? [] : db.fornecedores.filter((f) => f.ativo && db.contratos.some((c) => c.fornecedor_id === f.id
      && c.situacao === 'ativo' && c.pasta_id === pid && (f.deseja_enviar || U.vigenteNoMes(c, comp)))).sort((a, b) => a.nome.localeCompare(b.nome)).map((f) => f.id));
    const supsDe = (c) => (c.supervisores && c.supervisores.length ? c.supervisores : c.supervisor_id ? [c.supervisor_id] : []);
    const conf = (k, p) => (db.config[k] !== undefined ? db.config[k] : p);
    const salvar = () => U.storage.set(CHAVE, db);
    const clone = (o) => JSON.parse(JSON.stringify(o));
    const log = (entidade, entidade_id, fornecedor_id, acao, detalhes, autor, quando) => {
      db.historico.unshift({ id: db.seq++, entidade, entidade_id, fornecedor_id, acao, detalhes: detalhes || {}, autor: autor || 'demonstração', created_at: quando || agora() });
    };
    const forn = (id) => db.fornecedores.find((f) => f.id === id);
    // Fornecedor repetido: CNPJ igual ou mesmo nome sem CNPJ que diferencie (mesma regra do banco)
    function fornecedorRepetidoDemo(d) {
      const ant = d.id ? forn(d.id) : null, cn = U.cnpjNorm(d.cnpj), nn = U.normNome(d.nome);
      if (cn && (!ant || U.cnpjNorm(ant.cnpj) !== cn)) {
        const o = db.fornecedores.find((x) => x.id !== d.id && x.cnpj && U.cnpjNorm(x.cnpj) === cn);
        if (o) throw new Error(`Já existe o fornecedor ${o.nome} (cód. ${o.codigo || '—'}) com este CNPJ`);
      }
      if (nn && (!ant || U.normNome(ant.nome) !== nn || (ant.cnpj || '') !== (d.cnpj || ''))) {
        const o = db.fornecedores.find((x) => x.id !== d.id && U.normNome(x.nome) === nn && (!x.cnpj || !cn || U.cnpjNorm(x.cnpj) === cn));
        if (o) throw new Error(`Já existe o fornecedor ${o.nome} (cód. ${o.codigo || '—'}) com o mesmo nome. Se for outra unidade, informe o CNPJ dela (e o da existente).`);
      }
    }
    function duplicadosDemo() {
      const grupos = [], por = (lista, chave) => { const m = {}; lista.forEach((x) => { const k = chave(x); if (k) (m[k] = m[k] || []).push(x); }); return Object.values(m).filter((g) => g.length > 1); };
      por(db.fornecedores.filter((f) => f.cnpj), (f) => U.cnpjNorm(f.cnpj)).forEach((g) => grupos.push({ tipo: 'Fornecedores com o mesmo CNPJ', gravidade: 'alerta', chave: U.cnpj(g[0].cnpj), itens: g.map((f) => ({ id: f.id, nome: f.nome, codigo: f.codigo })) }));
      por(db.fornecedores, (f) => U.normNome(f.nome)).filter((g) => g.some((f) => !f.cnpj) && new Set(g.map((f) => U.cnpjNorm(f.cnpj)).filter(Boolean)).size < g.length)
        .forEach((g) => grupos.push({ tipo: 'Fornecedores com o mesmo nome (sem CNPJ que os diferencie)', gravidade: 'alerta', chave: g[0].nome, itens: g.map((f) => ({ id: f.id, nome: f.nome, codigo: f.codigo, cnpj: f.cnpj })) }));
      por(db.contatos, (c) => c.email && c.fornecedor_id + '|' + c.email.toLowerCase()).forEach((g) => grupos.push({ tipo: 'E-mail repetido nos contatos do fornecedor', gravidade: 'alerta', chave: ((forn(g[0].fornecedor_id) || {}).nome || '') + ' · ' + g[0].email.toLowerCase(), itens: g.map((c) => ({ id: c.id, nome: c.nome, email: c.email })) }));
      por(db.colaboradores, (c) => U.normNome(c.nome)).forEach((g) => grupos.push({ tipo: 'Contatos Klingele com o mesmo nome', gravidade: 'info', chave: g[0].nome, itens: g.map((c) => ({ id: c.id, nome: c.nome, email: c.email, ativo: c.ativo })) }));
      return grupos;
    }
    // Verificação de segurança (demonstração): o que depende do banco aparece como no site publicado recém-instalado
    function verificarDemo() {
      const it = (id, titulo, situacao, detalhe) => ({ id, titulo, situacao, detalhe });
      const dup = duplicadosDemo(), nDupA = dup.filter((g) => g.gravidade === 'alerta').length;
      const admins = db.usuarios.filter((u) => u.status === 'aprovado' && u.papel === 'admin');
      const ev24 = (db.eventos_seguranca || []).filter((e) => new Date(e.created_at) > new Date(Date.now() - 864e5));
      const nCrit = ev24.filter((e) => e.gravidade === 'critico').length, nAl = ev24.filter((e) => e.gravidade === 'alerta').length;
      const doms = String(conf('cadastro_dominios', '')).trim();
      const itens = [
        it('rls', 'Proteção por linha (RLS) em todas as tabelas', 'ok', 'Ligada nas 27 tabelas do app.'),
        it('anon_tabelas', 'Chave pública (sem login) sem acesso às tabelas', 'ok', 'Quem não entrou só usa as funções dos links (com prazo e limite).'),
        it('anon_funcoes', 'Funções liberadas sem login: só as dos links, do cadastro e do login', 'ok', '14 funções, todas com limite de tentativas (o aviso do Resend também confere a assinatura).'),
        it('gravacao_direta', 'Histórico, envios, usuários e pastas só mudam pelo app (com conferência)', 'ok', 'Gravação direta fechada; o histórico não pode ser apagado nem reescrito.'),
        it('politicas', 'Regras de acesso só para a equipe logada', 'ok', 'Nenhuma regra libera dados sem login.'),
        it('search_path', 'Funções privilegiadas com caminho de busca fixo', 'ok', 'Todas fixam o search_path.'),
        it('arquivos', 'Pasta de arquivos privada', 'ok', 'Arquivos só abrem com login ou pelo link do fornecedor, enquanto ele vale.'),
        it('limite_api', 'Limite de requisições na API', 'ok', '240/min por pessoa da equipe; 60/min e 600/h por IP nos links; teto geral.'),
        conf('exigir_mfa', 'false') === 'true' ? it('mfa', 'Verificação em duas etapas exigida', 'ok', 'Quem não ativou não vê os dados.')
          : it('mfa', 'Verificação em duas etapas', 'alerta', 'Não é exigida. Recomendado ativar (Configurações > Segurança) depois de cada administrador ativar a sua.'),
        it('senha_padrao', 'Nenhuma conta com a senha padrão da instalação', 'ok', 'A senha inicial já foi trocada.'),
        conf('cadastro_aberto', 'true') === 'true' && !doms ? it('cadastro', 'Cadastro pelo site limitado aos e-mails da empresa', 'alerta', 'Qualquer e-mail pode pedir conta (a aprovação continua obrigatória). Limite aos domínios da Klingele em Configurações > Cadastro.')
          : it('cadastro', 'Cadastro pelo site limitado aos e-mails da empresa', 'ok', conf('cadastro_aberto', 'true') === 'true' ? 'Só ' + doms : 'Cadastro fechado.'),
        it('admins', 'Administradores', admins.length >= 2 ? 'ok' : 'info', `${admins.length} administrador(es) aprovado(s)${admins.length < 2 ? '. Tenha pelo menos 2, para não perder o acesso se um sair.' : '.'}`),
        it('segredos', 'Nenhuma chave secreta gravada nas configurações', 'ok', 'A chave do e-mail fica no Vault do Supabase.'),
        it('duplicados', 'Cadastros sem repetição', nDupA ? 'alerta' : dup.length ? 'info' : 'ok', dup.length ? `${dup.length} grupo(s) para conferir${nDupA ? `, ${nDupA} a corrigir` : ''} (lista abaixo).` : 'Nenhum fornecedor, contato ou e-mail repetido.'),
        it('eventos', 'Tentativas bloqueadas nas últimas 24 horas', nCrit ? 'critico' : nAl ? 'alerta' : 'ok', nCrit + nAl ? `${nCrit + nAl} registro(s): veja Histórico > Segurança.` : 'Nenhuma.')
      ];
      const resumo = { critico: 0, alerta: 0, ok: 0, info: 0 }; itens.forEach((i) => { resumo[i.situacao]++; });
      return { verificado_em: agora(), itens, duplicados: dup, resumo, demonstracao: true };
    }
    const cfgLista = (k) => String(conf(k, '')).split(',').map((x) => x.trim().toLowerCase()).filter(Boolean);

    const FERIADOS = [
      ['2026-01-01', 'Confraternização Universal'], ['2026-02-16', 'Carnaval'], ['2026-02-17', 'Carnaval'], ['2026-04-03', 'Sexta-feira Santa'],
      ['2026-04-21', 'Tiradentes'], ['2026-05-01', 'Dia do Trabalho'], ['2026-06-04', 'Corpus Christi'], ['2026-09-07', 'Independência'],
      ['2026-10-12', 'Nossa Senhora Aparecida'], ['2026-11-02', 'Finados'], ['2026-11-15', 'Proclamação da República'],
      ['2026-11-20', 'Consciência Negra'], ['2026-12-25', 'Natal'], ['2027-01-01', 'Confraternização Universal'], ['2027-02-08', 'Carnaval'],
      ['2027-02-09', 'Carnaval'], ['2027-03-26', 'Sexta-feira Santa'], ['2027-04-21', 'Tiradentes'], ['2027-05-01', 'Dia do Trabalho'],
      ['2027-05-27', 'Corpus Christi'], ['2027-09-07', 'Independência'], ['2027-10-12', 'Nossa Senhora Aparecida'], ['2027-11-02', 'Finados'],
      ['2027-11-15', 'Proclamação da República'], ['2027-11-20', 'Consciência Negra'], ['2027-12-25', 'Natal']
    ];
    const MODELO_ASSUNTO = 'BOLETIM DE MEDIÇÃO {FORNECEDOR}/{MES} {ANO} - CONTRATO DE SERVIÇO KLINGELE';
    const MODELO_CORPO = 'Olá, bom dia!\n\nGostaria de solicitar, por gentileza, o envio do boletim de medição referente ao mês anterior de {MES}/{ANO}.\n\nServiços Realizados:\n{SERVICOS}\n\nPara enviar os documentos (boletim de medição, RDO, pré-NF, folha de ponto e outros, em PDF, Excel, JPG ou PNG) e confirmar os contatos de e-mail, acesse o link abaixo:\n{LINK}\n\nO link é de uso único e vale por {PRAZO_DIAS} dias úteis (até {PRAZO_DATA}). Depois do envio, ele deixa de funcionar.\n\nProblemas com o link ou o código? Fale com: {SUPORTE}\n\nAtenciosamente,\nKlingele Paper & Packing';
    const MODELO_AVAL_ASSUNTO = 'AVALIAÇÃO DE SERVIÇO {FORNECEDOR}/{MES} {ANO} - KLINGELE';
    const MODELO_AVAL_CORPO = 'Olá, {SUPERVISOR}!\n\nPedimos, por gentileza, sua avaliação do serviço prestado por {FORNECEDOR} em {MES}/{ANO}.\n\nPedidos:\n{SERVICOS}\n\nSão 9 itens com nota de 1 a 10: Know how, Organização e limpeza, Saúde e segurança, Iniciativa, Cumprimento de prazos, Planejamento, Supervisão, Condição dos equipamentos e Qualidade final. A nota geral é a média dos itens.\n\nResponda pelo link abaixo (uso único, válido até {PRAZO_DATA}):\n{LINK}\n\nSem resposta no prazo, a equipe de contratos poderá registrar a resposta padrão com a sua aprovação.\n\nAtenciosamente,\nKlingele Paper & Packing';
    const MODELO_NF_ASSUNTO = 'FOLHA DE SERVIÇO E NOTA FISCAL {FORNECEDOR} - PEDIDO {PEDIDO} - {MES}/{ANO} - KLINGELE';
    const MODELO_NF_CORPO = 'Olá, bom dia!\n\nSegue a folha de serviço referente à medição de {MES}/{ANO}. Pedimos, por gentileza, a emissão da nota fiscal com os dados abaixo.\n\nFolha de serviço: {FOLHA}\nPedido de compra: {PEDIDO}\nServiço: {SERVICO}\nParcela: {PARCELA}\nValor da nota: {VALOR}\nEmitir para o CNPJ: {CNPJ_KLINGELE}\n\nDescrição para a nota:\n{DESCRICAO}\n\nArquivos em anexo: {ANEXOS}\n\nInforme o número do pedido {PEDIDO} nas informações complementares da nota.\n\nEnvie a nota pelo link abaixo. É possível anexar mais de um arquivo (nota em PDF, XML, fatura ou recibo). O link é de uso único e vale por {PRAZO_DIAS} dias úteis (até {PRAZO_DATA}):\n{LINK}\n\nProblemas com o link? Fale com: {SUPORTE}\n\nAtenciosamente,\nKlingele Paper & Packing';
    const CNPJ_KLINGELE_DEMO = '61.064.929/0001-79';
    const MODELO_FS_ASSUNTO = 'NOTA FISCAL {NF_NUMERO} - {FORNECEDOR} - PEDIDO {PEDIDO} - {MES}/{ANO}';
    const MODELO_FS_CORPO = 'Olá!\n\nSegue a nota fiscal do serviço abaixo. A folha de serviço foi aprovada e o processo do mês está finalizado.\n\nFornecedor: {FORNECEDOR}\nPedido: {PEDIDO}\nServiço: {SERVICO}\nCompetência: {MES}/{ANO}\nParcela: {PARCELA}\n\nF.S.: {FOLHA}\nValor da F.S.: {VALOR}\nF.S. aprovada por: {APROVADO_POR}\n\nNota fiscal: {NF_TIPO} nº {NF_NUMERO}\nEmissão: {NF_EMISSAO}\nValor da nota: {NF_VALOR}\n\nArquivos em anexo: {ANEXOS}\n\nBMK · Boletim Mensal · Klingele Paper & Packing';
    const MODELO_VENC_ASSUNTO = 'AVISO DE VENCIMENTO - CONTRATO {PEDIDO} {FORNECEDOR} - {DATA_FIM}';
    const MODELO_VENC_CORPO = 'Olá, {SUPERVISOR}!\n\nO contrato abaixo vence em {DIAS} dias ({DATA_FIM}).\n\nFornecedor: {FORNECEDOR}\nPedido: {PEDIDO}\nServiço: {SERVICO}\nVigência: {DATA_INICIO} a {DATA_FIM}\n\nVerifique a renovação, um novo pedido ou o encerramento.\n\nBMK · Boletim Mensal · Klingele Paper & Packing';
    const PADRAO_DEMO = { know_how: 8, org_limpeza: 8, saude_seguranca: 8, iniciativa: 8, cumprimento_prazos: 8, planejamento: 8, supervisao: 8, cond_equipamento: 8, qualidade_final: 8 };

    // Nome organizado do documento (mesma regra do banco: o 2º do mesmo tipo no mês ganha _2)
    function nomeDoc(d) {
      const f = forn(d.fornecedor_id);
      const ext = U.extensao(d.caminho || d.nome_arquivo);
      let n = 1, nome;
      do {
        nome = U.nomePadrao({ competencia: d.competencia, fornecedor: f ? f.nome : '', tipo: d.tipo, ext, seq: n });
        n++;
      } while (n < 200 && db.documentos.some((x) => x !== d && x.id !== d.id && x.fornecedor_id === d.fornecedor_id && x.competencia === d.competencia && x.nome_padrao === nome));
      return nome;
    }

    // ---------- Avaliações (mesmas regras do banco) ----------
    function gerarAval(comp, ids, quando) {
      const fim = U.fimMes(comp);
      const prazo = Number(conf('avaliacao_prazo_dias_uteis', 7));
      const grupos = {};
      db.contratos.slice().sort((a, b) => a.pedido - b.pedido).forEach((c) => {
        const f = forn(c.fornecedor_id);
        if (!f || !f.ativo || (ids && !ids.includes(f.id))) return;
        const meds = db.medicoes.filter((m) => m.contrato_id === c.id && m.competencia === comp);
        const vale = meds.some((m) => m.status !== 'sem_medicao') || (!meds.length && c.situacao === 'ativo' && (!!U.modalidade(f, db.contratos, comp, db.config) || !!ids)
          && (!c.data_inicio || c.data_inicio <= fim) && (!c.data_fim || c.data_fim >= comp));
        if (!vale) return;
        supsDe(c).forEach((sid) => {
          const co = colab(sid);
          if (!co || !co.ativo || !co.supervisor) return;
          const k = f.id + '|' + co.id;
          (grupos[k] = grupos[k] || { f, co, contratos: [] }).contratos.push(c.id);
        });
      });
      let n = 0;
      Object.values(grupos).forEach((g) => {
        if (db.avaliacoes.some((a) => a.fornecedor_id === g.f.id && a.competencia === comp && a.supervisor_id === g.co.id && a.status !== 'cancelada')) return;
        const a = { id: uuid(), fornecedor_id: g.f.id, competencia: comp, supervisor_id: g.co.id, supervisor_nome: g.co.nome, supervisor_email: g.co.email || null,
          contratos: g.contratos, token: token64(), status: 'gerada', notas: null, nota_geral: null, observacao: null, respondido_por: null, respondido_em: null,
          padrao_aplicado_por: null, emails_destino: [], assunto: null, corpo: null, enviado_em: null, aberto_em: null,
          expira_em: U.fimPrazoISO(quando || agora(), prazo, feriadosSet()), envio_via: null, envio_status: null, envio_erro: null,
          criado_por: 'demonstração', created_at: quando || agora() };
        db.avaliacoes.push(a); n++;
        log('avaliacoes', a.id, g.f.id, 'avaliação gerada', { competencia: U.compCurta(comp), supervisor: g.co.nome }, null, quando);
      });
      return n;
    }
    function emailAval(a, prazoISO) {
      const f = forn(a.fornecedor_id);
      return U.montarEmailAvaliacao({ modeloAssunto: conf('modelo_aval_assunto', ''), modeloCorpo: conf('modelo_aval_corpo', ''), supervisor: a.supervisor_nome,
        fornecedor: f.nome, competencia: a.competencia, servicos: a.contratos.map((id) => db.contratos.find((c) => c.id === id)).filter(Boolean),
        link: (conf('site_url', '') || 'https://seu-site.netlify.app').replace(/\/$/, '') + '/avaliacao.html#' + a.token, prazoISO,
        prazoDias: Number(conf('avaliacao_prazo_dias_uteis', 7)) });
    }
    function registrarEnvioAval(a, via, para, assunto, corpo, manter, quando) {
      const ja = !!a.enviado_em || db.envios_email.some((e) => e.avaliacao_id === a.id);
      const lembrete = manter && ja;
      if (!lembrete) a.expira_em = U.fimPrazoISO(quando || agora(), Number(conf('avaliacao_prazo_dias_uteis', 7)), feriadosSet());
      const tipo = lembrete ? 'lembrete' : ja ? 'reenvio' : 'envio';
      if (!assunto) { const m = emailAval(a, a.expira_em); assunto = (lembrete ? 'LEMBRETE - ' : '') + m.assunto; corpo = m.corpo; }
      Object.assign(a, { enviado_em: quando || agora(), emails_destino: para, assunto, corpo, envio_via: via, envio_status: via === 'outlook' ? null : 'ok', envio_erro: null,
        status: a.status === 'gerada' ? 'enviada' : a.status });
      db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: a.id, fornecedor_id: a.fornecedor_id, competencia: a.competencia, tipo, via, para: para.slice(),
        assunto, corpo, prazo_ate: a.expira_em, status: via === 'outlook' ? 'registrado' : 'aceito', erro: null, autor: 'demonstração', created_at: quando || agora() });
      log('avaliacoes', a.id, a.fornecedor_id, via === 'outlook' ? { envio: 'avaliação enviada (Outlook)', reenvio: 'avaliação reenviada (Outlook)', lembrete: 'lembrete de avaliação (Outlook)' }[tipo]
        : via === 'automatico' ? 'avaliação enviada automaticamente' : { envio: 'avaliação enviada ao supervisor', reenvio: 'avaliação reenviada', lembrete: 'lembrete de avaliação enviado' }[tipo],
        { para, supervisor: a.supervisor_nome }, null, quando);
      return { ok: true, tipo, expira_em: a.expira_em };
    }
    function enviarAvalDemo(a, via, paraEscolhido, manter, quando) {
      if (!['gerada', 'enviada', 'aberta'].includes(a.status) || a.expira_em < (quando || agora())) return { ok: false, motivo: 'status' };
      const co = colab(a.supervisor_id);
      const para = paraEscolhido ? [...new Set(paraEscolhido.map((e) => e.trim().toLowerCase()))] : co && co.email ? [co.email] : a.supervisor_email ? [a.supervisor_email] : [];
      if (!para.length) { a.envio_status = 'falha'; a.envio_erro = 'Supervisor sem e-mail cadastrado'; return { ok: false, motivo: 'sem_email' }; }
      return registrarEnvioAval(a, via, para, null, null, manter, quando);
    }
    function dadosAvaliacao(a) {
      const f = forn(a.fornecedor_id);
      return {
        ok: true, competencia: a.competencia, mes: U.mesNome(a.competencia), ano: Number(a.competencia.slice(0, 4)), expira_em: a.expira_em,
        supervisor: a.supervisor_nome, fornecedor: { nome: f.nome, codigo: f.codigo },
        contratos: a.contratos.map((id) => db.contratos.find((c) => c.id === id)).filter(Boolean).map((c) => ({ pedido: c.pedido, titulo: c.titulo, tipo_servico: c.tipo_servico || null })),
        categorias: U.CATEGORIAS.map((c) => c[0]),
        feriados: db.feriados.map((x) => x.data).filter((x) => x >= U.hojeISO() && x <= U.dataLocal(a.expira_em)),
        contatos_klingele: contatosDemo()
      };
    }
    function aplicarPadrao(a, quando) {
      const p = JSON.parse(conf('avaliacao_padrao', '') || 'null');
      if (!U.notasCompletas(p)) throw new Error('Defina a resposta padrão em Configurações > Avaliação de satisfação');
      if (!['gerada', 'enviada', 'aberta', 'expirada'].includes(a.status)) throw new Error('Só é possível aplicar a resposta padrão em avaliações ainda não respondidas');
      Object.assign(a, { status: 'padrao', notas: { ...p }, nota_geral: U.mediaNotas(p), observacao: 'Resposta aprovada pelo supervisor ' + a.supervisor_nome,
        respondido_por: 'Resposta padrão', respondido_em: quando || agora(), padrao_aplicado_por: 'demonstração' });
      log('avaliacoes', a.id, a.fornecedor_id, 'resposta padrão aplicada', { competencia: U.compCurta(a.competencia), supervisor: a.supervisor_nome, nota_geral: a.nota_geral }, null, quando);
    }

    // Gera os links (igual a _gerar_solicitacoes): pasta informada = contratos da pasta; sem pasta e sem lista = Envio mensal;
    // lista de fornecedores sem pasta = link avulso (contratos sem pasta)
    function gerar(comp, ids, quando, pastaId) {
      let pid = pastaId || null;
      if (!pid && !ids) { const pad = padraoDemo(); if (!pad) return []; pid = pad.id; }
      const prazo = prazoLinkDemo(pid), nomeP = (pastaD(pid) || {}).nome || 'avulso';
      const out = [];
      const alvo = ids || idsEnvioPastaDemo(pid, comp);
      db.fornecedores.filter((f) => f.ativo && alvo.includes(f.id)).sort((a, b) => a.nome.localeCompare(b.nome)).forEach((f) => {
        let sel = contratosPastaComp(pid, comp, f.id).filter((c) => !emOutroLink(c.id, comp, pid));
        if (!sel.length) {
          sel = db.contratos.filter((c) => c.fornecedor_id === f.id && c.situacao === 'ativo' && (c.pasta_id || null) === pid && (ids || f.deseja_enviar) && !emOutroLink(c.id, comp, pid))
            .sort((a, b) => String(b.data_fim || '').localeCompare(String(a.data_fim || ''))).slice(0, 1);
        }
        if (!sel.length) return;
        // envio dispensado no mês: a pasta não gera outro link sozinha
        if (!ids && db.solicitacoes.some((x) => x.fornecedor_id === f.id && x.competencia === comp && (x.pasta_envio_id || null) === pid && x.dispensa)) return;
        let s = db.solicitacoes.find((x) => x.fornecedor_id === f.id && x.competencia === comp && (x.pasta_envio_id || null) === pid && !['expirado', 'cancelado'].includes(x.status));
        if (!s) {
          s = {
            id: uuid(), fornecedor_id: f.id, competencia: comp, pasta_envio_id: pid, token: token64(), status: 'gerado', pasta: pastaDe(f, comp),
            emails_destino: db.contatos.filter((c) => c.fornecedor_id === f.id && c.recebe_boletim).sort((a, b) => b.principal - a.principal).map((c) => c.email),
            assunto: null, corpo: null, gerado_em: quando || agora(), enviado_em: null, aberto_em: null,
            expira_em: U.fimPrazoISO(quando || agora(), prazo, feriadosSet()), recebido_em: null, conferido_em: null,
            respondido_por: null, observacao_fornecedor: null, criado_por: 'demonstração', created_at: quando || agora()
          };
          db.solicitacoes.push(s);
          log('solicitacoes', s.id, f.id, 'link gerado', { competencia: U.compCurta(comp), pasta: nomeP }, null, quando);
          // link vencido/cancelado refeito: os documentos da Klingele continuam valendo no link novo
          const velhos = db.solicitacoes.filter((o) => o.id !== s.id && o.fornecedor_id === f.id && o.competencia === comp && (o.pasta_envio_id || null) === pid
            && ['expirado', 'cancelado'].includes(o.status) && !o.dispensa).map((o) => o.id);
          db.documentos.forEach((d) => { if (d.tipo === 'klingele' && velhos.includes(d.solicitacao_id)) d.solicitacao_id = s.id; });
        }
        sel.forEach((c) => {
          let m = db.medicoes.find((x) => x.contrato_id === c.id && x.competencia === comp);
          if (!m) {
            m = { id: uuid(), contrato_id: c.id, fornecedor_id: f.id, competencia: comp, solicitacao_id: s.id, valor_contratado: c.valor_mensal,
              valor_informado: null, valor_lido: null, valor_aprovado: null, status: 'aguardando', nota_fiscal: null, data_pagamento: null,
              observacao: null, created_at: agora(), updated_at: agora() };
            db.medicoes.push(m);
          } else if (!m.solicitacao_id || m.solicitacao_id === s.id || !linkAtivo(m.solicitacao_id)) m.solicitacao_id = s.id;
        });
        out.push(s);
      });
      return out;
    }
    // ---------- Documentos da Klingele (demonstração) ----------
    const docsKlgDemo = (s) => db.documentos.filter((d) => d.solicitacao_id === s.id && d.tipo === 'klingele');
    const aguardaDocsDemo = (s) => !!(forn(s.fornecedor_id) || {}).docs_klingele && !docsKlgDemo(s).length;
    const docsLinkOk = (s) => !s.dispensa && (s.status === 'gerado' || (['enviado', 'aberto'].includes(s.status) && s.expira_em > agora()));
    function colabDocsDemo(f) {
      const c = db.colaboradores.find((x) => x.id === f.docs_colaborador_id && x.ativo && x.email);
      return c || db.colaboradores.find((x) => x.ativo && x.email && f.docs_analista && x.email.toLowerCase() === f.docs_analista.toLowerCase()) || null;
    }
    function pedirDocsDemo(links, autor, quando) {
      links.filter(docsLinkOk).forEach((s) => {
        if (!s.docs_token) s.docs_token = token64();
        const f = forn(s.fornecedor_id), c = colabDocsDemo(f);
        s.docs_pedido_em = quando || agora();
        log('solicitacoes', s.id, f.id, 'documentos pedidos ao colaborador', { competencia: U.compCurta(s.competencia), para: c ? c.email : (f.docs_analista || 'analistas') }, autor, quando);
      });
    }
    function situacaoDocsDemo(s) {
      if (s.dispensa) return { ok: false, motivo: 'dispensado', dispensa: s.dispensa, dispensa_em: s.dispensa_em, dispensa_por: s.dispensa_por };
      if (['recebido', 'conferido'].includes(s.status)) return { ok: false, motivo: 'respondido', recebido_em: s.recebido_em };
      if (s.status === 'cancelado') return { ok: false, motivo: 'cancelado' };
      if (s.status === 'expirado' || (s.status !== 'gerado' && s.expira_em < agora())) return { ok: false, motivo: 'expirado' };
      return null;
    }
    function dadosDocs(s) {
      const f = forn(s.fornecedor_id), c = colabDocsDemo(f);
      return { ok: true, competencia: s.competencia, mes: U.mesNome(s.competencia), ano: Number(s.competencia.slice(0, 4)), pasta_upload: s.pasta + '/' + s.docs_token,
        pasta: (pastaD(s.pasta_envio_id) || {}).nome || 'Avulso', link_status: s.status, link_enviado_em: s.enviado_em, docs_enviado_em: s.docs_enviado_em || null,
        docs_por: s.docs_por || null, email_pronto: !!(db.config.__chave_email && conf('email_remetente', '') && conf('site_url', '')),
        limites: { arquivos: 15, mb_por_arquivo: 25 }, fornecedor: { nome: f.nome, codigo: f.codigo }, colaborador: c ? c.nome : null,
        contatos_klingele: contatosDe(contratosDoLink(s)),
        contratos: contratosDoLink(s).sort((a, b) => a.pedido - b.pedido).map((k) => ({ pedido: k.pedido, titulo: k.titulo, tipo_servico: k.tipo_servico })),
        documentos: docsKlgDemo(s).map((d) => ({ id: d.id, nome: d.nome_padrao || d.nome_arquivo, nome_arquivo: d.nome_arquivo, caminho: d.caminho, tamanho: d.tamanho, enviado_em: d.created_at })) };
    }
    function dispensarDemo(s, motivo, obs, autor) {
      if (!['sem_medicao', 'sem_contrato'].includes(motivo)) throw new Error('Escolha: não houve medição ou não há contrato no mês');
      if (!s || !['gerado', 'enviado', 'aberto', 'expirado'].includes(s.status) || s.dispensa) throw new Error('Só dá para dispensar o envio de um link ainda não respondido pelo fornecedor');
      if (obs && obs.length > 1000) throw new Error('Observação inválida (até 1.000 caracteres)');
      Object.assign(s, { status: 'cancelado', dispensa: motivo, dispensa_obs: obs || null, dispensa_por: autor, dispensa_em: agora() });
      db.medicoes.filter((m) => m.solicitacao_id === s.id && m.status === 'aguardando' && m.valor_informado === null).forEach((m) => {
        m.status = 'sem_medicao';
        if (!m.observacao) m.observacao = `${motivo === 'sem_contrato' ? 'Sem contrato no mês' : 'Sem medição no mês'} (informado por ${autor})`;
      });
      log('solicitacoes', s.id, s.fornecedor_id, 'envio dispensado no mês', { competencia: U.compCurta(s.competencia), motivo, observacao: obs || null, pasta: (pastaD(s.pasta_envio_id) || {}).nome || 'avulso' }, autor);
      return s;
    }
    function enviarPastaDemo(p, comp, via, autor) {
      const ids = idsEnvioPastaDemo(p.id, comp);
      let ok = 0; const sem = [], falhas = [], aguardando = [];
      if (ids.length) {
        gerar(comp, null, null, p.id);
        db.solicitacoes.filter((s) => s.competencia === comp && s.pasta_envio_id === p.id && s.status === 'gerado').forEach((s) => {
          if (aguardaDocsDemo(s)) { aguardando.push(forn(s.fornecedor_id).nome); if (!s.docs_pedido_em) pedirDocsDemo([s], autor || 'demonstração'); return; }
          const r = enviarDemo(s, via, null, false);
          if (r.ok) ok++; else if (r.motivo === 'sem_email') sem.push(forn(s.fornecedor_id).nome); else falhas.push(forn(s.fornecedor_id).nome);
        });
      }
      const ja = db.solicitacoes.filter((s) => s.competencia === comp && s.pasta_envio_id === p.id && ['enviado', 'aberto', 'recebido', 'conferido'].includes(s.status)).length;
      return { ok: true, fornecedores: ids.length, enviados: ok, ja_enviados: Math.max(ja - ok, 0), sem_email: sem, falhas, aguardando_docs: aguardando, pasta_id: p.id, pasta: p.nome,
        competencia: comp.slice(0, 7), via: via === 'app' ? 'manual' : via, autor: autor || 'demonstração' };
    }

    // ---------- Dados de exemplo ----------
    function semear() {
      const P = window.DADOS_PLANILHA || [];
      db = { versao: 17, seq: 1, usuarios: [], alertas: [], fornecedores: [], contatos: [], contratos: [], solicitacoes: [], medicoes: [], documentos: [], historico: [], envios_email: [],
        avaliacoes: [], colaboradores: [], solicitacoes_nf: [], notas_fiscais: [], pastas_envio: [], pasta_fornecedores: [],
        pasta_compartilhamentos: [], equipes_trabalho: [], equipe_membros: [], eventos_seguranca: [],
        config: { prazo_dias_uteis: '7', contato_klingele: '', emails_suporte: '', modelo_assunto: MODELO_ASSUNTO, modelo_corpo: MODELO_CORPO, envio_automatico: 'false',
          exigir_mfa: 'false', email_provedor: 'resend', email_remetente: '', email_remetente_nome: 'Klingele Paper & Packing', email_resposta: '', email_copia: '', site_url: '',
          horario_envio: '08:00', dia_util_envio: '1', avaliacao_automatica: 'false', avaliacao_junto: 'true', nf_encaminhar_automatico: 'true', avaliacao_prazo_dias_uteis: '7', avaliacao_padrao: JSON.stringify(PADRAO_DEMO),
          modelo_aval_assunto: MODELO_AVAL_ASSUNTO, modelo_aval_corpo: MODELO_AVAL_CORPO,
          cnpj_klingele: CNPJ_KLINGELE_DEMO, nf_prazo_dias_uteis: '7', email_limite_dia: '300', modelo_nf_assunto: MODELO_NF_ASSUNTO, modelo_nf_corpo: MODELO_NF_CORPO,
          envio_incluir_fixos: 'true', envio_incluir_spot: 'true', cobranca_automatica: 'true', cobranca_reenvio_dias: '10', cobranca_semanal_dias: '5',
          cobranca_intervalo_dias: '7', cobranca_lembretes_max: '4', fs_emails_servicos: 'servicos@exemplo.com.br', fs_emails_ocorrencia: 'ocorrencia@exemplo.com.br',
          modelo_fs_assunto: MODELO_FS_ASSUNTO, modelo_fs_corpo: MODELO_FS_CORPO, alerta_venc_automatico: 'true', alerta_venc_longo_dias: '42', alerta_venc_curto_dias: '14',
          alerta_venc_limite_curto: '42', alerta_venc_emails: 'contratos@exemplo.com.br', modelo_venc_assunto: MODELO_VENC_ASSUNTO, modelo_venc_corpo: MODELO_VENC_CORPO,
          cadastro_aberto: 'true', cadastro_dominios: 'klingele.com.br' },
        feriados: FERIADOS.map(([data, nome]) => ({ data, nome, tipo: 'feriado' })),
        equipe: [{ email: 'guilhermealmeidafsilva@gmail.com', nome: 'Guilherme Silva', papel: 'admin' }, { email: 'carla.mendes@klingele.com.br', nome: 'Carla Mendes', papel: 'supervisor' },
          { email: 'joao.lima@klingele.com.br', nome: 'João Lima', papel: 'analista' }],
        rotina_log: [] };
      // Usuários de exemplo: o administrador inicial, uma supervisora ligada a ele, um analista aprovado e dois cadastros aguardando aprovação
      const adm = { id: uuid(), email: 'guilhermealmeidafsilva@gmail.com', usuario: 'Gsilv1', nome: 'Guilherme Silva', cargo: 'Administrador do sistema', telefone: null,
        email_aviso: null, status: 'aprovado', papel: 'admin', aprovador_id: null, supervisor_id: null, colaborador_id: null, motivo: null, decidido_por: 'instalação',
        decidido_em: agora(), created_at: U.addDias(U.hojeISO(), -40) + 'T09:00:00-03:00', updated_at: agora() };
      db.usuarios.push(adm,
        { id: uuid(), email: 'joao.lima@klingele.com.br', usuario: 'joao.lima', nome: 'João Lima', cargo: 'Analista de contratos', telefone: '(11) 4000-1000', email_aviso: null,
          status: 'aprovado', papel: 'analista', aprovador_id: adm.id, supervisor_id: null, colaborador_id: null, motivo: null, decidido_por: adm.email,
          decidido_em: U.addDias(U.hojeISO(), -20) + 'T10:00:00-03:00', created_at: U.addDias(U.hojeISO(), -21) + 'T15:00:00-03:00', updated_at: agora() },
        { id: 'demo-sup-carla', email: 'carla.mendes@klingele.com.br', usuario: 'carla.mendes', nome: 'Carla Mendes', cargo: 'Supervisora de serviços', telefone: '(11) 4000-1500',
          email_aviso: null, status: 'aprovado', papel: 'supervisor', admin_id: adm.id, aprovador_id: adm.id, supervisor_id: null, colaborador_id: null, motivo: null,
          decidido_por: adm.email, decidido_em: U.addDias(U.hojeISO(), -30) + 'T10:00:00-03:00', created_at: U.addDias(U.hojeISO(), -31) + 'T09:00:00-03:00', updated_at: agora() },
        { id: uuid(), email: 'maria.souza@klingele.com.br', usuario: 'maria.souza', nome: 'Maria Souza', cargo: 'Compradora', telefone: '(11) 4000-2000', email_aviso: null,
          status: 'pendente', papel: null, aprovador_id: 'demo-sup-carla', supervisor_id: null, colaborador_id: null, motivo: null, decidido_por: null, decidido_em: null,
          created_at: U.addDias(U.hojeISO(), -1) + 'T08:40:00-03:00', updated_at: agora() },
        { id: uuid(), email: 'carlos.pereira@klingele.com.br', usuario: 'carlos.p', nome: 'Carlos Pereira', cargo: 'Técnico de manutenção', telefone: null, email_aviso: null,
          status: 'pendente', papel: null, aprovador_id: null, supervisor_id: null, colaborador_id: null, motivo: null, decidido_por: null, decidido_em: null,
          created_at: agora(), updated_at: agora() });
      // Contato de exemplo para o fornecedor; gestores da planilha viram supervisores (e-mails de exemplo)
      db.colaboradores.push({ id: uuid(), nome: 'Equipe de Contratos', cargo: 'Compras e contratos', email: 'contratos@exemplo.com.br', telefone: null,
        contato_fornecedor: true, supervisor: false, ativo: true, ordem: 1, created_at: agora(), updated_at: agora() });
      const gestores = [...new Set(P.flatMap((p) => (p.contratos || []).map((c) => (c.gestor || '').trim())).filter(Boolean))].sort();
      gestores.forEach((g) => db.colaboradores.push({ id: uuid(), nome: g, cargo: null, email: U.slug(g).replace(/-/g, '.') + '@exemplo.com.br', telefone: null,
        contato_fornecedor: false, supervisor: true, ativo: true, ordem: 0, created_at: agora(), updated_at: agora() }));
      P.forEach((p) => {
        const f = { id: uuid(), codigo: p.codigo, nome: p.nome, cnpj: p.cnpj, telefone: p.telefone, tipo_contrato: p.tipo_contrato,
          deseja_enviar: !!p.deseja_enviar, observacoes: p.observacoes, ativo: true, created_at: agora(), updated_at: agora() };
        db.fornecedores.push(f);
        (p.contatos || []).forEach((c) => db.contatos.push({ id: uuid(), fornecedor_id: f.id, nome: c.nome, email: c.email, telefone: c.telefone,
          recebe_boletim: true, principal: !!c.principal, origem: 'planilha', created_at: agora(), updated_at: agora() }));
        (p.contratos || []).forEach((c) => {
          const sup = db.colaboradores.find((x) => x.supervisor && c.gestor && x.nome.toLowerCase() === c.gestor.trim().toLowerCase());
          db.contratos.push({ id: uuid(), fornecedor_id: f.id, ...c, supervisor_id: sup ? sup.id : null, supervisores: sup ? [sup.id] : [], contatos: [],
            tipo_servico: /^\s*(loca[çc][ãa]o|aluguel)/i.test(c.titulo || '') ? 'locacao' : null,
            parcelas_total: c.meses_vigencia || null, parcelas_pagas_antes: 0, created_at: agora(), updated_at: agora() });
        });
      });

      // Pastas de fechamento de exemplo (antes dos links, para cada link sair só com os contratos da sua pasta):
      // Envio mensal (padrão) com os contínuos; "Serviços Spot" por datas (do João, compartilhada com a equipe Manutenção);
      // "Locações trimestrais" nos meses mar/jun/set/dez; "Obras de fim de ano" só manual (da supervisora Carla)
      const hojeP = U.hojeISO(), ferP = feriadosSet();
      const novaPasta = (o) => { const p = { id: uuid(), padrao: false, calendario: 'mensal', dia_util: 1, horario: '08:00', meses: [], datas: [], pede: 'mes_anterior',
        ativa: true, responsavel: o.criado_por || null, prazo_dias: null, cobranca: true, avaliacao: true, descricao: null, criado_por: null, visibilidade: 'restrita',
        tipo: 'lista', filtro: null, responsaveis: [], created_at: agora(), updated_at: agora(), ...o }; db.pastas_envio.push(p); return p; };
      novaPasta({ nome: 'Envio mensal', padrao: true, visibilidade: 'todos_ver', created_at: U.addDias(hojeP, -40) + 'T08:00:00-03:00',
        descricao: 'Rotina base do mês: contratos contínuos (locação, suporte técnico, valor fixo e boletim mensal).' });
      db.contratos.forEach((c) => { c.pasta_escolhida = false; c.pasta_id = pastaParaContratoDemo(c); });
      const ativosE = (fid) => db.contratos.filter((c) => c.fornecedor_id === fid && c.situacao === 'ativo').sort((a, b) => a.pedido - b.pedido);
      const pSpot = novaPasta({ nome: 'Serviços Spot', calendario: 'datas', datas: [U.addDiasUteis(hojeP, 4, ferP), U.addDiasUteis(hojeP, 24, ferP)], horario: '09:00',
        criado_por: 'joao.lima@klingele.com.br', descricao: 'Serviços pontuais: o link sai na data combinada com o fornecedor.', prazo_dias: 5,
        filtro: { tipos: ['servico_especifico', 'servico_unico'] }, created_at: U.addDias(hojeP, -12) + 'T10:00:00-03:00' });
      db.fornecedores.filter((f) => f.deseja_enviar).sort((a, b) => a.nome.localeCompare(b.nome)).filter((f) => ativosE(f.id).length >= 2).slice(0, 2).forEach((f) => {
        const cs = ativosE(f.id), spot = cs[cs.length - 1];
        if (!spot.tipo_servico) spot.tipo_servico = 'servico_especifico';
        Object.assign(spot, { pasta_id: pSpot.id, pasta_escolhida: true });
      });
      const pTri = novaPasta({ nome: 'Locações trimestrais', calendario: 'meses', meses: [3, 6, 9, 12], dia_util: 0, horario: '16:00', visibilidade: 'todos_ver',
        criado_por: 'guilhermealmeidafsilva@gmail.com', descricao: 'Locações medidas a cada trimestre, no último dia útil.', created_at: U.addDias(hojeP, -10) + 'T10:00:00-03:00' });
      db.fornecedores.filter((f) => f.ativo && !f.deseja_enviar && ativosE(f.id).length && ativosE(f.id).every((c) => c.tipo_servico === 'locacao')).slice(0, 2)
        .forEach((f) => ativosE(f.id).forEach((c) => Object.assign(c, { pasta_id: pTri.id, pasta_escolhida: true })));
      const pObra = novaPasta({ nome: 'Obras de fim de ano', calendario: 'manual', criado_por: 'carla.mendes@klingele.com.br', avaliacao: false,
        descricao: 'Serviços de obra: o link sai pelo botão quando a obra termina.', created_at: U.addDias(hojeP, -5) + 'T10:00:00-03:00' });
      db.contratos.filter((c) => c.situacao === 'ativo' && !c.pasta_id).slice(0, 2).forEach((c) => Object.assign(c, { pasta_id: pObra.id, pasta_escolhida: true }));

      // Três competências de exemplo, relativas a hoje
      const fer = feriadosSet();
      const atual = U.compAnterior();
      const comps = [U.addMes(atual, -2), U.addMes(atual, -1), atual];
      const fatores = [[1, 1, 0.97, 1, 1.02, 1], [1, 0.95, 1, 1.03, 1, 1], [1, 1, 1.0505, 1, 0.94, 1]];
      const primeiroUtil = (comp) => { let d = U.addDias(U.addMes(comp, 1), -1); do { d = U.addDias(d, 1); } while (!U.ehDiaUtil(d, fer)); return d; };
      const listaEnvio = db.fornecedores.filter((f) => f.deseja_enviar).sort((a, b) => a.nome.localeCompare(b.nome));
      const hoje = U.hojeISO();

      // Parcelas pagas antes do sistema: meses decorridos até o primeiro mês da demonstração (só contratos fixos)
      db.contratos.forEach((c) => {
        const fixo = ['locacao', 'suporte_tecnico'].includes(c.tipo_servico) || (forn(c.fornecedor_id) || {}).tipo_contrato === 'FIXO';
        if (!c.data_inicio || !fixo) return;
        const meses = (Number(comps[0].slice(0, 4)) - Number(c.data_inicio.slice(0, 4))) * 12 + Number(comps[0].slice(5, 7)) - Number(c.data_inicio.slice(5, 7));
        c.parcelas_pagas_antes = Math.max(0, Math.min(meses, c.parcelas_total || 600));
      });

      comps.forEach((comp, ci) => {
        // No mês mais recente o envio fica a poucos dias de hoje, para os links de exemplo ainda estarem no prazo
        const pu = primeiroUtil(comp), recente = U.addDias(hoje, -3);
        const diaEnvio = ci === comps.length - 1 && pu < recente ? recente : pu < hoje ? pu : U.addDias(hoje, -1);
        const envioISO = `${diaEnvio}T09:12:00-03:00`;
        gerar(comp, null, envioISO);
        listaEnvio.forEach((f, fi) => {
          const s = db.solicitacoes.find((x) => x.fornecedor_id === f.id && x.competencia === comp);
          const meds = db.medicoes.filter((m) => m.solicitacao_id === s.id);
          const ultimo = ci === comps.length - 1;
          s.enviado_em = envioISO;
          s.emails_destino = db.contatos.filter((c) => c.fornecedor_id === f.id).map((c) => c.email);
          const corpoMail = U.montarEmail({ modeloAssunto: MODELO_ASSUNTO, modeloCorpo: MODELO_CORPO, fornecedor: f.nome, competencia: comp,
            servicos: meds.map((m) => db.contratos.find((c) => c.id === m.contrato_id)), link: 'https://seu-site.netlify.app/portal.html#' + s.token,
            prazoISO: s.expira_em, prazoDias: 7, suporte: contatosDemo(), suporteServicos: servicosSuporte(meds.map((m) => db.contratos.find((c) => c.id === m.contrato_id))) });
          s.assunto = corpoMail.assunto; s.corpo = corpoMail.corpo;
          s.status = 'enviado';
          s.envio_via = 'outlook';
          db.envios_email.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: f.id, competencia: comp, tipo: 'envio', via: 'outlook', para: s.emails_destino.slice(),
            assunto: s.assunto, corpo: s.corpo, prazo_ate: s.expira_em, status: 'registrado', erro: null, autor: 'demonstração', created_at: envioISO });
          log('solicitacoes', s.id, f.id, 'e-mail enviado (Outlook)', { para: s.emails_destino, assunto: s.assunto }, null, envioISO);
          // Situação de cada fornecedor no mês corrente da demonstração
          const cenario = ultimo ? ['aberto', 'recebido', 'enviado', 'recebido', 'enviado', 'conferido'][fi] : 'conferido';
          if (cenario === 'enviado' && ultimo && fi === 4) {
            // Sem resposta no prazo: a cobrança automática reenviou o link com 10 dias úteis
            const q = `${U.addDias(hoje, -1)}T08:00:00-03:00`, ini = `${U.addDias(hoje, -14)}T09:12:00-03:00`;
            const e0 = db.envios_email.find((x) => x.solicitacao_id === s.id);
            if (e0) { e0.created_at = ini; e0.prazo_ate = U.fimPrazoISO(ini, 7, fer); }
            s.envio_via = 'automatico'; s.enviado_em = q; s.expira_em = U.fimPrazoISO(q, 10, fer);
            db.envios_email.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: f.id, competencia: comp, tipo: 'reenvio', via: 'automatico', para: s.emails_destino.slice(),
              assunto: 'LEMBRETE - ' + s.assunto, corpo: s.corpo, prazo_ate: s.expira_em, status: 'aceito', erro: null, autor: 'cobrança automática', created_at: q });
            log('solicitacoes', s.id, f.id, 'cobrança: link reenviado com novo prazo', { competencia: U.compCurta(comp), prazo_dias_uteis: 10 }, 'cobrança automática', q);
          }
          if (cenario === 'enviado') return;
          s.aberto_em = `${U.addDias(diaEnvio, 1 + (fi % 2))}T10:${10 + fi}:00-03:00`;
          s.status = 'aberto';
          if (cenario === 'aberto') return;
          const diaReceb = U.addDias(diaEnvio, 2 + (fi % 3));
          s.recebido_em = `${diaReceb <= hoje || !ultimo ? diaReceb : hoje}T14:${20 + fi}:00-03:00`;
          s.status = 'recebido';
          const contato = db.contatos.find((c) => c.fornecedor_id === f.id);
          s.respondido_por = contato ? [U.cap(contato.nome || ''), contato.email].filter(Boolean).join(' · ') : null;
          meds.forEach((m, mi) => {
            const fat = fatores[ci][(fi + mi) % 6];
            const valor = Math.round(m.valor_contratado * fat * 100) / 100;
            m.valor_informado = valor;
            m.valor_lido = valor;
            m.status = 'recebido';
            const c = db.contratos.find((x) => x.id === m.contrato_id);
            db.documentos.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: f.id, contrato_id: m.contrato_id, competencia: comp, tipo: 'boletim',
              nome_arquivo: `BM-${c.pedido}-${U.mesNome(comp).toLowerCase()}-${comp.slice(0, 4)}.xlsx`, caminho: `${s.pasta}/${s.token}/bm-${c.pedido}.xlsx`,
              mime: U.MIME.xlsx, tamanho: 18000 + mi * 2300, valor_lido: valor, enviado_por: 'fornecedor', created_at: s.recebido_em, hash_sha256: null,
              exemplo: { tipo: 'boletim', pedido: c.pedido, titulo: c.titulo, fornecedor: f.nome, comp, total: valor } });
            if (/m[aã]o de obra|t[eé]cnico|mec[aâ]nico|eletromec/i.test(c.titulo)) {
              db.documentos.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: f.id, contrato_id: m.contrato_id, competencia: comp, tipo: 'ponto',
                nome_arquivo: `Ponto-${U.mesNome(comp).toLowerCase()}-${c.pedido}.xlsx`, caminho: `${s.pasta}/${s.token}/ponto-${c.pedido}.xlsx`,
                mime: U.MIME.xlsx, tamanho: 9400, valor_lido: null, enviado_por: 'fornecedor', created_at: s.recebido_em,
                exemplo: { tipo: 'ponto', pedido: c.pedido, fornecedor: f.nome, comp } });
            }
          });
          if (fi === 3 && ultimo) s.observacao_fornecedor = 'Medição inclui uma visita corretiva extra no dia 18, conforme ordem de serviço.';
          log('solicitacoes', s.id, f.id, 'documentos recebidos', { competencia: U.compCurta(comp), arquivos: meds.length }, 'fornecedor (portal)', s.recebido_em);
          if (cenario !== 'conferido') return;
          s.status = 'conferido';
          s.conferido_em = `${U.addDias(diaReceb, 2)}T11:00:00-03:00`;
          meds.forEach((m, mi) => {
            m.valor_aprovado = m.valor_informado;
            const pago = ci === 0;
            m.status = pago ? 'pago' : 'aprovado';
            m.nota_fiscal = pago || ci === 1 ? String(4100 + fi * 37 + mi + ci * 300) : null;
            m.data_pagamento = pago ? U.addDias(U.addMes(comp, 1), 24) : null;
          });
        });
        // Abertura em mês corrente: medicões ainda sem resposta seguem "aguardando"

        // Avaliações de satisfação do mês: enviadas aos supervisores junto com o pedido do boletim
        gerarAval(comp, null, envioISO);
        db.avaliacoes.filter((a) => a.competencia === comp).forEach((a, ai) => {
          enviarAvalDemo(a, 'app', null, false, envioISO);
          const ultimo = ci === comps.length - 1;
          const notas = {};
          U.CATEGORIAS.forEach(([k], i) => { notas[k] = Math.max(5, Math.min(10, [9, 8, 8, 7, 9, 8, 8, 9, 8][i] - ((ai + i + ci) % 4 === 0 ? 2 : 0) + ((ai + ci) % 3 === 0 && i % 2 ? 1 : 0))); });
          const quando = `${U.addDias(diaEnvio, 2 + (ai % 3))}T16:${10 + ai}:00-03:00`;
          if (ultimo && ai > 0) { if (ai % 2) { a.aberto_em = `${U.addDias(diaEnvio, 1)}T09:30:00-03:00`; a.status = 'aberta'; } return; }
          if (ci === 1 && ai === 1) { aplicarPadrao(a, quando); return; }
          Object.assign(a, { status: 'respondida', aberto_em: quando, notas, nota_geral: U.mediaNotas(notas), respondido_por: a.supervisor_nome, respondido_em: quando,
            observacao: ai === 0 && ultimo ? 'Equipe cumpriu a programação; reforçar a limpeza ao final do serviço.' : null });
          log('avaliacoes', a.id, a.fornecedor_id, 'avaliação respondida', { competencia: U.compCurta(comp), nota_geral: a.nota_geral }, 'supervisor (link de avaliação)', quando);
        });
      });
      db.documentos.forEach((d) => { d.nome_padrao = nomeDoc(d); });
      semearNF(comps, fer);
      // Demonstração: o administrador acompanha os contratos do supervisor com mais contratos ("Meus contratos")
      const cont = {};
      db.contratos.forEach((c) => { if (c.supervisor_id) cont[c.supervisor_id] = (cont[c.supervisor_id] || 0) + 1; });
      const supTop = Object.keys(cont).sort((a, b) => cont[b] - cont[a])[0];
      if (supTop) db.usuarios[0].supervisor_id = supTop;
      // Responsáveis de exemplo: contatos por serviço (Ana nos fixos, Rafael nos serviços Spot) e um contrato com dois supervisores
      const novoColab = (nome, cargo, email, telefone, ordem) => ({ id: uuid(), nome, cargo, email, telefone, contato_fornecedor: false, supervisor: false, ativo: true, ordem,
        created_at: agora(), updated_at: agora() });
      const ana = novoColab('Ana Paula Costa', 'Analista de contratos', 'ana.costa@exemplo.com.br', '(11) 4000-3100', 2);
      const rafa = novoColab('Rafael Lima', 'Serviços Spot', 'rafael.lima@exemplo.com.br', '(11) 4000-3200', 3);
      db.colaboradores.push(ana, rafa);
      // Documentos da Klingele para a medição (mês mais recente): um aguardando o colaborador, um dispensado e um já enviado com os documentos
      const paulo = novoColab('Paulo Reis', 'Almoxarifado e documentação', 'paulo.reis@exemplo.com.br', '(11) 4000-3300', 4);
      db.colaboradores.push(paulo);
      {
        const padD = padraoDemo(), compD = U.compAnterior(), ultD = U.ultimoDiaUtil(compD, feriadosSet());
        const marcar = (f) => Object.assign(f, { docs_klingele: true, docs_colaborador_id: paulo.id, docs_analista: 'guilhermealmeidafsilva@gmail.com' });
        const gerados = db.solicitacoes.filter((x) => x.competencia === compD && x.status === 'gerado' && padD && x.pasta_envio_id === padD.id)
          .sort((a, b) => forn(a.fornecedor_id).nome.localeCompare(forn(b.fornecedor_id).nome));
        if (gerados[0]) {
          const s0 = gerados[0]; marcar(forn(s0.fornecedor_id));
          Object.assign(s0, { docs_token: token64(), docs_pedido_em: `${ultD}T08:00:00-03:00` });
          log('solicitacoes', s0.id, s0.fornecedor_id, 'documentos pedidos ao colaborador', { competencia: U.compCurta(compD), para: paulo.email }, 'documentos da Klingele', s0.docs_pedido_em);
        }
        if (gerados[1]) {
          const s1 = gerados[1]; marcar(forn(s1.fornecedor_id));
          const q = `${ultD}T15:40:00-03:00`;
          Object.assign(s1, { docs_token: token64(), docs_pedido_em: `${ultD}T08:00:00-03:00`, docs_aberto_em: `${ultD}T15:31:00-03:00`, status: 'cancelado',
            dispensa: 'sem_medicao', dispensa_obs: 'Equipamento parado para manutenção o mês inteiro: sem horas a medir.', dispensa_por: 'Paulo Reis (colaborador)', dispensa_em: q });
          db.medicoes.filter((m) => m.solicitacao_id === s1.id).forEach((m) => { m.status = 'sem_medicao'; m.observacao = 'Sem medição no mês (informado por Paulo Reis (colaborador))'; });
          log('solicitacoes', s1.id, s1.fornecedor_id, 'envio dispensado no mês', { competencia: U.compCurta(compD), motivo: 'sem_medicao', observacao: s1.dispensa_obs }, 'Paulo Reis (colaborador)', q);
        }
        const s2 = db.solicitacoes.find((x) => x.competencia === compD && x.status === 'enviado' && db.medicoes.some((m) => m.solicitacao_id === x.id) && !forn(x.fornecedor_id).docs_klingele);
        if (s2) {
          const f2 = forn(s2.fornecedor_id); marcar(f2);
          const q = U.addDias(String(s2.enviado_em).slice(0, 10), -1) + 'T17:05:00-03:00';
          Object.assign(s2, { docs_token: token64(), docs_pedido_em: `${ultD}T08:00:00-03:00`, docs_aberto_em: q, docs_enviado_em: q, docs_por: 'Paulo Reis' });
          [['RDO consolidado', 'rdo-consolidado.pdf', 52000], ['Controle de horas da portaria', 'controle-horas.pdf', 31000]].forEach(([titulo, arq, tam], i) => {
            const d = { id: uuid(), solicitacao_id: s2.id, fornecedor_id: f2.id, contrato_id: null, competencia: compD, tipo: 'klingele', nome_arquivo: arq,
              caminho: `${s2.pasta}/${s2.docs_token}/${arq.replace('.pdf', '')}--k${i}.pdf`, mime: U.MIME.pdf, tamanho: tam, valor_lido: null, enviado_por: 'colaborador',
              created_at: q, exemplo: { tipo: 'klingele', titulo, comp: compD } };
            d.nome_padrao = nomeDoc(d); db.documentos.push(d);
          });
          log('solicitacoes', s2.id, f2.id, 'documentos da Klingele anexados', { competencia: U.compCurta(compD), arquivos: 2 }, 'Paulo Reis (colaborador)', q);
        }
      }
      const ativosDe = (fid) => db.contratos.filter((c) => c.fornecedor_id === fid && c.situacao === 'ativo').sort((a, b) => a.pedido - b.pedido);
      const multi = listaEnvio.filter((f) => ativosDe(f.id).length >= 2).slice(0, 2);
      multi.forEach((f) => {
        const cs = ativosDe(f.id), spot = cs[cs.length - 1];
        if (!spot.tipo_servico) spot.tipo_servico = 'servico_especifico';
        spot.contatos = [rafa.id];
        cs.slice(0, -1).forEach((c) => { c.contatos = [ana.id]; });
      });
      db.contratos.filter((c) => c.tipo_servico === 'locacao' && !c.contatos.length).forEach((c) => { c.contatos = [ana.id]; });
      const dois = supTop && db.contratos.find((c) => c.situacao === 'ativo' && c.supervisor_id === supTop);
      const outroSup = dois && db.colaboradores.find((x) => x.supervisor && x.id !== supTop);
      if (outroSup) dois.supervisores = [supTop, outroSup.id];
      // Equipes: "Manutenção" (da supervisora Carla, com o João e um convite ao administrador) e "Contratos" (do administrador)
      const eqMan = { id: uuid(), nome: 'Manutenção', descricao: 'Serviços de manutenção e Spot', criado_por: 'carla.mendes@klingele.com.br', created_at: agora(), updated_at: agora() };
      const eqCon = { id: uuid(), nome: 'Contratos', descricao: 'Equipe de contratos e compras', criado_por: 'guilhermealmeidafsilva@gmail.com', created_at: agora(), updated_at: agora() };
      db.equipes_trabalho.push(eqMan, eqCon);
      const membro = (eq, email, status, por) => db.equipe_membros.push({ equipe_id: eq.id, email, status, convidado_por: por, convidado_em: agora(), respondido_em: status === 'convidado' ? null : agora() });
      membro(eqMan, 'carla.mendes@klingele.com.br', 'ativo', 'carla.mendes@klingele.com.br'); membro(eqMan, 'joao.lima@klingele.com.br', 'ativo', 'carla.mendes@klingele.com.br');
      membro(eqMan, 'guilhermealmeidafsilva@gmail.com', 'convidado', 'carla.mendes@klingele.com.br');
      membro(eqCon, 'guilhermealmeidafsilva@gmail.com', 'ativo', 'guilhermealmeidafsilva@gmail.com'); membro(eqCon, 'joao.lima@klingele.com.br', 'ativo', 'guilhermealmeidafsilva@gmail.com');
      db.pasta_compartilhamentos.push({ pasta_id: pSpot.id, alvo_tipo: 'equipe', alvo: eqMan.id, nivel: 'editar', criado_por: 'joao.lima@klingele.com.br', created_at: agora() },
        { pasta_id: pObra.id, alvo_tipo: 'usuario', alvo: 'joao.lima@klingele.com.br', nivel: 'ver', criado_por: 'carla.mendes@klingele.com.br', created_at: agora() });
      db.documentos.forEach((d) => { if (!d.nome_padrao) d.nome_padrao = nomeDoc(d); });
      // Cada usuário aprovado (admin, supervisor ou analista) tem o seu cadastro em Contatos Klingele
      db.usuarios.forEach((u) => ligarColaboradorDemo(u, false, true));

      // Tentativas bloqueadas de exemplo (no site publicado, o banco registra sozinho)
      const ev = (horas, tipo, gravidade, ip, email, detalhes) => db.eventos_seguranca.push({ id: db.eventos_seguranca.length + 1,
        created_at: new Date(Date.now() - horas * 3600e3).toISOString(), tipo, gravidade, ip, email, detalhes: detalhes || {}, visto_em: null, visto_por: null });
      ev(2, 'Links inválidos repetidos: IP bloqueado por 1 hora (tentativa de adivinhar links)', 'alerta', '187.45.12.9', null, { limite: 15, origem: '187.45.12.9' });
      ev(5, 'Senha errada repetida: entrada pelo usuário bloqueada por 15 minutos', 'alerta', '201.17.88.4', null, { limite: 10, usuario: 'joao.lima' });
      ev(9, 'Teste de nomes de usuário inexistentes (busca de contas)', 'alerta', '45.155.205.33', null, { limite: 10, origem: '45.155.205.33' });
      ev(30, 'Conta criada com e-mail já liberado na equipe: aguarda confirmação do e-mail ou aprovação', 'alerta', '177.92.1.20', 'carlos.pereira@klingele.com.br', { usuario: 'carlos.p', papel_na_equipe: 'analista' });
      ev(52, 'Senha da conta trocada', 'info', '189.6.33.150', 'joao.lima@klingele.com.br', { usuario: 'joao.lima' });
      ev(80, 'Muitas tentativas de envio no mesmo link do boletim', 'alerta', '200.150.3.7', null, { limite: 20, fornecedor: (db.fornecedores[0] || {}).nome || 'Fornecedor' });
      db.eventos_seguranca.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));

      // Execuções da rotina 8h/16h dos últimos dias
      for (let i = 4; i >= 0; i--) {
        const d = U.addDias(hoje, -i);
        ['08:00', '16:00'].forEach((h) => {
          const iso = `${d}T${h}:00-03:00`;
          if (new Date(iso) <= new Date()) db.rotina_log.unshift({ id: db.seq++, origem: 'pg_cron 8h/16h', executado_em: iso, detalhes: { links_expirados: 0, contratos_vencendo_60d: 2 } });
        });
      }
      // Avisos de vencimento que a rotina das 8h já mandou hoje
      avisarVencimentosDemo(`${hoje}T08:00:00-03:00`);
      db.historico.sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
      salvar();
    }

    function pdfDeExemplo(ex) {
      const t = ex.tipo === 'pedido' ? `PEDIDO DE COMPRA ${ex.pedido} - ${U.compLabel(ex.comp)} - exemplo`
        : ex.tipo === 'klingele' ? `${ex.titulo} - ${U.compLabel(ex.comp)} - exemplo` : `NOTA FISCAL ${ex.numero} - ${U.compLabel(ex.comp)} - exemplo`;
      return new Blob([U.NF ? U.NF.pdfExemplo(t) : '%PDF-1.4\n%%EOF\n'], { type: 'application/pdf' });
    }
    function planilhaExemplo(ex) {
      const XLSX = window.XLSX;
      let aoa;
      if (ex.tipo === 'boletim') {
        const itens = [['Mão de obra / serviço executado', 0.62], ['Materiais e consumíveis', 0.23], ['Deslocamento e apoio técnico', 0.15]];
        let soma = 0;
        const linhas = itens.map(([d, p], i) => {
          const v = i === itens.length - 1 ? Math.round((ex.total - soma) * 100) / 100 : Math.round(ex.total * p * 100) / 100;
          soma += v;
          return [i + 1, d, 1, v, v];
        });
        aoa = [['BOLETIM DE MEDIÇÃO'], ['Fornecedor', ex.fornecedor], ['Cliente', 'Klingele Paper & Packing'], ['Competência', U.compLabel(ex.comp)], ['Pedido', ex.pedido],
          ['Serviço', ex.titulo], [], ['Item', 'Descrição', 'Qtd', 'Valor unitário', 'Valor'], ...linhas, [], ['TOTAL GERAL', null, null, null, ex.total]];
      } else {
        aoa = [['FOLHA DE PONTO'], ['Fornecedor', ex.fornecedor], ['Competência', U.compLabel(ex.comp)], ['Pedido', ex.pedido], [],
          ['Colaborador', 'Dias trabalhados', 'Horas normais', 'Horas extras'], ['Colaborador 1', 21, 176, 6], ['Colaborador 2', 21, 176, 0]];
      }
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(aoa), ex.tipo === 'boletim' ? 'Boletim' : 'Ponto');
      const out = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
      return new Blob([out], { type: U.MIME.xlsx });
    }

    // ---------- Nota fiscal (mesmas regras do banco) ----------
    const contr = (id) => db.contratos.find((c) => c.id === id);
    const NF_MODELO_OK = (m) => ['nfe', 'nfse', 'fatura'].includes(m);
    const cnpjsKlg = () => String(conf('cnpj_klingele', '')).split(',').map((x) => x.trim()).filter(Boolean);
    const prazoNF = () => Number(conf('nf_prazo_dias_uteis', 7)) || 7;
    const nfPedida = (medId) => db.solicitacoes_nf.some((n) => n.medicao_id === medId && ['enviada', 'aberta', 'recebida', 'aprovada'].includes(n.status));
    function parcelasDe(cid) {
      const c = contr(cid), meds = db.medicoes.filter((m) => m.contrato_id === cid);
      const pagasSis = meds.filter((m) => m.status === 'pago').length, antes = Number(c.parcelas_pagas_antes || 0), pagas = antes + pagasSis;
      const ult = meds.reduce((mx, m) => Math.max(mx, m.parcela || 0), 0) || null;
      const total = c.parcelas_total === undefined || c.parcelas_total === null ? null : Number(c.parcelas_total);
      const base = Math.max(pagas, ult || 0);
      return { contrato_id: cid, parcelas_total: total, parcelas_pagas_antes: antes, pagas_sistema: pagasSis, pagas,
        lancadas: meds.filter((m) => m.parcela !== null && m.parcela !== undefined && m.status !== 'pago').length,
        a_pagar: total === null ? null : Math.max(total - pagas, 0), ultima_parcela: ult, proxima_parcela: total !== null && base >= total ? null : base + 1 };
    }
    const descricaoPadrao = (c, comp, parcela) => `${c.titulo} - referente a ${U.mesNome(comp)}/${comp.slice(0, 4)} - parcela ${parcela}${c.parcelas_total ? '/' + c.parcelas_total : ''} - pedido ${c.pedido}`;
    function emailNF(n, prazoISO, anexos) {
      const m = db.medicoes.find((x) => x.id === n.medicao_id), c = contr(n.contrato_id), f = forn(n.fornecedor_id);
      const rec = db.notas_fiscais.filter((x) => x.solicitacao_nf_id === n.id && x.status === 'recusada').sort((a, b) => (a.created_at < b.created_at ? 1 : -1))[0];
      return U.montarEmailNF({ modeloAssunto: conf('modelo_nf_assunto', ''), modeloCorpo: conf('modelo_nf_corpo', ''), fornecedor: f.nome, competencia: n.competencia,
        pedido: c.pedido, servico: c.titulo, parcela: m.parcela, parcelasTotal: c.parcelas_total, valor: m.valor_aprovado, folhaNumero: m.folha_numero, folhaData: m.folha_data,
        descricao: m.descricao_nf, link: (conf('site_url', '') || 'https://seu-site.netlify.app').replace(/\/$/, '') + '/nf.html#' + n.token, prazoISO, prazoDias: prazoNF(),
        suporte: contatosDemo(), suporteServicos: servicosSuporte([c]), cnpjs: cnpjsKlg(), anexos, recusa: rec ? { numero: rec.numero, motivo: rec.motivo_recusa } : null });
    }
    function registrarEnvioNFDemo(n, via, para, assunto, corpo, anexos, manter, quando) {
      const ja = !!n.enviado_em || db.envios_email.some((e) => e.solicitacao_nf_id === n.id);
      const lembrete = manter && ja;
      if (!lembrete) n.expira_em = U.fimPrazoISO(quando || agora(), prazoNF(), feriadosSet());
      const tipo = lembrete ? 'lembrete' : ja ? 'reenvio' : 'envio';
      if (anexos) n.anexos = anexos;
      if (!assunto) { const m = emailNF(n, n.expira_em, n.anexos); assunto = (lembrete ? 'LEMBRETE - ' : '') + m.assunto; corpo = m.corpo; }
      Object.assign(n, { enviado_em: quando || agora(), emails_destino: para, assunto, corpo, envio_via: via, envio_status: via === 'outlook' ? null : 'ok', envio_erro: null,
        status: n.status === 'gerada' ? 'enviada' : n.status });
      db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: null, solicitacao_nf_id: n.id, fornecedor_id: n.fornecedor_id, competencia: n.competencia, tipo, via,
        para: para.slice(), assunto, corpo, prazo_ate: n.expira_em, status: via === 'outlook' ? 'registrado' : 'aceito', erro: null, autor: 'demonstração', created_at: quando || agora() });
      log('solicitacoes_nf', n.id, n.fornecedor_id, via === 'outlook' ? { envio: 'F.S. enviada ao fornecedor (Outlook)', reenvio: 'F.S. reenviada ao fornecedor (Outlook)', lembrete: 'lembrete de nota fiscal (Outlook)' }[tipo]
        : { envio: 'F.S. enviada ao fornecedor pelo app (pedido de NF)', reenvio: 'F.S. reenviada ao fornecedor (pedido de NF)', lembrete: 'lembrete de nota fiscal enviado' }[tipo], { para, anexos: (n.anexos || []).length }, null, quando);
      return { ok: true, tipo, expira_em: n.expira_em };
    }
    // Links dos arquivos enviados com a F.S.: só arquivos da F.S. ou do pedido de compra da própria medição
    function anexosValidos(n, anexos) {
      if (!Array.isArray(anexos) || anexos.length > 10) return null;
      const out = [];
      for (const a of anexos) {
        const mt = /^https:\/\/[A-Za-z0-9.-]+(?::[0-9]{2,5})?\/storage\/v1\/object\/sign\/boletins\/([A-Za-z0-9/_.-]+)\?token=[A-Za-z0-9._~-]+$/.exec((a && a.url) || '');
        const d = mt && !/\.\./.test(mt[1]) && db.documentos.find((x) => x.caminho === mt[1] && ['folha_servico', 'pedido_compra'].includes(x.tipo) && x.contrato_id === n.contrato_id && x.competencia === n.competencia);
        if (!d) return null;
        const img = /\.(jpe?g|png)$/i.test(d.caminho);
        out.push({ nome: d.nome_padrao || d.nome_arquivo || 'arquivo.pdf', url: a.url, caminho: d.caminho, ...(img ? { imagem: true, cid: 'fs-imagem-' + (out.length + 1) } : {}) });
      }
      return out;
    }
    function dadosNF(n) {
      const m = db.medicoes.find((x) => x.id === n.medicao_id), c = contr(n.contrato_id), f = forn(n.fornecedor_id);
      const rec = db.notas_fiscais.filter((x) => x.solicitacao_nf_id === n.id && x.status === 'recusada').sort((a, b) => (a.created_at < b.created_at ? 1 : -1))[0];
      return {
        ok: true, competencia: n.competencia, mes: U.mesNome(n.competencia), ano: Number(n.competencia.slice(0, 4)), expira_em: n.expira_em, pasta_upload: n.pasta + '/' + n.token,
        fornecedor: { nome: f.nome, codigo: f.codigo, cnpj: f.cnpj }, pedido: c.pedido, servico: c.titulo, parcela: m.parcela, parcelas_total: c.parcelas_total || null,
        folha: { numero: m.folha_numero, data: m.folha_data }, descricao: m.descricao_nf, valor: m.valor_aprovado,
        // Demonstração: as imagens abrem do próprio navegador (o link temporário de exemplo não existe)
        anexos: (n.anexos || []).map((a) => ({ nome: a.nome, url: a.imagem && arquivos[a.caminho] ? URL.createObjectURL(arquivos[a.caminho]) : a.url, imagem: !!a.imagem })), cnpj_klingele: cnpjsKlg().map(U.cnpj),
        recusa: rec ? { numero: rec.numero, motivo: rec.motivo_recusa, em: rec.conferido_em } : null,
        feriados: db.feriados.map((x) => x.data).filter((x) => x >= U.hojeISO() && x <= U.dataLocal(n.expira_em)), contatos_klingele: contatosContrato(contr(n.contrato_id)),
        limites: { arquivos: 10, mb_por_arquivo: 25, xml_kb: 500 }
      };
    }
    function novaSolicitacaoNF(m, quando) {
      const f = forn(m.fornecedor_id);
      const n = { id: uuid(), medicao_id: m.id, fornecedor_id: m.fornecedor_id, contrato_id: m.contrato_id, competencia: m.competencia, token: token64(), status: 'gerada',
        pasta: pastaDe(f, m.competencia), emails_destino: db.contatos.filter((c) => c.fornecedor_id === f.id && c.recebe_boletim).map((c) => c.email), anexos: [],
        assunto: null, corpo: null, enviado_em: null, aberto_em: null, recebido_em: null, expira_em: U.fimPrazoISO(quando || agora(), prazoNF(), feriadosSet()),
        envio_via: null, envio_status: null, envio_erro: null, criado_por: 'demonstração', created_at: quando || agora() };
      db.solicitacoes_nf.push(n);
      log('solicitacoes_nf', n.id, n.fornecedor_id, 'pedido de nota fiscal gerado', { competencia: U.compCurta(n.competencia), parcela: m.parcela, folha: m.folha_numero }, null, quando);
      return n;
    }
    // Notas de exemplo nos dois meses mais antigos: folha, pedido de compra, pedido da NF e a nota recebida
    function semearNF(comps) {
      if (!U.NF) return;
      const hoje = U.hojeISO();
      comps.slice(0, 2).forEach((comp, ci) => {
        const meds = db.medicoes.filter((m) => m.competencia === comp && ['aprovado', 'pago'].includes(m.status))
          .sort((a, b) => forn(a.fornecedor_id).nome.localeCompare(forn(b.fornecedor_id).nome) || contr(a.contrato_id).pedido - contr(b.contrato_id).pedido);
        meds.forEach((m, j) => {
          const c = contr(m.contrato_id), f = forn(m.fornecedor_id);
          const cenario = ci === 0 ? 'aprovada' : ['aprovada', 'conferir', 'aguardando', 'sem_folha'][j % 4];
          const numeroNF = m.nota_fiscal ? Number(m.nota_fiscal) : 7100 + j * 13 + ci * 200;
          m.nota_fiscal = null;
          if (cenario === 'sem_folha') return;
          const ult = db.medicoes.reduce((mx, x) => (x.contrato_id === c.id ? Math.max(mx, x.parcela || 0) : mx), 0);
          const parcela = Math.max(Number(c.parcelas_pagas_antes || 0), ult) + 1;
          if (c.parcelas_total && parcela > c.parcelas_total) return;
          const dFolha = U.addDias(U.addMes(comp, 1), 2 + (j % 3));
          const fsAprovada = cenario === 'aprovada' || cenario === 'conferir';
          Object.assign(m, { parcela, folha_numero: 'FS-' + (52000 + ci * 300 + j), folha_data: dFolha, descricao_nf: descricaoPadrao(c, comp, parcela),
            folha_por: 'demonstração', folha_em: dFolha + 'T10:00:00-03:00', folha_valor: m.valor_aprovado, folha_status: fsAprovada ? 'aprovada' : 'lancada',
            folha_aprovada_por: fsAprovada ? 'demonstração' : null, folha_aprovada_em: fsAprovada ? dFolha + 'T16:00:00-03:00' : null,
            finalizado_em: null, encaminhado_em: null, encaminhado_por: null });
          log('medicoes', m.id, f.id, 'folha de serviço lançada', { competencia: U.compCurta(comp), pedido: c.pedido, folha: m.folha_numero, parcela }, null, m.folha_em);
          const fsDoc = { id: uuid(), solicitacao_id: null, solicitacao_nf_id: null, fornecedor_id: f.id, contrato_id: c.id, competencia: comp, tipo: 'folha_servico',
            nome_arquivo: `FS ${m.folha_numero}.pdf`, caminho: `${pastaDe(f, comp)}/equipe/fs-${c.pedido}.pdf`, mime: U.MIME.pdf, tamanho: 36000 + j * 200,
            valor_lido: null, enviado_por: 'equipe', created_at: m.folha_em, hash_sha256: null, exemplo: { tipo: 'pedido', pedido: c.pedido, titulo: 'F.S. ' + m.folha_numero, fornecedor: f.nome, comp } };
          db.documentos.push(fsDoc);
          fsDoc.nome_padrao = nomeDoc(fsDoc);
          if (fsAprovada) {
            m.folha_anexos = [{ nome: fsDoc.nome_padrao, url: `https://demo.supabase.co/storage/v1/object/sign/boletins/${fsDoc.caminho}?token=demonstracao` }];
            log('medicoes', m.id, f.id, 'F.S. aprovada', { competencia: U.compCurta(comp), folha: m.folha_numero, parcela, valor: m.folha_valor }, null, m.folha_aprovada_em);
          }
          const pc = { id: uuid(), solicitacao_id: null, solicitacao_nf_id: null, fornecedor_id: f.id, contrato_id: c.id, competencia: comp, tipo: 'pedido_compra',
            nome_arquivo: `Pedido de compra ${c.pedido}.pdf`, caminho: `${pastaDe(f, comp)}/equipe/pedido-${c.pedido}.pdf`, mime: U.MIME.pdf, tamanho: 41000 + j * 300,
            valor_lido: null, enviado_por: 'equipe', created_at: m.folha_em, hash_sha256: null, exemplo: { tipo: 'pedido', pedido: c.pedido, titulo: c.titulo, fornecedor: f.nome, comp } };
          db.documentos.push(pc);
          pc.nome_padrao = nomeDoc(pc);
          const envio = cenario === 'aguardando' ? `${U.addDias(hoje, -2)}T11:00:00-03:00` : dFolha + 'T11:00:00-03:00';
          const n = novaSolicitacaoNF(m, envio);
          const anexos = [fsDoc, pc].map((d) => ({ nome: d.nome_padrao, url: `https://demo.supabase.co/storage/v1/object/sign/boletins/${d.caminho}?token=demonstracao`, caminho: d.caminho }));
          registrarEnvioNFDemo(n, 'app', n.emails_destino.length ? n.emails_destino : ['contato@exemplo.com.br'], null, null, anexos, false, envio);
          if (cenario === 'aguardando') return;
          const quando = `${U.addDias(dFolha, 2)}T15:${10 + (j % 40)}:00-03:00`;
          const valor = cenario === 'conferir' ? Math.round(m.valor_aprovado * 1.02 * 100) / 100 : Number(m.valor_aprovado);
          const cnpjForn = U.cnpjValido(f.cnpj) ? f.cnpj : '11.222.333/0001-81';
          const { xml } = U.NF.xmlExemplo({ cnpjEmitente: cnpjForn, nomeEmitente: f.nome, cnpjDestinatario: CNPJ_KLINGELE_DEMO, numero: numeroNF, valor,
            pedido: c.pedido, data: U.addDias(dFolha, 1), descricao: c.titulo, complemento: m.descricao_nf });
          const r = U.NF.conferir({ modelo: 'nfe', xml: U.NF.lerXml(xml), temXml: true, form: {}, competencia: comp, valorAprovado: m.valor_aprovado, pedido: c.pedido,
            cnpjFornecedor: f.cnpj, cnpjsKlingele: cnpjsKlg(), hoje });
          const doc = { id: uuid(), solicitacao_id: null, solicitacao_nf_id: n.id, fornecedor_id: f.id, contrato_id: c.id, competencia: comp, tipo: 'nota_fiscal',
            nome_arquivo: `DANFE ${numeroNF}.pdf`, caminho: `${n.pasta}/${n.token}/danfe-${numeroNF}.pdf`, mime: U.MIME.pdf, tamanho: 64000, valor_lido: null,
            enviado_por: 'fornecedor', created_at: quando, hash_sha256: null, exemplo: { tipo: 'nf', numero: numeroNF, fornecedor: f.nome, comp, total: valor } };
          db.documentos.push(doc);
          doc.nome_padrao = nomeDoc(doc);
          const aprovada = cenario === 'aprovada';
          const nf = { id: uuid(), solicitacao_nf_id: n.id, medicao_id: m.id, contrato_id: c.id, fornecedor_id: f.id, competencia: comp, ...r.nota, xml, documento_id: doc.id,
            status: aprovada ? 'aprovada' : 'em_conferencia', validacoes: r.itens, alertas: r.alertas, responsavel: (f.contatos && f.contatos[0] && f.contatos[0].nome) || 'Financeiro do fornecedor',
            observacao: null, conferido_por: aprovada ? 'demonstração' : null, conferido_em: aprovada ? `${U.addDias(dFolha, 4)}T09:00:00-03:00` : null, motivo_recusa: null, created_at: quando };
          db.notas_fiscais.push(nf);
          Object.assign(n, { status: aprovada ? 'aprovada' : 'recebida', aberto_em: quando, recebido_em: quando });
          log('notas_fiscais', nf.id, f.id, 'nota fiscal recebida', { competencia: U.compCurta(comp), pedido: c.pedido, parcela, numero: nf.numero, valor, alertas: r.alertas }, 'fornecedor (link da nota fiscal)', quando);
          if (aprovada) {
            m.nota_fiscal = String(nf.numero);
            log('notas_fiscais', nf.id, f.id, 'nota fiscal aprovada', { competencia: U.compCurta(comp), numero: nf.numero, valor }, null, nf.conferido_em);
            // F.S. aprovada + NF aprovada: encaminhada a Serviços (fim do processo)
            const enc = `${U.addDias(dFolha, 4)}T09:05:00-03:00`, para = cfgLista('fs_emails_servicos').concat(cfgLista('fs_emails_ocorrencia'));
            Object.assign(m, { encaminhado_em: enc, encaminhado_por: 'encaminhamento automático', finalizado_em: enc });
            db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: null, solicitacao_nf_id: null, medicao_id: m.id, contrato_id: null, fornecedor_id: f.id,
              competencia: comp, tipo: 'nf_servicos', via: 'automatico', para, assunto: `NOTA FISCAL ${nf.numero} - ${f.nome} - PEDIDO ${c.pedido} - ${U.mesNome(comp)}/${comp.slice(0, 4)}`,
              corpo: '', prazo_ate: null, status: 'aceito', erro: null, autor: 'encaminhamento automático', created_at: enc });
            log('medicoes', m.id, f.id, 'NF encaminhada a Serviços · processo finalizado', { competencia: U.compCurta(comp), nf: nf.numero, para, via: 'automatico' }, 'encaminhamento automático', enc);
          }
        });
      });
    }

    // ---------- Encaminhamento da NF a Serviços (mesma regra do banco) ----------
    const emailPronto = () => !!db.config.__chave_email && !!conf('email_remetente', '') && !!conf('site_url', '');
    const notaParaServicos = (mid) => db.notas_fiscais.filter((x) => x.medicao_id === mid && ['em_conferencia', 'aprovada'].includes(x.status))
      .sort((a, b) => (a.status === 'aprovada') === (b.status === 'aprovada') ? (a.created_at < b.created_at ? 1 : -1) : (a.status === 'aprovada' ? -1 : 1))[0] || null;
    function destinatariosServicos(m, autor) {
      const aviso = (email) => { const u = (db.usuarios || []).find((x) => (x.email || '').toLowerCase() === String(email || '').toLowerCase()); return u ? (u.email_aviso || u.email) : null; };
      return [...new Set(cfgLista('fs_emails_servicos').concat(cfgLista('fs_emails_ocorrencia'), [aviso(m.folha_aprovada_por), aviso(autor)].filter(Boolean).map((x) => x.toLowerCase())))].filter(U.emailValido);
    }
    function situacaoServicos(mid) {
      const m = db.medicoes.find((x) => x.id === mid);
      if (m.encaminhado_em) return 'encaminhado';
      const nf = notaParaServicos(mid);
      if (!nf) return 'nf';
      if (m.folha_status !== 'aprovada') return 'fs';
      if (nf.status === 'em_conferencia' && nf.alertas > 0) return 'conferencia';
      if (!destinatariosServicos(m, null).length) return 'sem_destinatario';
      return 'pronto';
    }
    function anexosServicos(m, nf) {
      return (m.folha_anexos || []).map((a) => ({ nome: a.nome, url: a.url })).concat(nf.anexos || [], nf.xml ? [{ nome: 'NF-' + String(nf.numero || 'nota').replace(/[^A-Za-z0-9-]/g, '') + '.xml' }] : []);
    }
    function emailServicos(m, nf) {
      const c = contr(m.contrato_id), f = forn(m.fornecedor_id);
      return U.montarEmailFS({ modeloAssunto: conf('modelo_fs_assunto', ''), modeloCorpo: conf('modelo_fs_corpo', ''), fornecedor: f.nome, competencia: m.competencia, pedido: c.pedido,
        servico: c.titulo, folha: m.folha_numero, folhaData: m.folha_data, parcela: m.parcela, parcelasTotal: c.parcelas_total, valor: m.folha_valor ?? m.valor_aprovado,
        aprovadoPor: m.folha_aprovada_por, anexos: anexosServicos(m, nf), descricao: m.descricao_nf, nfModelo: nf.modelo, nfNumero: nf.numero, nfSerie: nf.serie, nfValor: nf.valor, nfEmissao: nf.data_emissao });
    }
    function encaminharServ(mid, autor, via, para, assunto, corpo) {
      const m = db.medicoes.find((x) => x.id === mid);
      if (!m) return { ok: false, motivo: 'medicao' };
      if (m.encaminhado_em) return { ok: false, motivo: 'encaminhado' };
      if (m.folha_status !== 'aprovada') return { ok: false, motivo: 'fs' };
      const nf = notaParaServicos(mid);
      if (!nf) return { ok: false, motivo: 'nf' };
      const e = emailServicos(m, nf);
      const dest = via === 'outlook' ? para : destinatariosServicos(m, autor);
      if (!dest.length) return { ok: false, motivo: 'sem_destinatario' };
      db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: null, solicitacao_nf_id: null, medicao_id: m.id, contrato_id: null, fornecedor_id: m.fornecedor_id,
        competencia: m.competencia, tipo: 'nf_servicos', via, para: dest, assunto: via === 'outlook' ? String(assunto || e.assunto).replace(/[\r\n]+/g, ' ').slice(0, 400) : e.assunto,
        corpo: via === 'outlook' ? corpo || e.corpo : e.corpo, prazo_ate: null, status: via === 'outlook' ? 'registrado' : 'aceito', erro: null, autor, created_at: agora() });
      if (nf.status === 'em_conferencia') {
        Object.assign(nf, { status: 'aprovada', conferido_por: via === 'automatico' ? 'conferência automática' : autor, conferido_em: agora(), motivo_recusa: null });
        const sn = db.solicitacoes_nf.find((x) => x.id === nf.solicitacao_nf_id); if (sn) sn.status = 'aprovada';
        log('notas_fiscais', nf.id, nf.fornecedor_id, 'nota fiscal aprovada', { competencia: U.compCurta(nf.competencia), numero: nf.numero, valor: nf.valor, alertas: nf.alertas, no_encaminhamento: true }, autor);
      }
      Object.assign(m, { nota_fiscal: String(nf.numero).slice(0, 60), encaminhado_em: agora(), encaminhado_por: autor, finalizado_em: agora() });
      log('medicoes', m.id, m.fornecedor_id, 'NF encaminhada a Serviços · processo finalizado', { competencia: U.compCurta(m.competencia), nf: nf.numero, para: dest, via }, autor);
      return { ok: true, para: dest, assunto: e.assunto, via };
    }
    function encaminharAuto(mid) {
      if (conf('nf_encaminhar_automatico', 'true') !== 'true') return { ok: false, motivo: 'manual' };
      const s = situacaoServicos(mid);
      if (s !== 'pronto') return { ok: false, motivo: s };
      if (!emailPronto()) return { ok: false, motivo: 'email' };
      return encaminharServ(mid, 'encaminhamento automático', 'automatico');
    }

    function exigirEmailConfigurado() {
      if (!db.config.__chave_email || !conf('email_remetente', '') || !conf('site_url', '')) throw new Error('Envio pelo app ainda não configurado: preencha Configurações > Envio de e-mail pelo app');
    }
    function dadosPortal(s) {
      const f = forn(s.fornecedor_id);
      const meds = db.medicoes.filter((m) => m.solicitacao_id === s.id);
      return {
        ok: true, competencia: s.competencia, mes: U.mesNome(s.competencia), ano: Number(s.competencia.slice(0, 4)), expira_em: s.expira_em,
        pasta_upload: s.pasta + '/' + s.token, contato: suporteDemo()[0] || '', suporte: emailsDe(contratosDoLink(s)),
        contatos_klingele: contatosDe(contratosDoLink(s)), contatos_servicos: contatosServicos(contratosDoLink(s)),
        feriados: db.feriados.map((x) => x.data).filter((x) => x >= U.hojeISO() && x <= U.dataLocal(s.expira_em)),
        fornecedor: { nome: f.nome, codigo: f.codigo, cnpj: f.cnpj },
        contatos: db.contatos.filter((c) => c.fornecedor_id === f.id).sort((a, b) => b.principal - a.principal)
          .map((c) => ({ id: c.id, nome: c.nome, email: c.email, telefone: c.telefone, recebe_boletim: c.recebe_boletim })),
        contratos: meds.map((m) => db.contratos.find((c) => c.id === m.contrato_id)).filter(Boolean)
          .sort((a, b) => a.pedido - b.pedido).map((c) => ({ id: c.id, pedido: c.pedido, titulo: c.titulo })),
        documentos_klingele: docsKlgDemo(s).map((d) => ({ id: d.id, nome: d.nome_padrao || d.nome_arquivo, nome_arquivo: d.nome_arquivo, caminho: d.caminho, tamanho: d.tamanho, mime: d.mime, enviado_em: d.created_at })),
        pede_docs_klingele: !!f.docs_klingele
      };
    }
    // Simula o envio pelo serviço de e-mail (na demonstração todo envio é aceito)
    function enviarDemo(s, via, paraEscolhido, manterPrazo) {
      if (!['gerado', 'enviado', 'aberto'].includes(s.status) || s.expira_em < agora()) return { ok: false, motivo: 'status' };
      const f = forn(s.fornecedor_id);
      const para = paraEscolhido ? [...new Set(paraEscolhido.map((e) => e.trim().toLowerCase()))]
        : db.contatos.filter((x) => x.fornecedor_id === s.fornecedor_id && x.recebe_boletim).map((x) => x.email);
      if (!para.length) { s.envio_status = 'falha'; s.envio_erro = 'Fornecedor sem e-mail cadastrado'; return { ok: false, motivo: 'sem_email' }; }
      const ja = !!s.enviado_em || db.envios_email.some((e) => e.solicitacao_id === s.id);
      const lembrete = manterPrazo && ja;
      if (!lembrete) s.expira_em = U.fimPrazoISO(agora(), Number(conf('prazo_dias_uteis', 7)), feriadosSet());
      const tipo = lembrete ? 'lembrete' : ja ? 'reenvio' : 'envio';
      const m = U.montarEmail({ modeloAssunto: conf('modelo_assunto', ''), modeloCorpo: conf('modelo_corpo', ''), fornecedor: f.nome, competencia: s.competencia,
        servicos: db.medicoes.filter((x) => x.fornecedor_id === f.id && x.competencia === s.competencia).map((x) => db.contratos.find((k) => k.id === x.contrato_id)).filter(Boolean),
        link: conf('site_url', '').replace(/\/$/, '') + '/portal.html#' + s.token, prazoISO: s.expira_em, prazoDias: Number(conf('prazo_dias_uteis', 7)),
        suporte: contatosDemo(), suporteServicos: servicosSuporte(contratosDoLink(s)), documentos: docsKlgDemo(s).map((d) => d.nome_padrao || d.nome_arquivo) });
      if (lembrete) m.assunto = 'LEMBRETE - ' + m.assunto;
      Object.assign(s, { enviado_em: agora(), emails_destino: para, assunto: m.assunto, corpo: m.corpo, envio_via: via, envio_status: 'ok', envio_erro: null,
        status: s.status === 'gerado' ? 'enviado' : s.status });
      db.envios_email.push({ id: uuid(), solicitacao_id: s.id, avaliacao_id: null, fornecedor_id: f.id, competencia: s.competencia, tipo, via, para, assunto: m.assunto, corpo: m.corpo,
        prazo_ate: s.expira_em, status: 'aceito', erro: null, autor: 'demonstração', created_at: agora() });
      log('solicitacoes', s.id, f.id, { envio: 'e-mail enviado pelo app', reenvio: 'e-mail reenviado pelo app', lembrete: 'lembrete enviado pelo app' }[tipo], { para, assunto: m.assunto });
      if (tipo === 'envio') avaliacaoJuntoDemo(s);
      return { ok: true, tipo, expira_em: s.expira_em };
    }
    // Avaliação de satisfação vai junto com a solicitação do mês (primeiro envio); sem envio pelo app, fica gerada
    function avaliacaoJuntoDemo(s) {
      const p = pastaD(s.pasta_envio_id);
      if (p ? p.avaliacao === false : conf('avaliacao_junto', 'true') !== 'true') return;
      gerarAval(s.competencia, [s.fornecedor_id]);
      if (!emailPronto()) return;
      db.avaliacoes.filter((a) => a.fornecedor_id === s.fornecedor_id && a.competencia === s.competencia && a.status === 'gerada').forEach((a) => enviarAvalDemo(a, 'app', null, false));
    }


    // ---------- Fluxo do mês: cobrança, F.S. aprovada e aviso de vencimento (mesmas regras do banco) ----------
    const cfgNum = (k, p) => Number(conf(k, p)) || p;
    function cobrancaEtapa(s) {
      const auto = db.envios_email.filter((e) => e.solicitacao_id === s.id && e.autor === 'cobrança automática').sort((a, b) => (a.created_at < b.created_at ? -1 : 1));
      const n = auto.length, ult = n ? auto[n - 1].created_at : null, max = cfgNum('cobranca_lembretes_max', 4);
      if (!s.enviado_em || s.recebido_em || !['enviado', 'aberto', 'expirado'].includes(s.status)) return { devida: false, etapa: 'fora', feitas: n };
      if (!n) return { devida: s.expira_em < agora(), etapa: 'reenvio', dias: cfgNum('cobranca_reenvio_dias', 10), feitas: 0, quando: s.expira_em };
      if (n - 1 >= max) return { devida: false, etapa: 'encerrada', feitas: n };
      const prox = new Date(new Date(ult).getTime() + cfgNum('cobranca_intervalo_dias', 7) * 86400000).toISOString();
      return { devida: s.expira_em < agora() || (n > 1 && prox <= agora()), etapa: 'semanal', dias: cfgNum('cobranca_semanal_dias', 5), feitas: n, semana: n, de: max,
        quando: n > 1 && prox < s.expira_em ? prox : s.expira_em };
    }
    function cobrar(via) {
      let re = 0, sem = 0; const falta = [];
      db.solicitacoes.filter((s) => s.competencia >= U.addMes(U.compDe(U.hojeISO()), -3)).forEach((s) => {
        const e = cobrancaEtapa(s);
        if (!e.devida) return;
        const f = forn(s.fornecedor_id);
        const para = db.contatos.filter((c) => c.fornecedor_id === s.fornecedor_id && c.recebe_boletim).map((c) => c.email);
        if (!para.length) { falta.push(f.nome); return; }
        if (s.status === 'expirado') s.status = s.aberto_em ? 'aberto' : 'enviado';
        s.expira_em = U.fimPrazoISO(agora(), e.dias, feriadosSet());
        const m = U.montarEmail({ modeloAssunto: conf('modelo_assunto', ''), modeloCorpo: conf('modelo_corpo', ''), fornecedor: f.nome, competencia: s.competencia,
          servicos: db.medicoes.filter((x) => x.fornecedor_id === f.id && x.competencia === s.competencia).map((x) => contr(x.contrato_id)).filter(Boolean),
          link: (conf('site_url', '') || 'https://seu-site.netlify.app').replace(/\/$/, '') + '/portal.html#' + s.token, prazoISO: s.expira_em, prazoDias: e.dias,
          suporte: contatosDemo(), suporteServicos: servicosSuporte(contratosDoLink(s)) });
        Object.assign(s, { enviado_em: agora(), emails_destino: para, assunto: 'LEMBRETE - ' + m.assunto, corpo: m.corpo, envio_via: via, envio_status: 'ok' });
        db.envios_email.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: f.id, competencia: s.competencia, tipo: e.etapa === 'reenvio' ? 'reenvio' : 'lembrete', via,
          para, assunto: s.assunto, corpo: m.corpo, prazo_ate: s.expira_em, status: 'aceito', erro: null, autor: 'cobrança automática', created_at: agora() });
        log('solicitacoes', s.id, f.id, e.etapa === 'reenvio' ? 'cobrança: link reenviado com novo prazo' : 'cobrança: lembrete semanal',
          { competencia: U.compCurta(s.competencia), prazo_dias_uteis: e.dias }, 'cobrança automática');
        if (e.etapa === 'reenvio') re++; else sem++;
      });
      return { ok: true, reenvios: re, lembretes: sem, sem_email: falta };
    }
    function destinatariosVenc(c) {
      const sups = supsDe(c).map(colab).filter((co) => co && co.ativo && co.email).map((co) => co.email.toLowerCase());
      return [...new Set([...sups, ...cfgLista('alerta_venc_emails')].filter((e) => e && U.emailValido(e)))];
    }
    function emailVenc(c) {
      const nomes = supsDe(c).map(colab).filter(Boolean).map((co) => co.nome), f = forn(c.fornecedor_id);
      return U.montarEmailVenc({ modeloAssunto: conf('modelo_venc_assunto', ''), modeloCorpo: conf('modelo_venc_corpo', ''), fornecedor: f ? f.nome : '', pedido: c.pedido,
        servico: c.titulo, supervisor: nomes.length ? nomes.join(', ') : null, dataInicio: c.data_inicio, dataFim: c.data_fim });
    }
    function registrarAviso(c, para, via, quando) {
      const e = emailVenc(c);
      db.alertas = db.alertas.filter((a) => !(a.contrato_id === c.id && a.data_fim === c.data_fim));
      db.alertas.push({ id: uuid(), contrato_id: c.id, data_fim: c.data_fim, dias_antes: U.alertaDias(c, db.config), para, status: 'enviado', created_at: quando || agora() });
      db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: null, solicitacao_nf_id: null, medicao_id: null, contrato_id: c.id, fornecedor_id: c.fornecedor_id,
        competencia: U.compDe(U.hojeISO()), tipo: 'vencimento', via, para, assunto: e.assunto, corpo: e.corpo, prazo_ate: null,
        status: via === 'outlook' ? 'registrado' : 'aceito', erro: null, autor: via === 'automatico' ? 'aviso de vencimento' : 'demonstração', created_at: quando || agora() });
      log('contratos', c.id, c.fornecedor_id, via === 'outlook' ? 'aviso de vencimento registrado (Outlook)' : 'aviso de vencimento enviado',
        { pedido: c.pedido, data_fim: c.data_fim, para }, via === 'automatico' ? 'aviso de vencimento' : null, quando);
      return e;
    }
    function avisarVencimentosDemo(quando) {
      if (conf('alerta_venc_automatico', 'true') !== 'true') return { ok: true, desligado: true };
      const hoje = U.hojeISO();
      let ok = 0, semDest = 0;
      db.contratos.filter((c) => c.situacao === 'ativo' && c.data_fim && c.data_fim >= hoje && !db.alertas.some((a) => a.contrato_id === c.id && a.data_fim === c.data_fim))
        .forEach((c) => {
          if (hoje < U.addDias(c.data_fim, -U.alertaDias(c, db.config))) return;
          const para = destinatariosVenc(c);
          if (!para.length) { semDest++; return; }
          registrarAviso(c, para, 'automatico', quando); ok++;
        });
      return { ok: true, avisados: ok, sem_destinatario: semDest, pendentes: 0 };
    }
    const meuUsuario = () => db.usuarios.find((x) => x.usuario === 'Gsilv1');
    const noPeriodo = (iso, f) => { if (!f || (!f.de && !f.ate)) return true; const d = U.dataLocal(iso); return (!f.de || d >= f.de) && (!f.ate || d <= f.ate); };
    const travadas = (fid, comp, sid) => [...new Set(db.medicoes.filter((m) => m.fornecedor_id === fid && m.competencia === comp && (!sid || m.solicitacao_id === sid) && (m.folha_numero || m.status === 'pago' || nfPedida(m.id)))
      .map((m) => contr(m.contrato_id).pedido))].join(', ') || null;
    const comFornecedorContatos = () => db.fornecedores.map((f) => ({ ...clone(f), contatos: clone(db.contatos.filter((c) => c.fornecedor_id === f.id)) }));
    const atualizar = (lista, id, patch) => { const o = lista.find((x) => x.id === id); if (o) Object.assign(o, patch, { updated_at: agora() }); return o; };

    const api = {
      modo: 'demo',
      async init() {
        const salvo = U.storage.get(CHAVE, null);
        if (salvo && salvo.versao === 17) db = salvo; else semear();
      },
      restaurar() { U.storage.del(CHAVE); semear(); },
      async sessao() { return { email: (meuUsuario() || {}).email || 'demonstração' }; },
      async entrar() { return api.sessao(); },
      async sair() { /* demonstração */ },
      async recuperarSenha() { /* demonstração */ },
      async definirSenha() { /* demonstração */ },
      onAuth() { /* demonstração */ },
      async souEquipe() { return true; },
      async situacaoAcesso() {
        const u = db.usuarios.find((x) => x.usuario === 'Gsilv1') || {};
        return { liberado: true, papel: 'admin', exige_mfa: false, aal: 'aal1', email: u.email || 'demonstração',
          cadastro: { status: 'aprovado', usuario: u.usuario, nome: u.nome, papel: 'admin', cargo: u.cargo || null, telefone: u.telefone || null, email_aviso: u.email_aviso || null,
            supervisor_id: u.supervisor_id || null, colaborador_id: u.colaborador_id || null, admin_id: null, admin: null } };
      },
      async mfaNivel() { return { atual: 'aal1', proximo: 'aal1' }; },
      async mfaFatores() { return []; },
      async mfaIniciar() { throw new Error('A verificação em duas etapas funciona no site publicado (precisa do login real do Supabase).'); },
      async mfaConfirmar() { throw new Error('Disponível no site publicado.'); },
      async mfaEntrar() { throw new Error('Disponível no site publicado.'); },
      async mfaRemover() { throw new Error('Disponível no site publicado.'); },
      async registrarEvento(acao, entidade, id, fornecedorId, detalhes) { log(entidade || 'acesso', id || null, fornecedorId || null, acao, detalhes || {}); salvar(); },
      async emailConfigurado() {
        return { chave: !!db.config.__chave_email, remetente: !!conf('email_remetente', ''), site: !!conf('site_url', ''),
          provedor: conf('email_provedor', 'resend'), automatico: conf('envio_automatico', 'false') === 'true' };
      },
      async definirChaveEmail(chave) {
        if (!chave || String(chave).trim().length < 10) throw new Error('Chave inválida');
        db.config.__chave_email = true; log('configuracoes', null, null, 'chave de e-mail atualizada', {}); salvar(); return { ok: true };
      },
      async enviarSolicitacoes(comp, ids) {
        exigirEmailConfigurado();
        if (!ids && !U.compLiberada(comp, feriadosSet())) throw new Error('Só é possível solicitar o boletim de meses encerrados (ou do mês atual a partir do último dia útil)');
        if (!ids) gerar(comp, null);
        let ok = 0; const sem = [], aguardando = [];
        db.solicitacoes.filter((s) => s.competencia === comp && (ids ? ids.includes(s.id) && ['gerado', 'enviado', 'aberto'].includes(s.status) : s.status === 'gerado' && s.pasta_envio_id === (padraoDemo() || {}).id))
          .forEach((s) => {
            if (!ids && aguardaDocsDemo(s)) { aguardando.push(forn(s.fornecedor_id).nome); return; }
            const r = enviarDemo(s, 'app', null, false); if (r.ok) ok++; else if (r.motivo === 'sem_email') sem.push(forn(s.fornecedor_id).nome);
          });
        salvar();
        return { ok: true, enviados: ok, sem_email: sem, aguardando_docs: aguardando };
      },
      async reenviar(id, para, manterPrazo) {
        exigirEmailConfigurado();
        const s = db.solicitacoes.find((x) => x.id === id);
        if (['recebido', 'conferido'].includes(s.status)) throw new Error('O fornecedor já respondeu. Use "Liberar novo envio" para mandar outro link.');
        if (['expirado', 'cancelado'].includes(s.status) || s.expira_em < agora()) throw new Error('O link não está mais válido. Use "Gerar novo link e reenviar".');
        if (para && (para.length > 15 || para.some((e) => !U.emailValido(e)))) throw new Error('Confira os e-mails escolhidos (até 15 válidos)');
        const r = enviarDemo(s, 'app', para && para.length ? para : null, manterPrazo);
        if (!r.ok) throw new Error('Fornecedor sem e-mail cadastrado');
        salvar(); return r;
      },
      async lembretePendentes(comp) {
        exigirEmailConfigurado();
        let ok = 0; const sem = [];
        db.solicitacoes.filter((s) => s.competencia === comp && ['enviado', 'aberto'].includes(s.status) && s.expira_em > agora())
          .forEach((s) => { const r = enviarDemo(s, 'app', null, true); if (r.ok) ok++; else if (r.motivo === 'sem_email') sem.push(forn(s.fornecedor_id).nome); });
        salvar();
        return { ok: true, enviados: ok, sem_email: sem };
      },
      async enviosDe(id) { return clone(db.envios_email.filter((e) => e.solicitacao_id === id)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },
      async enviosCompetencia(comp) { return clone(db.envios_email.filter((e) => e.competencia === comp)); },
      async portalPrevia(id) {
        const s = db.solicitacoes.find((x) => x.id === id);
        const contato = suporteDemo()[0] || '', suporte = suporteDemo(), contatos_klingele = contatosDemo();
        if (!s) return { ok: false, motivo: 'invalido', contato, previa: true, suporte, contatos_klingele };
        if (['recebido', 'conferido'].includes(s.status)) return { ok: false, motivo: 'usado', recebido_em: s.recebido_em, contato, previa: true, suporte, contatos_klingele };
        if (s.status === 'cancelado') return { ok: false, motivo: 'cancelado', contato, previa: true, suporte, contatos_klingele };
        if (s.status === 'expirado' || s.expira_em < agora()) return { ok: false, motivo: 'expirado', expira_em: s.expira_em, contato, previa: true, suporte, contatos_klingele };
        return { ...dadosPortal(s), pasta_upload: null, previa: true };
      },
      async conferirEnvios() { return { ok: true }; },

      // ---------- Documentos da Klingele e envio dispensado (demonstração) ----------
      async urlDocPortal(doc) {
        if (arquivos[doc.caminho]) return URL.createObjectURL(arquivos[doc.caminho]);
        const d = db.documentos.find((x) => x.id === doc.id || x.caminho === doc.caminho);
        if (d && d.exemplo) return URL.createObjectURL(pdfDeExemplo(d.exemplo));
        throw new Error('Arquivo indisponível nesta demonstração (os anexos ficam só na aba em que foram enviados).');
      },
      async docsPrevia(id) {
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!s) return { ok: false, motivo: 'invalido', previa: true };
        const sit = situacaoDocsDemo(s);
        if (sit) return { ...sit, previa: true, contatos_klingele: contatosDemo() };
        return { ...dadosDocs(s), pasta_upload: null, previa: true };
      },
      async docsAbrir(token) {
        const s = db.solicitacoes.find((x) => x.docs_token && x.docs_token === token);
        if (!s) return { ok: false, motivo: 'invalido', contatos_klingele: contatosDemo() };
        const sit = situacaoDocsDemo(s);
        if (sit) return { ...sit, contatos_klingele: contatosDemo(), fornecedor: { nome: forn(s.fornecedor_id).nome }, mes: U.mesNome(s.competencia), ano: Number(s.competencia.slice(0, 4)) };
        if (!s.docs_aberto_em) { s.docs_aberto_em = agora(); log('solicitacoes', s.id, s.fornecedor_id, 'link de documentos aberto pelo colaborador', { competencia: U.compCurta(s.competencia) }, 'colaborador (documentos)'); salvar(); }
        return dadosDocs(s);
      },
      async docsEnviarArquivo(pastaUpload, file, i) {
        const ext = U.extensao(file.name);
        const caminho = `${pastaUpload}/${(U.slug(file.name.replace(/\.[^.]+$/, '')) || 'documento').slice(0, 60)}--${Date.now().toString(36)}${i}.${ext}`;
        arquivos[caminho] = file;
        return caminho;
      },
      async docsFinalizar(token, dados) {
        const s = db.solicitacoes.find((x) => x.docs_token && x.docs_token === token);
        if (!s) return { ok: false, erro: 'Link inválido' };
        const sit = situacaoDocsDemo(s);
        if (sit) return { ...sit, erro: sit.motivo === 'dispensado' ? 'O envio deste mês já foi dispensado.' : sit.motivo === 'respondido' ? 'O fornecedor já enviou o boletim deste mês.' : 'Este link não vale mais.' };
        const nome = String(dados.nome || '').trim();
        if (nome.length < 2 || nome.length > 120) return { ok: false, erro: 'Informe seu nome.' };
        const quem = nome + ' (colaborador)';
        if (dados.acao === 'dispensar') {
          if (!['sem_medicao', 'sem_contrato'].includes(dados.motivo)) return { ok: false, erro: 'Escolha: não houve medição ou não há contrato no mês.' };
          dispensarDemo(s, dados.motivo, (dados.observacao || '').trim() || null, quem); salvar();
          return { ok: true, acao: 'dispensar', dispensa: s.dispensa, em: s.dispensa_em };
        }
        const arqs = Array.isArray(dados.arquivos) ? dados.arquivos : [];
        if (dados.acao !== 'enviar' || !arqs.length) return { ok: false, erro: 'Anexe pelo menos um documento.' };
        if (arqs.length + docsKlgDemo(s).length > 15) return { ok: false, erro: 'No máximo 15 documentos por fornecedor no mês.' };
        const pref = s.pasta + '/' + s.docs_token + '/';
        if (arqs.some((a) => !a.caminho || !a.caminho.startsWith(pref) || !arquivos[a.caminho] || db.documentos.some((d) => d.caminho === a.caminho))) return { ok: false, erro: 'Um dos arquivos não foi encontrado. Anexe de novo.' };
        arqs.forEach((a) => {
          const d = { id: uuid(), solicitacao_id: s.id, fornecedor_id: s.fornecedor_id, contrato_id: null, competencia: s.competencia, tipo: 'klingele',
            nome_arquivo: String(a.nome || 'documento').slice(0, 200), caminho: a.caminho, mime: a.mime || null, tamanho: a.tamanho || null, valor_lido: null,
            enviado_por: 'colaborador', created_at: agora() };
          d.nome_padrao = nomeDoc(d); db.documentos.push(d);
        });
        Object.assign(s, { docs_enviado_em: agora(), docs_por: nome });
        log('solicitacoes', s.id, s.fornecedor_id, 'documentos da Klingele anexados', { competencia: U.compCurta(s.competencia), arquivos: arqs.length }, quem);
        let enviado = false, semEmail = false;
        const pronto = !!(db.config.__chave_email && conf('email_remetente', '') && conf('site_url', ''));
        const ja = s.status !== 'gerado';
        if (pronto && (!ja || dados.avisar !== false)) { const r = enviarDemo(s, 'app', null, ja); enviado = !!r.ok; semEmail = r.motivo === 'sem_email'; }
        salvar();
        return { ok: true, acao: 'enviar', anexados: arqs.length, link_enviado: enviado, ja_enviado: ja, sem_email: semEmail };
      },
      async dispensarEnvio(id, motivo, obs, fornId, comp, pastaId) {
        let s = id ? db.solicitacoes.find((x) => x.id === id) : null;
        if (!s) {
          if (comp > U.compDe(U.hojeISO())) throw new Error('Só dá para dispensar o mês atual ou meses anteriores');
          s = gerar(comp, [fornId], null, pastaId || null)[0];
          if (!s) throw new Error('Este fornecedor não tem pedido nesta pasta no mês');
        }
        dispensarDemo(s, motivo, obs, (meuUsuario() || {}).email || 'demonstração'); salvar();
        return { ok: true, id: s.id, dispensa: s.dispensa };
      },
      async reativarEnvio(id) {
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!s || !s.dispensa || s.status !== 'cancelado') throw new Error('Este link não está dispensado');
        if (db.solicitacoes.some((x) => x.id !== s.id && x.fornecedor_id === s.fornecedor_id && x.competencia === s.competencia && (x.pasta_envio_id || null) === (s.pasta_envio_id || null) && !['expirado', 'cancelado'].includes(x.status))) throw new Error('Já existe outro link deste fornecedor nesta pasta no mês');
        Object.assign(s, { status: 'gerado', dispensa: null, dispensa_obs: null, dispensa_por: null, dispensa_em: null, expira_em: U.fimPrazoISO(agora(), prazoLinkDemo(s.pasta_envio_id), feriadosSet()) });
        db.medicoes.filter((m) => m.solicitacao_id === s.id && m.status === 'sem_medicao' && m.valor_informado === null).forEach((m) => { m.status = 'aguardando'; });
        log('solicitacoes', s.id, s.fornecedor_id, 'envio reativado no mês', { competencia: U.compCurta(s.competencia) }); salvar();
        return { ok: true, id: s.id };
      },
      async pedirDocsKlingele(id) {
        exigirEmailConfigurado();
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!s || !docsLinkOk(s)) throw new Error('O link deste fornecedor já foi respondido, dispensado ou venceu');
        pedirDocsDemo([s], (meuUsuario() || {}).email || 'demonstração'); salvar();
        const c = colabDocsDemo(forn(s.fornecedor_id));
        return { ok: true, pedidos: 1, para: c ? c.email : 'analistas' };
      },

      // ---------- Cadastro e usuários ----------
      async cadastroOpcoes() {
        return { aberto: conf('cadastro_aberto', 'true') === 'true', dominios: cfgLista('cadastro_dominios').map((d) => d.replace(/^@/, '')),
          admins: db.usuarios.filter((u) => u.status === 'aprovado' && u.papel === 'admin').map((u) => ({ id: u.id, nome: u.nome })),
          responsaveis: db.usuarios.filter((u) => u.status === 'aprovado' && ['admin', 'supervisor'].includes(u.papel))
            .sort((a, b) => (a.papel === b.papel ? a.nome.localeCompare(b.nome) : a.papel === 'admin' ? -1 : 1))
            .map((u) => ({ id: u.id, nome: u.nome, papel: u.papel, admin: u.admin_id ? (db.usuarios.find((x) => x.id === u.admin_id) || {}).nome || null : null })) };
      },
      async usuarioLivre(u) { return U.usuarioValido(u) && !db.usuarios.some((x) => x.usuario.toLowerCase() === String(u).trim().toLowerCase()); },
      async cadastrar(d) {
        const email = String(d.email || '').trim().toLowerCase();
        if (!U.emailValido(email)) throw new Error('E-mail inválido');
        const dom = cfgLista('cadastro_dominios').map((x) => x.replace(/^@/, ''));
        if (dom.length && !dom.includes(email.split('@')[1])) throw new Error(`Cadastro permitido só para e-mails da Klingele (${dom.join(', ')}).`);
        if (db.usuarios.some((x) => x.email === email)) throw new Error('Este e-mail já tem cadastro. Use "Entrar" ou "Esqueci a senha".');
        if (!(await api.usuarioLivre(d.usuario))) throw new Error('Este usuário já existe ou é inválido. Escolha outro.');
        const resp = d.aprovador_id && db.usuarios.find((x) => x.id === d.aprovador_id && x.status === 'aprovado' && ['admin', 'supervisor'].includes(x.papel));
        const u = { id: uuid(), email, usuario: String(d.usuario).trim(), nome: String(d.nome).trim(), cargo: d.cargo || null, telefone: d.telefone || null, email_aviso: null,
          status: 'pendente', papel: null, aprovador_id: resp ? resp.id : null, admin_id: null, supervisor_id: null, colaborador_id: null, motivo: null, decidido_por: null, decidido_em: null,
          created_at: agora(), updated_at: agora() };
        db.usuarios.unshift(u);
        log('usuarios', u.id, null, 'conta criada', { usuario: u.usuario, email: u.email, status: 'pendente' }, u.email);
        salvar(); return { sessao: false, demo: true };
      },
      async usuarios() { return clone(db.usuarios).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },
      async salvarUsuario(id, d) {
        const u = db.usuarios.find((x) => x.id === id);
        if (!u) throw new Error('Usuário não encontrado');
        const v = { ...u };
        ['status', 'papel', 'nome', 'usuario', 'cargo', 'telefone', 'email_aviso', 'supervisor_id', 'colaborador_id', 'aprovador_id', 'admin_id', 'motivo'].forEach((k) => { if (k in d) v[k] = d[k] === '' ? null : d[k]; });
        if (!['pendente', 'aprovado', 'recusado', 'bloqueado'].includes(v.status)) throw new Error('Situação inválida');
        if (v.papel && !['admin', 'supervisor', 'analista', 'leitura'].includes(v.papel)) throw new Error('Perfil inválido');
        if (v.status === 'aprovado' && !v.papel) throw new Error('Escolha o perfil (admin, supervisor, analista ou leitura) para aprovar');
        if (v.aprovador_id && !db.usuarios.some((x) => x.id === v.aprovador_id && x.status === 'aprovado' && ['admin', 'supervisor'].includes(x.papel))) throw new Error('Escolha um administrador ou supervisor como responsável');
        if (v.admin_id && !db.usuarios.some((x) => x.id === v.admin_id && x.status === 'aprovado' && x.papel === 'admin')) throw new Error('Escolha um administrador aprovado para o supervisor');
        if (v.papel === 'supervisor') v.admin_id = v.admin_id || (meuUsuario() || {}).id || null; else v.admin_id = null;
        if (!v.nome || v.nome.trim().length < 2) throw new Error('Informe o nome');
        if (!U.usuarioValido(v.usuario)) throw new Error('Usuário inválido: use de 3 a 30 letras, números, ponto, hífen ou sublinhado');
        if (db.usuarios.some((x) => x.id !== id && x.usuario.toLowerCase() === v.usuario.toLowerCase())) throw new Error('Este usuário já existe');
        if (v.email_aviso && !U.emailValido(v.email_aviso)) throw new Error('E-mail de aviso inválido');
        if (['recusado', 'bloqueado'].includes(v.status) && String(v.motivo || '').trim().length < 3) throw new Error('Informe o motivo (o usuário verá este texto)');
        if (u.id === (meuUsuario() || {}).id && (v.status !== 'aprovado' || v.papel !== 'admin')) throw new Error('Você não pode tirar o seu próprio acesso de administrador');
        const outros = db.usuarios.filter((x) => x.id !== id && x.status === 'aprovado' && x.papel === 'admin').length;
        if (u.status === 'aprovado' && u.papel === 'admin' && (v.status !== 'aprovado' || v.papel !== 'admin') && !outros) throw new Error('É preciso manter pelo menos um administrador aprovado');
        if (v.status !== u.status || v.papel !== u.papel) { v.decidido_por = (meuUsuario() || {}).email || 'demonstração'; v.decidido_em = agora(); }
        if (v.status === 'aprovado') v.motivo = null;
        const mudouCol = v.colaborador_id !== u.colaborador_id, tinhaCol = !!u.colaborador_id, eraAdmin = u.status === 'aprovado' && u.papel === 'admin';
        Object.assign(u, v, { updated_at: agora() });
        db.equipe = db.equipe.filter((x) => x.email !== u.email);
        if (u.status === 'aprovado') db.equipe.push({ email: u.email, nome: u.nome, papel: u.papel });
        ligarColaboradorDemo(u, !mudouCol && tinhaCol);
        if (eraAdmin && (u.status !== 'aprovado' || u.papel !== 'admin')) db.usuarios.forEach((x) => { if (x.admin_id === u.id && x.papel === 'supervisor') x.admin_id = (meuUsuario() || {}).id; });
        log('usuarios', u.id, null, v.status !== u.status ? 'usuário ' + u.status : 'usuário alterado', { usuario: u.usuario, email: u.email, status: u.status, papel: u.papel,
          administrador: u.admin_id ? (db.usuarios.find((x) => x.id === u.admin_id) || {}).nome : undefined,
          supervisor: (colab(u.supervisor_id) || {}).nome, colaborador: (colab(u.colaborador_id) || {}).nome });
        salvar(); return clone(u);
      },
      async salvarMeuPerfil(d) {
        const u = meuUsuario();
        if ('email_aviso' in d && d.email_aviso && !U.emailValido(d.email_aviso)) throw new Error('E-mail de aviso inválido');
        if ('telefone' in d && !U.telefoneValido(d.telefone)) throw new Error('Telefone inválido');
        if ('nome' in d && String(d.nome || '').trim().length < 2) throw new Error('Informe o nome');
        ['nome', 'cargo', 'telefone', 'email_aviso'].forEach((k) => { if (k in d) u[k] = d[k] ? String(d[k]).trim() : null; });
        if (u.status === 'aprovado') { (db.equipe.find((x) => x.email === u.email) || {}).nome = u.nome; ligarColaboradorDemo(u, true); }
        salvar(); return { status: u.status, usuario: u.usuario, nome: u.nome, email_aviso: u.email_aviso };
      },
      // ---------- Cobrança de quem não respondeu ----------
      async cobrancaExecutar() { exigirEmailConfigurado(); const r = cobrar('app'); db.rotina_log.unshift({ id: db.seq++, origem: 'cobrança manual', executado_em: agora(), detalhes: r }); salvar(); return r; },
      // ---------- F.S. aprovada ----------
      async aprovarFolha(id, anexos) {
        const m = db.medicoes.find((x) => x.id === id);
        if (!m) throw new Error('Medição não encontrada');
        if (m.folha_status === 'aprovada') throw new Error('Esta F.S. já foi aprovada');
        if (!m.folha_numero || !m.parcela) throw new Error('Lance a F.S. (número, data e parcela) antes de aprovar');
        if (!db.documentos.some((d) => d.contrato_id === m.contrato_id && d.competencia === m.competencia && d.tipo === 'folha_servico')) throw new Error('Anexe o arquivo da F.S. antes de aprovar');
        const u = meuUsuario();
        Object.assign(m, { folha_status: 'aprovada', folha_aprovada_por: u.email, folha_aprovada_em: agora(), folha_anexos: (anexos || []).map((a) => ({ nome: a.nome, url: a.url })) });
        log('medicoes', m.id, m.fornecedor_id, 'F.S. aprovada', { competencia: U.compCurta(m.competencia), folha: m.folha_numero, parcela: m.parcela, valor: m.folha_valor }, u.email);
        const r = encaminharAuto(m.id);
        salvar();
        return { ok: true, encaminhado: !!(r && r.ok), situacao: situacaoServicos(m.id), para: r && r.para, nf: !!notaParaServicos(m.id) };
      },
      async desfazerAprovacaoFolha(id) {
        const m = db.medicoes.find((x) => x.id === id);
        if (m && m.encaminhado_em) throw new Error('A NF já foi encaminhada a Serviços (processo finalizado). A aprovação da F.S. não pode ser desfeita.');
        if (!m || m.folha_status !== 'aprovada') throw new Error('Esta F.S. não está aprovada');
        Object.assign(m, { folha_status: 'lancada', folha_aprovada_por: null, folha_aprovada_em: null, finalizado_em: null, folha_anexos: null });
        log('medicoes', m.id, m.fornecedor_id, 'aprovação da F.S. desfeita', { competencia: U.compCurta(m.competencia), folha: m.folha_numero });
        salvar(); return clone(m);
      },
      // ---------- Encaminhamento da NF a Serviços ----------
      async encaminharServicos(id, anexos) {
        const m = db.medicoes.find((x) => x.id === id);
        if (!m) throw new Error('Medição não encontrada');
        if (m.encaminhado_em) throw new Error('A NF já foi encaminhada a Serviços');
        if (m.folha_status !== 'aprovada') throw new Error('A NF só pode ir a Serviços depois da aprovação da F.S.');
        if (!notaParaServicos(m.id)) throw new Error('O fornecedor ainda não enviou a nota fiscal');
        if (anexos && anexos.length) m.folha_anexos = anexos.map((a) => ({ nome: a.nome, url: a.url }));
        const u = meuUsuario();
        if (emailPronto()) {
          const r = encaminharServ(m.id, u.email, 'app');
          if (!r.ok) throw new Error(r.motivo === 'sem_destinatario' ? 'Cadastre os e-mails de Serviços e Ocorrência em Configurações > Encaminhamento a Serviços' : 'Não foi possível encaminhar a NF');
          salvar(); return { ...r, enviado: true };
        }
        const e = emailServicos(m, notaParaServicos(m.id));
        return { ok: true, enviado: false, para: destinatariosServicos(m, u.email), assunto: e.assunto, corpo: e.corpo };
      },
      async registrarEncaminhamentoServicos(id, emails, assunto, corpo) {
        if (!emails || !emails.length || emails.some((e) => !U.emailValido(e))) throw new Error('Confira os e-mails do campo Para');
        const r = encaminharServ(id, meuUsuario().email, 'outlook', emails, assunto, corpo);
        if (!r.ok) throw new Error({ encaminhado: 'A NF já foi encaminhada a Serviços', fs: 'A NF só pode ir a Serviços depois da aprovação da F.S.', nf: 'O fornecedor ainda não enviou a nota fiscal' }[r.motivo] || 'Não foi possível registrar o encaminhamento');
        salvar(); return r;
      },
      async registrarEnvioFS(id, emails, assunto, corpo) {
        const m = db.medicoes.find((x) => x.id === id);
        if (!m || m.folha_status !== 'aprovada') throw new Error('Aprove a F.S. antes de registrar o aviso');
        if (!emails || !emails.length || emails.some((e) => !U.emailValido(e))) throw new Error('Confira os e-mails do campo Para');
        db.envios_email.push({ id: uuid(), solicitacao_id: null, avaliacao_id: null, solicitacao_nf_id: null, medicao_id: m.id, contrato_id: null, fornecedor_id: m.fornecedor_id,
          competencia: m.competencia, tipo: 'fs_aprovada', via: 'outlook', para: emails, assunto, corpo, prazo_ate: null, status: 'registrado', erro: null, autor: 'demonstração', created_at: agora() });
        salvar(); return { ok: true };
      },
      async enviosMedicao(id) { return clone(db.envios_email.filter((e) => e.medicao_id === id)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },
      // ---------- Aviso de vencimento ----------
      async avisarVencimento(id, somenteRegistrar, paraEsc) {
        const c = contr(id);
        if (!c || !c.data_fim) throw new Error('Contrato sem data de fim');
        const para = paraEsc && paraEsc.length ? [...new Set(paraEsc.map((x) => x.trim().toLowerCase()))] : destinatariosVenc(c);
        if (para.some((e) => !U.emailValido(e))) throw new Error('Confira os e-mails do campo Para');
        const e = emailVenc(c);
        if (!somenteRegistrar) {
          if (!para.length) throw new Error('Sem destinatário: cadastre o e-mail do supervisor ou a lista de aviso em Configurações');
          if (!db.config.__chave_email || !conf('email_remetente', '') || !conf('site_url', '')) return { ok: true, enviado: false, para, assunto: e.assunto, corpo: e.corpo };
        }
        registrarAviso(c, para, somenteRegistrar ? 'outlook' : 'app');
        salvar(); return { ok: true, enviado: !somenteRegistrar, para, assunto: e.assunto, corpo: e.corpo };
      },
      async enviosContrato(id) { return clone(db.envios_email.filter((e) => e.contrato_id === id)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },

      // ---------- Avaliações ----------
      async avaliacoes(comp) { return clone(db.avaliacoes.filter((a) => a.competencia === comp)); },
      async avaliacoesPeriodo(ini, fim) { return clone(db.avaliacoes.filter((a) => a.competencia >= ini && a.competencia <= fim && ['respondida', 'padrao'].includes(a.status))); },
      async avaliacoesFornecedor(id) {
        return clone(db.avaliacoes.filter((a) => a.fornecedor_id === id && ['respondida', 'padrao'].includes(a.status))).sort((a, b) => (a.competencia < b.competencia ? 1 : -1));
      },
      async enviosAvaliacao(id) { return clone(db.envios_email.filter((e) => e.avaliacao_id === id)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },
      async gerarAvaliacoes(comp, ids) {
        if (!U.compLiberada(comp, feriadosSet())) throw new Error('Só é possível avaliar meses encerrados (ou o mês atual a partir do último dia útil)');
        const n = gerarAval(comp, ids || null); salvar(); return { ok: true, geradas: n };
      },
      async enviarAvaliacoes(comp, ids) {
        exigirEmailConfigurado();
        if (!ids && !U.compLiberada(comp, feriadosSet())) throw new Error('Só é possível avaliar meses encerrados (ou o mês atual a partir do último dia útil)');
        if (!ids) gerarAval(comp, null);
        let ok = 0; const sem = [];
        db.avaliacoes.filter((a) => a.competencia === comp && (ids ? ids.includes(a.id) && ['gerada', 'enviada', 'aberta'].includes(a.status) : a.status === 'gerada'))
          .forEach((a) => { const r = enviarAvalDemo(a, 'app', null, false); if (r.ok) ok++; else if (r.motivo === 'sem_email') sem.push(`${a.supervisor_nome} (${forn(a.fornecedor_id).nome})`); });
        salvar(); return { ok: true, enviados: ok, sem_email: sem };
      },
      async reenviarAvaliacao(id, para, manter) {
        exigirEmailConfigurado();
        const a = db.avaliacoes.find((x) => x.id === id);
        if (['respondida', 'padrao'].includes(a.status)) throw new Error('Esta avaliação já foi respondida.');
        if (['expirada', 'cancelada'].includes(a.status) || a.expira_em < agora()) throw new Error('O link não está mais válido. Use "Gerar novo link e reenviar".');
        if (para && (para.length > 10 || para.some((e) => !U.emailValido(e)))) throw new Error('Confira os e-mails escolhidos (até 10 válidos)');
        const r = enviarAvalDemo(a, 'app', para && para.length ? para : null, manter);
        if (!r.ok) throw new Error('Supervisor sem e-mail cadastrado');
        salvar(); return r;
      },
      async registrarEnvioAvaliacao(id, emails, assunto, corpo, manter) {
        const a = db.avaliacoes.find((x) => x.id === id);
        if (!['gerada', 'enviada', 'aberta'].includes(a.status)) throw new Error('Esta avaliação não está aguardando envio');
        if (a.expira_em < agora()) throw new Error('O link expirou. Use "Gerar novo link e reenviar".');
        registrarEnvioAval(a, 'outlook', emails, assunto, corpo, manter);
        salvar(); return clone(a);
      },
      async renovarAvaliacao(id) {
        const a = db.avaliacoes.find((x) => x.id === id);
        if (['respondida', 'padrao'].includes(a.status)) throw new Error('Esta avaliação já foi respondida.');
        if (a.status === 'cancelada' && db.avaliacoes.some((x) => x.id !== id && x.fornecedor_id === a.fornecedor_id && x.competencia === a.competencia && x.supervisor_id === a.supervisor_id && x.status !== 'cancelada')) {
          throw new Error('Já existe outra avaliação ativa deste fornecedor e supervisor na competência');
        }
        Object.assign(a, { token: token64(), status: 'gerada', aberto_em: null, enviado_em: null, envio_status: null, envio_erro: null,
          expira_em: U.fimPrazoISO(agora(), Number(conf('avaliacao_prazo_dias_uteis', 7)), feriadosSet()) });
        log('avaliacoes', a.id, a.fornecedor_id, 'novo link de avaliação gerado', { competencia: U.compCurta(a.competencia), supervisor: a.supervisor_nome });
        salvar(); return clone(a);
      },
      async cancelarAvaliacao(id) {
        const a = db.avaliacoes.find((x) => x.id === id);
        if (!['gerada', 'enviada', 'aberta', 'expirada'].includes(a.status)) throw new Error('Só é possível cancelar avaliações ainda não respondidas');
        a.status = 'cancelada';
        log('avaliacoes', a.id, a.fornecedor_id, 'avaliação cancelada', { competencia: U.compCurta(a.competencia), supervisor: a.supervisor_nome });
        salvar(); return clone(a);
      },
      async aplicarRespostaPadrao(id) { const a = db.avaliacoes.find((x) => x.id === id); aplicarPadrao(a); salvar(); return clone(a); },
      async aplicarPadraoVencidas(comp) {
        const lista = db.avaliacoes.filter((a) => a.competencia === comp && (a.status === 'expirada' || (['gerada', 'enviada', 'aberta'].includes(a.status) && a.expira_em < agora())));
        lista.forEach((a) => aplicarPadrao(a));
        salvar(); return { ok: true, aplicadas: lista.length };
      },
      async avaliacaoPrevia(id) {
        const a = db.avaliacoes.find((x) => x.id === id), contatos_klingele = contatosDemo();
        if (!a) return { ok: false, motivo: 'invalido', contatos_klingele, previa: true };
        if (['respondida', 'padrao'].includes(a.status)) return { ok: false, motivo: 'usado', respondido_em: a.respondido_em, contatos_klingele, previa: true };
        if (a.status === 'cancelada') return { ok: false, motivo: 'cancelado', contatos_klingele, previa: true };
        if (a.status === 'expirada' || a.expira_em < agora()) return { ok: false, motivo: 'expirado', expira_em: a.expira_em, contatos_klingele, previa: true };
        return { ...dadosAvaliacao(a), previa: true };
      },
      async avaliacaoAbrir(token) {
        const a = db.avaliacoes.find((x) => x.token === token), contatos_klingele = contatosDemo();
        if (!a) return { ok: false, motivo: 'invalido', contatos_klingele };
        if (['respondida', 'padrao'].includes(a.status)) return { ok: false, motivo: 'usado', respondido_em: a.respondido_em, contatos_klingele };
        if (a.status === 'cancelada') return { ok: false, motivo: 'cancelado', contatos_klingele };
        if (a.status === 'expirada' || a.expira_em < agora()) { a.status = 'expirada'; salvar(); return { ok: false, motivo: 'expirado', expira_em: a.expira_em, contatos_klingele }; }
        if (!a.aberto_em) {
          a.aberto_em = agora(); if (['gerada', 'enviada'].includes(a.status)) a.status = 'aberta';
          log('avaliacoes', a.id, a.fornecedor_id, 'avaliação aberta pelo supervisor', { competencia: U.compCurta(a.competencia) }, 'supervisor (link de avaliação)');
          salvar();
        }
        return dadosAvaliacao(a);
      },
      async avaliacaoResponder(token, dados) {
        const erro = (codigo, msg) => ({ ok: false, codigo, erro: msg });
        const a = db.avaliacoes.find((x) => x.token === token);
        if (!a) return erro('link', 'Link inválido.');
        if (!['gerada', 'enviada', 'aberta'].includes(a.status)) return erro('link', 'Esta avaliação já foi respondida ou foi encerrada.');
        if (a.expira_em < agora()) { a.status = 'expirada'; salvar(); return erro('link', 'O prazo desta avaliação terminou.'); }
        const n = dados && dados.notas;
        if (!U.notasCompletas(n) || Object.keys(n).length !== U.CATEGORIAS.length) return erro('notas', 'Dê uma nota de 1 a 10 em todos os itens.');
        const nome = String((dados && dados.nome) || '').trim();
        if (nome.length < 2 || nome.length > 120) return erro('nome', 'Informe seu nome.');
        if (String(dados.observacao || '').length > 2000) return erro('observacao', 'Observação muito longa (máximo 2.000 caracteres).');
        Object.assign(a, { status: 'respondida', notas: { ...n }, nota_geral: U.mediaNotas(n), observacao: String(dados.observacao || '').trim() || null,
          respondido_por: nome, respondido_em: agora() });
        log('avaliacoes', a.id, a.fornecedor_id, 'avaliação respondida', { competencia: U.compCurta(a.competencia), nota_geral: a.nota_geral, responsavel: nome }, 'supervisor (link de avaliação)');
        salvar(); return { ok: true, nota_geral: a.nota_geral, respondido_em: a.respondido_em };
      },

      // ---------- Nota fiscal ----------
      async solicitacoesNF(comp) { return clone(db.solicitacoes_nf.filter((n) => n.competencia === comp)); },
      async notasFiscais(comp) {
        return clone(db.notas_fiscais.filter((n) => n.competencia === comp).map(({ xml, ...r }) => r)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
      },
      async xmlNotaFiscal(id) { const n = db.notas_fiscais.find((x) => x.id === id); return n ? n.xml || null : null; },
      async enviosNF(id) { return clone(db.envios_email.filter((e) => e.solicitacao_nf_id === id)).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)); },
      async lancarFolha(id, numero, data, parcela, descricao, valor) {
        const m = db.medicoes.find((x) => x.id === id);
        if (!m) throw new Error('Medição não encontrada');
        if (m.folha_status === 'aprovada') throw new Error('A F.S. já foi aprovada (processo finalizado). Desfaça a aprovação antes de alterar.');
        if (nfPedida(m.id)) throw new Error('A nota fiscal desta medição já foi pedida ao fornecedor. Cancele o pedido de NF antes de alterar a folha de serviço.');
        const c = contr(m.contrato_id);
        const num = String(numero || '').trim(), desc = String(descricao || '').trim();
        if (!num && !data && (parcela === null || parcela === '' || parcela === undefined) && !desc) {
          Object.assign(m, { folha_numero: null, folha_data: null, parcela: null, descricao_nf: null, folha_por: null, folha_em: null, folha_valor: null, folha_status: null });
          log('medicoes', m.id, m.fornecedor_id, 'folha de serviço desfeita', { competencia: U.compCurta(m.competencia) });
          salvar(); return clone(m);
        }
        if (!['aprovado', 'pago'].includes(m.status)) throw new Error('Aprove a medição antes de lançar a folha de serviço');
        if (!/^[A-Za-z0-9./ -]{1,40}$/.test(num)) throw new Error('Informe o número da folha de serviço (letras, números, ponto, barra ou hífen)');
        if (!data || data > U.hojeISO() || data < m.competencia) throw new Error('A data da folha deve estar entre o início do mês do serviço e hoje');
        const p = Number(parcela);
        if (!Number.isInteger(p) || p < 1) throw new Error('Informe a parcela que está sendo paga');
        if (desc.length < 5) throw new Error('Escreva a descrição que o fornecedor deve colocar na nota fiscal');
        if (desc.length > 1000) throw new Error('Descrição com mais de 1.000 caracteres');
        if (c.parcelas_total && p > c.parcelas_total) throw new Error(`A parcela ${p} passa do total de ${c.parcelas_total} parcelas do contrato`);
        if (p <= Number(c.parcelas_pagas_antes || 0)) throw new Error(`A parcela ${p} já consta como paga antes do sistema (${c.parcelas_pagas_antes} parcelas pagas antes). Ajuste o contrato se necessário.`);
        const outra = db.medicoes.find((x) => x.contrato_id === m.contrato_id && x.parcela === p && x.id !== m.id);
        if (outra) throw new Error(`A parcela ${p} deste contrato já foi lançada na medição de ${outra.competencia.slice(5, 7)}/${outra.competencia.slice(0, 4)}`);
        const v = valor === null || valor === undefined || valor === '' ? null : Number(valor);
        if (v !== null && !U.valorOk(v)) throw new Error('Valor da F.S. inválido');
        Object.assign(m, { folha_numero: num, folha_data: data, parcela: p, descricao_nf: desc, folha_por: 'demonstração', folha_em: agora(),
          folha_valor: v ?? m.valor_aprovado, folha_status: 'lancada' });
        log('medicoes', m.id, m.fornecedor_id, 'folha de serviço lançada', { competencia: U.compCurta(m.competencia), pedido: c.pedido, folha: num, parcela: p, parcelas_total: c.parcelas_total || null });
        salvar(); return clone(m);
      },
      async gerarSolicitacaoNF(medId) {
        const m = db.medicoes.find((x) => x.id === medId);
        if (!m) throw new Error('Medição não encontrada');
        const ativa = db.solicitacoes_nf.find((n) => n.medicao_id === m.id && !['expirada', 'cancelada', 'recusada'].includes(n.status));
        if (ativa) return clone(ativa);
        if (!['aprovado', 'pago'].includes(m.status)) throw new Error('Aprove a medição antes de pedir a nota fiscal');
        if (!(Number(m.valor_aprovado) > 0)) throw new Error('A medição precisa de um valor aprovado maior que zero');
        if (!m.folha_numero || !m.parcela) throw new Error('Lance a folha de serviço (número e parcela) antes de pedir a nota fiscal');
        if (!m.descricao_nf) throw new Error('Preencha a descrição para a nota fiscal na folha de serviço');
        const n = novaSolicitacaoNF(m); salvar(); return clone(n);
      },
      async linksPedidoCompra(docs) {
        return docs.map((d) => ({ nome: d.nome_padrao || d.nome_arquivo, url: `https://demo.supabase.co/storage/v1/object/sign/boletins/${d.caminho}?token=demonstracao` }));
      },
      async enviarSolicitacaoNF(id, anexos, para, manter) {
        exigirEmailConfigurado();
        const n = db.solicitacoes_nf.find((x) => x.id === id);
        if (!n) throw new Error('Pedido de nota fiscal não encontrado');
        if (['recebida', 'aprovada'].includes(n.status)) throw new Error('O fornecedor já enviou a nota fiscal.');
        if (['expirada', 'cancelada', 'recusada'].includes(n.status) || n.expira_em < agora()) throw new Error('O link não está mais válido. Use "Gerar novo link".');
        let anx = n.anexos || [];
        if (anexos && anexos.length) { anx = anexosValidos(n, anexos); if (!anx) throw new Error('Os arquivos escolhidos não conferem com esta medição (F.S. ou pedido de compra)'); }
        if (para && (para.length > 15 || para.some((e) => !U.emailValido(e)))) throw new Error('Confira os e-mails escolhidos (até 15 válidos)');
        const dest = para && para.length ? [...new Set(para.map((e) => e.trim().toLowerCase()))] : db.contatos.filter((c) => c.fornecedor_id === n.fornecedor_id && c.recebe_boletim).map((c) => c.email);
        if (!dest.length) throw new Error('Fornecedor sem e-mail cadastrado');
        const r = registrarEnvioNFDemo(n, 'app', dest, null, null, anx, manter);
        salvar(); return r;
      },
      async registrarEnvioNF(id, emails, assunto, corpo, anexos, manter) {
        const n = db.solicitacoes_nf.find((x) => x.id === id);
        if (!n || !['gerada', 'enviada', 'aberta'].includes(n.status)) throw new Error('Este pedido de nota fiscal não está aguardando envio');
        if (n.expira_em < agora()) throw new Error('O link expirou. Use "Gerar novo link".');
        if (!emails || !emails.length || emails.length > 15 || emails.some((e) => !U.emailValido(e))) throw new Error('Confira os e-mails do campo Para');
        let anx = null;
        if (anexos && anexos.length) { anx = anexosValidos(n, anexos); if (!anx) throw new Error('Os arquivos escolhidos não conferem com esta medição (F.S. ou pedido de compra)'); }
        registrarEnvioNFDemo(n, 'outlook', emails, String(assunto || '').replace(/[\r\n]+/g, ' ').slice(0, 400), corpo, anx, manter);
        salvar(); return clone(n);
      },
      async renovarSolicitacaoNF(id) {
        const n = db.solicitacoes_nf.find((x) => x.id === id);
        if (!n) throw new Error('Pedido de nota fiscal não encontrado');
        if (n.status === 'recebida') throw new Error('A nota enviada está em conferência: aprove ou recuse antes de pedir outra.');
        if (n.status === 'aprovada') throw new Error('A nota fiscal deste pedido já foi aprovada.');
        if (['cancelada', 'expirada', 'recusada'].includes(n.status) && db.solicitacoes_nf.some((x) => x.medicao_id === n.medicao_id && x.id !== n.id && !['expirada', 'cancelada', 'recusada'].includes(x.status))) {
          throw new Error('Já existe outro pedido de nota fiscal ativo para esta medição');
        }
        Object.assign(n, { token: token64(), status: 'gerada', aberto_em: null, enviado_em: null, recebido_em: null, envio_status: null, envio_erro: null,
          expira_em: U.fimPrazoISO(agora(), prazoNF(), feriadosSet()) });
        log('solicitacoes_nf', n.id, n.fornecedor_id, 'novo link de nota fiscal gerado', { competencia: U.compCurta(n.competencia) });
        salvar(); return clone(n);
      },
      async cancelarSolicitacaoNF(id) {
        const n = db.solicitacoes_nf.find((x) => x.id === id);
        if (!n || !['gerada', 'enviada', 'aberta', 'expirada'].includes(n.status)) throw new Error('Só é possível cancelar pedidos de nota fiscal ainda sem nota enviada');
        n.status = 'cancelada';
        log('solicitacoes_nf', n.id, n.fornecedor_id, 'pedido de nota fiscal cancelado', { competencia: U.compCurta(n.competencia) });
        salvar(); return clone(n);
      },
      async conferirNF(id, aprovar, motivo) {
        const nf = db.notas_fiscais.find((x) => x.id === id);
        if (!nf) throw new Error('Nota fiscal não encontrada');
        const n = db.solicitacoes_nf.find((x) => x.id === nf.solicitacao_nf_id), m = db.medicoes.find((x) => x.id === nf.medicao_id);
        if (aprovar) {
          if (nf.status !== 'em_conferencia') throw new Error('Esta nota já foi conferida');
          Object.assign(nf, { status: 'aprovada', conferido_por: 'demonstração', conferido_em: agora(), motivo_recusa: null });
          if (n) n.status = 'aprovada';
          if (m) m.nota_fiscal = String(nf.numero).slice(0, 60);
          log('notas_fiscais', nf.id, nf.fornecedor_id, 'nota fiscal aprovada', { competencia: U.compCurta(nf.competencia), numero: nf.numero, valor: nf.valor, alertas: nf.alertas });
          encaminharAuto(nf.medicao_id);
        } else {
          const mot = String(motivo || '').trim();
          if (mot.length < 5) throw new Error('Informe o motivo da recusa (o fornecedor verá este texto)');
          if (nf.status === 'recusada') throw new Error('Esta nota já foi recusada');
          if (nf.status === 'aprovada' && m && m.status === 'pago') throw new Error('A medição já foi paga: desfaça o pagamento antes de recusar a nota');
          if (nf.status === 'aprovada' && m && m.encaminhado_em) throw new Error('A nota já foi encaminhada a Serviços (processo finalizado) e não pode ser recusada');
          Object.assign(nf, { status: 'recusada', motivo_recusa: mot.slice(0, 1000), conferido_por: 'demonstração', conferido_em: agora() });
          if (n) n.status = 'recusada';
          if (m && m.nota_fiscal === String(nf.numero)) m.nota_fiscal = null;
          log('notas_fiscais', nf.id, nf.fornecedor_id, 'nota fiscal recusada', { competencia: U.compCurta(nf.competencia), numero: nf.numero, motivo: mot });
        }
        salvar(); return clone(nf);
      },
      async nfPrevia(id) {
        const n = db.solicitacoes_nf.find((x) => x.id === id), contatos_klingele = contatosDemo();
        if (!n) return { ok: false, motivo: 'invalido', contatos_klingele, previa: true };
        if (['recebida', 'aprovada'].includes(n.status)) return { ok: false, motivo: 'usado', recebido_em: n.recebido_em, contatos_klingele, previa: true };
        if (['cancelada', 'recusada'].includes(n.status)) return { ok: false, motivo: n.status === 'cancelada' ? 'cancelado' : 'recusada', contatos_klingele, previa: true };
        if (n.status === 'expirada' || n.expira_em < agora()) return { ok: false, motivo: 'expirado', expira_em: n.expira_em, contatos_klingele, previa: true };
        return { ...dadosNF(n), pasta_upload: null, previa: true };
      },
      async nfAbrir(token) {
        const n = db.solicitacoes_nf.find((x) => x.token === token), contatos_klingele = contatosDemo();
        if (!n) return { ok: false, motivo: 'invalido', contatos_klingele };
        if (['recebida', 'aprovada'].includes(n.status)) return { ok: false, motivo: 'usado', recebido_em: n.recebido_em, contatos_klingele };
        if (n.status === 'recusada') return { ok: false, motivo: 'recusada', contatos_klingele };
        if (n.status === 'cancelada') return { ok: false, motivo: 'cancelado', contatos_klingele };
        if (n.status === 'expirada' || n.expira_em < agora()) { n.status = 'expirada'; salvar(); return { ok: false, motivo: 'expirado', expira_em: n.expira_em, contatos_klingele }; }
        if (!n.aberto_em) {
          n.aberto_em = agora(); if (['gerada', 'enviada'].includes(n.status)) n.status = 'aberta';
          log('solicitacoes_nf', n.id, n.fornecedor_id, 'link da nota fiscal aberto pelo fornecedor', { competencia: U.compCurta(n.competencia) }, 'fornecedor (link da nota fiscal)');
          salvar();
        }
        return dadosNF(n);
      },
      async nfLinksArquivos(caminhos) { return (caminhos || []).filter(Boolean).map((c) => ({ caminho: c, url: 'https://exemplo.supabase.co/storage/v1/object/sign/boletins/' + c + '?token=demo' })); },
      async nfFinalizar(token, dados) {
        const erro = (codigo, msg, extra) => ({ ok: false, codigo, erro: msg, ...(extra || {}) });
        const n = db.solicitacoes_nf.find((x) => x.token === token);
        if (!n) return erro('link', 'Link inválido.');
        if (!['gerada', 'enviada', 'aberta'].includes(n.status)) return erro('link', 'Este link já foi utilizado ou foi encerrado.');
        if (n.expira_em < agora()) { n.status = 'expirada'; salvar(); return erro('link', 'O prazo deste link terminou.'); }
        if (!dados || typeof dados !== 'object') return erro('dados', 'Dados inválidos.');
        const m = db.medicoes.find((x) => x.id === n.medicao_id), c = contr(n.contrato_id), f = forn(n.fornecedor_id);
        const xmlTxt = String(dados.xml || '').trim() || null;
        const r = U.NF.conferir({ modelo: dados.modelo, xml: xmlTxt ? U.NF.lerXml(xmlTxt) : null, temXml: !!xmlTxt, form: dados, competencia: n.competencia,
          valorAprovado: m.valor_aprovado, pedido: c.pedido, cnpjFornecedor: f.cnpj, cnpjsKlingele: cnpjsKlg(), hoje: U.hojeISO(),
          duplicada: (chave, numero, serie, modelo) => {
            const ativas = db.notas_fiscais.filter((x) => x.status !== 'recusada');
            if (chave && ativas.some((x) => x.chave === chave)) return 'chave';
            if (numero && ativas.some((x) => x.fornecedor_id === n.fornecedor_id && x.modelo === modelo && (x.serie || '') === (serie || '') && x.numero === numero)) return 'numero';
            return null;
          } });
        if (r.bloqueio) return erro(NF_MODELO_OK(dados.modelo) ? 'xml' : 'modelo', r.bloqueio);
        const arqs = Array.isArray(dados.arquivos) ? dados.arquivos : [];
        if (!arqs.length && !xmlTxt) return erro('arquivos', 'Anexe pelo menos um arquivo: nota fiscal (PDF ou imagem), XML, fatura ou recibo.', { validacoes: r.itens });
        if (arqs.length > 10) return erro('arquivos', 'Máximo de 10 arquivos por nota.', { validacoes: r.itens });
        const prefixo = n.pasta + '/' + n.token + '/', vistos = new Set(), hashes = new Set();
        for (const a of arqs) {
          if (!a || !a.caminho || !a.caminho.startsWith(prefixo) || /\.\./.test(a.caminho) || vistos.has(a.caminho)) return erro('arquivos', 'Arquivo fora da pasta deste link ou repetido.');
          vistos.add(a.caminho);
          if (!['pdf', 'jpg', 'jpeg', 'png'].includes(U.extensao(a.caminho))) return erro('arquivos', 'Tipo de arquivo não aceito (use PDF, JPG, PNG ou XML).');
          if (!arquivos[a.caminho]) return erro('arquivos', `O arquivo "${String(a.nome || '').slice(0, 80)}" não chegou ao servidor. Tente enviar de novo.`);
          if (!['nota_fiscal', 'outro'].includes(a.tipo)) return erro('arquivos', 'Tipo de documento inválido.');
          if (a.hash_sha256) {
            if (hashes.has(a.hash_sha256)) return erro('arquivos', 'O mesmo arquivo foi anexado duas vezes.');
            hashes.add(a.hash_sha256);
            if (db.documentos.some((d) => d.fornecedor_id === n.fornecedor_id && d.hash_sha256 === a.hash_sha256)) r.itens.push({ item: 'arquivo', nivel: 'alerta', msg: `O arquivo "${String(a.nome).slice(0, 80)}" é idêntico a um documento já recebido antes.` });
          }
        }
        const resp = dados.responsavel || {}, nome = String(resp.nome || '').trim(), email = String(resp.email || '').trim().toLowerCase();
        if (nome.length < 2) return erro('responsavel', 'Informe o nome de quem está enviando.', { validacoes: r.itens });
        if (email && !U.emailValido(email)) return erro('responsavel', 'Seu e-mail parece incorreto.', { validacoes: r.itens });
        if (String(dados.observacao || '').length > 1000) return erro('responsavel', 'Observação muito longa (máximo 1.000 caracteres).', { validacoes: r.itens });
        const errs = r.itens.filter((i) => i.nivel === 'erro'), alertas = r.itens.filter((i) => i.nivel === 'alerta').length;
        if (errs.length) return erro('validacao', errs[0].msg, { validacoes: r.itens });
        if (dados.somente_conferir) return { ok: true, conferencia: true, alertas, validacoes: r.itens, nota: { modelo: r.modelo, numero: r.nota.numero, serie: r.nota.serie, chave: r.nota.chave, data_emissao: r.nota.data_emissao, valor: r.nota.valor } };
        let docNf = null, docPrimeiro = null;
        arqs.forEach((a) => {
          const file = arquivos[a.caminho];
          const dup = a.hash_sha256 ? db.documentos.find((d) => d.fornecedor_id === n.fornecedor_id && d.hash_sha256 === a.hash_sha256) : null;
          const doc = { id: uuid(), solicitacao_id: null, solicitacao_nf_id: n.id, fornecedor_id: n.fornecedor_id, contrato_id: n.contrato_id, competencia: n.competencia, tipo: a.tipo,
            nome_arquivo: String(a.nome || 'arquivo').slice(0, 200), caminho: a.caminho, mime: U.mimeArquivo(a.caminho), tamanho: file ? file.size : null, valor_lido: null,
            enviado_por: 'fornecedor', created_at: agora(), hash_sha256: a.hash_sha256 || null, duplicado_de: dup ? dup.id : null };
          doc.nome_padrao = nomeDoc(doc);
          db.documentos.push(doc);
          if (a.tipo === 'nota_fiscal' && !docNf) docNf = doc;
          docPrimeiro = docPrimeiro || doc;
        });
        docNf = docNf || docPrimeiro;
        const nf = { id: uuid(), solicitacao_nf_id: n.id, medicao_id: n.medicao_id, contrato_id: n.contrato_id, fornecedor_id: n.fornecedor_id, competencia: n.competencia, ...r.nota,
          xml: xmlTxt, documento_id: docNf ? docNf.id : null, status: 'em_conferencia', validacoes: r.itens, alertas, responsavel: [nome, email].filter(Boolean).join(' · '),
          observacao: String(dados.observacao || '').trim() || null, conferido_por: null, conferido_em: null, motivo_recusa: null, created_at: agora(),
          anexos: (Array.isArray(dados.links) ? dados.links : []).filter((l) => l && vistos.has(l.caminho)).map((l) => ({ nome: (arqs.find((a) => a.caminho === l.caminho) || {}).nome || 'arquivo', url: l.url, caminho: l.caminho })) };
        db.notas_fiscais.push(nf);
        Object.assign(n, { status: 'recebida', recebido_em: agora() });
        log('notas_fiscais', nf.id, n.fornecedor_id, 'nota fiscal recebida', { competencia: U.compCurta(n.competencia), pedido: c.pedido, parcela: m.parcela, numero: nf.numero,
          valor: nf.valor, alertas, arquivos: arqs.length, responsavel: nf.responsavel }, 'fornecedor (link da nota fiscal)');
        encaminharAuto(n.medicao_id);
        salvar();
        return { ok: true, alertas, validacoes: r.itens, recebido_em: agora(), nota: { modelo: r.modelo, numero: nf.numero, valor: nf.valor } };
      },

      // ---------- Colaboradores ----------
      async salvarColaborador(c) {
        if ('email' in c) c = { ...c, email: c.email ? String(c.email).trim().toLowerCase() : null };
        const email = c.email || null;
        if (email && db.colaboradores.some((x) => x.id !== c.id && (x.email || '').toLowerCase() === email)) throw new Error('Já existe um colaborador com este e-mail.');
        let r;
        if (c.id) {
          r = db.colaboradores.find((x) => x.id === c.id);
          const futuro = { ...r, ...c };
          if (futuro.contato_fornecedor && !futuro.email && !futuro.telefone) throw new Error('Para aparecer ao fornecedor, informe e-mail ou telefone');
          const renomeou = c.nome !== undefined && c.nome !== r.nome;
          Object.assign(r, c, { updated_at: agora() });
          if (renomeou) db.contratos.forEach((k) => { if (k.supervisor_id === r.id) k.gestor = r.nome; });
          log('colaboradores', r.id, null, 'alteração', { nome: r.nome });
        } else {
          r = { contato_fornecedor: true, supervisor: false, ativo: true, ordem: 0, ...c, email, id: uuid(), created_at: agora(), updated_at: agora() };
          db.colaboradores.push(r);
          log('colaboradores', r.id, null, 'cadastro', { nome: r.nome });
        }
        salvar(); return clone(r);
      },
      async excluirColaborador(id) {
        const r = db.colaboradores.find((x) => x.id === id);
        db.colaboradores = db.colaboradores.filter((x) => x.id !== id);
        db.contratos.forEach((k) => {
          k.supervisores = supsDe(k).filter((x) => x !== id); k.contatos = (k.contatos || []).filter((x) => x !== id);
          k.supervisor_id = k.supervisores[0] || null; if (k.supervisor_id) k.gestor = (colab(k.supervisor_id) || {}).nome || k.gestor;
        });
        if (r) log('colaboradores', id, null, 'exclusão', { nome: r.nome });
        salvar();
      },

      async carregarBase() {
        return { alertas: clone(db.alertas), fornecedores: comFornecedorContatos(), contratos: clone(db.contratos), config: clone(db.config), feriados: clone(db.feriados), equipe: clone(db.equipe),
          colaboradores: clone(db.colaboradores).sort((a, b) => (a.ordem || 0) - (b.ordem || 0) || a.nome.localeCompare(b.nome)),
          parcelas: db.contratos.map((c) => parcelasDe(c.id)), pastas: clone(db.pastas_envio || []).sort((a, b) => a.nome.localeCompare(b.nome)),
          pastaItens: [], pastaExec: clone(db.rotina_log.filter((x) => ['pasta programada', 'envio automático'].includes(x.origem)).slice(0, 300)),
          equipes: clone(db.equipes_trabalho || []).sort((a, b) => a.nome.localeCompare(b.nome)), membros: clone(db.equipe_membros || []),
          compart: clone(db.pasta_compartilhamentos || []) };
      },
      // ---------- Equipes de trabalho (mesmas regras do banco; a demonstração entra como administrador) ----------
      async salvarEquipe(id, d) {
        const nome = String(d.nome || '').trim(), desc = String(d.descricao || '').trim() || null, eu = ((meuUsuario() || {}).email || '').toLowerCase();
        if (nome.length < 2 || nome.length > 80) throw new Error('Informe o nome da equipe (2 a 80 caracteres)');
        if (desc && desc.length > 300) throw new Error('Descrição inválida (até 300 caracteres)');
        if (db.equipes_trabalho.some((e) => e.id !== id && e.nome.trim().toLowerCase() === nome.toLowerCase())) throw new Error('Já existe uma equipe com este nome');
        let e = id ? db.equipes_trabalho.find((x) => x.id === id) : null;
        if (id && !e) throw new Error('Equipe não encontrada');
        if (!e) {
          e = { id: uuid(), nome, descricao: desc, criado_por: eu, created_at: agora(), updated_at: agora() }; db.equipes_trabalho.push(e);
          db.equipe_membros.push({ equipe_id: e.id, email: eu, status: 'ativo', convidado_por: eu, convidado_em: agora(), respondido_em: agora() });
        } else Object.assign(e, { nome, descricao: desc, updated_at: agora() });
        log('equipes', e.id, null, id ? 'equipe alterada' : 'equipe criada', { nome }); salvar(); return { ok: true, id: e.id };
      },
      async excluirEquipe(id) {
        const e = db.equipes_trabalho.find((x) => x.id === id);
        if (!e) throw new Error('Equipe não encontrada');
        db.equipes_trabalho = db.equipes_trabalho.filter((x) => x.id !== id);
        db.equipe_membros = db.equipe_membros.filter((m) => m.equipe_id !== id);
        db.pasta_compartilhamentos = db.pasta_compartilhamentos.filter((c) => !(c.alvo_tipo === 'equipe' && c.alvo === id));
        log('equipes', id, null, 'equipe excluída', { nome: e.nome }); salvar(); return { ok: true };
      },
      async convidarEquipe(id, emails) {
        const e = db.equipes_trabalho.find((x) => x.id === id), eu = ((meuUsuario() || {}).email || '').toLowerCase();
        if (!e) throw new Error('Equipe não encontrada');
        if (!emails || !emails.length || emails.length > 50) throw new Error('Escolha de 1 a 50 pessoas para convidar');
        let n = 0;
        emails.map((x) => String(x || '').trim().toLowerCase()).forEach((em) => {
          if (!db.equipe.some((q) => q.email.toLowerCase() === em)) throw new Error(`Convide só usuários com acesso ao BMK (${em})`);
          const m = db.equipe_membros.find((x) => x.equipe_id === id && x.email === em);
          if (m && ['ativo', 'convidado'].includes(m.status)) return;
          if (m) Object.assign(m, { status: 'convidado', convidado_por: eu, convidado_em: agora(), respondido_em: null });
          else db.equipe_membros.push({ equipe_id: id, email: em, status: 'convidado', convidado_por: eu, convidado_em: agora(), respondido_em: null });
          n++;
        });
        if (n) log('equipes', id, null, 'convite enviado', { nome: e.nome, convidados: n });
        salvar(); return { ok: true, convidados: n };
      },
      async responderConvite(id, aceitar) {
        const eu = ((meuUsuario() || {}).email || '').toLowerCase(), m = db.equipe_membros.find((x) => x.equipe_id === id && x.email === eu && x.status === 'convidado');
        if (!m) throw new Error('Convite não encontrado');
        Object.assign(m, { status: aceitar ? 'ativo' : 'recusado', respondido_em: agora() });
        log('equipes', id, null, aceitar ? 'convite aceito' : 'convite recusado', { nome: (db.equipes_trabalho.find((x) => x.id === id) || {}).nome }, eu);
        salvar(); return { ok: true };
      },
      async removerMembroEquipe(id, email) {
        const e = db.equipes_trabalho.find((x) => x.id === id), em = String(email || '').toLowerCase();
        if (!e) throw new Error('Equipe não encontrada');
        if (e.criado_por === em) throw new Error('Quem criou a equipe não sai dela; para encerrar, exclua a equipe');
        const antes = db.equipe_membros.length;
        db.equipe_membros = db.equipe_membros.filter((m) => !(m.equipe_id === id && m.email === em));
        if (antes === db.equipe_membros.length) throw new Error('Pessoa não está na equipe');
        log('equipes', id, null, em === ((meuUsuario() || {}).email || '').toLowerCase() ? 'saiu da equipe' : 'removido da equipe', { nome: e.nome, email: em });
        salvar(); return { ok: true };
      },
      // ---------- Responsáveis dos contratos e pastas programadas (mesmas regras do banco) ----------
      async definirResponsavel(colabId, papel, contratos) {
        const co = colab(colabId);
        if (!co) throw new Error('Contato Klingele não encontrado');
        if (!['supervisor', 'contato'].includes(papel)) throw new Error('Escolha supervisor ou contato');
        if (papel === 'supervisor' && !co.supervisor && (contratos || []).length) throw new Error('Marque o contato como supervisor antes de ligá-lo aos contratos');
        const ids = new Set(contratos || []);
        let inc = 0, rem = 0;
        db.contratos.forEach((k) => {
          const lista = papel === 'supervisor' ? supsDe(k).slice() : (k.contatos || []).slice();
          const tem = lista.includes(co.id);
          if (ids.has(k.id) && !tem) { lista.push(co.id); inc++; } else if (!ids.has(k.id) && tem) { lista.splice(lista.indexOf(co.id), 1); rem++; } else return;
          if (papel === 'supervisor') { k.supervisores = lista; k.supervisor_id = lista[0] || null; if (k.supervisor_id) k.gestor = colab(k.supervisor_id).nome; } else k.contatos = lista;
          k.updated_at = agora();
          log('contratos', k.id, k.fornecedor_id, 'alteração', { [papel === 'supervisor' ? 'supervisores' : 'contatos']: { para: lista.map((x) => (colab(x) || {}).nome) } });
        });
        salvar(); return { ok: true, incluidos: inc, removidos: rem };
      },
      async salvarPasta(id, d) {
        const ant = id ? pastaD(id) : null;
        if (id && !ant) throw new Error('Pasta não encontrada');
        const eu = ((meuUsuario() || {}).email || '').toLowerCase();
        const x = ant ? { ...ant, ...d } : d;   // o que não vem fica como está
        const nome = String(x.nome || '').trim(), cal = x.calendario || 'mensal', dia = Number(x.dia_util ?? 1), hora = x.horario || '08:00', pede = x.pede || 'mes_anterior';
        if (nome.length < 2 || nome.length > 80) throw new Error('Informe o nome da pasta (2 a 80 caracteres)');
        if (String(x.descricao || '').length > 300) throw new Error('Descrição inválida (até 300 caracteres)');
        if (!['mensal', 'meses', 'datas', 'manual'].includes(cal)) throw new Error('Escolha quando a pasta dispara (todo mês, meses escolhidos, datas marcadas ou só manual)');
        if (ant && ant.padrao && cal !== 'mensal') throw new Error('O Envio mensal dispara todo mês: escolha o dia útil e o horário');
        if (!(Number.isInteger(dia) && dia >= 0 && dia <= 10)) throw new Error('Dia do envio: último dia útil do mês ou do 1º ao 10º dia útil do mês seguinte');
        if (!U.HORARIOS.includes(hora)) throw new Error('Horário inválido: das 06:00 às 20:45, de 15 em 15 minutos');
        const meses = [...new Set((x.meses || []).map(Number))].sort((a, b) => a - b);
        if (meses.some((m) => !(m >= 1 && m <= 12))) throw new Error('Mês inválido');
        if (cal === 'meses' && !meses.length) throw new Error('Marque pelo menos um mês');
        const datas = [...new Set(x.datas || [])].sort();
        if (datas.length > 36) throw new Error('Até 36 datas por pasta');
        datas.forEach((dt) => { if (!U.ehDiaUtil(dt, feriadosSet())) throw new Error(`${U.dataBR(dt)} não é dia útil (sábado, domingo ou feriado)`); });
        if (cal === 'datas' && !datas.length) throw new Error('Marque pelo menos uma data');
        const prazo = x.prazo_dias === '' || x.prazo_dias === null || x.prazo_dias === undefined ? null : Number(x.prazo_dias);
        if (prazo !== null && !(Number.isInteger(prazo) && prazo >= 1 && prazo <= 30)) throw new Error('Prazo do link: de 1 a 30 dias úteis (vazio = padrão)');
        const vis = x.visibilidade || 'restrita';
        if (!['restrita', 'todos_ver', 'todos_editar'].includes(vis)) throw new Error('Escolha quem vê a pasta');
        let regra = ant ? ant.filtro || null : null;
        if ('regra' in d) {
          regra = null;
          if (d.regra && !(ant && ant.padrao)) {
            const f = d.regra;
            if ((f.tipos || []).some((k) => !U.FILTRO_TIPOS.some(([v]) => v === k))) throw new Error('Tipo de serviço inválido no filtro');
            regra = {}; ['tipos', 'supervisores', 'contatos', 'equipes'].forEach((k) => { if ((f[k] || []).length) regra[k] = [...new Set(f[k])]; });
            if (String(f.texto || '').trim()) { if (String(f.texto).trim().length > 80) throw new Error('Texto do filtro inválido (até 80 caracteres)'); regra.texto = String(f.texto).trim(); }
            if (!U.filtroTemRegra(regra)) throw new Error('Escolha pelo menos uma regra (tipo de serviço, supervisor, contato, equipe ou texto)');
          }
        }
        let resp = String(x.responsavel || '').trim().toLowerCase() || (ant ? null : eu);
        if (resp && !db.equipe.some((q) => q.email.toLowerCase() === resp && ['admin', 'supervisor', 'analista'].includes(q.papel))) throw new Error('O responsável precisa ser um usuário do BMK que envia (administrador, supervisor ou analista)');
        if (db.pastas_envio.some((p) => p.id !== id && p.nome.trim().toLowerCase() === nome.toLowerCase())) throw new Error('Já existe uma pasta com este nome');
        const campos = { nome, descricao: String(x.descricao || '').trim() || null, calendario: cal, dia_util: dia, horario: hora, meses, datas, pede,
          ativa: x.ativa !== false, responsavel: resp || null, prazo_dias: prazo, cobranca: x.cobranca !== false, avaliacao: x.avaliacao !== false, filtro: regra, tipo: 'lista' };
        let p = ant;
        if (!p) { p = { id: uuid(), padrao: false, responsaveis: [], criado_por: eu, visibilidade: vis, created_at: agora(), updated_at: agora(), ...campos }; db.pastas_envio.push(p); }
        else Object.assign(p, campos, { visibilidade: p.padrao ? p.visibilidade : vis, updated_at: agora() });
        let entram = 0, saem = 0;
        if (Array.isArray(d.contratos)) {
          if (d.contratos.length > 500) throw new Error('Até 500 contratos por pasta');
          const ids = [...new Set(d.contratos)];
          if (ids.some((cid) => !contr(cid))) throw new Error('Contrato inválido na pasta');
          db.contratos.forEach((c) => {
            if (ids.includes(c.id) && c.pasta_id !== p.id) { c.pasta_id = p.id; c.pasta_escolhida = true; entram++; }
            else if (!ids.includes(c.id) && c.pasta_id === p.id) { c.pasta_id = null; c.pasta_escolhida = true; saem++; }
          });
        }
        if (Array.isArray(d.compartilhamentos)) {
          db.pasta_compartilhamentos = db.pasta_compartilhamentos.filter((c) => c.pasta_id !== p.id);
          d.compartilhamentos.forEach((c) => {
            if (!['usuario', 'equipe'].includes(c.alvo_tipo) || !['ver', 'editar', 'gerir'].includes(c.nivel || 'ver')) throw new Error('Compartilhamento inválido');
            const alvo = c.alvo_tipo === 'usuario' ? String(c.alvo || '').toLowerCase() : c.alvo;
            if (c.alvo_tipo === 'usuario' && !db.equipe.some((q) => q.email.toLowerCase() === alvo)) throw new Error(`Compartilhe só com usuários com acesso ao BMK (${alvo})`);
            if (c.alvo_tipo === 'equipe' && !db.equipes_trabalho.some((e) => e.id === alvo)) throw new Error('Equipe não encontrada');
            if (c.alvo_tipo === 'usuario' && alvo === p.criado_por) return;
            db.pasta_compartilhamentos.push({ pasta_id: p.id, alvo_tipo: c.alvo_tipo, alvo, nivel: c.nivel || 'ver', criado_por: eu, created_at: agora() });
          });
        }
        const nComp = db.pasta_compartilhamentos.filter((c) => c.pasta_id === p.id).length;
        log('pastas_envio', p.id, null, id ? 'pasta alterada' : 'pasta criada', { nome, calendario: cal, dia_util: dia, horario: hora, meses, datas, ativa: p.ativa,
          responsavel: p.responsavel, visibilidade: p.visibilidade, regra, contratos_entraram: entram, contratos_sairam: saem, compartilhamentos: nComp });
        salvar(); return { ok: true, id: p.id, contratos: db.contratos.filter((c) => c.pasta_id === p.id).length, entraram: entram, sairam: saem, compartilhamentos: nComp };
      },
      async excluirPasta(id) {
        const p = pastaD(id);
        if (!p) throw new Error('Pasta não encontrada');
        if (p.padrao) throw new Error('O Envio mensal é a pasta base do mês e não pode ser excluído');
        let n = 0;
        db.contratos.forEach((c) => { if (c.pasta_id === id) { c.pasta_id = null; c.pasta_escolhida = true; n++; } });
        db.pastas_envio = db.pastas_envio.filter((x) => x.id !== id);
        db.pasta_compartilhamentos = db.pasta_compartilhamentos.filter((x) => x.pasta_id !== id);
        log('pastas_envio', id, null, 'pasta excluída', { nome: p.nome, contratos_avulsos: n }); salvar(); return { ok: true, avulsos: n };
      },
      async transferirPasta(id, email) {
        const p = pastaD(id), para = String(email || '').trim().toLowerCase(), eu = ((meuUsuario() || {}).email || '').toLowerCase();
        if (!p) throw new Error('Pasta não encontrada');
        if (p.padrao) throw new Error('O Envio mensal é do sistema: troque só o responsável');
        if (!db.equipe.some((q) => q.email.toLowerCase() === para && ['admin', 'supervisor', 'analista'].includes(q.papel))) throw new Error('Transfira para um usuário do BMK que envia (administrador, supervisor ou analista)');
        if (para === p.criado_por) throw new Error('Esta pessoa já é a dona da pasta');
        if (p.criado_por) {
          db.pasta_compartilhamentos = db.pasta_compartilhamentos.filter((c) => !(c.pasta_id === p.id && c.alvo_tipo === 'usuario' && c.alvo === p.criado_por));
          db.pasta_compartilhamentos.push({ pasta_id: p.id, alvo_tipo: 'usuario', alvo: p.criado_por, nivel: 'gerir', criado_por: eu, created_at: agora() });
        }
        db.pasta_compartilhamentos = db.pasta_compartilhamentos.filter((c) => !(c.pasta_id === p.id && c.alvo_tipo === 'usuario' && c.alvo === para));
        log('pastas_envio', p.id, null, 'pasta transferida', { nome: p.nome, de: p.criado_por, para });
        Object.assign(p, { criado_por: para, responsavel: para, updated_at: agora() });
        salvar(); return { ok: true };
      },
      async moverContratos(ids, pasta) {
        if (!ids || !ids.length || ids.length > 500) throw new Error('Escolha de 1 a 500 contratos');
        if (pasta && !pastaD(pasta)) throw new Error('Pasta não encontrada');
        let n = 0;
        ids.forEach((cid) => { const c = contr(cid); if (c && ((c.pasta_id || null) !== (pasta || null) || !c.pasta_escolhida)) { c.pasta_id = pasta || null; c.pasta_escolhida = true; n++; } });
        log('pastas_envio', pasta || null, null, 'contratos movidos', { pasta: (pastaD(pasta) || {}).nome || 'avulso', pedidos: ids.map((cid) => (contr(cid) || {}).pedido) });
        salvar(); return { ok: true, movidos: n };
      },
      async executarPasta(id, comp) {
        exigirEmailConfigurado();
        if (!U.compLiberada(comp, feriadosSet())) throw new Error('Só é possível solicitar o boletim de meses encerrados (ou do mês atual a partir do último dia útil)');
        const p = pastaD(id);
        if (!p) throw new Error('Pasta não encontrada');
        const r = enviarPastaDemo(p, comp, 'app', (meuUsuario() || {}).email);
        db.rotina_log.unshift({ id: db.seq++, origem: p.padrao ? 'envio automático' : 'pasta programada', executado_em: agora(), detalhes: r });
        salvar(); return r;
      },
      async solicitacoes(comp) { return clone(db.solicitacoes.filter((s) => s.competencia === comp)); },
      async medicoes(comp) { return clone(db.medicoes.filter((m) => m.competencia === comp)); },
      async medicoesPeriodo(ini, fim) { return clone(db.medicoes.filter((m) => m.competencia >= ini && m.competencia <= fim)); },
      async medicoesFornecedor(id) { return clone(db.medicoes.filter((m) => m.fornecedor_id === id)).sort((a, b) => (a.competencia < b.competencia ? 1 : -1)); },
      async documentos(comp) { return clone(db.documentos.filter((d) => d.competencia === comp)); },
      async envios(f) { return clone(db.envios_email.filter((e) => noPeriodo(e.created_at, f))).sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).slice(0, (f && f.limite) || 2000); },
      async historico(f) { return clone(db.historico.filter((h) => (!f || !f.fornecedor_id || h.fornecedor_id === f.fornecedor_id) && noPeriodo(h.created_at, f)).slice(0, (f && f.limite) || 300)); },
      async rotinaLog(f) { return clone(db.rotina_log.filter((r) => noPeriodo(r.executado_em, f)).slice(0, (f && f.limite) || 40)); },
      // ---------- Segurança (demonstração: a verificação do banco de verdade roda no site publicado) ----------
      async eventosSeguranca(f) {
        return clone((db.eventos_seguranca || []).filter((e) => noPeriodo(e.created_at, f) && (!f || !f.naoVistos || (!e.visto_em && e.gravidade !== 'info')))
          .slice(0, (f && f.limite) || 500));
      },
      async marcarEventosVistos(ids) {
        let n = 0;
        (db.eventos_seguranca || []).forEach((e) => { if (!e.visto_em && (!ids || !ids.length || ids.includes(e.id))) { e.visto_em = agora(); e.visto_por = (meuUsuario() || {}).email || 'demonstração'; n++; } });
        salvar(); return n;
      },
      async segurancaVerificar() { return verificarDemo(); },
      // Confirmação de entrega (demonstração: no site publicado, o Resend avisa pelo webhook)
      async webhookSituacao() {
        const t = db.config.__email_teste ? JSON.parse(db.config.__email_teste) : null;
        return { segredo: !!db.config.__segredo_webhook, ultimo_tipo: t && db.config.__segredo_webhook ? 'email.delivered' : null,
          ultimo_em: t && db.config.__segredo_webhook ? t.em : null, eventos_7d: t ? 2 : 0, entregues_7d: t && db.config.__segredo_webhook ? 1 : 0, devolvidos_7d: 0, sem_aviso: 0 };
      },
      async definirSegredoWebhook(s) {
        if (!/^whsec_[A-Za-z0-9+/=]{16,200}$/.test(String(s || '').trim())) throw new Error('Segredo inválido: copie o "Signing secret" do webhook no Resend (começa com whsec_)');
        db.config.__segredo_webhook = 'sim'; log('configuracoes', null, null, 'segredo do webhook de e-mail atualizado', {}); salvar(); return { ok: true };
      },
      async emailTeste() {
        if (!db.config.__chave_email || !conf('email_remetente', '') || !conf('site_url', '')) throw new Error('Cadastre a chave, o e-mail do remetente e o endereço do site antes do teste');
        const para = (meuUsuario() || {}).email || 'admin@exemplo.com.br';
        db.config.__email_teste = JSON.stringify({ para, em: agora() }); log('configuracoes', null, null, 'e-mail de teste enviado', { para }); salvar();
        return { ok: true, para };
      },
      async emailTesteResultado() {
        const t = db.config.__email_teste ? JSON.parse(db.config.__email_teste) : null;
        if (!t) return { teste: false };
        return { teste: true, para: t.para, em: t.em, pronto: true, ok: true, http: 200, provedor_id: 'demo',
          avisos: db.config.__segredo_webhook ? [{ tipo: 'email.sent', em: t.em }, { tipo: 'email.delivered', em: t.em }] : [] };
      },
      // ---------- Correções e limpeza (mesmas regras do banco) ----------
      async limparHistorico(de, ate, partes, motivo) {
        const mot = String(motivo || '').trim();
        if (mot.length < 5) throw new Error('Informe o motivo (pelo menos 5 caracteres)');
        if (!de || !ate || de > ate) throw new Error('Informe o período (data inicial até data final)');
        if (ate > U.hojeISO()) throw new Error('A data final não pode ser futura');
        if (!partes || !partes.length) throw new Error('Escolha o que limpar: atividades, e-mails enviados ou rotina');
        const f = { de, ate }, aberto = (e) => {
          const s = e.solicitacao_id && db.solicitacoes.find((x) => x.id === e.solicitacao_id), a = e.avaliacao_id && db.avaliacoes.find((x) => x.id === e.avaliacao_id),
            n = e.solicitacao_nf_id && db.solicitacoes_nf.find((x) => x.id === e.solicitacao_nf_id);
          return e.status === 'pendente' || (s && ['gerado', 'enviado', 'aberto', 'expirado'].includes(s.status) && !s.recebido_em)
            || (a && ['gerada', 'enviada', 'aberta'].includes(a.status)) || (n && ['gerada', 'enviada', 'aberta'].includes(n.status));
        };
        // Nada é apagado: os registros recebem a marca de "limpo" (saem da lista; aparecem no filtro e na busca)
        let ativ = 0, mail = 0, mant = 0, rot = 0;
        const quem = (meuUsuario() || {}).email || 'demonstração', marca = (x) => { x.arquivado_em = agora(); x.arquivado_por = quem; };
        if (partes.includes('atividades')) db.historico.filter((h) => noPeriodo(h.created_at, f) && h.acao !== 'histórico limpo' && !h.arquivado_em).forEach((h) => { marca(h); ativ++; });
        if (partes.includes('emails')) {
          const no = db.envios_email.filter((e) => noPeriodo(e.created_at, f) && !e.arquivado_em);
          mant = no.filter(aberto).length;
          no.filter((e) => !aberto(e)).forEach((e) => { marca(e); mail++; });
        }
        if (partes.includes('rotina')) {
          db.rotina_log.filter((r) => noPeriodo(r.executado_em, f) && !r.arquivado_em && !['envio automático', 'avaliação automática', 'pasta programada'].includes(r.origem)
            && !(r.origem === 'cobrança automática' && U.dataLocal(r.executado_em) === U.hojeISO())).forEach((r) => { marca(r); rot++; });
        }
        log('historico', null, null, 'histórico limpo', { de: U.dataBR(de), ate: U.dataBR(ate), partes, oculto: true, atividades: ativ, emails: mail, emails_mantidos: mant, rotina: rot, motivo: mot });
        salvar(); return { ok: true, atividades: ativ, emails: mail, emails_mantidos: mant, rotina: rot };
      },
      async excluirRecebimento(id, motivo, modo) {
        const mot = String(motivo || '').trim();
        if (mot.length < 5) throw new Error('Informe o motivo (pelo menos 5 caracteres)');
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!s || !['recebido', 'conferido'].includes(s.status)) throw new Error('Esta solicitação não tem recebimento para excluir');
        const trav = travadas(s.fornecedor_id, s.competencia, s.id);
        if (trav) throw new Error(`O pedido ${trav} já tem F.S., NF pedida ou pagamento. Desfaça essas etapas antes de excluir o recebimento.`);
        const docs = db.documentos.filter((d) => d.solicitacao_id === s.id);
        db.documentos = db.documentos.filter((d) => d.solicitacao_id !== s.id);
        docs.forEach((d) => { delete arquivos[d.caminho]; });
        const meds = db.medicoes.filter((m) => m.solicitacao_id === s.id);
        meds.forEach((m) => Object.assign(m, { valor_informado: null, valor_lido: null, valor_aprovado: null, status: 'aguardando' }));
        if (modo === 'cancelar') Object.assign(s, { status: 'cancelado', recebido_em: null, conferido_em: null, respondido_por: null, observacao_fornecedor: null });
        else Object.assign(s, { token: token64(), status: 'gerado', aberto_em: null, enviado_em: null, recebido_em: null, conferido_em: null, respondido_por: null,
          observacao_fornecedor: null, envio_status: null, envio_erro: null, expira_em: U.fimPrazoISO(agora(), prazoLinkDemo(s.pasta_envio_id), feriadosSet()) });
        log('solicitacoes', s.id, s.fornecedor_id, 'recebimento excluído', { competencia: U.compCurta(s.competencia), arquivos: docs.length, medicoes: meds.length,
          modo: modo === 'cancelar' ? 'solicitação cancelada' : 'link reaberto', motivo: mot });
        salvar(); return { ok: true, caminhos: docs.map((d) => d.caminho), modo, status: s.status };
      },
      async excluirSolicitacao(id, motivo) {
        const mot = String(motivo || '').trim();
        if (mot.length < 5) throw new Error('Informe o motivo (pelo menos 5 caracteres)');
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!s) throw new Error('Solicitação não encontrada');
        const trav = travadas(s.fornecedor_id, s.competencia, s.id);
        if (trav) throw new Error(`O pedido ${trav} já tem F.S., NF pedida ou pagamento. Desfaça essas etapas antes de excluir a solicitação.`);
        if (db.medicoes.some((m) => m.solicitacao_id === s.id && ['aprovado', 'pago'].includes(m.status))) throw new Error('Há valores aprovados nesta solicitação. Exclua o recebimento ou desfaça a aprovação antes.');
        const docs = db.documentos.filter((d) => d.solicitacao_id === s.id);
        db.documentos = db.documentos.filter((d) => d.solicitacao_id !== s.id);
        const env = db.envios_email.filter((e) => e.solicitacao_id === s.id).length;
        db.envios_email = db.envios_email.filter((e) => e.solicitacao_id !== s.id);
        const antes = db.medicoes.length;
        db.medicoes = db.medicoes.filter((m) => !(m.solicitacao_id === s.id && !m.folha_numero && !db.solicitacoes_nf.some((n) => n.medicao_id === m.id)));
        db.solicitacoes = db.solicitacoes.filter((x) => x.id !== s.id);
        log('solicitacoes', s.id, s.fornecedor_id, 'solicitação excluída', { competencia: U.compCurta(s.competencia), situacao: s.status, arquivos: docs.length, envios: env,
          medicoes: antes - db.medicoes.length, motivo: mot });
        salvar(); return { ok: true, caminhos: docs.map((d) => d.caminho), envios: env, medicoes: antes - db.medicoes.length };
      },
      async excluirEnvioEmail(id, motivo) {
        const mot = String(motivo || '').trim();
        if (mot.length < 5) throw new Error('Informe o motivo (pelo menos 5 caracteres)');
        const e = db.envios_email.find((x) => x.id === id);
        if (!e) throw new Error('Envio não encontrado');
        if (e.status === 'pendente') throw new Error('Este e-mail ainda está na fila do serviço. Aguarde a confirmação para excluir o registro.');
        db.envios_email = db.envios_email.filter((x) => x.id !== id);
        const volta = (lista, campo, st, novo) => {
          if (!e[campo] || db.envios_email.some((x) => x[campo] === e[campo])) return;
          const o = lista.find((x) => x.id === e[campo]);
          if (o && o.status === st && !o.aberto_em) Object.assign(o, { status: novo, enviado_em: null, envio_via: null, envio_status: null, envio_erro: null });
        };
        volta(db.solicitacoes, 'solicitacao_id', 'enviado', 'gerado');
        volta(db.avaliacoes, 'avaliacao_id', 'enviada', 'gerada');
        volta(db.solicitacoes_nf, 'solicitacao_nf_id', 'enviada', 'gerada');
        if (e.contrato_id && e.tipo === 'vencimento' && !db.envios_email.some((x) => x.contrato_id === e.contrato_id && x.tipo === 'vencimento')) {
          db.alertas = db.alertas.filter((a) => a.contrato_id !== e.contrato_id);
        }
        log('envios_email', e.id, e.fornecedor_id, 'registro de envio excluído', { competencia: U.compCurta(e.competencia), tipo: e.tipo, via: e.via, para: e.para, motivo: mot });
        salvar(); return { ok: true };
      },
      async removerArquivos(caminhos) { (caminhos || []).forEach((c) => { delete arquivos[c]; }); return { ok: true, removidos: (caminhos || []).length }; },

      async gerarSolicitacoes(comp, ids, pasta) {
        if (!U.compLiberada(comp, feriadosSet())) throw new Error('Só é possível solicitar o boletim de meses encerrados (ou do mês atual a partir do último dia útil)');
        const r = gerar(comp, ids, null, pasta || null); salvar(); return clone(r);
      },
      async registrarEnvio(id, emails, assunto, corpo, manterPrazo) {
        const s = db.solicitacoes.find((x) => x.id === id);
        if (!['gerado', 'enviado', 'aberto'].includes(s.status)) throw new Error('Esta solicitação não está aguardando envio');
        if (s.expira_em < agora()) throw new Error('O link expirou. Use "Gerar novo link e reenviar".');
        const ja = !!s.enviado_em || db.envios_email.some((e) => e.solicitacao_id === s.id);
        const lembrete = manterPrazo && ja;
        if (!lembrete) s.expira_em = U.fimPrazoISO(agora(), Number(conf('prazo_dias_uteis', 7)), feriadosSet());
        const tipo = lembrete ? 'lembrete' : ja ? 'reenvio' : 'envio';
        Object.assign(s, { enviado_em: agora(), emails_destino: emails, assunto, corpo, envio_via: 'outlook', envio_status: null, envio_erro: null,
          status: s.status === 'gerado' ? 'enviado' : s.status });
        db.envios_email.push({ id: uuid(), solicitacao_id: s.id, fornecedor_id: s.fornecedor_id, competencia: s.competencia, tipo, via: 'outlook', para: emails.slice(),
          assunto, corpo, prazo_ate: s.expira_em, status: 'registrado', erro: null, autor: 'demonstração', created_at: agora() });
        log('solicitacoes', s.id, s.fornecedor_id, { envio: 'e-mail enviado (Outlook)', reenvio: 'e-mail reenviado (Outlook)', lembrete: 'lembrete enviado (Outlook)' }[tipo], { para: emails, assunto });
        if (tipo === 'envio') avaliacaoJuntoDemo(s);
        salvar(); return clone(s);
      },
      async renovarLink(id) {
        const s = db.solicitacoes.find((x) => x.id === id);
        if (['expirado', 'cancelado'].includes(s.status) && db.solicitacoes.some((x) => x.id !== id && x.fornecedor_id === s.fornecedor_id && x.competencia === s.competencia
            && (x.pasta_envio_id || null) === (s.pasta_envio_id || null) && !['expirado', 'cancelado'].includes(x.status))) {
          throw new Error('Já existe outra solicitação ativa deste fornecedor para a competência (nesta pasta).');
        }
        Object.assign(s, { token: token64(), status: 'gerado', aberto_em: null, enviado_em: null, expira_em: U.fimPrazoISO(agora(), prazoLinkDemo(s.pasta_envio_id), feriadosSet()) });
        log('solicitacoes', s.id, s.fornecedor_id, 'novo link gerado', { competencia: U.compCurta(s.competencia) });
        salvar(); return clone(s);
      },
      async cancelarSolicitacao(id) {
        const s = db.solicitacoes.find((x) => x.id === id); s.status = 'cancelado';
        log('solicitacoes', s.id, s.fornecedor_id, 'solicitação cancelada', { competencia: U.compCurta(s.competencia) });
        salvar(); return clone(s);
      },
      async atualizarSolicitacao(id, patch) { const s = db.solicitacoes.find((x) => x.id === id); Object.assign(s, patch); salvar(); return clone(s); },

      async salvarFornecedor(f) {
        const { contatos, ...dados } = f;
        fornecedorRepetidoDemo(dados);
        if (dados.docs_colaborador_id && !db.colaboradores.some((c) => c.id === dados.docs_colaborador_id && c.ativo && c.email)) throw new Error('Escolha um colaborador ativo e com e-mail para mandar os documentos');
        const antes = dados.id ? forn(dados.id) : null;
        if (dados.docs_klingele && (!antes || !antes.docs_klingele || !antes.docs_analista)) dados.docs_analista = (meuUsuario() || {}).email || 'demonstração';
        let r;
        if (dados.id) { r = atualizar(db.fornecedores, dados.id, dados); log('fornecedores', r.id, r.id, 'alteração', {}); }
        else { r = { ...dados, id: uuid(), created_at: agora(), updated_at: agora() }; db.fornecedores.push(r); log('fornecedores', r.id, r.id, 'cadastro', { nome: r.nome }); }
        salvar(); return clone(r);
      },
      async excluirFornecedor(id) {
        const f = forn(id);
        db.fornecedores = db.fornecedores.filter((x) => x.id !== id);
        ['contatos', 'contratos', 'medicoes', 'solicitacoes', 'documentos', 'avaliacoes', 'solicitacoes_nf', 'notas_fiscais'].forEach((k) => { db[k] = db[k].filter((x) => x.fornecedor_id !== id); });
        log('fornecedores', id, id, 'exclusão', { nome: f && f.nome }); salvar();
      },
      async salvarContato(c) {
        let r;
        c = { ...c, email: String(c.email || '').trim().toLowerCase() };
        if (db.contatos.some((x) => x.id !== c.id && x.fornecedor_id === c.fornecedor_id && String(x.email || '').toLowerCase() === c.email)) throw new Error(`O e-mail ${c.email} já está nos contatos deste fornecedor`);
        if (c.id) r = atualizar(db.contatos, c.id, c);
        else { r = { ...c, id: uuid(), origem: c.origem || 'equipe', created_at: agora(), updated_at: agora() }; db.contatos.push(r); }
        log('contatos', r.id, r.fornecedor_id, c.id ? 'alteração' : 'cadastro', { email: r.email }); salvar(); return clone(r);
      },
      async excluirContato(id) {
        const c = db.contatos.find((x) => x.id === id);
        db.contatos = db.contatos.filter((x) => x.id !== id);
        if (c) log('contatos', id, c.fornecedor_id, 'exclusão', { email: c.email });
        salvar();
      },
      async salvarContrato(c) {
        let r;
        if (c.tipo_servico && !U.TIPOS_SERVICO[c.tipo_servico]) throw new Error('Tipo de serviço inválido');
        if ('parcelas_total' in c || 'parcelas_pagas_antes' in c) {
          const atual = c.id ? contr(c.id) : {};
          const total = 'parcelas_total' in c ? c.parcelas_total : atual.parcelas_total, antes = Number('parcelas_pagas_antes' in c ? c.parcelas_pagas_antes : atual.parcelas_pagas_antes) || 0;
          if (total !== null && total !== undefined && !(Number.isInteger(total) && total >= 1 && total <= 600)) throw new Error('Total de parcelas entre 1 e 600');
          if (!(Number.isInteger(antes) && antes >= 0 && antes <= 600) || (total && antes > total)) throw new Error('Parcelas do contrato inválidas: as pagas antes do sistema não podem passar do total (até 600).');
          const ps = c.id ? db.medicoes.filter((m) => m.contrato_id === c.id && m.parcela).map((m) => m.parcela) : [];
          if (ps.length && total && Math.max(...ps) > total) throw new Error(`A parcela ${Math.max(...ps)} já foi lançada: o total de parcelas não pode ser menor que ${Math.max(...ps)}`);
          if (ps.length && antes >= Math.min(...ps)) throw new Error(`A parcela ${Math.min(...ps)} já foi lançada no sistema: as parcelas pagas antes do sistema devem ser menos de ${Math.min(...ps)}`);
        }
        if (c.supervisores || c.contatos || 'supervisor_id' in c) {
          const atual = c.id ? contr(c.id) || {} : {};
          let sups = c.supervisores ? [...new Set(c.supervisores.filter(Boolean))]
            : 'supervisor_id' in c ? (c.supervisor_id ? [c.supervisor_id, ...supsDe(atual).filter((x) => x !== c.supervisor_id && x !== atual.supervisor_id)] : supsDe(atual).filter((x) => x !== atual.supervisor_id))
            : supsDe(atual);
          const cts = c.contatos ? [...new Set(c.contatos.filter(Boolean))] : (atual.contatos || []);
          if (sups.length > 10 || cts.length > 10) throw new Error('Até 10 supervisores e 10 contatos Klingele por contrato');
          const antes = supsDe(atual);
          if (sups.some((x) => !antes.includes(x) && !(colab(x) || {}).supervisor)) throw new Error('Supervisor inválido: escolha um contato Klingele marcado como supervisor');
          if (cts.some((x) => !colab(x))) throw new Error('Contato Klingele não encontrado');
          c = { ...c, supervisores: sups, contatos: cts, supervisor_id: sups[0] || null };
          if (sups[0]) c.gestor = colab(sups[0]).nome;
        }
        if ('pasta_id' in c && c.pasta_id && !pastaD(c.pasta_id)) throw new Error('Pasta não encontrada');
        const antes = c.id ? contr(c.id) || {} : {};
        if (c.id) r = atualizar(db.contratos, c.id, c);
        else { r = { pasta_id: null, pasta_escolhida: false, ...c, id: uuid(), created_at: agora(), updated_at: agora() }; db.contratos.push(r); }
        // pasta: escolha da equipe vale; contrato que ninguém pôs em pasta segue a regra das pastas (igual ao banco)
        if (c.id ? (r.pasta_id || null) !== (antes.pasta_id || null) : !!r.pasta_id) r.pasta_escolhida = true;
        else if (!r.pasta_id && !r.pasta_escolhida) r.pasta_id = pastaParaContratoDemo(r);
        log('contratos', r.id, r.fornecedor_id, c.id ? 'alteração' : 'cadastro', { pedido: r.pedido }); salvar(); return clone(r);
      },
      async excluirContrato(id) {
        const c = db.contratos.find((x) => x.id === id);
        db.contratos = db.contratos.filter((x) => x.id !== id);
        db.medicoes = db.medicoes.filter((m) => m.contrato_id !== id);
        db.solicitacoes_nf = db.solicitacoes_nf.filter((x) => x.contrato_id !== id);
        db.notas_fiscais = db.notas_fiscais.filter((x) => x.contrato_id !== id);
        if (c) log('contratos', id, c.fornecedor_id, 'exclusão', { pedido: c.pedido });
        salvar();
      },
      async salvarMedicao(m) {
        const campos = ['valor_aprovado', 'valor_lido', 'valor_informado', 'status', 'nota_fiscal', 'data_pagamento', 'observacao'];
        const alvo = db.medicoes.find((x) => x.id === m.id);
        const prev = { ...alvo, ...m };
        if (['aprovado', 'pago'].includes(prev.status) && (prev.valor_aprovado === null || prev.valor_aprovado === '' || prev.valor_aprovado === undefined)) throw new Error('Informe o valor aprovado antes de aprovar ou pagar');
        if (prev.status === 'pago' && !prev.data_pagamento) throw new Error('Informe a data de pagamento');
        if (alvo.folha_status === 'aprovada' && (('valor_aprovado' in m && Number(m.valor_aprovado) !== Number(alvo.valor_aprovado)) || !['aprovado', 'pago'].includes(prev.status))) {
          throw new Error('A folha de serviço desta medição já foi aprovada (processo finalizado). Desfaça a aprovação da F.S. antes de alterar.');
        }
        if ('valor_aprovado' in m && Number(m.valor_aprovado) !== Number(alvo.valor_aprovado) && nfPedida(alvo.id)) {
          throw new Error('A nota fiscal desta medição já foi pedida ao fornecedor. Cancele o pedido de NF antes de alterar o valor aprovado.');
        }
        const mud = {};
        campos.forEach((k) => { if (k in m) { const v = m[k] === '' ? null : m[k]; if (alvo[k] !== v) mud[k] = { de: alvo[k], para: v }; alvo[k] = v; } });
        alvo.updated_at = agora();
        if (Object.keys(mud).length) log('medicoes', alvo.id, alvo.fornecedor_id, 'alteração', mud);
        salvar(); return clone(alvo);
      },
      async incluirMedicao(c, comp) {
        const k = contr(c.id) || c, s = db.solicitacoes.find((x) => x.fornecedor_id === c.fornecedor_id && x.competencia === comp
          && !['expirado', 'cancelado'].includes(x.status) && (x.pasta_envio_id || null) === (k.pasta_id || null));
        const m = { id: uuid(), contrato_id: c.id, fornecedor_id: c.fornecedor_id, competencia: comp, solicitacao_id: s ? s.id : null, valor_contratado: c.valor_mensal,
          valor_informado: null, valor_lido: null, valor_aprovado: null, status: 'aguardando', nota_fiscal: null, data_pagamento: null, observacao: null,
          created_at: agora(), updated_at: agora() };
        db.medicoes.push(m); log('medicoes', m.id, m.fornecedor_id, 'cadastro', { pedido: c.pedido }); salvar(); return clone(m);
      },
      async salvarConfig(chave, valor) {
        const v = String(valor);
        if (chave === 'site_url' && v && !/^https:\/\/[^\s/]+(\/\S*)?$/.test(v)) throw new Error('O endereço do site precisa começar com https://');
        if (['email_remetente', 'email_resposta', 'email_copia', 'contato_klingele'].includes(chave) && v && !U.emailValido(v)) throw new Error('E-mail inválido: ' + v);
        if (chave === 'emails_suporte' && v && (v.split(',').length > 5 || v.split(',').some((e) => !U.emailValido(e.trim())))) throw new Error('Até 5 e-mails de suporte válidos');
        if (chave === 'horario_envio' && !U.HORARIOS.includes(v)) throw new Error('Horário inválido (06:00 às 20:45, de 15 em 15 minutos)');
        if (chave === 'dia_util_envio' && !/^[0-5]$/.test(v)) throw new Error('Escolha o último dia útil ou do 1º ao 5º dia útil');
        if (['cobranca_reenvio_dias', 'cobranca_semanal_dias', 'cobranca_intervalo_dias'].includes(chave) && !(Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 30)) throw new Error('Use de 1 a 30 dias');
        if (chave === 'cobranca_lembretes_max' && !(Number.isInteger(Number(v)) && Number(v) >= 0 && Number(v) <= 12)) throw new Error('Lembretes semanais: de 0 a 12');
        if (['alerta_venc_longo_dias', 'alerta_venc_curto_dias', 'alerta_venc_limite_curto'].includes(chave) && !(Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 999)) throw new Error('Dias do aviso entre 1 e 999');
        if (['fs_emails_servicos', 'fs_emails_ocorrencia', 'alerta_venc_emails'].includes(chave) && v && (v.split(',').length > 10 || v.split(',').some((e) => !U.emailValido(e.trim())))) throw new Error('Lista de e-mails inválida (até 10, separados por vírgula)');
        if (chave === 'cadastro_dominios' && v && !/^@?[a-z0-9.-]+\.[a-z]{2,}(\s*,\s*@?[a-z0-9.-]+\.[a-z]{2,}){0,9}$/.test(v)) throw new Error('Domínios inválidos (ex.: klingele.com.br)');
        if (['prazo_dias_uteis', 'avaliacao_prazo_dias_uteis', 'nf_prazo_dias_uteis'].includes(chave) && !(Number(v) >= 1 && Number(v) <= 30)) throw new Error('Use um prazo entre 1 e 30 dias úteis');
        if (chave === 'email_limite_dia' && !(Number.isInteger(Number(v)) && Number(v) >= 1 && Number(v) <= 5000)) throw new Error('Limite de e-mails por dia entre 1 e 5.000');
        if (chave === 'cnpj_klingele' && v && (v.split(',').length > 20 || v.split(',').some((x) => !U.cnpjValido(x.trim())))) throw new Error('CNPJ inválido na lista');
        if (chave === 'avaliacao_padrao' && v) { let p = null; try { p = JSON.parse(v); } catch (e) { /* inválido */ } if (!U.notasCompletas(p)) throw new Error('Resposta padrão inválida: notas de 1 a 10 em todos os itens'); }
        db.config[chave] = v; salvar();
      },
      async salvarFeriado(f) { db.feriados = db.feriados.filter((x) => x.data !== f.data).concat([{ data: f.data, nome: f.nome, tipo: 'feriado' }]).sort((a, b) => (a.data < b.data ? -1 : 1)); salvar(); },
      async excluirFeriado(data) { db.feriados = db.feriados.filter((x) => x.data !== data); salvar(); },
      async salvarMembro(m) { db.equipe = db.equipe.filter((x) => x.email !== m.email).concat([m]); salvar(); },
      async excluirMembro(email) { db.equipe = db.equipe.filter((x) => x.email !== email); salvar(); },
      async executarRotina() {
        let n = 0;
        db.solicitacoes.forEach((s) => { if (['gerado', 'enviado', 'aberto'].includes(s.status) && s.expira_em < agora()) { s.status = 'expirado'; n++; } });
        let na = 0;
        db.avaliacoes.forEach((a) => { if (['gerada', 'enviada', 'aberta'].includes(a.status) && a.expira_em < agora()) { a.status = 'expirada'; na++; } });
        const hoje = U.hojeISO();
        const venc = db.contratos.filter((c) => c.situacao === 'ativo' && c.data_fim >= hoje && c.data_fim <= U.addDias(hoje, 60)).length;
        let nn = 0;
        db.solicitacoes_nf.forEach((x) => { if (['gerada', 'enviada', 'aberta'].includes(x.status) && x.expira_em < agora()) { x.status = 'expirada'; nn++; } });
        const av = avisarVencimentosDemo();
        const det = { links_expirados: n, avaliacoes_expiradas: na, links_nf_expirados: nn, contratos_vencendo_60d: venc, avisos_vencimento: av };
        db.rotina_log.unshift({ id: db.seq++, origem: 'executado manualmente', executado_em: agora(), detalhes: det });
        salvar(); return { ok: true, ...det };
      },

      async urlDocumento(doc) {
        const f = arquivos[doc.caminho];
        if (f) return URL.createObjectURL(f);
        const d = db.documentos.find((x) => x.id === doc.id) || doc;
        return d.exemplo && ['pedido', 'nf', 'klingele'].includes(d.exemplo.tipo) ? URL.createObjectURL(pdfDeExemplo(d.exemplo)) : null;
      },
      async baixarDocumento(doc) {
        if (arquivos[doc.caminho]) return arquivos[doc.caminho];
        const d = db.documentos.find((x) => x.id === doc.id) || doc;
        if (d.exemplo && ['pedido', 'nf', 'klingele'].includes(d.exemplo.tipo)) return pdfDeExemplo(d.exemplo);
        if (d.exemplo) { await U.carregarXLSX(); return planilhaExemplo(d.exemplo); }
        throw new Error('Arquivo indisponível nesta demonstração (os anexos ficam só na aba em que foram enviados).');
      },
      async anexarDocumento({ solicitacao, fornecedor, competencia, file, tipo, contrato_id, valor_lido }) {
        const pasta = solicitacao ? solicitacao.pasta : pastaDe(fornecedor, competencia);
        const ext = U.extensao(file.name);
        if (tipo === 'klingele') {
          const s = solicitacao && db.solicitacoes.find((x) => x.id === solicitacao.id);
          if (!s || !docsLinkOk(s) || docsKlgDemo(s).length >= 15) throw new Error('Documento da Klingele: anexe no link do fornecedor ainda aberto (até 15 arquivos por link)');
        }
        const caminho = `${pasta}/equipe/${U.nomePadrao({ competencia, fornecedor: fornecedor.nome, tipo, ext }).replace(/\.[^.]+$/, '')}--${Date.now().toString(36)}${tipo === 'klingele' ? '-' + U.sufixoAleatorio() : ''}.${ext}`;
        arquivos[caminho] = file;
        const d = { id: uuid(), solicitacao_id: solicitacao ? solicitacao.id : null, fornecedor_id: fornecedor.id, contrato_id: contrato_id || null, competencia, tipo,
          nome_arquivo: file.name, caminho, mime: U.mimeArquivo(file.name), tamanho: file.size, valor_lido: valor_lido ?? null, enviado_por: 'equipe', created_at: agora() };
        d.nome_padrao = nomeDoc(d);
        db.documentos.push(d); log('documentos', d.id, fornecedor.id, 'documento anexado pela equipe', { arquivo: d.nome_padrao }); salvar(); return clone(d);
      },
      async atualizarDocumento(id, patch) {
        const d = db.documentos.find((x) => x.id === id);
        const mudouTipo = patch.tipo && patch.tipo !== d.tipo;
        Object.assign(d, patch);
        if (mudouTipo) d.nome_padrao = nomeDoc(d);
        salvar(); return clone(d);
      },
      async excluirDocumento(doc) { db.documentos = db.documentos.filter((x) => x.id !== doc.id); delete arquivos[doc.caminho]; salvar(); },

      // ---------- Portal ----------
      async portalAbrir(token) {
        const s = db.solicitacoes.find((x) => x.token === token);
        const contato = suporteDemo()[0] || '', suporte = suporteDemo(), contatos_klingele = contatosDemo();
        if (!s) return { ok: false, motivo: 'invalido', contato, suporte, contatos_klingele };
        if (['recebido', 'conferido'].includes(s.status)) return { ok: false, motivo: 'usado', recebido_em: s.recebido_em, contato, suporte, contatos_klingele };
        if (s.status === 'cancelado') return { ok: false, motivo: 'cancelado', dispensa: s.dispensa || null, contato, suporte, contatos_klingele };
        if (s.status === 'expirado' || s.expira_em < agora()) { s.status = 'expirado'; salvar(); return { ok: false, motivo: 'expirado', expira_em: s.expira_em, contato, suporte, contatos_klingele }; }
        const f = forn(s.fornecedor_id);
        if (!s.aberto_em) {
          s.aberto_em = agora();
          if (['gerado', 'enviado'].includes(s.status)) s.status = 'aberto';
          log('solicitacoes', s.id, f.id, 'link aberto pelo fornecedor', { competencia: U.compCurta(s.competencia) }, 'fornecedor (portal)');
          salvar();
        }
        return dadosPortal(s);
      },
      async portalEnviarArquivo(pastaUpload, file, i, nomeBase) {
        await new Promise((r) => setTimeout(r, 250));
        const caminho = `${pastaUpload}/${nomeBase || 'arquivo'}--${Date.now().toString(36)}${i}.${U.extensao(file.name)}`;
        arquivos[caminho] = file;
        return caminho;
      },
      async portalFinalizar(token, dados) {
        const erro = (codigo, msg, extra) => ({ ok: false, codigo, erro: msg, ...(extra || {}) });
        const s = db.solicitacoes.find((x) => x.token === token);
        if (!s) return erro('link', 'Link inválido.');
        if (!['gerado', 'enviado', 'aberto'].includes(s.status)) return erro('link', 'Este link já foi utilizado ou foi encerrado.');
        if (s.expira_em < agora()) return erro('link', 'O prazo deste link terminou.');
        // Mesmas regras do servidor
        if (dados.confirmacao_contatos !== true) return erro('contatos', 'Confirme que os contatos de e-mail estão corretos.');
        const ativos = (dados.contatos || []).filter((c) => !c.remover);
        if (ativos.some((c) => !U.emailValido(c.email))) return erro('contatos', 'E-mail inválido.');
        const naoCitados = db.contatos.filter((c) => c.fornecedor_id === s.fornecedor_id && c.recebe_boletim && !(dados.contatos || []).some((x) => x.id === c.id));
        if (!ativos.some((c) => c.recebe_boletim !== false) && !naoCitados.length) return erro('contatos', 'Mantenha pelo menos um contato recebendo a solicitação mensal.');
        const meds0 = db.medicoes.filter((m) => m.solicitacao_id === s.id);
        for (const m of meds0) {
          const v = (dados.valores || []).find((x) => x.contrato_id === m.contrato_id);
          if (!v) return erro('valores', 'Informe o valor de todos os pedidos ou marque "Sem medição no mês".');
          if (!v.sem_medicao && !U.valorOk(v.valor)) return erro('valores', 'Valor inválido no pedido.');
        }
        if (!dados.arquivos || !dados.arquivos.length) return erro('arquivos', 'Anexe pelo menos um arquivo.');
        if (dados.arquivos.length > U.LIMITES.arquivos) return erro('arquivos', 'Máximo de 20 arquivos por envio.');
        if (dados.arquivos.some((a) => !U.TIPOS_DOC_FORNECEDOR[a.tipo])) return erro('arquivos', 'Tipo de documento inválido.');
        const todosSem = meds0.length > 0 && (dados.valores || []).every((v) => v.sem_medicao);
        if (!todosSem && !dados.arquivos.some((a) => a.tipo === 'boletim')) return erro('arquivos', 'Anexe o boletim de medição (escolha o tipo "Boletim de medição" no arquivo).');
        if (!dados.responsavel || String(dados.responsavel.nome || '').trim().length < 2) return erro('responsavel', 'Informe o nome de quem está enviando.');
        const hashes = dados.arquivos.map((a) => a.hash_sha256).filter(Boolean);
        if (new Set(hashes).size !== hashes.length) return erro('arquivos', 'O mesmo arquivo foi anexado duas vezes.');
        if (!dados.confirmar_duplicados) {
          const dups = db.documentos.filter((d) => d.fornecedor_id === s.fornecedor_id && d.hash_sha256 && hashes.includes(d.hash_sha256))
            .map((d) => ({ arquivo: d.nome_arquivo, competencia: d.competencia.slice(5, 7) + '/' + d.competencia.slice(0, 4) }));
          if (dups.length) return erro('duplicado', 'Um ou mais arquivos são idênticos a documentos já enviados antes. Confira se é o boletim do mês certo.', { duplicados: dups });
        }
        (dados.contatos || []).forEach((c) => {
          if (c.remover) { if (c.id) db.contatos = db.contatos.filter((x) => x.id !== c.id); return; }
          if (c.id) {
            const o = db.contatos.find((x) => x.id === c.id);
            const mudou = o.nome !== c.nome || o.email !== c.email.toLowerCase() || (o.telefone || '') !== (c.telefone || '') || o.recebe_boletim !== c.recebe_boletim;
            Object.assign(o, { nome: c.nome, email: c.email.toLowerCase(), telefone: c.telefone, recebe_boletim: c.recebe_boletim, updated_at: agora() });
            if (mudou) { o.origem = 'fornecedor'; log('contatos', o.id, s.fornecedor_id, 'alteração', { email: o.email }, 'fornecedor (portal)'); }
          } else {
            const n = { id: uuid(), fornecedor_id: s.fornecedor_id, nome: c.nome, email: c.email.toLowerCase(), telefone: c.telefone, recebe_boletim: c.recebe_boletim !== false,
              principal: false, origem: 'fornecedor', created_at: agora(), updated_at: agora() };
            db.contatos.push(n); log('contatos', n.id, s.fornecedor_id, 'cadastro', { email: n.email }, 'fornecedor (portal)');
          }
        });
        (dados.valores || []).forEach((v) => {
          const m = db.medicoes.find((x) => x.contrato_id === v.contrato_id && x.competencia === s.competencia);
          if (!m) return;
          m.valor_informado = v.sem_medicao ? 0 : U.parseValor(v.valor);
          m.status = v.sem_medicao ? 'sem_medicao' : 'recebido';
          m.solicitacao_id = s.id;
        });
        const meds = db.medicoes.filter((m) => m.solicitacao_id === s.id);
        const unico = meds.length === 1 ? meds[0].contrato_id : null;
        dados.arquivos.forEach((a) => {
          const contrato_id = a.contrato_id && meds.some((m) => m.contrato_id === a.contrato_id) ? a.contrato_id : unico;
          const dup = a.hash_sha256 ? db.documentos.find((d) => d.fornecedor_id === s.fornecedor_id && d.hash_sha256 === a.hash_sha256) : null;
          const doc = { id: uuid(), solicitacao_id: s.id, fornecedor_id: s.fornecedor_id, contrato_id, competencia: s.competencia, tipo: a.tipo,
            nome_arquivo: a.nome, caminho: a.caminho, mime: a.mime, tamanho: a.tamanho, valor_lido: a.valor_lido ?? null, enviado_por: 'fornecedor', created_at: agora(),
            hash_sha256: a.hash_sha256 || null, duplicado_de: dup ? dup.id : null };
          doc.nome_padrao = nomeDoc(doc);
          db.documentos.push(doc);
          if (contrato_id && a.tipo === 'boletim' && a.valor_lido != null) { const m = meds.find((x) => x.contrato_id === contrato_id); m.valor_lido = a.valor_lido; }
        });
        Object.assign(s, { status: 'recebido', recebido_em: agora(), observacao_fornecedor: (dados.observacao || '').trim() || null,
          respondido_por: [dados.responsavel && dados.responsavel.nome, dados.responsavel && dados.responsavel.email].filter(Boolean).join(' · ') || null });
        log('solicitacoes', s.id, s.fornecedor_id, 'documentos recebidos', { competencia: U.compCurta(s.competencia), arquivos: dados.arquivos.length }, 'fornecedor (portal)');
        salvar();
        return { ok: true, arquivos: dados.arquivos.length, recebido_em: agora() };
      }
    };
    return api;
  }

  window.API = cfg.modo === 'demo' ? criarDemo() : criarSupabase();
})();

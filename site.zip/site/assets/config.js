/* BMK · Boletim Mensal Klingele · configuração do site
   Use SOMENTE a chave publicável (sb_publishable_...). Ela pode ficar no navegador:
   sem login da equipe ela não lê nenhuma tabela, só chama as funções do portal.
   NUNCA coloque a chave secreta (sb_secret_...) neste arquivo nem em nenhum HTML. */
window.APP_CONFIG = {
  modo: 'supabase',                                   // 'demo' usa dados locais de exemplo
  supabaseUrl: 'https://hyshticwkszbofyybpbu.supabase.co',
  supabaseKey: 'sb_publishable_uJe0mGclRlyB-oEZL4Fqvg_MdfttKGU',
  portalUrl: null,                                    // padrão: mesmo site + /portal.html
  turnstileSiteKey: null,                             // opcional: chave do site do Cloudflare Turnstile (anti-robô no login)
  // Opcional (recomendado): hash de integridade de cada biblioteca externa. Com o hash, o navegador
  // recusa o arquivo se ele for alterado no servidor de origem. Veja o LEIAME (seção "Integridade").
  // Exemplo: 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.49.4/dist/umd/supabase.min.js': 'sha384-...'
  sri: {}
};

/* BMK · Boletim Mensal Klingele · avaliação de satisfação do supervisor (link de uso único) */
(function () {
  'use strict';
  const esc = U.esc;

  function montar(el, token, opts) {
    const api = opts.api;
    const st = { fase: 'carregando', d: null, notas: {}, obs: '', nome: '', enviando: false, resultado: null, previa: false };

    const topo = () => `<header class="portal-top"><div class="in">
      ${U.marca('Boletim Mensal Klingele · avaliação de satisfação')}
    </div></header>`;

    const contatos = () => ((st.d && st.d.contatos_klingele) || []);
    const cartoes = () => `<div class="kl-contatos">${contatos().map((c) => `<div class="kl-contato">
        ${c.nome ? `<b>${esc(c.nome)}</b>` : ''}${c.cargo ? `<span class="small muted">${esc(c.cargo)}</span>` : ''}
        ${c.email ? `<a href="mailto:${esc(c.email)}">${U.ic.mail}<span>${esc(c.email)}</span></a>` : ''}
        ${c.telefone ? `<a href="tel:${esc(String(c.telefone).replace(/[^0-9+]/g, ''))}">${U.ic.tel}<span>${esc(c.telefone)}</span></a>` : ''}
      </div>`).join('')}</div>`;
    const ajuda = () => (contatos().length ? `<div class="stack" style="gap:8px"><p>Problemas com o link? Fale com a equipe de contratos:</p>${cartoes()}</div>` : '');

    function render() {
      let corpo = '';
      if (st.fase === 'carregando') corpo = '<div class="portal-done"><p class="muted">Abrindo a avaliação…</p></div>';
      else if (st.fase === 'erro') corpo = telaErro();
      else if (st.fase === 'concluido') corpo = telaConcluido();
      else corpo = telaFormulario();
      const faixa = st.previa ? '<div class="demo-banner"><strong>Prévia da equipe</strong><span>É o que o supervisor vê ao abrir o link. Nada aqui é gravado e o link não é marcado como aberto.</span></div>' : '';
      el.innerHTML = `<div class="portal">${topo()}<main class="portal-main">${faixa}${corpo}</main></div>`;
      if (st.fase === 'form') atualizarMedia();
    }

    function telaErro() {
      const d = st.d || {};
      const t = {
        invalido: ['Link não encontrado', 'Confira se o endereço foi copiado inteiro do e-mail. Se o problema continuar, peça um novo link à equipe de contratos.'],
        usado: ['Esta avaliação já foi registrada', `A avaliação foi registrada em ${U.dataHoraBR(d.respondido_em)}. Cada link aceita uma única resposta.`],
        expirado: ['O prazo desta avaliação terminou', `O link valia até ${U.dataBR(U.dataLocal(d.expira_em))}. Se ainda quiser avaliar, peça um novo link à equipe de contratos.`],
        cancelado: ['Avaliação cancelada', 'Esta avaliação foi cancelada pela equipe de contratos.'],
        bloqueado: ['Acesso bloqueado temporariamente', 'Houve muitas tentativas com links inválidos a partir desta rede. Aguarde uma hora e abra o link do e-mail novamente.'],
        limite: ['Muitas tentativas em pouco tempo', 'Aguarde alguns minutos e recarregue a página.'],
        falha: ['Não foi possível abrir a avaliação', d.mensagem || 'Verifique sua conexão e recarregue a página.']
      }[d.motivo] || ['Link indisponível', ''];
      return `<section class="portal-done"><h1>${esc(t[0])}</h1><p>${esc(t[1])}</p>${ajuda()}</section>`;
    }

    function telaConcluido() {
      const r = st.resultado || {};
      return `<section class="portal-done">
        <div class="mark">${U.ic.ok}</div>
        <h1>Avaliação registrada</h1>
        <p>Obrigado! A avaliação de <b>${esc(st.d.fornecedor.nome)}</b> em <b>${esc(U.cap(st.d.mes))}/${esc(st.d.ano)}</b> foi registrada em ${esc(U.dataHoraBR(r.respondido_em || new Date().toISOString()))}.</p>
        <div class="nota-resumo"><span class="label">Nota geral</span><span class="nota-badge ${U.classeNota(r.nota_geral)}">${esc(U.nota(r.nota_geral))}</span></div>
        <div class="table-wrap"><table class="tbl"><tbody>${U.CATEGORIAS.map(([k, n]) => `<tr><td>${esc(n)}</td><td class="r num"><b>${esc(st.notas[k])}</b></td></tr>`).join('')}</tbody></table></div>
        <p class="muted">Este link foi encerrado.</p>
        ${opts.simulacao ? '<div class="row"><button class="btn primary" data-a="fechar">Voltar ao app da equipe</button></div>' : ''}
      </section>`;
    }

    function telaFormulario() {
      const d = st.d;
      const prazo = U.dataLocal(d.expira_em);
      const restam = U.diasUteisAte(prazo, { feriados: new Set(d.feriados || []) });
      return `
      <section class="portal-hero">
        <span class="label">Avaliação de satisfação · ${esc(U.cap(d.mes))}/${esc(d.ano)}</span>
        <h1>${esc(d.fornecedor.nome)}</h1>
        <div class="portal-facts">
          <span>Supervisor <b>${esc(d.supervisor)}</b></span>
          <span>Prazo <b>${esc(U.dataBR(prazo))}</b> ${restam <= 2 ? `<span class="chip warn">${restam <= 0 ? 'último dia' : `faltam ${restam} dias úteis`}</span>` : `<span class="muted">(${restam} dias úteis)</span>`}</span>
        </div>
        ${d.contratos && d.contratos.length ? `<ul class="small" style="margin:0;padding-left:18px;color:var(--ink-2)">${d.contratos.map((c) => `<li>${esc(c.titulo)} <span class="mono muted">${esc(c.pedido)}</span>${c.tipo_servico ? ` <span class="muted">· ${esc(U.tipoServicoTxt(c.tipo_servico))}</span>` : ''}</li>`).join('')}</ul>` : ''}
        <p class="muted small">Nota de 1 a 10 por item; a geral é a média. Link de uso único.</p>
        ${contatos().length ? `<details class="kl-box"><summary>Dúvidas? Contatos da Klingele (${contatos().length})</summary>${cartoes()}</details>` : ''}
      </section>

      <section class="pstep" id="a-sec-notas">
        <div class="pstep-head"><span class="pstep-n">1</span><div><h2>Notas</h2><p>1 = muito ruim · 10 = excelente</p></div></div>
        <div class="pstep-body">${U.CATEGORIAS.map(([k, nome, desc]) => `
          <fieldset class="nota-item" data-cat="${k}">
            <legend><b>${esc(nome)}</b><span class="small muted">${esc(desc)}</span></legend>
            <div class="escala" role="radiogroup" aria-label="${esc(nome)}">${Array.from({ length: 10 }, (_, i) => i + 1).map((n) => `
              <label><input type="radio" name="n-${k}" value="${n}" ${st.notas[k] === n ? 'checked' : ''}><span>${n}</span></label>`).join('')}</div>
          </fieldset>`).join('')}
        </div>
      </section>

      <section class="pstep" id="a-sec-envio">
        <div class="pstep-head"><span class="pstep-n">2</span><div><h2>Revisar e enviar</h2><p>Confira a média e, se quiser, deixe um comentário.</p></div></div>
        <div class="pstep-body">
          <div class="nota-resumo"><span class="label">Nota geral (média)</span><span class="nota-badge" id="a-media">—</span><span class="small muted" id="a-cont"></span></div>
          <div class="form-grid">
            <label class="field"><span>Seu nome</span><input type="text" id="a-nome" maxlength="120" autocomplete="name" value="${esc(st.nome)}"></label>
            <label class="field full"><span>Observações <span class="hint">(opcional)</span></span><textarea id="a-obs" rows="3" maxlength="2000" style="min-height:84px">${esc(st.obs)}</textarea></label>
          </div>
          <div id="a-erros"></div>
          <div class="row"><button class="btn primary" type="button" data-a="enviar" id="a-enviar" ${st.previa ? 'disabled title="Desativado na prévia"' : ''}>${U.ic.envio} Enviar avaliação</button>
            <span class="small muted" id="a-status"></span></div>
        </div>
      </section>`;
    }

    function atualizarMedia() {
      const m = U.mediaNotas(st.notas);
      const n = U.CATEGORIAS.filter(([k]) => Number.isInteger(st.notas[k])).length;
      const b = el.querySelector('#a-media'), c = el.querySelector('#a-cont');
      if (b) { b.textContent = U.nota(m); b.className = 'nota-badge ' + U.classeNota(m); }
      if (c) c.textContent = `${n} de ${U.CATEGORIAS.length} itens avaliados`;
    }

    function validar() {
      const e = [];
      const falta = U.CATEGORIAS.filter(([k]) => !Number.isInteger(st.notas[k]));
      if (falta.length) e.push(['a-sec-notas', `Dê nota para: ${falta.map((x) => x[1]).join(', ')}.`]);
      if (st.nome.trim().length < 2) e.push(['a-sec-envio', 'Informe seu nome.']);
      if (st.obs.length > U.LIMITES.observacao) e.push(['a-sec-envio', 'Observação muito longa (máximo 2.000 caracteres).']);
      return e;
    }

    async function enviar() {
      if (st.enviando) return;
      if (st.previa) { U.toast('Na prévia o envio fica desativado'); return; }
      const box = el.querySelector('#a-erros');
      const erros = validar();
      if (erros.length) {
        box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Antes de enviar</strong><ul style="margin:6px 0 0;padding-left:18px">${erros.map((x) => `<li>${esc(x[1])}</li>`).join('')}</ul></div></div>`;
        const alvo = el.querySelector('#' + erros[0][0]);
        if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      box.innerHTML = '';
      st.enviando = true;
      const btn = el.querySelector('#a-enviar'), stt = el.querySelector('#a-status');
      btn.disabled = true; stt.textContent = 'Enviando…';
      try {
        const notas = {};
        U.CATEGORIAS.forEach(([k]) => { notas[k] = st.notas[k]; });
        const r = await api.avaliacaoResponder(token, { notas, nome: st.nome.trim(), observacao: st.obs });
        if (!r || r.ok === false) {
          st.enviando = false; btn.disabled = false; stt.textContent = '';
          box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Avaliação não enviada</strong><p style="margin-top:4px">${esc((r && r.erro) || 'Tente de novo.')}</p></div></div>`;
          return;
        }
        st.resultado = r;
        st.fase = 'concluido';
        render();
        (el.closest('.portal-overlay') || document.scrollingElement || document.documentElement).scrollTo(0, 0);
        if (opts.aoConcluir) opts.aoConcluir();
      } catch (err) {
        st.enviando = false; btn.disabled = false; stt.textContent = '';
        box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Avaliação não enviada</strong><p style="margin-top:4px">${esc(err.message)} Tente de novo.</p></div></div>`;
      }
    }

    el.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-a]');
      if (!b) return;
      if (b.dataset.a === 'enviar') enviar();
      if (b.dataset.a === 'fechar' && opts.aoFechar) opts.aoFechar();
    });
    el.addEventListener('change', (ev) => {
      const t = ev.target;
      if (t.type === 'radio' && /^n-/.test(t.name)) {
        st.notas[t.name.slice(2)] = Number(t.value);
        const fs = t.closest('.nota-item'); if (fs) fs.classList.add('feito');
        atualizarMedia();
      }
    });
    el.addEventListener('input', (ev) => {
      const t = ev.target;
      if (t.id === 'a-nome') st.nome = t.value;
      if (t.id === 'a-obs') st.obs = t.value;
    });

    render();
    (async () => {
      try {
        let d;
        if (opts.previaId) { st.previa = true; d = await api.avaliacaoPrevia(opts.previaId); }
        else {
          if (!token || token.length !== 64) { st.d = { ok: false, motivo: 'invalido' }; st.fase = 'erro'; return render(); }
          d = await api.avaliacaoAbrir(token);
        }
        st.d = d;
        if (!d.ok) { st.fase = 'erro'; return render(); }
        st.nome = d.supervisor || '';
        st.fase = 'form';
        render();
      } catch (e) {
        st.d = { ok: false, motivo: 'falha', mensagem: e.message };
        st.fase = 'erro';
        render();
      }
    })();
  }

  window.Avaliacao = { montar };
})();

/* BMK · Boletim Mensal Klingele · portal do fornecedor (link de uso único) */
(function () {
  'use strict';
  const esc = U.esc;

  function montar(el, token, opts) {
    const api = opts.api;
    const st = {
      fase: 'carregando', d: null, contatos: [], valores: {}, semMed: {}, arquivos: [],
      obs: '', resp: { nome: '', email: '' }, confirma: false, erros: [], progresso: 0, enviando: false, resultado: null
    };
    let seq = 0;

    const topo = () => `<header class="portal-top"><div class="in">
      ${U.marca('Boletim Mensal Klingele · envio do boletim de medição')}
    </div></header>`;

    function render() {
      let corpo = '';
      if (st.fase === 'carregando') corpo = `<div class="portal-done"><p class="muted">Abrindo sua solicitação…</p></div>`;
      else if (st.fase === 'erro') corpo = telaErro();
      else if (st.fase === 'concluido') corpo = telaConcluido();
      else corpo = telaFormulario();
      const faixa = st.previa ? `<div class="demo-banner"><strong>Prévia da equipe</strong><span>É exatamente o que o fornecedor vê ao abrir o link. Nada aqui é gravado e o link não é marcado como aberto.</span></div>` : '';
      el.innerHTML = `<div class="portal">${topo()}<main class="portal-main">${faixa}${corpo}</main></div>`;
      if (st.fase === 'form') { renderContatos(); renderValores(); renderArquivos(); }
    }

    // Contatos Klingele (nome, cargo, e-mail e telefone) cadastrados pela equipe no painel de envio
    const listaSuporte = () => {
      const d = st.d || {};
      if (d.contatos_klingele && d.contatos_klingele.length) return d.contatos_klingele;
      return (d.suporte && d.suporte.length ? d.suporte : d.contato ? [d.contato] : []).filter(Boolean).map((e) => ({ email: e }));
    };
    // Contatos por serviço: quando cada serviço tem os seus contatos (ex.: serviços Spot), a página separa por serviço
    const gruposSuporte = () => {
      const ss = ((st.d && st.d.contatos_servicos) || []).filter((s) => s.contatos && s.contatos.length);
      return new Set(ss.map((s) => JSON.stringify(s.contatos))).size > 1 ? ss : null;
    };
    const cartoesContato = (lista) => `<div class="kl-contatos">${(lista || listaSuporte()).map((c) => `<div class="kl-contato">
        ${c.nome ? `<b>${esc(c.nome)}</b>` : ''}${c.cargo ? `<span class="small muted">${esc(c.cargo)}</span>` : ''}
        ${c.email ? `<a href="mailto:${esc(c.email)}">${U.ic.mail}<span>${esc(c.email)}</span></a>` : ''}
        ${c.telefone ? `<a href="tel:${esc(String(c.telefone).replace(/[^0-9+]/g, ''))}">${U.ic.tel}<span>${esc(c.telefone)}</span></a>` : ''}
      </div>`).join('')}</div>`;
    function contatoKlingele() {
      const g = gruposSuporte();
      if (g) {
        return `<div class="stack" style="gap:10px"><p>Problemas com o link ou o código? Fale com o contato Klingele de cada serviço:</p>
          ${g.map((s) => `<div class="kl-servico"><span class="small"><b>${esc(s.titulo)}</b>${s.pedido ? ` · Pedido ${esc(s.pedido)}` : ''}</span>${cartoesContato(s.contatos)}</div>`).join('')}</div>`;
      }
      return listaSuporte().length ? `<div class="stack" style="gap:8px"><p>Problemas com o link ou o código? Fale com a Klingele:</p>${cartoesContato()}</div>`
        : '<p class="muted">Fale com seu contato na Klingele.</p>';
    }
    // Nome com que cada arquivo fica guardado na Klingele (o 2º do mesmo tipo ganha _2)
    function nomeArquivo(a) {
      const iguais = st.arquivos.filter((x) => !x.erro && x.tipo === a.tipo);
      const seq = iguais.indexOf(a) + 1;
      return U.nomePadrao({ competencia: st.d.competencia, fornecedor: st.d.fornecedor.nome, tipo: a.tipo, ext: U.extensao(a.file.name), seq: seq > 0 ? seq : 1 });
    }

    function telaErro() {
      const d = st.d || {};
      const t = {
        invalido: ['Link não encontrado', 'Confira se o endereço foi copiado inteiro do e-mail. Se o problema continuar, peça um novo link.'],
        usado: ['Este link já foi utilizado', `Os documentos foram recebidos em ${U.dataHoraBR(d.recebido_em)}. Cada link aceita um único envio. Para complementar, peça um novo link à Klingele.`],
        expirado: ['O prazo deste link terminou', `O link valia até ${U.dataBR(U.dataLocal(d.expira_em))}. Peça um novo link à Klingele para enviar o boletim.`],
        cancelado: ['Solicitação cancelada', 'Esta solicitação foi cancelada pela Klingele. Se ainda precisar enviar documentos, peça um novo link.'],
        bloqueado: ['Acesso bloqueado temporariamente', 'Houve muitas tentativas com links inválidos a partir desta rede. Aguarde uma hora e abra o link do e-mail novamente.'],
        limite: ['Muitas tentativas em pouco tempo', 'Aguarde alguns minutos e recarregue a página.'],
        falha: ['Não foi possível abrir a solicitação', d.mensagem || 'Verifique sua conexão e recarregue a página.']
      }[d.motivo] || ['Link indisponível', ''];
      if (d.motivo === 'cancelado' && d.dispensa) {
        t[0] = 'Envio dispensado neste mês';
        t[1] = `A Klingele registrou que ${d.dispensa === 'sem_contrato' ? 'não há contrato' : 'não houve medição'} neste mês. Não é preciso enviar o boletim por este link. Se houve serviço, fale com a Klingele.`;
      }
      return `<section class="portal-done"><h1>${esc(t[0])}</h1><p>${esc(t[1])}</p>${contatoKlingele()}</section>`;
    }
    // Documentos que a Klingele deixou no link para o fornecedor fazer a medição
    function secaoDocsKlg() {
      const docs = st.d.documentos_klingele || [];
      if (!docs.length) return '';
      return `<section class="pstep docs-klg" id="p-sec-docs">
        <div class="pstep-head"><span class="pstep-n" aria-hidden="true">${U.ic.docs}</span><div><h2>Documentos da Klingele para a medição</h2>
          <p>Baixe ${docs.length === 1 ? 'o documento' : `os ${docs.length} documentos`} que a Klingele preparou para este mês. Depois de fazer a medição, envie o boletim abaixo, por este mesmo link.</p></div></div>
        <div class="pstep-body"><div class="stack" style="gap:8px">${docs.map((x, i) => {
          const ext = U.extensao(x.nome || x.nome_arquivo);
          return `<div class="file-row">
            <span class="ext ${esc(ext)}">${esc(ext)}</span>
            <div class="stack" style="gap:2px;min-width:0"><b style="overflow-wrap:anywhere">${esc(x.nome || x.nome_arquivo)}</b>
              <span class="small muted">${x.tamanho ? U.tamanho(x.tamanho) + ' · ' : ''}${x.nome_arquivo && x.nome_arquivo !== x.nome ? 'original: ' + esc(x.nome_arquivo) : 'documento da Klingele'}</span></div>
            <button class="btn sm" type="button" data-p="baixar-klg" data-i="${i}">${U.ic.baixar} Baixar</button>
          </div>`;
        }).join('')}</div></div>
      </section>`;
    }
    async function baixarDocKlg(i) {
      const x = (st.d.documentos_klingele || [])[i];
      if (!x) return;
      try {
        const url = await api.urlDocPortal(x);
        const a = document.createElement('a');
        a.href = url; a.download = x.nome || x.nome_arquivo || 'documento'; a.rel = 'noopener';
        document.body.appendChild(a); a.click(); a.remove();
      } catch (e) { U.toast(e.message || 'Não foi possível baixar o arquivo. Recarregue a página.', 'erro'); }
    }

    function telaConcluido() {
      const r = st.resultado || {};
      const lista = st.arquivos.map((a) => `<li><span class="mono small" style="overflow-wrap:anywhere">${esc(nomeArquivo(a))}</span> <span class="muted">· ${esc(U.TIPOS_DOC[a.tipo])} · enviado como ${esc(a.file.name)}</span></li>`).join('');
      const vals = st.d.contratos.map((c) => `<li>Pedido <span class="mono">${esc(c.pedido)}</span>: ${st.semMed[c.id] ? 'sem medição no mês' : esc(U.brl(U.parseValor(st.valores[c.id])))}</li>`).join('');
      return `<section class="portal-done">
        <div class="mark">${U.ic.ok}</div>
        <h1>Documentos recebidos</h1>
        <p>Recebemos o boletim de <b>${esc(U.cap(st.d.mes))}/${esc(st.d.ano)}</b> de <b>${esc(st.d.fornecedor.nome)}</b> em ${esc(U.dataHoraBR(r.recebido_em || new Date().toISOString()))}.</p>
        <div class="stack"><div><span class="label">Arquivos</span><ul>${lista}</ul></div><div><span class="label">Valores informados</span><ul>${vals}</ul></div></div>
        <p class="muted">Este link foi encerrado. Guarde esta tela como comprovante do envio.</p>
        ${opts.simulacao ? '<div class="row"><button class="btn primary" data-p="fechar">Voltar ao app da equipe</button></div>' : ''}
      </section>`;
    }

    function telaFormulario() {
      const d = st.d;
      const prazo = U.dataLocal(d.expira_em);
      const fer = { feriados: new Set(d.feriados || []) };
      const restam = U.diasUteisAte(prazo, fer);
      const multi = d.contratos.length > 1;
      return `
      <section class="portal-hero">
        <span class="label">Boletim de medição · ${esc(U.cap(d.mes))}/${esc(d.ano)}</span>
        <h1>${esc(d.fornecedor.nome)}</h1>
        <div class="portal-facts">
          ${d.fornecedor.cnpj ? `<span>CNPJ <b class="num">${esc(d.fornecedor.cnpj)}</b></span>` : ''}
          ${d.fornecedor.codigo ? `<span>Código Klingele <b class="num">${esc(d.fornecedor.codigo)}</b></span>` : ''}
          <span>Prazo <b>${esc(U.dataBR(prazo))}</b> ${restam <= 2 ? `<span class="chip warn">${restam <= 0 ? 'último dia' : `faltam ${restam} dias úteis`}</span>` : `<span class="muted">(${restam} dias úteis)</span>`}</span>
        </div>
        <p class="muted small">Link de uso único: depois do envio ele deixa de funcionar.</p>
        ${d.pede_docs_klingele && !(d.documentos_klingele || []).length ? '<p class="small docs-klg-aviso">A Klingele ainda vai deixar neste link os documentos para a medição. Se precisar deles antes, fale com os contatos abaixo.</p>' : ''}
        ${gruposSuporte() ? `<details class="kl-box"><summary>Dúvidas? Contatos da Klingele por serviço (${gruposSuporte().length})</summary>
          ${gruposSuporte().map((s) => `<div class="kl-servico"><span class="small"><b>${esc(s.titulo)}</b>${s.pedido ? ` · Pedido ${esc(s.pedido)}` : ''}</span>${cartoesContato(s.contatos)}</div>`).join('')}</details>`
          : listaSuporte().length ? `<details class="kl-box"><summary>Dúvidas? Contatos da Klingele (${listaSuporte().length})</summary>${cartoesContato()}</details>` : ''}
      </section>

      ${secaoDocsKlg()}
      <section class="pstep" id="p-sec-contatos">
        <div class="pstep-head"><span class="pstep-n">1</span><div><h2>Contatos de e-mail</h2>
          <p>Quem recebe a solicitação mensal.</p></div></div>
        <div class="pstep-body">
          <div id="p-contatos" class="stack"></div>
          <div class="row between">
            <button class="btn sm" type="button" data-p="add-contato" ${st.contatos.length >= U.LIMITES.contatos ? 'disabled' : ''}>${U.ic.mais} Adicionar contato</button>
            <label class="check"><input type="checkbox" id="p-confirma" ${st.confirma ? 'checked' : ''}> Os contatos acima estão corretos</label>
          </div>
        </div>
      </section>

      <section class="pstep" id="p-sec-valores">
        <div class="pstep-head"><span class="pstep-n">2</span><div><h2>${multi ? 'Valor de cada pedido' : 'Valor do boletim'}</h2>
          <p>Total da medição de ${esc(U.cap(d.mes).toLowerCase())}. Com PDF ou Excel anexado, o total é lido automaticamente.</p></div></div>
        <div class="pstep-body"><div id="p-valores"></div></div>
      </section>

      <section class="pstep" id="p-sec-arquivos">
        <div class="pstep-head"><span class="pstep-n">3</span><div><h2>Documentos</h2>
          <p>Boletim, RDO, pré-NF, folha de ponto e outros (PDF, Excel, CSV, JPG ou PNG, até 25 MB). Escolha o tipo de cada arquivo.</p></div></div>
        <div class="pstep-body">
          <label class="drop" id="p-drop" for="p-file">
            ${U.ic.upload}
            <b>Arraste os arquivos aqui ou clique para escolher</b>
            <span class="small muted">PDF · XLSX · XLS · CSV · JPG · PNG · até ${U.LIMITES.arquivos} arquivos de ${U.LIMITES.mb} MB</span>
          </label>
          <input type="file" id="p-file" class="sr-only" multiple accept="${U.ACEITOS}">
          <div id="p-arquivos" class="stack"></div>
        </div>
      </section>

      <section class="pstep" id="p-sec-envio">
        <div class="pstep-head"><span class="pstep-n">4</span><div><h2>Revisar e enviar</h2>
          <p>Seu nome e, se quiser, uma observação.</p></div></div>
        <div class="pstep-body">
          <div class="form-grid">
            <label class="field"><span>Seu nome</span><input type="text" id="p-resp-nome" maxlength="120" autocomplete="name" value="${esc(st.resp.nome)}"></label>
            <label class="field"><span>Seu e-mail <span class="hint">(opcional)</span></span><input type="email" id="p-resp-email" maxlength="254" autocomplete="email" value="${esc(st.resp.email)}"></label>
            <label class="field full"><span>Observações <span class="hint">(opcional)</span></span><textarea id="p-obs" rows="3" maxlength="2000" style="min-height:84px">${esc(st.obs)}</textarea></label>
          </div>
          <div id="p-erros"></div>
          <div class="progress" id="p-prog" hidden><i></i></div>
          <div class="row"><button class="btn primary" type="button" data-p="enviar" id="p-enviar" ${st.previa ? 'disabled title="Desativado na prévia"' : ''}>${U.ic.envio} Enviar documentos</button>
            <span class="small muted" id="p-status"></span></div>
        </div>
      </section>`;
    }

    // ---------- Contatos ----------
    function renderContatos() {
      const box = el.querySelector('#p-contatos');
      if (!box) return;
      box.innerHTML = st.contatos.map((c, i) => `
        <div class="contact-row ${c.remover ? 'removed' : ''}">
          <input type="text" maxlength="120" placeholder="Nome" aria-label="Nome do contato" data-c="${i}" data-k="nome" value="${esc(c.nome || '')}" ${c.remover ? 'disabled' : ''}>
          <input class="c-mail" type="email" maxlength="254" placeholder="email@empresa.com.br" aria-label="E-mail do contato" data-c="${i}" data-k="email" value="${esc(c.email || '')}" ${c.remover ? 'disabled' : ''}>
          <input type="tel" maxlength="30" placeholder="Telefone" aria-label="Telefone do contato" data-c="${i}" data-k="telefone" value="${esc(c.telefone || '')}" ${c.remover ? 'disabled' : ''}>
          <label class="check small" title="Recebe a solicitação mensal"><input type="checkbox" data-c="${i}" data-k="recebe_boletim" ${c.recebe_boletim !== false ? 'checked' : ''} ${c.remover ? 'disabled' : ''}> Recebe</label>
          <button class="icon-btn" type="button" data-p="rm-contato" data-i="${i}" title="${c.remover ? 'Manter contato' : 'Remover contato'}" aria-label="${c.remover ? 'Manter contato' : 'Remover contato'}">${c.remover ? U.ic.refazer : U.ic.lixo}</button>
        </div>`).join('') || '<p class="muted">Nenhum contato cadastrado. Adicione pelo menos um e-mail.</p>';
    }

    // ---------- Valores ----------
    function renderValores() {
      const box = el.querySelector('#p-valores');
      if (!box) return;
      if (!st.d.contratos.length) { box.innerHTML = '<p class="muted">Nenhum pedido vinculado. Informe o valor nas observações.</p>'; return; }
      box.innerHTML = st.d.contratos.map((c) => `
        <div class="value-row">
          <div><div class="cell-title">${esc(c.titulo)}</div><div class="cell-sub">Pedido <span class="mono">${esc(c.pedido)}</span></div></div>
          <div class="stack" style="gap:6px">
            <input type="text" inputmode="decimal" maxlength="18" placeholder="R$ 0,00" aria-label="Valor do pedido ${esc(c.pedido)}" data-v="${esc(c.id)}"
              value="${esc(st.valores[c.id] || '')}" ${st.semMed[c.id] ? 'disabled' : ''}>
            <label class="check small"><input type="checkbox" data-sm="${esc(c.id)}" ${st.semMed[c.id] ? 'checked' : ''}> Sem medição no mês</label>
            <span class="small muted" data-vh="${esc(c.id)}"></span>
          </div>
        </div>`).join('');
    }

    // ---------- Arquivos ----------
    function renderArquivos() {
      const box = el.querySelector('#p-arquivos');
      if (!box) return;
      const contratos = st.d.contratos;
      box.innerHTML = st.arquivos.map((a) => {
        const ext = U.extensao(a.file.name);
        let leitura = '';
        if (a.verificando) leitura = '<span class="muted">Conferindo o arquivo…</span>';
        else if (a.lendo) leitura = '<span class="muted">Lendo o valor do arquivo…</span>';
        else if (a.leitura && a.leitura.valor) {
          const alvo = a.contrato_id || (contratos.length === 1 ? contratos[0].id : '');
          leitura = `<span>Valor identificado: <b class="num">${U.brl(a.leitura.valor)}</b></span><span class="muted">${esc(a.leitura.rotulo || '')}</span>
            ${alvo ? `<button class="btn sm" type="button" data-p="usar" data-a="${a.id}">Usar no pedido ${esc((contratos.find((c) => c.id === alvo) || {}).pedido || '')}</button>` : '<span class="muted">Escolha o pedido para usar este valor.</span>'}`;
        } else if (a.leitura) leitura = `<span class="muted">${esc(a.leitura.motivo || 'Total não identificado no arquivo. Informe o valor no passo 2.')}</span>`;
        return `<div class="file-row">
          <span class="ext ${esc(ext)}">${esc(ext)}</span>
          <div class="stack" style="gap:2px;min-width:0">
            <b style="overflow-wrap:anywhere">${esc(a.file.name)}</b>
            <span class="small muted">${U.tamanho(a.file.size)}${a.erro ? ` · <span style="color:var(--crit)">${esc(a.erro)}</span>` : ''}</span>
            ${a.erro ? '' : `<span class="small">Guardado como <span class="mono" style="overflow-wrap:anywhere">${esc(nomeArquivo(a))}</span></span>`}
            <div class="leitura">${leitura}</div>
            <div class="opts">
              <label class="field"><span>Tipo</span><select data-at="${a.id}">${Object.entries(U.TIPOS_DOC_FORNECEDOR).map(([k, v]) => `<option value="${k}" ${a.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
              ${contratos.length > 1 ? `<label class="field"><span>Pedido</span><select data-ac="${a.id}"><option value="">Todos / não se aplica</option>${contratos.map((c) => `<option value="${esc(c.id)}" ${a.contrato_id === c.id ? 'selected' : ''}>${esc(c.pedido)} · ${esc(c.titulo.slice(0, 40))}</option>`).join('')}</select></label>` : ''}
            </div>
          </div>
          <button class="icon-btn" type="button" data-p="rm-arquivo" data-a="${a.id}" aria-label="Remover arquivo">${U.ic.x}</button>
        </div>`;
      }).join('');
    }

    function adicionarArquivos(lista) {
      Array.from(lista || []).forEach((file) => {
        if (st.arquivos.length >= U.LIMITES.arquivos) { U.toast(`Máximo de ${U.LIMITES.arquivos} arquivos por envio`, 'erro'); return; }
        const ext = U.extensao(file.name);
        // Tipo sugerido pelo nome do arquivo; sem pista, o primeiro vira boletim e os demais "Outros"
        const sugerido = U.tipoPeloNome(file.name);
        const tipo = (sugerido && U.TIPOS_DOC_FORNECEDOR[sugerido] ? sugerido : null) || (st.arquivos.some((x) => x.tipo === 'boletim') ? 'outro' : 'boletim');
        const a = { id: ++seq, file, tipo,
          contrato_id: st.d.contratos.length === 1 ? st.d.contratos[0].id : '', leitura: null, lendo: false, caminho: null, erro: null, hash: null, verificando: true };
        st.arquivos.push(a);
        if (!U.MIME[ext]) { a.erro = 'Tipo não aceito'; a.verificando = false; return; }
        if (file.size > U.LIMITES.mb * 1048576) { a.erro = `Maior que ${U.LIMITES.mb} MB`; a.verificando = false; return; }
        if (file.size === 0) { a.erro = 'Arquivo vazio'; a.verificando = false; return; }
        (async () => {
          const assinaturaOk = await U.conferirAssinatura(file).catch(() => false);
          if (!assinaturaOk) { a.erro = `O conteúdo não corresponde a um arquivo .${ext}`; a.verificando = false; renderArquivos(); return; }
          a.hash = await U.sha256(file);
          a.verificando = false;
          if (a.hash && st.arquivos.some((x) => x !== a && x.hash === a.hash)) { a.erro = 'Arquivo repetido nesta lista'; renderArquivos(); return; }
          await lerValorArquivo(a);
        })();
      });
      renderArquivos();
    }

    // Lê o total de PDF e Excel (não lê folha de ponto nem RDO); no boletim, preenche o valor do pedido
    async function lerValorArquivo(a) {
      const ext = U.extensao(a.file.name);
      const legivel = ['pdf', 'xlsx', 'xls', 'csv'].includes(ext);
      if (legivel && !['ponto', 'rdo'].includes(a.tipo)) {
        a.lendo = true; renderArquivos();
        const r = await U.lerValor(a.file, a.file.name);
        a.lendo = false; a.leitura = r;
        const alvo = a.contrato_id || (st.d.contratos.length === 1 ? st.d.contratos[0].id : '');
        if (r.valor && alvo && !st.valores[alvo] && !st.semMed[alvo] && r.confianca !== 'baixa' && a.tipo === 'boletim') aplicarValor(a, alvo, true);
      } else {
        a.leitura = { suportado: false, naoLido: legivel, motivo: legivel ? `${U.TIPOS_DOC[a.tipo]}: sem leitura de valor.` : 'Imagem: informe o valor no passo 2.' };
      }
      renderArquivos();
    }

    function aplicarValor(a, contratoId, automatico) {
      st.valores[contratoId] = U.numBR(a.leitura.valor);
      const inp = el.querySelector(`[data-v="${CSS.escape(contratoId)}"]`);
      if (inp) inp.value = st.valores[contratoId];
      const h = el.querySelector(`[data-vh="${CSS.escape(contratoId)}"]`);
      if (h) h.textContent = (automatico ? 'Preenchido a partir de ' : 'Valor de ') + a.file.name + '. Confira antes de enviar.';
    }

    // ---------- Validação e envio ----------
    function validar() {
      const e = [];
      const ativos = st.contatos.filter((c) => !c.remover);
      if (!ativos.length) e.push(['p-sec-contatos', 'Mantenha pelo menos um contato de e-mail.']);
      if (ativos.length > U.LIMITES.contatos) e.push(['p-sec-contatos', `Máximo de ${U.LIMITES.contatos} contatos.`]);
      ativos.forEach((c) => {
        if (!U.emailValido(c.email)) e.push(['p-sec-contatos', `E-mail inválido: "${c.email || '(vazio)'}".`]);
        if (!U.telefoneValido((c.telefone || '').trim())) e.push(['p-sec-contatos', `Telefone inválido: "${c.telefone}". Use só números, espaço, parênteses, + e -.`]);
      });
      const emails = ativos.map((c) => (c.email || '').trim().toLowerCase());
      if (new Set(emails).size !== emails.length) e.push(['p-sec-contatos', 'Há e-mails repetidos na lista de contatos.']);
      if (ativos.length && !ativos.some((c) => c.recebe_boletim !== false)) e.push(['p-sec-contatos', 'Deixe pelo menos um contato marcado em "Recebe".']);
      if (!st.confirma) e.push(['p-sec-contatos', 'Confirme que os contatos estão corretos.']);
      st.d.contratos.forEach((c) => {
        if (st.semMed[c.id]) return;
        const v = U.arred(U.parseValor(st.valores[c.id]));
        if (!U.valorOk(v)) e.push(['p-sec-valores', `Informe um valor válido para o pedido ${c.pedido} (até R$ 100 milhões) ou marque "Sem medição no mês".`]);
      });
      if (!st.arquivos.length) e.push(['p-sec-arquivos', 'Anexe pelo menos um arquivo.']);
      if (st.arquivos.some((a) => a.verificando || a.lendo)) e.push(['p-sec-arquivos', 'Aguarde a conferência dos arquivos terminar.']);
      st.arquivos.forEach((a) => { if (a.erro) e.push(['p-sec-arquivos', `Remova o arquivo "${a.file.name}" (${a.erro}).`]); });
      const todosSem = st.d.contratos.length > 0 && st.d.contratos.every((c) => st.semMed[c.id]);
      if (st.arquivos.length && !todosSem && !st.arquivos.some((a) => a.tipo === 'boletim')) e.push(['p-sec-arquivos', 'Marque pelo menos um arquivo como "Boletim de medição".']);
      if (st.resp.nome.trim().length < 2) e.push(['p-sec-envio', 'Informe seu nome.']);
      if (st.resp.email && !U.emailValido(st.resp.email)) e.push(['p-sec-envio', 'Seu e-mail parece incorreto.']);
      if (st.obs.length > U.LIMITES.observacao) e.push(['p-sec-envio', 'Observação muito longa (máximo 2.000 caracteres).']);
      return e;
    }

    async function enviar() {
      if (st.enviando) return;
      if (st.previa) { U.toast('Na prévia o envio fica desativado'); return; }
      const erros = validar();
      const box = el.querySelector('#p-erros');
      if (erros.length) {
        box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Antes de enviar</strong><ul style="margin:6px 0 0;padding-left:18px">${erros.map((x) => `<li>${esc(x[1])}</li>`).join('')}</ul></div></div>`;
        const alvo = el.querySelector('#' + erros[0][0]);
        if (alvo) alvo.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      box.innerHTML = '';
      st.enviando = true;
      const btn = el.querySelector('#p-enviar'), prog = el.querySelector('#p-prog'), stt = el.querySelector('#p-status');
      btn.disabled = true; prog.hidden = false;
      try {
        const total = st.arquivos.length + 1;
        for (let i = 0; i < st.arquivos.length; i++) {
          const a = st.arquivos[i];
          stt.textContent = `Enviando ${i + 1} de ${st.arquivos.length}: ${a.file.name}`;
          if (!a.caminho) a.caminho = await api.portalEnviarArquivo(st.d.pasta_upload, a.file, i + 1, nomeArquivo(a).replace(/\.[^.]+$/, ''));
          prog.firstElementChild.style.width = Math.round(((i + 1) / total) * 100) + '%';
        }
        stt.textContent = 'Concluindo…';
        const r = await api.portalFinalizar(token, {
          confirmacao_contatos: st.confirma === true,
          confirmar_duplicados: st.confirmarDup === true,
          contatos: st.contatos.filter((c) => c.id || !c.remover).map((c) => ({ id: c.id || undefined, nome: (c.nome || '').trim(), email: (c.email || '').trim(), telefone: (c.telefone || '').trim(), recebe_boletim: c.recebe_boletim !== false, remover: !!c.remover })),
          valores: st.d.contratos.map((c) => ({ contrato_id: c.id, valor: st.semMed[c.id] ? null : U.arred(U.parseValor(st.valores[c.id])), sem_medicao: !!st.semMed[c.id] })),
          arquivos: st.arquivos.map((a) => ({ caminho: a.caminho, nome: a.file.name, tipo: a.tipo, mime: U.mimeArquivo(a.file.name), tamanho: a.file.size,
            contrato_id: a.contrato_id || null, hash_sha256: a.hash || null,
            valor_lido: a.leitura && a.leitura.valor && a.tipo === 'boletim' ? U.arred(a.leitura.valor) : null })),
          responsavel: { nome: st.resp.nome.trim(), email: st.resp.email.trim() },
          observacao: st.obs
        });
        if (!r || r.ok === false) {
          st.enviando = false; btn.disabled = false; stt.textContent = ''; prog.hidden = true;
          if (r && r.codigo === 'duplicado') {
            const lista = (r.duplicados || []).map((x) => `<li>${esc(x.arquivo)} (enviado em ${esc(x.competencia)})</li>`).join('');
            box.innerHTML = `<div class="demo-banner"><div><strong>Arquivo já enviado antes</strong><p style="margin-top:4px">${esc(r.erro)}</p><ul style="margin:6px 0;padding-left:18px">${lista}</ul>
              <div class="row"><button class="btn sm" type="button" data-p="enviar-dup">Enviar mesmo assim</button><span class="small muted">ou remova o arquivo e anexe o correto.</span></div></div></div>`;
          } else {
            const sec = { contatos: 'p-sec-contatos', valores: 'p-sec-valores', arquivos: 'p-sec-arquivos', responsavel: 'p-sec-envio' }[r && r.codigo];
            box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Envio não concluído</strong><p style="margin-top:4px">${esc((r && r.erro) || 'Tente de novo.')}</p></div></div>`;
            if (sec) el.querySelector('#' + sec).scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
          return;
        }
        st.resultado = r;
        prog.firstElementChild.style.width = '100%';
        st.fase = 'concluido';
        render();
        (el.closest('.portal-overlay') || document.scrollingElement || document.documentElement).scrollTo(0, 0);
        if (opts.aoConcluir) opts.aoConcluir();
      } catch (err) {
        st.enviando = false; btn.disabled = false;
        stt.textContent = '';
        box.innerHTML = `<div class="demo-banner" style="background:var(--crit-soft);border-color:transparent"><div><strong style="color:var(--crit)">Envio não concluído</strong><p style="margin-top:4px">${esc(err.message)} Tente de novo; os arquivos já enviados não serão duplicados.</p></div></div>`;
      }
    }

    // ---------- Eventos ----------
    el.addEventListener('click', (ev) => {
      const b = ev.target.closest('[data-p]');
      if (!b) return;
      const acao = b.dataset.p;
      if (acao === 'baixar-klg') { baixarDocKlg(Number(b.dataset.i)); return; }
      if (acao === 'add-contato' && st.contatos.length >= U.LIMITES.contatos) { U.toast(`Máximo de ${U.LIMITES.contatos} contatos`, 'erro'); return; }
      if (acao === 'add-contato') { st.contatos.push({ nome: '', email: '', telefone: '', recebe_boletim: true, novo: true }); renderContatos(); const ins = el.querySelectorAll('#p-contatos input[data-k="nome"]'); ins[ins.length - 1].focus(); }
      if (acao === 'rm-contato') {
        const c = st.contatos[Number(b.dataset.i)];
        if (c.id) c.remover = !c.remover; else st.contatos.splice(Number(b.dataset.i), 1);
        renderContatos();
      }
      if (acao === 'rm-arquivo') {
        st.arquivos = st.arquivos.filter((a) => a.id !== Number(b.dataset.a));
        st.arquivos.forEach((a) => { if (a.erro === 'Arquivo repetido nesta lista' && !st.arquivos.some((x) => x !== a && x.hash === a.hash && !x.erro)) a.erro = null; });
        renderArquivos();
      }
      if (acao === 'usar') {
        const a = st.arquivos.find((x) => x.id === Number(b.dataset.a));
        const alvo = a.contrato_id || st.d.contratos[0].id;
        st.semMed[alvo] = false;
        aplicarValor(a, alvo, false);
        U.toast('Valor aplicado ao pedido');
      }
      if (acao === 'enviar') { st.confirmarDup = false; enviar(); }
      if (acao === 'enviar-dup') { st.confirmarDup = true; enviar(); }
      if (acao === 'fechar' && opts.aoFechar) opts.aoFechar();
    });
    el.addEventListener('input', (ev) => {
      const t = ev.target;
      if (t.dataset.c !== undefined && t.dataset.k && t.type !== 'checkbox') st.contatos[Number(t.dataset.c)][t.dataset.k] = t.value;
      if (t.dataset.v) { st.valores[t.dataset.v] = t.value; const h = el.querySelector(`[data-vh="${CSS.escape(t.dataset.v)}"]`); if (h) h.textContent = ''; }
      if (t.id === 'p-resp-nome') st.resp.nome = t.value;
      if (t.id === 'p-resp-email') st.resp.email = t.value;
      if (t.id === 'p-obs') st.obs = t.value;
    });
    el.addEventListener('change', (ev) => {
      const t = ev.target;
      if (t.dataset.c !== undefined && t.dataset.k === 'recebe_boletim') st.contatos[Number(t.dataset.c)].recebe_boletim = t.checked;
      if (t.id === 'p-confirma') st.confirma = t.checked;
      if (t.dataset.sm) { st.semMed[t.dataset.sm] = t.checked; renderValores(); }
      if (t.id === 'p-file') { adicionarArquivos(t.files); t.value = ''; }
      if (t.dataset.at) {
        const a = st.arquivos.find((x) => x.id === Number(t.dataset.at));
        a.tipo = t.value;
        // Passou de ponto/RDO para um tipo com valor: lê o arquivo agora
        if (!a.erro && !a.verificando && a.leitura && a.leitura.naoLido && !['ponto', 'rdo'].includes(a.tipo)) lerValorArquivo(a);
        else renderArquivos();
      }
      if (t.dataset.ac !== undefined) { const a = st.arquivos.find((x) => x.id === Number(t.dataset.ac)); a.contrato_id = t.value; renderArquivos(); }
    });
    el.addEventListener('dragover', (ev) => { const d = ev.target.closest('#p-drop'); if (d) { ev.preventDefault(); d.classList.add('over'); } });
    el.addEventListener('dragleave', (ev) => { const d = ev.target.closest('#p-drop'); if (d) d.classList.remove('over'); });
    el.addEventListener('drop', (ev) => { const d = ev.target.closest('#p-drop'); if (d) { ev.preventDefault(); d.classList.remove('over'); adicionarArquivos(ev.dataTransfer.files); } });

    // ---------- Início ----------
    render();
    (async () => {
      try {
        let d;
        if (opts.previaId) { st.previa = true; d = await api.portalPrevia(opts.previaId); }
        else {
          if (!token || token.length !== 64) { st.d = { ok: false, motivo: 'invalido' }; st.fase = 'erro'; return render(); }
          d = await api.portalAbrir(token);
        }
        st.d = d;
        if (!d.ok) { st.fase = 'erro'; return render(); }
        st.contatos = (d.contatos || []).map((c) => ({ ...c }));
        st.fase = 'form';
        render();
      } catch (e) {
        st.d = { ok: false, motivo: 'falha', mensagem: e.message };
        st.fase = 'erro';
        render();
      }
    })();
  }

  window.Portal = { montar };
})();

/* Abre a página da nota fiscal. O link chega como nf.html#CODIGO:
   o trecho depois do # não vai para o servidor nem aparece em logs. */
(async function () {
  var el = document.getElementById('nf');
  var token = (location.hash || '').slice(1) || '';
  try {
    if (token) sessionStorage.setItem('klg-nf', token);
    else token = sessionStorage.getItem('klg-nf') || '';
    history.replaceState(null, '', location.pathname);
  } catch (e) { /* sem armazenamento */ }
  try { await API.init({ portal: true }); }
  catch (e) { el.textContent = 'Não foi possível carregar a página. Verifique sua conexão e recarregue.'; return; }
  NotaFiscal.montar(el, token.trim(), {
    api: API,
    aoConcluir: function () { try { sessionStorage.removeItem('klg-nf'); } catch (e) { /* sem armazenamento */ } }
  });
})();
